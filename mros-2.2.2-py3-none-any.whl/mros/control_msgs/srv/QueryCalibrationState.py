import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg

class QueryCalibrationStateRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(QueryCalibrationStateRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/QueryCalibrationState"

    def getMD5(self):
        return "28af3beedcb84986b8e470dc5470507d"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class QueryCalibrationStateResponse(mros.Message):
    __slots__ = ['__id__','is_calibrated']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(QueryCalibrationStateResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.is_calibrated is None:
                self.is_calibrated = False
        else:
            self.__id__ = 0
            self.is_calibrated = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_is_calibrated = struct.Struct("<B")
            buff.write(struct_is_calibrated.pack(self.is_calibrated))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_is_calibrated = struct.Struct("<B")
            (self.is_calibrated,) = struct_is_calibrated.unpack(buff[offset:(offset + 1)])
            self.is_calibrated = bool(self.is_calibrated)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"is_calibrated":%s' % self.is_calibrated
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/QueryCalibrationState"

    def getMD5(self):
        return "28af3beedcb84986b8e470dc5470507d"
    def getDef(self):
        return "bool is_calibrated\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class QueryCalibrationState(object):
    Request = QueryCalibrationStateRequest
    Response = QueryCalibrationStateResponse

    __slots__ = ['request','response']
    _slot_types = ['QueryCalibrationStateRequest','QueryCalibrationStateResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(QueryCalibrationState, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

