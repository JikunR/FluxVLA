import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg

class QueryTrajectoryStateRequest(mros.Message):
    __slots__ = ['__id__','time']
    _slot_types = ['uint32','Time']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(QueryTrajectoryStateRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.time is None:
                self.time = mros.Time()
        else:
            self.__id__ = 0
            self.time = mros.Time()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(_struct_I.pack(self.time.sec))
            offset += 4
            buff.write(_struct_I.pack(self.time.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.time.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.time.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"time.sec":%s,' % self.time.sec
        string_echo += '"time.nsec":%s' % self.time.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/QueryTrajectoryState"

    def getMD5(self):
        return "ec93cdecbd8062d761aa52b7c90cd44b"
    def getDef(self):
        return "time time\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class QueryTrajectoryStateResponse(mros.Message):
    __slots__ = ['__id__','name','position','velocity','acceleration']
    _slot_types = ['uint32','string[]','float64[]','float64[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(QueryTrajectoryStateResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.name is None:
                self.name = []
            if self.position is None:
                self.position = []
            if self.velocity is None:
                self.velocity = []
            if self.acceleration is None:
                self.acceleration = []
        else:
            self.__id__ = 0
            self.name = []
            self.position = []
            self.velocity = []
            self.acceleration = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            name_length = len(self.name)
            buff.write(struct.pack('<I', name_length))
            offset += 4
            for i in range(0, name_length):
                _x = self.name[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            position_length = len(self.position)
            buff.write(struct.pack('<I', position_length))
            buff.write(struct.pack(f'<{position_length}d', *self.position))
            offset += 4 + position_length * 8
            velocity_length = len(self.velocity)
            buff.write(struct.pack('<I', velocity_length))
            buff.write(struct.pack(f'<{velocity_length}d', *self.velocity))
            offset += 4 + velocity_length * 8
            acceleration_length = len(self.acceleration)
            buff.write(struct.pack('<I', acceleration_length))
            buff.write(struct.pack(f'<{acceleration_length}d', *self.acceleration))
            offset += 4 + acceleration_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (name_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.name) != name_length:
                self.name = ['' for _ in range(name_length)]
            for i in range(0, name_length):
                (length_namei,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.name[i] = buff[offset:(offset + length_namei)].decode('utf-8')
                else:
                    self.name[i] = buff[offset:(offset + length_namei)]
                offset += length_namei
            (position_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.position = np.frombuffer(buff[offset:offset + position_length * 8], dtype=np.float64)
            offset += position_length * 8
            (velocity_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.velocity = np.frombuffer(buff[offset:offset + velocity_length * 8], dtype=np.float64)
            offset += velocity_length * 8
            (acceleration_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.acceleration = np.frombuffer(buff[offset:offset + acceleration_length * 8], dtype=np.float64)
            offset += acceleration_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, name_length):
            namei_x = self.name[i]
            namei_length = len(namei_x)
            if python3 or type(namei_x) == unicode:
                namei_x = namei_x.encode('utf-8')
                namei_length = len(namei_x)
            length += 4
            length += namei_length
        length += 4
        length += len(self.position) * 8
        length += 4
        length += len(self.velocity) * 8
        length += 4
        length += len(self.acceleration) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"name":['
        name_length = len(self.name)
        for i in range(0, name_length):
            if i == (name_length - 1): 
                string_echo += '"name[i]":"%s"' % self.name[i]
                string_echo += ''
            else:
                string_echo += '"name[i]":"%s"' % self.name[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"position":['
        position_length = len(self.position)
        for i in range(0, position_length):
            if i == (position_length - 1): 
                string_echo += '%s' % self.position[i]
            else:
                string_echo += '%s,' % self.position[i]
        string_echo += '],'
        string_echo += '"velocity":['
        velocity_length = len(self.velocity)
        for i in range(0, velocity_length):
            if i == (velocity_length - 1): 
                string_echo += '%s' % self.velocity[i]
            else:
                string_echo += '%s,' % self.velocity[i]
        string_echo += '],'
        string_echo += '"acceleration":['
        acceleration_length = len(self.acceleration)
        for i in range(0, acceleration_length):
            if i == (acceleration_length - 1): 
                string_echo += '%s' % self.acceleration[i]
            else:
                string_echo += '%s,' % self.acceleration[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/QueryTrajectoryState"

    def getMD5(self):
        return "ec93cdecbd8062d761aa52b7c90cd44b"
    def getDef(self):
        return "string[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] acceleration\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class QueryTrajectoryState(object):
    Request = QueryTrajectoryStateRequest
    Response = QueryTrajectoryStateResponse

    __slots__ = ['request','response']
    _slot_types = ['QueryTrajectoryStateRequest','QueryTrajectoryStateResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(QueryTrajectoryState, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

