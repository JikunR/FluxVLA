import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg
import mros.std_msgs.msg

class JointJog(mros.Message):
    __slots__ = ['header','joint_names','displacements','velocities','duration']
    _slot_types = ['std_msgs/Header','string[]','float64[]','float64[]','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointJog, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.joint_names is None:
                self.joint_names = []
            if self.displacements is None:
                self.displacements = []
            if self.velocities is None:
                self.velocities = []
            if self.duration is None:
                self.duration = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.joint_names = []
            self.displacements = []
            self.velocities = []
            self.duration = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            joint_names_length = len(self.joint_names)
            buff.write(struct.pack('<I', joint_names_length))
            offset += 4
            for i in range(0, joint_names_length):
                _x = self.joint_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            displacements_length = len(self.displacements)
            buff.write(struct.pack('<I', displacements_length))
            buff.write(struct.pack(f'<{displacements_length}d', *self.displacements))
            offset += 4 + displacements_length * 8
            velocities_length = len(self.velocities)
            buff.write(struct.pack('<I', velocities_length))
            buff.write(struct.pack(f'<{velocities_length}d', *self.velocities))
            offset += 4 + velocities_length * 8
            struct_duration = struct.Struct("<d")
            buff.write(struct_duration.pack(self.duration))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (joint_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.joint_names) != joint_names_length:
                self.joint_names = ['' for _ in range(joint_names_length)]
            for i in range(0, joint_names_length):
                (length_joint_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)].decode('utf-8')
                else:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)]
                offset += length_joint_namesi
            (displacements_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.displacements = np.frombuffer(buff[offset:offset + displacements_length * 8], dtype=np.float64)
            offset += displacements_length * 8
            (velocities_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.velocities = np.frombuffer(buff[offset:offset + velocities_length * 8], dtype=np.float64)
            offset += velocities_length * 8
            struct_duration = struct.Struct("<d")
            (self.duration,) = struct_duration.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, joint_names_length):
            joint_namesi_x = self.joint_names[i]
            joint_namesi_length = len(joint_namesi_x)
            if python3 or type(joint_namesi_x) == unicode:
                joint_namesi_x = joint_namesi_x.encode('utf-8')
                joint_namesi_length = len(joint_namesi_x)
            length += 4
            length += joint_namesi_length
        length += 4
        length += len(self.displacements) * 8
        length += 4
        length += len(self.velocities) * 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"joint_names":['
        joint_names_length = len(self.joint_names)
        for i in range(0, joint_names_length):
            if i == (joint_names_length - 1): 
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ''
            else:
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"displacements":['
        displacements_length = len(self.displacements)
        for i in range(0, displacements_length):
            if i == (displacements_length - 1): 
                string_echo += '%s' % self.displacements[i]
            else:
                string_echo += '%s,' % self.displacements[i]
        string_echo += '],'
        string_echo += '"velocities":['
        velocities_length = len(self.velocities)
        for i in range(0, velocities_length):
            if i == (velocities_length - 1): 
                string_echo += '%s' % self.velocities[i]
            else:
                string_echo += '%s,' % self.velocities[i]
        string_echo += '],'
        string_echo += '"duration":%s' % self.duration
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/JointJog"

    def getMD5(self):
        return "1685da700c8c2e1254afc92a5fb89c96"

    def getDef(self):
        return "std_msgs/Header header\nstring[] joint_names\nfloat64[] displacements\nfloat64[] velocities\nfloat64 duration\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

