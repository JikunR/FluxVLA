import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg
import mros.std_msgs.msg

class JointControllerState(mros.Message):
    __slots__ = ['header','set_point','process_value','process_value_dot','error','time_step','command','p','i','d','i_clamp','antiwindup']
    _slot_types = ['std_msgs/Header','float64','float64','float64','float64','float64','float64','float64','float64','float64','float64','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointControllerState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.set_point is None:
                self.set_point = 0.
            if self.process_value is None:
                self.process_value = 0.
            if self.process_value_dot is None:
                self.process_value_dot = 0.
            if self.error is None:
                self.error = 0.
            if self.time_step is None:
                self.time_step = 0.
            if self.command is None:
                self.command = 0.
            if self.p is None:
                self.p = 0.
            if self.i is None:
                self.i = 0.
            if self.d is None:
                self.d = 0.
            if self.i_clamp is None:
                self.i_clamp = 0.
            if self.antiwindup is None:
                self.antiwindup = False
        else:
            self.header = mros.std_msgs.msg.Header()
            self.set_point = 0.
            self.process_value = 0.
            self.process_value_dot = 0.
            self.error = 0.
            self.time_step = 0.
            self.command = 0.
            self.p = 0.
            self.i = 0.
            self.d = 0.
            self.i_clamp = 0.
            self.antiwindup = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_set_point = struct.Struct("<d")
            buff.write(struct_set_point.pack(self.set_point))
            offset += 8
            struct_process_value = struct.Struct("<d")
            buff.write(struct_process_value.pack(self.process_value))
            offset += 8
            struct_process_value_dot = struct.Struct("<d")
            buff.write(struct_process_value_dot.pack(self.process_value_dot))
            offset += 8
            struct_error = struct.Struct("<d")
            buff.write(struct_error.pack(self.error))
            offset += 8
            struct_time_step = struct.Struct("<d")
            buff.write(struct_time_step.pack(self.time_step))
            offset += 8
            struct_command = struct.Struct("<d")
            buff.write(struct_command.pack(self.command))
            offset += 8
            struct_p = struct.Struct("<d")
            buff.write(struct_p.pack(self.p))
            offset += 8
            struct_i = struct.Struct("<d")
            buff.write(struct_i.pack(self.i))
            offset += 8
            struct_d = struct.Struct("<d")
            buff.write(struct_d.pack(self.d))
            offset += 8
            struct_i_clamp = struct.Struct("<d")
            buff.write(struct_i_clamp.pack(self.i_clamp))
            offset += 8
            struct_antiwindup = struct.Struct("<B")
            buff.write(struct_antiwindup.pack(self.antiwindup))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_set_point = struct.Struct("<d")
            (self.set_point,) = struct_set_point.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_process_value = struct.Struct("<d")
            (self.process_value,) = struct_process_value.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_process_value_dot = struct.Struct("<d")
            (self.process_value_dot,) = struct_process_value_dot.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_error = struct.Struct("<d")
            (self.error,) = struct_error.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_time_step = struct.Struct("<d")
            (self.time_step,) = struct_time_step.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_command = struct.Struct("<d")
            (self.command,) = struct_command.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_p = struct.Struct("<d")
            (self.p,) = struct_p.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i = struct.Struct("<d")
            (self.i,) = struct_i.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_d = struct.Struct("<d")
            (self.d,) = struct_d.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i_clamp = struct.Struct("<d")
            (self.i_clamp,) = struct_i_clamp.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_antiwindup = struct.Struct("<B")
            (self.antiwindup,) = struct_antiwindup.unpack(buff[offset:(offset + 1)])
            self.antiwindup = bool(self.antiwindup)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"set_point":%s' % self.set_point
        string_echo += ','
        string_echo += '"process_value":%s' % self.process_value
        string_echo += ','
        string_echo += '"process_value_dot":%s' % self.process_value_dot
        string_echo += ','
        string_echo += '"error":%s' % self.error
        string_echo += ','
        string_echo += '"time_step":%s' % self.time_step
        string_echo += ','
        string_echo += '"command":%s' % self.command
        string_echo += ','
        string_echo += '"p":%s' % self.p
        string_echo += ','
        string_echo += '"i":%s' % self.i
        string_echo += ','
        string_echo += '"d":%s' % self.d
        string_echo += ','
        string_echo += '"i_clamp":%s' % self.i_clamp
        string_echo += ','
        string_echo += '"antiwindup":%s' % self.antiwindup
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/JointControllerState"

    def getMD5(self):
        return "987ad85e4756f3aef7f1e5e7fe0595d1"

    def getDef(self):
        return "std_msgs/Header header\nfloat64 set_point\nfloat64 process_value\nfloat64 process_value_dot\nfloat64 error\nfloat64 time_step\nfloat64 command\nfloat64 p\nfloat64 i\nfloat64 d\nfloat64 i_clamp\nbool antiwindup\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

