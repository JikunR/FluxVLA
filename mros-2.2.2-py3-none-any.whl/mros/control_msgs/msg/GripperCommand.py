import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg

class GripperCommand(mros.Message):
    __slots__ = ['position','max_effort']
    _slot_types = ['float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GripperCommand, self).__init__(*args, **kwds)
            if self.position is None:
                self.position = 0.
            if self.max_effort is None:
                self.max_effort = 0.
        else:
            self.position = 0.
            self.max_effort = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_position = struct.Struct("<d")
            buff.write(struct_position.pack(self.position))
            offset += 8
            struct_max_effort = struct.Struct("<d")
            buff.write(struct_max_effort.pack(self.max_effort))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_position = struct.Struct("<d")
            (self.position,) = struct_position.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_max_effort = struct.Struct("<d")
            (self.max_effort,) = struct_max_effort.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"position":%s' % self.position
        string_echo += ','
        string_echo += '"max_effort":%s' % self.max_effort
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/GripperCommand"

    def getMD5(self):
        return "680acaff79486f017132a7f198d40f08"

    def getDef(self):
        return "float64 position\nfloat64 max_effort\n"

_struct_I = struct.Struct('<I')

