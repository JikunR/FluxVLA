import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg
import mros.std_msgs.msg
import mros.trajectory_msgs.msg

class JointTrajectoryControllerState(mros.Message):
    __slots__ = ['header','joint_names','desired','actual','error']
    _slot_types = ['std_msgs/Header','string[]','trajectory_msgs/JointTrajectoryPoint','trajectory_msgs/JointTrajectoryPoint','trajectory_msgs/JointTrajectoryPoint']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointTrajectoryControllerState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.joint_names is None:
                self.joint_names = []
            if self.desired is None:
                self.desired = mros.trajectory_msgs.msg.JointTrajectoryPoint()
            if self.actual is None:
                self.actual = mros.trajectory_msgs.msg.JointTrajectoryPoint()
            if self.error is None:
                self.error = mros.trajectory_msgs.msg.JointTrajectoryPoint()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.joint_names = []
            self.desired = mros.trajectory_msgs.msg.JointTrajectoryPoint()
            self.actual = mros.trajectory_msgs.msg.JointTrajectoryPoint()
            self.error = mros.trajectory_msgs.msg.JointTrajectoryPoint()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            joint_names_length = len(self.joint_names)
            buff.write(struct.pack('<I', joint_names_length))
            offset += 4
            for i in range(0, joint_names_length):
                _x = self.joint_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            offset += self.desired.serialize(buff)
            offset += self.actual.serialize(buff)
            offset += self.error.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (joint_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.joint_names) != joint_names_length:
                self.joint_names = ['' for _ in range(joint_names_length)]
            for i in range(0, joint_names_length):
                (length_joint_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)].decode('utf-8')
                else:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)]
                offset += length_joint_namesi
            offset += self.desired.deserialize(buff[offset:])
            offset += self.actual.deserialize(buff[offset:])
            offset += self.error.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, joint_names_length):
            joint_namesi_x = self.joint_names[i]
            joint_namesi_length = len(joint_namesi_x)
            if python3 or type(joint_namesi_x) == unicode:
                joint_namesi_x = joint_namesi_x.encode('utf-8')
                joint_namesi_length = len(joint_namesi_x)
            length += 4
            length += joint_namesi_length
        length += self.desired.serializedLength()
        length += self.actual.serializedLength()
        length += self.error.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"joint_names":['
        joint_names_length = len(self.joint_names)
        for i in range(0, joint_names_length):
            if i == (joint_names_length - 1): 
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ''
            else:
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"desired":'
        string_echo += self.desired.echo()
        string_echo += ','
        string_echo += '"actual":'
        string_echo += self.actual.echo()
        string_echo += ','
        string_echo += '"error":'
        string_echo += self.error.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/JointTrajectoryControllerState"

    def getMD5(self):
        return "10817c60c2486ef6b33e97dcd87f4474"

    def getDef(self):
        return "std_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint desired\ntrajectory_msgs/JointTrajectoryPoint actual\ntrajectory_msgs/JointTrajectoryPoint error\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n"

_struct_I = struct.Struct('<I')

