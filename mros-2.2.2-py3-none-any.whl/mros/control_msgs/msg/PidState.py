import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg
import mros.std_msgs.msg

class PidState(mros.Message):
    __slots__ = ['header','timestep','error','error_dot','p_error','i_error','d_error','p_term','i_term','d_term','i_max','i_min','output']
    _slot_types = ['std_msgs/Header','Duration','float64','float64','float64','float64','float64','float64','float64','float64','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PidState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.timestep is None:
                self.timestep = mros.Duration()
            if self.error is None:
                self.error = 0.
            if self.error_dot is None:
                self.error_dot = 0.
            if self.p_error is None:
                self.p_error = 0.
            if self.i_error is None:
                self.i_error = 0.
            if self.d_error is None:
                self.d_error = 0.
            if self.p_term is None:
                self.p_term = 0.
            if self.i_term is None:
                self.i_term = 0.
            if self.d_term is None:
                self.d_term = 0.
            if self.i_max is None:
                self.i_max = 0.
            if self.i_min is None:
                self.i_min = 0.
            if self.output is None:
                self.output = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.timestep = mros.Duration()
            self.error = 0.
            self.error_dot = 0.
            self.p_error = 0.
            self.i_error = 0.
            self.d_error = 0.
            self.p_term = 0.
            self.i_term = 0.
            self.d_term = 0.
            self.i_max = 0.
            self.i_min = 0.
            self.output = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(_struct_I.pack(self.timestep.sec))
            offset += 4
            buff.write(_struct_I.pack(self.timestep.nsec))
            offset += 4
            struct_error = struct.Struct("<d")
            buff.write(struct_error.pack(self.error))
            offset += 8
            struct_error_dot = struct.Struct("<d")
            buff.write(struct_error_dot.pack(self.error_dot))
            offset += 8
            struct_p_error = struct.Struct("<d")
            buff.write(struct_p_error.pack(self.p_error))
            offset += 8
            struct_i_error = struct.Struct("<d")
            buff.write(struct_i_error.pack(self.i_error))
            offset += 8
            struct_d_error = struct.Struct("<d")
            buff.write(struct_d_error.pack(self.d_error))
            offset += 8
            struct_p_term = struct.Struct("<d")
            buff.write(struct_p_term.pack(self.p_term))
            offset += 8
            struct_i_term = struct.Struct("<d")
            buff.write(struct_i_term.pack(self.i_term))
            offset += 8
            struct_d_term = struct.Struct("<d")
            buff.write(struct_d_term.pack(self.d_term))
            offset += 8
            struct_i_max = struct.Struct("<d")
            buff.write(struct_i_max.pack(self.i_max))
            offset += 8
            struct_i_min = struct.Struct("<d")
            buff.write(struct_i_min.pack(self.i_min))
            offset += 8
            struct_output = struct.Struct("<d")
            buff.write(struct_output.pack(self.output))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (self.timestep.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.timestep.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_error = struct.Struct("<d")
            (self.error,) = struct_error.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_error_dot = struct.Struct("<d")
            (self.error_dot,) = struct_error_dot.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_p_error = struct.Struct("<d")
            (self.p_error,) = struct_p_error.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i_error = struct.Struct("<d")
            (self.i_error,) = struct_i_error.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_d_error = struct.Struct("<d")
            (self.d_error,) = struct_d_error.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_p_term = struct.Struct("<d")
            (self.p_term,) = struct_p_term.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i_term = struct.Struct("<d")
            (self.i_term,) = struct_i_term.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_d_term = struct.Struct("<d")
            (self.d_term,) = struct_d_term.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i_max = struct.Struct("<d")
            (self.i_max,) = struct_i_max.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i_min = struct.Struct("<d")
            (self.i_min,) = struct_i_min.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_output = struct.Struct("<d")
            (self.output,) = struct_output.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += 4
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"timestep.sec":%s,' % self.timestep.sec
        string_echo += '"timestep.nsec":%s' % self.timestep.nsec
        string_echo += ','
        string_echo += '"error":%s' % self.error
        string_echo += ','
        string_echo += '"error_dot":%s' % self.error_dot
        string_echo += ','
        string_echo += '"p_error":%s' % self.p_error
        string_echo += ','
        string_echo += '"i_error":%s' % self.i_error
        string_echo += ','
        string_echo += '"d_error":%s' % self.d_error
        string_echo += ','
        string_echo += '"p_term":%s' % self.p_term
        string_echo += ','
        string_echo += '"i_term":%s' % self.i_term
        string_echo += ','
        string_echo += '"d_term":%s' % self.d_term
        string_echo += ','
        string_echo += '"i_max":%s' % self.i_max
        string_echo += ','
        string_echo += '"i_min":%s' % self.i_min
        string_echo += ','
        string_echo += '"output":%s' % self.output
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/PidState"

    def getMD5(self):
        return "b138ec00e886c10e73f27e8712252ea6"

    def getDef(self):
        return "std_msgs/Header header\nduration timestep\nfloat64 error\nfloat64 error_dot\nfloat64 p_error\nfloat64 i_error\nfloat64 d_error\nfloat64 p_term\nfloat64 i_term\nfloat64 d_term\nfloat64 i_max\nfloat64 i_min\nfloat64 output\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

