import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_msgs.msg

class JointTolerance(mros.Message):
    __slots__ = ['name','position','velocity','acceleration']
    _slot_types = ['string','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointTolerance, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.position is None:
                self.position = 0.
            if self.velocity is None:
                self.velocity = 0.
            if self.acceleration is None:
                self.acceleration = 0.
        else:
            self.name = ''
            self.position = 0.
            self.velocity = 0.
            self.acceleration = 0.

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_position = struct.Struct("<d")
            buff.write(struct_position.pack(self.position))
            offset += 8
            struct_velocity = struct.Struct("<d")
            buff.write(struct_velocity.pack(self.velocity))
            offset += 8
            struct_acceleration = struct.Struct("<d")
            buff.write(struct_acceleration.pack(self.acceleration))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            struct_position = struct.Struct("<d")
            (self.position,) = struct_position.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_velocity = struct.Struct("<d")
            (self.velocity,) = struct_velocity.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_acceleration = struct.Struct("<d")
            (self.acceleration,) = struct_acceleration.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"position":%s' % self.position
        string_echo += ','
        string_echo += '"velocity":%s' % self.velocity
        string_echo += ','
        string_echo += '"acceleration":%s' % self.acceleration
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_msgs/JointTolerance"

    def getMD5(self):
        return "f544fe9c16cf04547e135dd6063ff5be"

    def getDef(self):
        return "string name\nfloat64 position\nfloat64 velocity\nfloat64 acceleration\n"

_struct_I = struct.Struct('<I')

