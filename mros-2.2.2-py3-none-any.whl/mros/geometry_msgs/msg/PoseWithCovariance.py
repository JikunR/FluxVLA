import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class PoseWithCovariance(mros.Message):
    __slots__ = ['pose','covariance']
    _slot_types = ['geometry_msgs/Pose','float64[36]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PoseWithCovariance, self).__init__(*args, **kwds)
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
            if self.covariance is None:
                self.covariance = [0. for x in range(0, 36)]
        else:
            self.pose = mros.geometry_msgs.msg.Pose()
            self.covariance = [0. for x in range(0, 36)]

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.pose.serialize(buff)
            buff.write(struct.pack(f'<{36}d', *self.covariance))
            offset += 36 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.pose.deserialize(buff[offset:])
            self.covariance = np.frombuffer(buff[offset:offset + 36 * 8], dtype=np.float64)
            offset += 36 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.pose.serializedLength()
        length += 36 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ','
        string_echo += '"covariance":['
        for i in range(0, 36):
            if i == (36 - 1): 
                string_echo += '%s' % self.covariance[i]
            else:
                string_echo += '%s,' % self.covariance[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/PoseWithCovariance"

    def getMD5(self):
        return "c23e848cf1b7533a8d7c259073a97e6f"

    def getDef(self):
        return "geometry_msgs/Pose pose\nfloat64[36] covariance\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

