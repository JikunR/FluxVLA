import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Pose(mros.Message):
    __slots__ = ['position','orientation']
    _slot_types = ['geometry_msgs/Point','geometry_msgs/Quaternion']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Pose, self).__init__(*args, **kwds)
            if self.position is None:
                self.position = mros.geometry_msgs.msg.Point()
            if self.orientation is None:
                self.orientation = mros.geometry_msgs.msg.Quaternion()
        else:
            self.position = mros.geometry_msgs.msg.Point()
            self.orientation = mros.geometry_msgs.msg.Quaternion()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.position.serialize(buff)
            offset += self.orientation.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.position.deserialize(buff[offset:])
            offset += self.orientation.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.position.serializedLength()
        length += self.orientation.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"position":'
        string_echo += self.position.echo()
        string_echo += ','
        string_echo += '"orientation":'
        string_echo += self.orientation.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Pose"

    def getMD5(self):
        return "e45d45a5a1ce597b249e23fb30fc871f"

    def getDef(self):
        return "geometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

