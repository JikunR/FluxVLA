import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Polygon(mros.Message):
    __slots__ = ['points']
    _slot_types = ['geometry_msgs/Point32[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Polygon, self).__init__(*args, **kwds)
            if self.points is None:
                self.points = []
        else:
            self.points = []

    def serialize(self, buff):
        offset = 0
        try:
            points_length = len(self.points)
            buff.write(struct.pack('<I', points_length))
            offset += 4
            for i in range(0, points_length):
                offset += self.points[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (points_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.points) != points_length:
                self.points = [mros.geometry_msgs.msg.Point32() for _ in range(points_length)]
            for i in range(0, points_length):
                offset += self.points[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, points_length):
            length += self.points[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"points":['
        points_length = len(self.points)
        for i in range(0, points_length):
            if i == (points_length - 1): 
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ''
            else:
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Polygon"

    def getMD5(self):
        return "cd60a26494a087f577976f0329fa120e"

    def getDef(self):
        return "geometry_msgs/Point32[] points\n================================================================================\nMSG: geometry_msgs/Point32\nfloat32 x\nfloat32 y\nfloat32 z\n"

_struct_I = struct.Struct('<I')

