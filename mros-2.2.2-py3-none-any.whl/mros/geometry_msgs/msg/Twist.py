import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Twist(mros.Message):
    __slots__ = ['linear','angular']
    _slot_types = ['geometry_msgs/Vector3','geometry_msgs/Vector3']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Twist, self).__init__(*args, **kwds)
            if self.linear is None:
                self.linear = mros.geometry_msgs.msg.Vector3()
            if self.angular is None:
                self.angular = mros.geometry_msgs.msg.Vector3()
        else:
            self.linear = mros.geometry_msgs.msg.Vector3()
            self.angular = mros.geometry_msgs.msg.Vector3()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.linear.serialize(buff)
            offset += self.angular.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.linear.deserialize(buff[offset:])
            offset += self.angular.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.linear.serializedLength()
        length += self.angular.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"linear":'
        string_echo += self.linear.echo()
        string_echo += ','
        string_echo += '"angular":'
        string_echo += self.angular.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Twist"

    def getMD5(self):
        return "9f195f881246fdfa2798d1d3eebca84a"

    def getDef(self):
        return "geometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

