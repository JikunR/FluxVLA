import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Pose2D(mros.Message):
    __slots__ = ['x','y','theta']
    _slot_types = ['float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Pose2D, self).__init__(*args, **kwds)
            if self.x is None:
                self.x = 0.
            if self.y is None:
                self.y = 0.
            if self.theta is None:
                self.theta = 0.
        else:
            self.x = 0.
            self.y = 0.
            self.theta = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_x = struct.Struct("<d")
            buff.write(struct_x.pack(self.x))
            offset += 8
            struct_y = struct.Struct("<d")
            buff.write(struct_y.pack(self.y))
            offset += 8
            struct_theta = struct.Struct("<d")
            buff.write(struct_theta.pack(self.theta))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_x = struct.Struct("<d")
            (self.x,) = struct_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_y = struct.Struct("<d")
            (self.y,) = struct_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_theta = struct.Struct("<d")
            (self.theta,) = struct_theta.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"x":%s' % self.x
        string_echo += ','
        string_echo += '"y":%s' % self.y
        string_echo += ','
        string_echo += '"theta":%s' % self.theta
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Pose2D"

    def getMD5(self):
        return "938fa65709584ad8e77d238529be13b8"

    def getDef(self):
        return "float64 x\nfloat64 y\nfloat64 theta\n"

_struct_I = struct.Struct('<I')

