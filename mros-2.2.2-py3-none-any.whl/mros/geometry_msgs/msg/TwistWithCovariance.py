import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class TwistWithCovariance(mros.Message):
    __slots__ = ['twist','covariance']
    _slot_types = ['geometry_msgs/Twist','float64[36]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TwistWithCovariance, self).__init__(*args, **kwds)
            if self.twist is None:
                self.twist = mros.geometry_msgs.msg.Twist()
            if self.covariance is None:
                self.covariance = [0. for x in range(0, 36)]
        else:
            self.twist = mros.geometry_msgs.msg.Twist()
            self.covariance = [0. for x in range(0, 36)]

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.twist.serialize(buff)
            buff.write(struct.pack(f'<{36}d', *self.covariance))
            offset += 36 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.twist.deserialize(buff[offset:])
            self.covariance = np.frombuffer(buff[offset:offset + 36 * 8], dtype=np.float64)
            offset += 36 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.twist.serializedLength()
        length += 36 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"twist":'
        string_echo += self.twist.echo()
        string_echo += ','
        string_echo += '"covariance":['
        for i in range(0, 36):
            if i == (36 - 1): 
                string_echo += '%s' % self.covariance[i]
            else:
                string_echo += '%s,' % self.covariance[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/TwistWithCovariance"

    def getMD5(self):
        return "1fe8a28e6890a4cc3ae4c3ca5c7d82e6"

    def getDef(self):
        return "geometry_msgs/Twist twist\nfloat64[36] covariance\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

