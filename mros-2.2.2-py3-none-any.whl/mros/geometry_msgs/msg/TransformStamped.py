import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.std_msgs.msg

class TransformStamped(mros.Message):
    __slots__ = ['header','child_frame_id','transform']
    _slot_types = ['std_msgs/Header','string','geometry_msgs/Transform']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TransformStamped, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.child_frame_id is None:
                self.child_frame_id = ''
            if self.transform is None:
                self.transform = mros.geometry_msgs.msg.Transform()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.child_frame_id = ''
            self.transform = mros.geometry_msgs.msg.Transform()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            _x = self.child_frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.transform.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (length_child_frame_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.child_frame_id = buff[offset:(offset + length_child_frame_id)].decode('utf-8')
            else:
                self.child_frame_id = buff[offset:(offset + length_child_frame_id)]
            offset += length_child_frame_id
            offset += self.transform.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        child_frame_id_x = self.child_frame_id
        child_frame_id_length = len(child_frame_id_x)
        if python3 or type(child_frame_id_x) == unicode:
            child_frame_id_x = child_frame_id_x.encode('utf-8')
            child_frame_id_length = len(child_frame_id_x)
        length += 4
        length += child_frame_id_length
        length += self.transform.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"child_frame_id":"%s"' % self.child_frame_id
        string_echo += ','
        string_echo += '"transform":'
        string_echo += self.transform.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/TransformStamped"

    def getMD5(self):
        return "b5764a33bfeb3588febc2682852579b0"

    def getDef(self):
        return "std_msgs/Header header\nstring child_frame_id\ngeometry_msgs/Transform transform\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

