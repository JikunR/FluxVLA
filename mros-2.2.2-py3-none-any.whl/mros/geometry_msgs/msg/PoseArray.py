import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.std_msgs.msg

class PoseArray(mros.Message):
    __slots__ = ['header','poses']
    _slot_types = ['std_msgs/Header','geometry_msgs/Pose[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PoseArray, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.poses is None:
                self.poses = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.poses = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            poses_length = len(self.poses)
            buff.write(struct.pack('<I', poses_length))
            offset += 4
            for i in range(0, poses_length):
                offset += self.poses[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (poses_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.poses) != poses_length:
                self.poses = [mros.geometry_msgs.msg.Pose() for _ in range(poses_length)]
            for i in range(0, poses_length):
                offset += self.poses[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, poses_length):
            length += self.poses[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"poses":['
        poses_length = len(self.poses)
        for i in range(0, poses_length):
            if i == (poses_length - 1): 
                string_echo += '{poses%s":' % i
                string_echo += self.poses[i].echo()
                string_echo += ''
            else:
                string_echo += '{poses%s":' % i
                string_echo += self.poses[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/PoseArray"

    def getMD5(self):
        return "916c28c5764443f268b296bb671b9d97"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Pose[] poses\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

