import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Inertia(mros.Message):
    __slots__ = ['m','com','ixx','ixy','ixz','iyy','iyz','izz']
    _slot_types = ['float64','geometry_msgs/Vector3','float64','float64','float64','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Inertia, self).__init__(*args, **kwds)
            if self.m is None:
                self.m = 0.
            if self.com is None:
                self.com = mros.geometry_msgs.msg.Vector3()
            if self.ixx is None:
                self.ixx = 0.
            if self.ixy is None:
                self.ixy = 0.
            if self.ixz is None:
                self.ixz = 0.
            if self.iyy is None:
                self.iyy = 0.
            if self.iyz is None:
                self.iyz = 0.
            if self.izz is None:
                self.izz = 0.
        else:
            self.m = 0.
            self.com = mros.geometry_msgs.msg.Vector3()
            self.ixx = 0.
            self.ixy = 0.
            self.ixz = 0.
            self.iyy = 0.
            self.iyz = 0.
            self.izz = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_m = struct.Struct("<d")
            buff.write(struct_m.pack(self.m))
            offset += 8
            offset += self.com.serialize(buff)
            struct_ixx = struct.Struct("<d")
            buff.write(struct_ixx.pack(self.ixx))
            offset += 8
            struct_ixy = struct.Struct("<d")
            buff.write(struct_ixy.pack(self.ixy))
            offset += 8
            struct_ixz = struct.Struct("<d")
            buff.write(struct_ixz.pack(self.ixz))
            offset += 8
            struct_iyy = struct.Struct("<d")
            buff.write(struct_iyy.pack(self.iyy))
            offset += 8
            struct_iyz = struct.Struct("<d")
            buff.write(struct_iyz.pack(self.iyz))
            offset += 8
            struct_izz = struct.Struct("<d")
            buff.write(struct_izz.pack(self.izz))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_m = struct.Struct("<d")
            (self.m,) = struct_m.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.com.deserialize(buff[offset:])
            struct_ixx = struct.Struct("<d")
            (self.ixx,) = struct_ixx.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_ixy = struct.Struct("<d")
            (self.ixy,) = struct_ixy.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_ixz = struct.Struct("<d")
            (self.ixz,) = struct_ixz.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_iyy = struct.Struct("<d")
            (self.iyy,) = struct_iyy.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_iyz = struct.Struct("<d")
            (self.iyz,) = struct_iyz.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_izz = struct.Struct("<d")
            (self.izz,) = struct_izz.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += self.com.serializedLength()
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"m":%s' % self.m
        string_echo += ','
        string_echo += '"com":'
        string_echo += self.com.echo()
        string_echo += ','
        string_echo += '"ixx":%s' % self.ixx
        string_echo += ','
        string_echo += '"ixy":%s' % self.ixy
        string_echo += ','
        string_echo += '"ixz":%s' % self.ixz
        string_echo += ','
        string_echo += '"iyy":%s' % self.iyy
        string_echo += ','
        string_echo += '"iyz":%s' % self.iyz
        string_echo += ','
        string_echo += '"izz":%s' % self.izz
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Inertia"

    def getMD5(self):
        return "1d26e4bb6c83ff141c5cf0d883c2b0fe"

    def getDef(self):
        return "float64 m\ngeometry_msgs/Vector3 com\nfloat64 ixx\nfloat64 ixy\nfloat64 ixz\nfloat64 iyy\nfloat64 iyz\nfloat64 izz\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

