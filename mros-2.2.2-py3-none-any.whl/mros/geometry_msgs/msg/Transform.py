import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Transform(mros.Message):
    __slots__ = ['translation','rotation']
    _slot_types = ['geometry_msgs/Vector3','geometry_msgs/Quaternion']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Transform, self).__init__(*args, **kwds)
            if self.translation is None:
                self.translation = mros.geometry_msgs.msg.Vector3()
            if self.rotation is None:
                self.rotation = mros.geometry_msgs.msg.Quaternion()
        else:
            self.translation = mros.geometry_msgs.msg.Vector3()
            self.rotation = mros.geometry_msgs.msg.Quaternion()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.translation.serialize(buff)
            offset += self.rotation.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.translation.deserialize(buff[offset:])
            offset += self.rotation.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.translation.serializedLength()
        length += self.rotation.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"translation":'
        string_echo += self.translation.echo()
        string_echo += ','
        string_echo += '"rotation":'
        string_echo += self.rotation.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Transform"

    def getMD5(self):
        return "ac9eff44abf714214112b05d54a3cf9b"

    def getDef(self):
        return "geometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

