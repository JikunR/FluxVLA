import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Wrench(mros.Message):
    __slots__ = ['force','torque']
    _slot_types = ['geometry_msgs/Vector3','geometry_msgs/Vector3']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Wrench, self).__init__(*args, **kwds)
            if self.force is None:
                self.force = mros.geometry_msgs.msg.Vector3()
            if self.torque is None:
                self.torque = mros.geometry_msgs.msg.Vector3()
        else:
            self.force = mros.geometry_msgs.msg.Vector3()
            self.torque = mros.geometry_msgs.msg.Vector3()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.force.serialize(buff)
            offset += self.torque.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.force.deserialize(buff[offset:])
            offset += self.torque.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.force.serializedLength()
        length += self.torque.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"force":'
        string_echo += self.force.echo()
        string_echo += ','
        string_echo += '"torque":'
        string_echo += self.torque.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Wrench"

    def getMD5(self):
        return "4f539cf138b23283b520fd271b567936"

    def getDef(self):
        return "geometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

