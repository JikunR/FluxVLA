import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg

class Quaternion(mros.Message):
    __slots__ = ['x','y','z','w']
    _slot_types = ['float64','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Quaternion, self).__init__(*args, **kwds)
            if self.x is None:
                self.x = 0.
            if self.y is None:
                self.y = 0.
            if self.z is None:
                self.z = 0.
            if self.w is None:
                self.w = 0.
        else:
            self.x = 0.
            self.y = 0.
            self.z = 0.
            self.w = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_x = struct.Struct("<d")
            buff.write(struct_x.pack(self.x))
            offset += 8
            struct_y = struct.Struct("<d")
            buff.write(struct_y.pack(self.y))
            offset += 8
            struct_z = struct.Struct("<d")
            buff.write(struct_z.pack(self.z))
            offset += 8
            struct_w = struct.Struct("<d")
            buff.write(struct_w.pack(self.w))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_x = struct.Struct("<d")
            (self.x,) = struct_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_y = struct.Struct("<d")
            (self.y,) = struct_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_z = struct.Struct("<d")
            (self.z,) = struct_z.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_w = struct.Struct("<d")
            (self.w,) = struct_w.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"x":%s' % self.x
        string_echo += ','
        string_echo += '"y":%s' % self.y
        string_echo += ','
        string_echo += '"z":%s' % self.z
        string_echo += ','
        string_echo += '"w":%s' % self.w
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/Quaternion"

    def getMD5(self):
        return "a779879fadf0160734f906b8c19c7004"

    def getDef(self):
        return "float64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

