import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.std_msgs.msg

class PolygonStamped(mros.Message):
    __slots__ = ['header','polygon']
    _slot_types = ['std_msgs/Header','geometry_msgs/Polygon']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PolygonStamped, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.polygon is None:
                self.polygon = mros.geometry_msgs.msg.Polygon()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.polygon = mros.geometry_msgs.msg.Polygon()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.polygon.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.polygon.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.polygon.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"polygon":'
        string_echo += self.polygon.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "geometry_msgs/PolygonStamped"

    def getMD5(self):
        return "c6be8f7dc3bee7fe9e8d296070f53340"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Polygon polygon\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Polygon\ngeometry_msgs/Point32[] points\n================================================================================\nMSG: geometry_msgs/Point32\nfloat32 x\nfloat32 y\nfloat32 z\n"

_struct_I = struct.Struct('<I')

