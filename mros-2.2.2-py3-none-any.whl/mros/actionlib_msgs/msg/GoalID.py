import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib_msgs.msg

class GoalID(mros.Message):
    __slots__ = ['stamp','id']
    _slot_types = ['Time','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GoalID, self).__init__(*args, **kwds)
            if self.stamp is None:
                self.stamp = mros.Time()
            if self.id is None:
                self.id = ''
        else:
            self.stamp = mros.Time()
            self.id = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.stamp.sec))
            offset += 4
            buff.write(_struct_I.pack(self.stamp.nsec))
            offset += 4
            _x = self.id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.stamp.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.stamp.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.id = buff[offset:(offset + length_id)].decode('utf-8')
            else:
                self.id = buff[offset:(offset + length_id)]
            offset += length_id
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        id_x = self.id
        id_length = len(id_x)
        if python3 or type(id_x) == unicode:
            id_x = id_x.encode('utf-8')
            id_length = len(id_x)
        length += 4
        length += id_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"stamp.sec":%s,' % self.stamp.sec
        string_echo += '"stamp.nsec":%s' % self.stamp.nsec
        string_echo += ','
        string_echo += '"id":"%s"' % self.id
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib_msgs/GoalID"

    def getMD5(self):
        return "302881f31927c1df708a2dbab0e80ee8"

    def getDef(self):
        return "time stamp\nstring id\n"

_struct_I = struct.Struct('<I')

