import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib_msgs.msg

class GoalStatus(mros.Message):
    __slots__ = ['goal_id','status','text']
    _slot_types = ['actionlib_msgs/GoalID','uint8','string']

    PENDING =  0   
    ACTIVE =  1   
    PREEMPTED =  2   
    SUCCEEDED =  3   
    ABORTED =  4   
    REJECTED =  5   
    PREEMPTING =  6   
    RECALLING =  7   
    RECALLED =  8   
    LOST =  9   

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GoalStatus, self).__init__(*args, **kwds)
            if self.goal_id is None:
                self.goal_id = mros.actionlib_msgs.msg.GoalID()
            if self.status is None:
                self.status = 0
            if self.text is None:
                self.text = ''
        else:
            self.goal_id = mros.actionlib_msgs.msg.GoalID()
            self.status = 0
            self.text = ''

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.goal_id.serialize(buff)
            struct_status = struct.Struct("<B")
            buff.write(struct_status.pack(self.status))
            offset += 1
            _x = self.text
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.goal_id.deserialize(buff[offset:])
            struct_status = struct.Struct("<B")
            (self.status,) = struct_status.unpack(buff[offset:(offset + 1)])
            offset += 1
            (length_text,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.text = buff[offset:(offset + length_text)].decode('utf-8')
            else:
                self.text = buff[offset:(offset + length_text)]
            offset += length_text
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.goal_id.serializedLength()
        length += 1
        text_x = self.text
        text_length = len(text_x)
        if python3 or type(text_x) == unicode:
            text_x = text_x.encode('utf-8')
            text_length = len(text_x)
        length += 4
        length += text_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"goal_id":'
        string_echo += self.goal_id.echo()
        string_echo += ','
        string_echo += '"status":%s' % self.status
        string_echo += ','
        string_echo += '"text":"%s"' % self.text
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib_msgs/GoalStatus"

    def getMD5(self):
        return "d388f9b87b3c471f784434d671988d4a"

    def getDef(self):
        return "actionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n"

_struct_I = struct.Struct('<I')

