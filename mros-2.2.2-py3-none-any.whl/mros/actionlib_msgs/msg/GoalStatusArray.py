import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib_msgs.msg
import mros.std_msgs.msg

class GoalStatusArray(mros.Message):
    __slots__ = ['header','status_list']
    _slot_types = ['std_msgs/Header','actionlib_msgs/GoalStatus[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GoalStatusArray, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.status_list is None:
                self.status_list = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.status_list = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            status_list_length = len(self.status_list)
            buff.write(struct.pack('<I', status_list_length))
            offset += 4
            for i in range(0, status_list_length):
                offset += self.status_list[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (status_list_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.status_list) != status_list_length:
                self.status_list = [mros.actionlib_msgs.msg.GoalStatus() for _ in range(status_list_length)]
            for i in range(0, status_list_length):
                offset += self.status_list[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, status_list_length):
            length += self.status_list[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"status_list":['
        status_list_length = len(self.status_list)
        for i in range(0, status_list_length):
            if i == (status_list_length - 1): 
                string_echo += '{status_list%s":' % i
                string_echo += self.status_list[i].echo()
                string_echo += ''
            else:
                string_echo += '{status_list%s":' % i
                string_echo += self.status_list[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib_msgs/GoalStatusArray"

    def getMD5(self):
        return "8b2b82f13216d0a8ea88bd3af735e619"

    def getDef(self):
        return "std_msgs/Header header\nactionlib_msgs/GoalStatus[] status_list\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalStatus\nactionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n"

_struct_I = struct.Struct('<I')

