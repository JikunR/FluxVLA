import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.joint_extended_msgs.msg
import mros.std_msgs.msg

class JointSafetyLimits(mros.Message):
    __slots__ = ['header','names','min_position','max_position','max_velocity','max_torque','na']
    _slot_types = ['std_msgs/Header','string[]','float32[]','float32[]','float32[]','float32[]','uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointSafetyLimits, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.names is None:
                self.names = []
            if self.min_position is None:
                self.min_position = []
            if self.max_position is None:
                self.max_position = []
            if self.max_velocity is None:
                self.max_velocity = []
            if self.max_torque is None:
                self.max_torque = []
            if self.na is None:
                self.na = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.names = []
            self.min_position = []
            self.max_position = []
            self.max_velocity = []
            self.max_torque = []
            self.na = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            names_length = len(self.names)
            buff.write(struct.pack('<I', names_length))
            offset += 4
            for i in range(0, names_length):
                _x = self.names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            min_position_length = len(self.min_position)
            buff.write(struct.pack('<I', min_position_length))
            buff.write(struct.pack(f'<{min_position_length}f', *self.min_position))
            offset += 4 + min_position_length * 4
            max_position_length = len(self.max_position)
            buff.write(struct.pack('<I', max_position_length))
            buff.write(struct.pack(f'<{max_position_length}f', *self.max_position))
            offset += 4 + max_position_length * 4
            max_velocity_length = len(self.max_velocity)
            buff.write(struct.pack('<I', max_velocity_length))
            buff.write(struct.pack(f'<{max_velocity_length}f', *self.max_velocity))
            offset += 4 + max_velocity_length * 4
            max_torque_length = len(self.max_torque)
            buff.write(struct.pack('<I', max_torque_length))
            buff.write(struct.pack(f'<{max_torque_length}f', *self.max_torque))
            offset += 4 + max_torque_length * 4
            buff.write(_struct_I.pack(self.na))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.names) != names_length:
                self.names = ['' for _ in range(names_length)]
            for i in range(0, names_length):
                (length_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.names[i] = buff[offset:(offset + length_namesi)].decode('utf-8')
                else:
                    self.names[i] = buff[offset:(offset + length_namesi)]
                offset += length_namesi
            (min_position_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.min_position = np.frombuffer(buff[offset:offset + min_position_length * 4], dtype=np.float32)
            offset += min_position_length * 4
            (max_position_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.max_position = np.frombuffer(buff[offset:offset + max_position_length * 4], dtype=np.float32)
            offset += max_position_length * 4
            (max_velocity_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.max_velocity = np.frombuffer(buff[offset:offset + max_velocity_length * 4], dtype=np.float32)
            offset += max_velocity_length * 4
            (max_torque_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.max_torque = np.frombuffer(buff[offset:offset + max_torque_length * 4], dtype=np.float32)
            offset += max_torque_length * 4
            (self.na,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, names_length):
            namesi_x = self.names[i]
            namesi_length = len(namesi_x)
            if python3 or type(namesi_x) == unicode:
                namesi_x = namesi_x.encode('utf-8')
                namesi_length = len(namesi_x)
            length += 4
            length += namesi_length
        length += 4
        length += len(self.min_position) * 4
        length += 4
        length += len(self.max_position) * 4
        length += 4
        length += len(self.max_velocity) * 4
        length += 4
        length += len(self.max_torque) * 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"names":['
        names_length = len(self.names)
        for i in range(0, names_length):
            if i == (names_length - 1): 
                string_echo += '"names[i]":"%s"' % self.names[i]
                string_echo += ''
            else:
                string_echo += '"names[i]":"%s"' % self.names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"min_position":['
        min_position_length = len(self.min_position)
        for i in range(0, min_position_length):
            if i == (min_position_length - 1): 
                string_echo += '%s' % self.min_position[i]
            else:
                string_echo += '%s,' % self.min_position[i]
        string_echo += '],'
        string_echo += '"max_position":['
        max_position_length = len(self.max_position)
        for i in range(0, max_position_length):
            if i == (max_position_length - 1): 
                string_echo += '%s' % self.max_position[i]
            else:
                string_echo += '%s,' % self.max_position[i]
        string_echo += '],'
        string_echo += '"max_velocity":['
        max_velocity_length = len(self.max_velocity)
        for i in range(0, max_velocity_length):
            if i == (max_velocity_length - 1): 
                string_echo += '%s' % self.max_velocity[i]
            else:
                string_echo += '%s,' % self.max_velocity[i]
        string_echo += '],'
        string_echo += '"max_torque":['
        max_torque_length = len(self.max_torque)
        for i in range(0, max_torque_length):
            if i == (max_torque_length - 1): 
                string_echo += '%s' % self.max_torque[i]
            else:
                string_echo += '%s,' % self.max_torque[i]
        string_echo += '],'
        string_echo += '"na":%s' % self.na
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "joint_extended_msgs/JointSafetyLimits"

    def getMD5(self):
        return "8fbddbc8df1fa28e0f59c21f6db569bb"

    def getDef(self):
        return "std_msgs/Header header\nstring[] names\nfloat32[] min_position\nfloat32[] max_position\nfloat32[] max_velocity\nfloat32[] max_torque\nuint32 na\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

