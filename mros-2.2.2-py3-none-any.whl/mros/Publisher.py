import sys
import mros

if sys.version > '3':
    long = int

try:
    from cStringIO import StringIO  # Python 2.x
except ImportError:
    from io import BytesIO as StringIO  # Python 3.x


class Publisher(object):
    __slots__ = ['native', 'topic_name', 'msg_class',
                 'msg_orig', 'message_type', 'md5sum', 'msg_def']

    def __init__(self, topic_name, msg_class, intra_process: bool = False, queue_size: int = 50):
        try:
            self.native = mros.PublisherNative()
            self.topic_name = topic_name
            self.msg_class = msg_class
            self.msg_orig = self.msg_class()
            self.message_type = self.msg_orig.getType()
            self.md5sum = self.msg_orig.getMD5()
            self.msg_def = self.msg_orig.getDef()
            self.native.advertise(self.topic_name, self.message_type,
                                  self.md5sum, self.msg_def, intra_process, queue_size)
        except Exception as e:
            print(str(e))

    def publish(self, msg):
        buff = StringIO()
        msg.serialize(buff)
        return self.native.publish(buff)

    def getMsgType(self):
        return self.message_type

    def getMsgMD5(self):
        return self.md5sum

    def getMsgDef(self):
        return self.msg_def

    def setEnabled(self, enabled: bool):
        return self.native.setEnabled(enabled)

    def getEnabled(self):
        return self.native.getEnabled()

    def getNumSubscribers(self):
        return self.native.getNumSubscribers()

    def negotiated(self):
        return self.native.negotiated()
