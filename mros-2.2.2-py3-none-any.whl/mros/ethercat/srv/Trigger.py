import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ethercat.msg

class TriggerRequest(mros.Message):
    __slots__ = ['__id__','cmd']
    _slot_types = ['uint32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TriggerRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.cmd is None:
                self.cmd = ''
        else:
            self.__id__ = 0
            self.cmd = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.cmd
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_cmd,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.cmd = buff[offset:(offset + length_cmd)].decode('utf-8')
            else:
                self.cmd = buff[offset:(offset + length_cmd)]
            offset += length_cmd
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        cmd_x = self.cmd
        cmd_length = len(cmd_x)
        if python3 or type(cmd_x) == unicode:
            cmd_x = cmd_x.encode('utf-8')
            cmd_length = len(cmd_x)
        length += 4
        length += cmd_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"cmd":"%s"' % self.cmd
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ethercat/Trigger"

    def getMD5(self):
        return "b2a5e91b3538fff299e8081e2d180289"
    def getDef(self):
        return "string cmd\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class TriggerResponse(mros.Message):
    __slots__ = ['__id__','success','error_msg']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TriggerResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.error_msg is None:
                self.error_msg = ''
        else:
            self.__id__ = 0
            self.success = False
            self.error_msg = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.error_msg
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_error_msg,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.error_msg = buff[offset:(offset + length_error_msg)].decode('utf-8')
            else:
                self.error_msg = buff[offset:(offset + length_error_msg)]
            offset += length_error_msg
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        error_msg_x = self.error_msg
        error_msg_length = len(error_msg_x)
        if python3 or type(error_msg_x) == unicode:
            error_msg_x = error_msg_x.encode('utf-8')
            error_msg_length = len(error_msg_x)
        length += 4
        length += error_msg_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"error_msg":"%s"' % self.error_msg
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ethercat/Trigger"

    def getMD5(self):
        return "b2a5e91b3538fff299e8081e2d180289"
    def getDef(self):
        return "bool success\nstring error_msg\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class Trigger(object):
    Request = TriggerRequest
    Response = TriggerResponse

    __slots__ = ['request','response']
    _slot_types = ['TriggerRequest','TriggerResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Trigger, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

