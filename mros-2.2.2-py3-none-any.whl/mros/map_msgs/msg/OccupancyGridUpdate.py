import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.map_msgs.msg
import mros.std_msgs.msg

class OccupancyGridUpdate(mros.Message):
    __slots__ = ['header','x','y','width','height','data']
    _slot_types = ['std_msgs/Header','int32','int32','uint32','uint32','int8[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(OccupancyGridUpdate, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.x is None:
                self.x = 0
            if self.y is None:
                self.y = 0
            if self.width is None:
                self.width = 0
            if self.height is None:
                self.height = 0
            if self.data is None:
                self.data = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.x = 0
            self.y = 0
            self.width = 0
            self.height = 0
            self.data = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_x = struct.Struct("<i")
            buff.write(struct_x.pack(self.x))
            offset += 4
            struct_y = struct.Struct("<i")
            buff.write(struct_y.pack(self.y))
            offset += 4
            buff.write(_struct_I.pack(self.width))
            offset += 4
            buff.write(_struct_I.pack(self.height))
            offset += 4
            data_length = len(self.data)
            buff.write(struct.pack('<I', data_length))
            buff.write(struct.pack(f'<{data_length}b', *self.data))
            offset += 4 + data_length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_x = struct.Struct("<i")
            (self.x,) = struct_x.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_y = struct.Struct("<i")
            (self.y,) = struct_y.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.width,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.height,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (data_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.data = np.frombuffer(buff[offset:offset + data_length], dtype=np.int8)
            offset += data_length
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += len(self.data)
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"x":%s' % self.x
        string_echo += ','
        string_echo += '"y":%s' % self.y
        string_echo += ','
        string_echo += '"width":%s' % self.width
        string_echo += ','
        string_echo += '"height":%s' % self.height
        string_echo += ','
        string_echo += '"data":['
        data_length = len(self.data)
        for i in range(0, data_length):
            if i == (data_length - 1): 
                string_echo += '%s' % self.data[i]
            else:
                string_echo += '%s,' % self.data[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/OccupancyGridUpdate"

    def getMD5(self):
        return "b295be292b335c34718bd939deebe1c9"

    def getDef(self):
        return "std_msgs/Header header\nint32 x\nint32 y\nuint32 width\nuint32 height\nint8[] data\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

