import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.map_msgs.msg
import mros.std_msgs.msg
import mros.sensor_msgs.msg

class PointCloud2Update(mros.Message):
    __slots__ = ['header','type','points']
    _slot_types = ['std_msgs/Header','uint32','sensor_msgs/PointCloud2']

    ADD = 0
    DELETE = 1

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PointCloud2Update, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.type is None:
                self.type = 0
            if self.points is None:
                self.points = mros.sensor_msgs.msg.PointCloud2()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.type = 0
            self.points = mros.sensor_msgs.msg.PointCloud2()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(_struct_I.pack(self.type))
            offset += 4
            offset += self.points.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (self.type,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.points.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += self.points.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"type":%s' % self.type
        string_echo += ','
        string_echo += '"points":'
        string_echo += self.points.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/PointCloud2Update"

    def getMD5(self):
        return "6c58e4f249ae9cd2b24fb1ee0f99195e"

    def getDef(self):
        return "uint32 ADD=0\nuint32 DELETE=1\nstd_msgs/Header header\nuint32 type\nsensor_msgs/PointCloud2 points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: sensor_msgs/PointCloud2\nstd_msgs/Header header\nuint32 height\nuint32 width\nsensor_msgs/PointField[] fields\nbool is_bigendian\nuint32 point_step\nuint32 row_step\nuint8[] data\nbool is_dense\n================================================================================\nMSG: sensor_msgs/PointField\nuint8 INT8    = 1\nuint8 UINT8   = 2\nuint8 INT16   = 3\nuint8 UINT16  = 4\nuint8 INT32   = 5\nuint8 UINT32  = 6\nuint8 FLOAT32 = 7\nuint8 FLOAT64 = 8\nstring name\nuint32 offset\nuint8 datatype\nuint32 count\n"

_struct_I = struct.Struct('<I')

