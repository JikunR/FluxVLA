import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.map_msgs.msg
import mros.nav_msgs.msg

class ProjectedMap(mros.Message):
    __slots__ = ['map','min_z','max_z']
    _slot_types = ['nav_msgs/OccupancyGrid','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ProjectedMap, self).__init__(*args, **kwds)
            if self.map is None:
                self.map = mros.nav_msgs.msg.OccupancyGrid()
            if self.min_z is None:
                self.min_z = 0.
            if self.max_z is None:
                self.max_z = 0.
        else:
            self.map = mros.nav_msgs.msg.OccupancyGrid()
            self.min_z = 0.
            self.max_z = 0.

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.map.serialize(buff)
            struct_min_z = struct.Struct("<d")
            buff.write(struct_min_z.pack(self.min_z))
            offset += 8
            struct_max_z = struct.Struct("<d")
            buff.write(struct_max_z.pack(self.max_z))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.map.deserialize(buff[offset:])
            struct_min_z = struct.Struct("<d")
            (self.min_z,) = struct_min_z.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_max_z = struct.Struct("<d")
            (self.max_z,) = struct_max_z.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.map.serializedLength()
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"map":'
        string_echo += self.map.echo()
        string_echo += ','
        string_echo += '"min_z":%s' % self.min_z
        string_echo += ','
        string_echo += '"max_z":%s' % self.max_z
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/ProjectedMap"

    def getMD5(self):
        return "7bbe8f96e45089681dc1ea7d023cbfca"

    def getDef(self):
        return "nav_msgs/OccupancyGrid map\nfloat64 min_z\nfloat64 max_z\n================================================================================\nMSG: nav_msgs/OccupancyGrid\nstd_msgs/Header header\nnav_msgs/MapMetaData info\nint8[] data\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: nav_msgs/MapMetaData\ntime map_load_time\nfloat32 resolution\nuint32 width\nuint32 height\ngeometry_msgs/Pose origin\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

