import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.sensor_msgs.msg
import mros.map_msgs.msg

class GetPointMapRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPointMapRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/GetPointMap"

    def getMD5(self):
        return "b84fbb39505086eb6a62d933c75cb7b4"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetPointMapResponse(mros.Message):
    __slots__ = ['__id__','map']
    _slot_types = ['uint32','sensor_msgs/PointCloud2']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPointMapResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.map is None:
                self.map = mros.sensor_msgs.msg.PointCloud2()
        else:
            self.__id__ = 0
            self.map = mros.sensor_msgs.msg.PointCloud2()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.map.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.map.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.map.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"map":'
        string_echo += self.map.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/GetPointMap"

    def getMD5(self):
        return "b84fbb39505086eb6a62d933c75cb7b4"
    def getDef(self):
        return "sensor_msgs/PointCloud2 map\n================================================================================\nMSG: sensor_msgs/PointCloud2\nstd_msgs/Header header\nuint32 height\nuint32 width\nsensor_msgs/PointField[] fields\nbool is_bigendian\nuint32 point_step\nuint32 row_step\nuint8[] data\nbool is_dense\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: sensor_msgs/PointField\nuint8 INT8    = 1\nuint8 UINT8   = 2\nuint8 INT16   = 3\nuint8 UINT16  = 4\nuint8 INT32   = 5\nuint8 UINT32  = 6\nuint8 FLOAT32 = 7\nuint8 FLOAT64 = 8\nstring name\nuint32 offset\nuint8 datatype\nuint32 count\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetPointMap(object):
    Request = GetPointMapRequest
    Response = GetPointMapResponse

    __slots__ = ['request','response']
    _slot_types = ['GetPointMapRequest','GetPointMapResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPointMap, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

