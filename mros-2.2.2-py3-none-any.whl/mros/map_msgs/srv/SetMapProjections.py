import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.map_msgs.msg

class SetMapProjectionsRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetMapProjectionsRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/SetMapProjections"

    def getMD5(self):
        return "d7980a33202421c8cd74565e57a4d229"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetMapProjectionsResponse(mros.Message):
    __slots__ = ['__id__','projected_maps_info']
    _slot_types = ['uint32','map_msgs/ProjectedMapInfo[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetMapProjectionsResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.projected_maps_info is None:
                self.projected_maps_info = []
        else:
            self.__id__ = 0
            self.projected_maps_info = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            projected_maps_info_length = len(self.projected_maps_info)
            buff.write(struct.pack('<I', projected_maps_info_length))
            offset += 4
            for i in range(0, projected_maps_info_length):
                offset += self.projected_maps_info[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (projected_maps_info_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.projected_maps_info) != projected_maps_info_length:
                self.projected_maps_info = [mros.map_msgs.msg.ProjectedMapInfo() for _ in range(projected_maps_info_length)]
            for i in range(0, projected_maps_info_length):
                offset += self.projected_maps_info[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, projected_maps_info_length):
            length += self.projected_maps_info[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"projected_maps_info":['
        projected_maps_info_length = len(self.projected_maps_info)
        for i in range(0, projected_maps_info_length):
            if i == (projected_maps_info_length - 1): 
                string_echo += '{projected_maps_info%s":' % i
                string_echo += self.projected_maps_info[i].echo()
                string_echo += ''
            else:
                string_echo += '{projected_maps_info%s":' % i
                string_echo += self.projected_maps_info[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/SetMapProjections"

    def getMD5(self):
        return "d7980a33202421c8cd74565e57a4d229"
    def getDef(self):
        return "map_msgs/ProjectedMapInfo[] projected_maps_info\n================================================================================\nMSG: map_msgs/ProjectedMapInfo\nstring frame_id\nfloat64 x\nfloat64 y\nfloat64 width\nfloat64 height\nfloat64 min_z\nfloat64 max_z\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetMapProjections(object):
    Request = SetMapProjectionsRequest
    Response = SetMapProjectionsResponse

    __slots__ = ['request','response']
    _slot_types = ['SetMapProjectionsRequest','SetMapProjectionsResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetMapProjections, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

