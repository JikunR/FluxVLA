import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.std_msgs.msg
import mros.map_msgs.msg

class SaveMapRequest(mros.Message):
    __slots__ = ['__id__','filename']
    _slot_types = ['uint32','std_msgs/String']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SaveMapRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.filename is None:
                self.filename = mros.std_msgs.msg.String()
        else:
            self.__id__ = 0
            self.filename = mros.std_msgs.msg.String()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.filename.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.filename.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.filename.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"filename":'
        string_echo += self.filename.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/SaveMap"

    def getMD5(self):
        return "716e25f9d9dc76ceba197f93cbf05dc7"
    def getDef(self):
        return "std_msgs/String filename\n================================================================================\nMSG: std_msgs/String\nstring data\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SaveMapResponse(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SaveMapResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/SaveMap"

    def getMD5(self):
        return "716e25f9d9dc76ceba197f93cbf05dc7"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SaveMap(object):
    Request = SaveMapRequest
    Response = SaveMapResponse

    __slots__ = ['request','response']
    _slot_types = ['SaveMapRequest','SaveMapResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SaveMap, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

