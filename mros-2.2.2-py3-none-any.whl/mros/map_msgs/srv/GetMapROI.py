import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.nav_msgs.msg
import mros.map_msgs.msg

class GetMapROIRequest(mros.Message):
    __slots__ = ['__id__','x','y','l_x','l_y']
    _slot_types = ['uint32','float64','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetMapROIRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.x is None:
                self.x = 0.
            if self.y is None:
                self.y = 0.
            if self.l_x is None:
                self.l_x = 0.
            if self.l_y is None:
                self.l_y = 0.
        else:
            self.__id__ = 0
            self.x = 0.
            self.y = 0.
            self.l_x = 0.
            self.l_y = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_x = struct.Struct("<d")
            buff.write(struct_x.pack(self.x))
            offset += 8
            struct_y = struct.Struct("<d")
            buff.write(struct_y.pack(self.y))
            offset += 8
            struct_l_x = struct.Struct("<d")
            buff.write(struct_l_x.pack(self.l_x))
            offset += 8
            struct_l_y = struct.Struct("<d")
            buff.write(struct_l_y.pack(self.l_y))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_x = struct.Struct("<d")
            (self.x,) = struct_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_y = struct.Struct("<d")
            (self.y,) = struct_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_l_x = struct.Struct("<d")
            (self.l_x,) = struct_l_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_l_y = struct.Struct("<d")
            (self.l_y,) = struct_l_y.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 8
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"x":%s' % self.x
        string_echo += ','
        string_echo += '"y":%s' % self.y
        string_echo += ','
        string_echo += '"l_x":%s' % self.l_x
        string_echo += ','
        string_echo += '"l_y":%s' % self.l_y
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/GetMapROI"

    def getMD5(self):
        return "81aa75ecf00f4571a9be0d9dc6dea512"
    def getDef(self):
        return "float64 x\nfloat64 y\nfloat64 l_x\nfloat64 l_y\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetMapROIResponse(mros.Message):
    __slots__ = ['__id__','sub_map']
    _slot_types = ['uint32','nav_msgs/OccupancyGrid']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetMapROIResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.sub_map is None:
                self.sub_map = mros.nav_msgs.msg.OccupancyGrid()
        else:
            self.__id__ = 0
            self.sub_map = mros.nav_msgs.msg.OccupancyGrid()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.sub_map.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.sub_map.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.sub_map.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"sub_map":'
        string_echo += self.sub_map.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/GetMapROI"

    def getMD5(self):
        return "81aa75ecf00f4571a9be0d9dc6dea512"
    def getDef(self):
        return "nav_msgs/OccupancyGrid sub_map\n================================================================================\nMSG: nav_msgs/OccupancyGrid\nstd_msgs/Header header\nnav_msgs/MapMetaData info\nint8[] data\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: nav_msgs/MapMetaData\ntime map_load_time\nfloat32 resolution\nuint32 width\nuint32 height\ngeometry_msgs/Pose origin\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetMapROI(object):
    Request = GetMapROIRequest
    Response = GetMapROIResponse

    __slots__ = ['request','response']
    _slot_types = ['GetMapROIRequest','GetMapROIResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetMapROI, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

