import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.sensor_msgs.msg
import mros.map_msgs.msg

class GetPointMapROIRequest(mros.Message):
    __slots__ = ['__id__','x','y','z','r','l_x','l_y','l_z']
    _slot_types = ['uint32','float64','float64','float64','float64','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPointMapROIRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.x is None:
                self.x = 0.
            if self.y is None:
                self.y = 0.
            if self.z is None:
                self.z = 0.
            if self.r is None:
                self.r = 0.
            if self.l_x is None:
                self.l_x = 0.
            if self.l_y is None:
                self.l_y = 0.
            if self.l_z is None:
                self.l_z = 0.
        else:
            self.__id__ = 0
            self.x = 0.
            self.y = 0.
            self.z = 0.
            self.r = 0.
            self.l_x = 0.
            self.l_y = 0.
            self.l_z = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_x = struct.Struct("<d")
            buff.write(struct_x.pack(self.x))
            offset += 8
            struct_y = struct.Struct("<d")
            buff.write(struct_y.pack(self.y))
            offset += 8
            struct_z = struct.Struct("<d")
            buff.write(struct_z.pack(self.z))
            offset += 8
            struct_r = struct.Struct("<d")
            buff.write(struct_r.pack(self.r))
            offset += 8
            struct_l_x = struct.Struct("<d")
            buff.write(struct_l_x.pack(self.l_x))
            offset += 8
            struct_l_y = struct.Struct("<d")
            buff.write(struct_l_y.pack(self.l_y))
            offset += 8
            struct_l_z = struct.Struct("<d")
            buff.write(struct_l_z.pack(self.l_z))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_x = struct.Struct("<d")
            (self.x,) = struct_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_y = struct.Struct("<d")
            (self.y,) = struct_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_z = struct.Struct("<d")
            (self.z,) = struct_z.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_r = struct.Struct("<d")
            (self.r,) = struct_r.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_l_x = struct.Struct("<d")
            (self.l_x,) = struct_l_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_l_y = struct.Struct("<d")
            (self.l_y,) = struct_l_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_l_z = struct.Struct("<d")
            (self.l_z,) = struct_l_z.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"x":%s' % self.x
        string_echo += ','
        string_echo += '"y":%s' % self.y
        string_echo += ','
        string_echo += '"z":%s' % self.z
        string_echo += ','
        string_echo += '"r":%s' % self.r
        string_echo += ','
        string_echo += '"l_x":%s' % self.l_x
        string_echo += ','
        string_echo += '"l_y":%s' % self.l_y
        string_echo += ','
        string_echo += '"l_z":%s' % self.l_z
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/GetPointMapROI"

    def getMD5(self):
        return "d955594b5ccde9615cbe5aed9442f733"
    def getDef(self):
        return "float64 x\nfloat64 y\nfloat64 z\nfloat64 r\nfloat64 l_x\nfloat64 l_y\nfloat64 l_z\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetPointMapROIResponse(mros.Message):
    __slots__ = ['__id__','sub_map']
    _slot_types = ['uint32','sensor_msgs/PointCloud2']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPointMapROIResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.sub_map is None:
                self.sub_map = mros.sensor_msgs.msg.PointCloud2()
        else:
            self.__id__ = 0
            self.sub_map = mros.sensor_msgs.msg.PointCloud2()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.sub_map.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.sub_map.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.sub_map.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"sub_map":'
        string_echo += self.sub_map.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "map_msgs/GetPointMapROI"

    def getMD5(self):
        return "d955594b5ccde9615cbe5aed9442f733"
    def getDef(self):
        return "sensor_msgs/PointCloud2 sub_map\n================================================================================\nMSG: sensor_msgs/PointCloud2\nstd_msgs/Header header\nuint32 height\nuint32 width\nsensor_msgs/PointField[] fields\nbool is_bigendian\nuint32 point_step\nuint32 row_step\nuint8[] data\nbool is_dense\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: sensor_msgs/PointField\nuint8 INT8    = 1\nuint8 UINT8   = 2\nuint8 INT16   = 3\nuint8 UINT16  = 4\nuint8 INT32   = 5\nuint8 UINT32  = 6\nuint8 FLOAT32 = 7\nuint8 FLOAT64 = 8\nstring name\nuint32 offset\nuint8 datatype\nuint32 count\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetPointMapROI(object):
    Request = GetPointMapROIRequest
    Response = GetPointMapROIResponse

    __slots__ = ['request','response']
    _slot_types = ['GetPointMapROIRequest','GetPointMapROIResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPointMapROI, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

