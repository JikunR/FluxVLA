import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class DeleteRobotStateFromWarehouseRequest(mros.Message):
    __slots__ = ['__id__','name','robot']
    _slot_types = ['uint32','string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DeleteRobotStateFromWarehouseRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.name is None:
                self.name = ''
            if self.robot is None:
                self.robot = ''
        else:
            self.__id__ = 0
            self.name = ''
            self.robot = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.robot
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (length_robot,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.robot = buff[offset:(offset + length_robot)].decode('utf-8')
            else:
                self.robot = buff[offset:(offset + length_robot)]
            offset += length_robot
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        robot_x = self.robot
        robot_length = len(robot_x)
        if python3 or type(robot_x) == unicode:
            robot_x = robot_x.encode('utf-8')
            robot_length = len(robot_x)
        length += 4
        length += robot_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"robot":"%s"' % self.robot
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/DeleteRobotStateFromWarehouse"

    def getMD5(self):
        return "dab44354403f811c40b84964e068219c"
    def getDef(self):
        return "string name\nstring robot\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class DeleteRobotStateFromWarehouseResponse(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DeleteRobotStateFromWarehouseResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/DeleteRobotStateFromWarehouse"

    def getMD5(self):
        return "dab44354403f811c40b84964e068219c"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class DeleteRobotStateFromWarehouse(object):
    Request = DeleteRobotStateFromWarehouseRequest
    Response = DeleteRobotStateFromWarehouseResponse

    __slots__ = ['request','response']
    _slot_types = ['DeleteRobotStateFromWarehouseRequest','DeleteRobotStateFromWarehouseResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DeleteRobotStateFromWarehouse, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

