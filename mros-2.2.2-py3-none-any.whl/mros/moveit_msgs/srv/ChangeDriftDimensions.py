import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.moveit_msgs.msg

class ChangeDriftDimensionsRequest(mros.Message):
    __slots__ = ['__id__','drift_x_translation','drift_y_translation','drift_z_translation','drift_x_rotation','drift_y_rotation','drift_z_rotation','transform_jog_frame_to_drift_frame']
    _slot_types = ['uint32','bool','bool','bool','bool','bool','bool','geometry_msgs/Transform']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ChangeDriftDimensionsRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.drift_x_translation is None:
                self.drift_x_translation = False
            if self.drift_y_translation is None:
                self.drift_y_translation = False
            if self.drift_z_translation is None:
                self.drift_z_translation = False
            if self.drift_x_rotation is None:
                self.drift_x_rotation = False
            if self.drift_y_rotation is None:
                self.drift_y_rotation = False
            if self.drift_z_rotation is None:
                self.drift_z_rotation = False
            if self.transform_jog_frame_to_drift_frame is None:
                self.transform_jog_frame_to_drift_frame = mros.geometry_msgs.msg.Transform()
        else:
            self.__id__ = 0
            self.drift_x_translation = False
            self.drift_y_translation = False
            self.drift_z_translation = False
            self.drift_x_rotation = False
            self.drift_y_rotation = False
            self.drift_z_rotation = False
            self.transform_jog_frame_to_drift_frame = mros.geometry_msgs.msg.Transform()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_drift_x_translation = struct.Struct("<B")
            buff.write(struct_drift_x_translation.pack(self.drift_x_translation))
            offset += 1
            struct_drift_y_translation = struct.Struct("<B")
            buff.write(struct_drift_y_translation.pack(self.drift_y_translation))
            offset += 1
            struct_drift_z_translation = struct.Struct("<B")
            buff.write(struct_drift_z_translation.pack(self.drift_z_translation))
            offset += 1
            struct_drift_x_rotation = struct.Struct("<B")
            buff.write(struct_drift_x_rotation.pack(self.drift_x_rotation))
            offset += 1
            struct_drift_y_rotation = struct.Struct("<B")
            buff.write(struct_drift_y_rotation.pack(self.drift_y_rotation))
            offset += 1
            struct_drift_z_rotation = struct.Struct("<B")
            buff.write(struct_drift_z_rotation.pack(self.drift_z_rotation))
            offset += 1
            offset += self.transform_jog_frame_to_drift_frame.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_drift_x_translation = struct.Struct("<B")
            (self.drift_x_translation,) = struct_drift_x_translation.unpack(buff[offset:(offset + 1)])
            self.drift_x_translation = bool(self.drift_x_translation)
            offset += 1
            struct_drift_y_translation = struct.Struct("<B")
            (self.drift_y_translation,) = struct_drift_y_translation.unpack(buff[offset:(offset + 1)])
            self.drift_y_translation = bool(self.drift_y_translation)
            offset += 1
            struct_drift_z_translation = struct.Struct("<B")
            (self.drift_z_translation,) = struct_drift_z_translation.unpack(buff[offset:(offset + 1)])
            self.drift_z_translation = bool(self.drift_z_translation)
            offset += 1
            struct_drift_x_rotation = struct.Struct("<B")
            (self.drift_x_rotation,) = struct_drift_x_rotation.unpack(buff[offset:(offset + 1)])
            self.drift_x_rotation = bool(self.drift_x_rotation)
            offset += 1
            struct_drift_y_rotation = struct.Struct("<B")
            (self.drift_y_rotation,) = struct_drift_y_rotation.unpack(buff[offset:(offset + 1)])
            self.drift_y_rotation = bool(self.drift_y_rotation)
            offset += 1
            struct_drift_z_rotation = struct.Struct("<B")
            (self.drift_z_rotation,) = struct_drift_z_rotation.unpack(buff[offset:(offset + 1)])
            self.drift_z_rotation = bool(self.drift_z_rotation)
            offset += 1
            offset += self.transform_jog_frame_to_drift_frame.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += self.transform_jog_frame_to_drift_frame.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"drift_x_translation":%s' % self.drift_x_translation
        string_echo += ','
        string_echo += '"drift_y_translation":%s' % self.drift_y_translation
        string_echo += ','
        string_echo += '"drift_z_translation":%s' % self.drift_z_translation
        string_echo += ','
        string_echo += '"drift_x_rotation":%s' % self.drift_x_rotation
        string_echo += ','
        string_echo += '"drift_y_rotation":%s' % self.drift_y_rotation
        string_echo += ','
        string_echo += '"drift_z_rotation":%s' % self.drift_z_rotation
        string_echo += ','
        string_echo += '"transform_jog_frame_to_drift_frame":'
        string_echo += self.transform_jog_frame_to_drift_frame.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ChangeDriftDimensions"

    def getMD5(self):
        return "0d34c8d563fea2efff65829c37132a15"
    def getDef(self):
        return "bool drift_x_translation\nbool drift_y_translation\nbool drift_z_translation\nbool drift_x_rotation\nbool drift_y_rotation\nbool drift_z_rotation\ngeometry_msgs/Transform transform_jog_frame_to_drift_frame\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ChangeDriftDimensionsResponse(mros.Message):
    __slots__ = ['__id__','success']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ChangeDriftDimensionsResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
        else:
            self.__id__ = 0
            self.success = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ChangeDriftDimensions"

    def getMD5(self):
        return "0d34c8d563fea2efff65829c37132a15"
    def getDef(self):
        return "bool success\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ChangeDriftDimensions(object):
    Request = ChangeDriftDimensionsRequest
    Response = ChangeDriftDimensionsResponse

    __slots__ = ['request','response']
    _slot_types = ['ChangeDriftDimensionsRequest','ChangeDriftDimensionsResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ChangeDriftDimensions, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

