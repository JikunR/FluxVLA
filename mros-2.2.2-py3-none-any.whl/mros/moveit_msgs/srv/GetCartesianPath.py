import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.std_msgs.msg
import mros.geometry_msgs.msg
import mros.moveit_msgs.msg

class GetCartesianPathRequest(mros.Message):
    __slots__ = ['__id__','header','start_state','group_name','link_name','waypoints','max_step','jump_threshold','prismatic_jump_threshold','revolute_jump_threshold','avoid_collisions','path_constraints','cartesian_speed_limited_link','max_cartesian_speed']
    _slot_types = ['uint32','std_msgs/Header','moveit_msgs/RobotState','string','string','geometry_msgs/Pose[]','float64','float64','float64','float64','bool','moveit_msgs/Constraints','string','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetCartesianPathRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.start_state is None:
                self.start_state = mros.moveit_msgs.msg.RobotState()
            if self.group_name is None:
                self.group_name = ''
            if self.link_name is None:
                self.link_name = ''
            if self.waypoints is None:
                self.waypoints = []
            if self.max_step is None:
                self.max_step = 0.
            if self.jump_threshold is None:
                self.jump_threshold = 0.
            if self.prismatic_jump_threshold is None:
                self.prismatic_jump_threshold = 0.
            if self.revolute_jump_threshold is None:
                self.revolute_jump_threshold = 0.
            if self.avoid_collisions is None:
                self.avoid_collisions = False
            if self.path_constraints is None:
                self.path_constraints = mros.moveit_msgs.msg.Constraints()
            if self.cartesian_speed_limited_link is None:
                self.cartesian_speed_limited_link = ''
            if self.max_cartesian_speed is None:
                self.max_cartesian_speed = 0.
        else:
            self.__id__ = 0
            self.header = mros.std_msgs.msg.Header()
            self.start_state = mros.moveit_msgs.msg.RobotState()
            self.group_name = ''
            self.link_name = ''
            self.waypoints = []
            self.max_step = 0.
            self.jump_threshold = 0.
            self.prismatic_jump_threshold = 0.
            self.revolute_jump_threshold = 0.
            self.avoid_collisions = False
            self.path_constraints = mros.moveit_msgs.msg.Constraints()
            self.cartesian_speed_limited_link = ''
            self.max_cartesian_speed = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.start_state.serialize(buff)
            _x = self.group_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            waypoints_length = len(self.waypoints)
            buff.write(struct.pack('<I', waypoints_length))
            offset += 4
            for i in range(0, waypoints_length):
                offset += self.waypoints[i].serialize(buff)
            struct_max_step = struct.Struct("<d")
            buff.write(struct_max_step.pack(self.max_step))
            offset += 8
            struct_jump_threshold = struct.Struct("<d")
            buff.write(struct_jump_threshold.pack(self.jump_threshold))
            offset += 8
            struct_prismatic_jump_threshold = struct.Struct("<d")
            buff.write(struct_prismatic_jump_threshold.pack(self.prismatic_jump_threshold))
            offset += 8
            struct_revolute_jump_threshold = struct.Struct("<d")
            buff.write(struct_revolute_jump_threshold.pack(self.revolute_jump_threshold))
            offset += 8
            struct_avoid_collisions = struct.Struct("<B")
            buff.write(struct_avoid_collisions.pack(self.avoid_collisions))
            offset += 1
            offset += self.path_constraints.serialize(buff)
            _x = self.cartesian_speed_limited_link
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_max_cartesian_speed = struct.Struct("<d")
            buff.write(struct_max_cartesian_speed.pack(self.max_cartesian_speed))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.start_state.deserialize(buff[offset:])
            (length_group_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.group_name = buff[offset:(offset + length_group_name)].decode('utf-8')
            else:
                self.group_name = buff[offset:(offset + length_group_name)]
            offset += length_group_name
            (length_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.link_name = buff[offset:(offset + length_link_name)].decode('utf-8')
            else:
                self.link_name = buff[offset:(offset + length_link_name)]
            offset += length_link_name
            (waypoints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.waypoints) != waypoints_length:
                self.waypoints = [mros.geometry_msgs.msg.Pose() for _ in range(waypoints_length)]
            for i in range(0, waypoints_length):
                offset += self.waypoints[i].deserialize(buff[offset:])
            struct_max_step = struct.Struct("<d")
            (self.max_step,) = struct_max_step.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_jump_threshold = struct.Struct("<d")
            (self.jump_threshold,) = struct_jump_threshold.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_prismatic_jump_threshold = struct.Struct("<d")
            (self.prismatic_jump_threshold,) = struct_prismatic_jump_threshold.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_revolute_jump_threshold = struct.Struct("<d")
            (self.revolute_jump_threshold,) = struct_revolute_jump_threshold.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_avoid_collisions = struct.Struct("<B")
            (self.avoid_collisions,) = struct_avoid_collisions.unpack(buff[offset:(offset + 1)])
            self.avoid_collisions = bool(self.avoid_collisions)
            offset += 1
            offset += self.path_constraints.deserialize(buff[offset:])
            (length_cartesian_speed_limited_link,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.cartesian_speed_limited_link = buff[offset:(offset + length_cartesian_speed_limited_link)].decode('utf-8')
            else:
                self.cartesian_speed_limited_link = buff[offset:(offset + length_cartesian_speed_limited_link)]
            offset += length_cartesian_speed_limited_link
            struct_max_cartesian_speed = struct.Struct("<d")
            (self.max_cartesian_speed,) = struct_max_cartesian_speed.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.header.serializedLength()
        length += self.start_state.serializedLength()
        group_name_x = self.group_name
        group_name_length = len(group_name_x)
        if python3 or type(group_name_x) == unicode:
            group_name_x = group_name_x.encode('utf-8')
            group_name_length = len(group_name_x)
        length += 4
        length += group_name_length
        link_name_x = self.link_name
        link_name_length = len(link_name_x)
        if python3 or type(link_name_x) == unicode:
            link_name_x = link_name_x.encode('utf-8')
            link_name_length = len(link_name_x)
        length += 4
        length += link_name_length
        length += 4
        for i in range(0, waypoints_length):
            length += self.waypoints[i].serializedLength()
        length += 8
        length += 8
        length += 8
        length += 8
        length += 1
        length += self.path_constraints.serializedLength()
        cartesian_speed_limited_link_x = self.cartesian_speed_limited_link
        cartesian_speed_limited_link_length = len(cartesian_speed_limited_link_x)
        if python3 or type(cartesian_speed_limited_link_x) == unicode:
            cartesian_speed_limited_link_x = cartesian_speed_limited_link_x.encode('utf-8')
            cartesian_speed_limited_link_length = len(cartesian_speed_limited_link_x)
        length += 4
        length += cartesian_speed_limited_link_length
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"start_state":'
        string_echo += self.start_state.echo()
        string_echo += ','
        string_echo += '"group_name":"%s"' % self.group_name
        string_echo += ','
        string_echo += '"link_name":"%s"' % self.link_name
        string_echo += ','
        string_echo += '"waypoints":['
        waypoints_length = len(self.waypoints)
        for i in range(0, waypoints_length):
            if i == (waypoints_length - 1): 
                string_echo += '{waypoints%s":' % i
                string_echo += self.waypoints[i].echo()
                string_echo += ''
            else:
                string_echo += '{waypoints%s":' % i
                string_echo += self.waypoints[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"max_step":%s' % self.max_step
        string_echo += ','
        string_echo += '"jump_threshold":%s' % self.jump_threshold
        string_echo += ','
        string_echo += '"prismatic_jump_threshold":%s' % self.prismatic_jump_threshold
        string_echo += ','
        string_echo += '"revolute_jump_threshold":%s' % self.revolute_jump_threshold
        string_echo += ','
        string_echo += '"avoid_collisions":%s' % self.avoid_collisions
        string_echo += ','
        string_echo += '"path_constraints":'
        string_echo += self.path_constraints.echo()
        string_echo += ','
        string_echo += '"cartesian_speed_limited_link":"%s"' % self.cartesian_speed_limited_link
        string_echo += ','
        string_echo += '"max_cartesian_speed":%s' % self.max_cartesian_speed
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/GetCartesianPath"

    def getMD5(self):
        return "c54b9430d97ea6816e0f7c7ffd3779b8"
    def getDef(self):
        return "std_msgs/Header header\nmoveit_msgs/RobotState start_state\nstring group_name\nstring link_name\ngeometry_msgs/Pose[] waypoints\nfloat64 max_step\nfloat64 jump_threshold\nfloat64 prismatic_jump_threshold\nfloat64 revolute_jump_threshold\nbool avoid_collisions\nmoveit_msgs/Constraints path_constraints\nstring cartesian_speed_limited_link\nfloat64 max_cartesian_speed\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: moveit_msgs/Constraints\nstring name\nmoveit_msgs/JointConstraint[] joint_constraints\nmoveit_msgs/PositionConstraint[] position_constraints\nmoveit_msgs/OrientationConstraint[] orientation_constraints\nmoveit_msgs/VisibilityConstraint[] visibility_constraints\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: moveit_msgs/JointConstraint\nstring joint_name\nfloat64 position\nfloat64 tolerance_above\nfloat64 tolerance_below\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PositionConstraint\nstd_msgs/Header header\nstring link_name\ngeometry_msgs/Vector3 target_point_offset\nmoveit_msgs/BoundingVolume constraint_region\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/OrientationConstraint\nstd_msgs/Header header\ngeometry_msgs/Quaternion orientation\nstring link_name\nfloat64 absolute_x_axis_tolerance\nfloat64 absolute_y_axis_tolerance\nfloat64 absolute_z_axis_tolerance\nuint8 parameterization\nuint8 XYZ_EULER_ANGLES=0\nuint8 ROTATION_VECTOR=1\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/VisibilityConstraint\nfloat64 target_radius\ngeometry_msgs/PoseStamped target_pose\nint32 cone_sides\ngeometry_msgs/PoseStamped sensor_pose\nfloat64 max_view_angle\nfloat64 max_range_angle\nuint8 SENSOR_Z=0\nuint8 SENSOR_Y=1\nuint8 SENSOR_X=2\nuint8 sensor_view_direction\nfloat64 weight\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: moveit_msgs/BoundingVolume\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetCartesianPathResponse(mros.Message):
    __slots__ = ['__id__','start_state','solution','fraction','error_code']
    _slot_types = ['uint32','moveit_msgs/RobotState','moveit_msgs/RobotTrajectory','float64','moveit_msgs/MoveItErrorCodes']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetCartesianPathResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.start_state is None:
                self.start_state = mros.moveit_msgs.msg.RobotState()
            if self.solution is None:
                self.solution = mros.moveit_msgs.msg.RobotTrajectory()
            if self.fraction is None:
                self.fraction = 0.
            if self.error_code is None:
                self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()
        else:
            self.__id__ = 0
            self.start_state = mros.moveit_msgs.msg.RobotState()
            self.solution = mros.moveit_msgs.msg.RobotTrajectory()
            self.fraction = 0.
            self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.start_state.serialize(buff)
            offset += self.solution.serialize(buff)
            struct_fraction = struct.Struct("<d")
            buff.write(struct_fraction.pack(self.fraction))
            offset += 8
            offset += self.error_code.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.start_state.deserialize(buff[offset:])
            offset += self.solution.deserialize(buff[offset:])
            struct_fraction = struct.Struct("<d")
            (self.fraction,) = struct_fraction.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.error_code.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.start_state.serializedLength()
        length += self.solution.serializedLength()
        length += 8
        length += self.error_code.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"start_state":'
        string_echo += self.start_state.echo()
        string_echo += ','
        string_echo += '"solution":'
        string_echo += self.solution.echo()
        string_echo += ','
        string_echo += '"fraction":%s' % self.fraction
        string_echo += ','
        string_echo += '"error_code":'
        string_echo += self.error_code.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/GetCartesianPath"

    def getMD5(self):
        return "c54b9430d97ea6816e0f7c7ffd3779b8"
    def getDef(self):
        return "moveit_msgs/RobotState start_state\nmoveit_msgs/RobotTrajectory solution\nfloat64 fraction\nmoveit_msgs/MoveItErrorCodes error_code\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: moveit_msgs/RobotTrajectory\ntrajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetCartesianPath(object):
    Request = GetCartesianPathRequest
    Response = GetCartesianPathResponse

    __slots__ = ['request','response']
    _slot_types = ['GetCartesianPathRequest','GetCartesianPathResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetCartesianPath, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

