import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class ChangeControlDimensionsRequest(mros.Message):
    __slots__ = ['__id__','control_x_translation','control_y_translation','control_z_translation','control_x_rotation','control_y_rotation','control_z_rotation']
    _slot_types = ['uint32','bool','bool','bool','bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ChangeControlDimensionsRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.control_x_translation is None:
                self.control_x_translation = False
            if self.control_y_translation is None:
                self.control_y_translation = False
            if self.control_z_translation is None:
                self.control_z_translation = False
            if self.control_x_rotation is None:
                self.control_x_rotation = False
            if self.control_y_rotation is None:
                self.control_y_rotation = False
            if self.control_z_rotation is None:
                self.control_z_rotation = False
        else:
            self.__id__ = 0
            self.control_x_translation = False
            self.control_y_translation = False
            self.control_z_translation = False
            self.control_x_rotation = False
            self.control_y_rotation = False
            self.control_z_rotation = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_control_x_translation = struct.Struct("<B")
            buff.write(struct_control_x_translation.pack(self.control_x_translation))
            offset += 1
            struct_control_y_translation = struct.Struct("<B")
            buff.write(struct_control_y_translation.pack(self.control_y_translation))
            offset += 1
            struct_control_z_translation = struct.Struct("<B")
            buff.write(struct_control_z_translation.pack(self.control_z_translation))
            offset += 1
            struct_control_x_rotation = struct.Struct("<B")
            buff.write(struct_control_x_rotation.pack(self.control_x_rotation))
            offset += 1
            struct_control_y_rotation = struct.Struct("<B")
            buff.write(struct_control_y_rotation.pack(self.control_y_rotation))
            offset += 1
            struct_control_z_rotation = struct.Struct("<B")
            buff.write(struct_control_z_rotation.pack(self.control_z_rotation))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_control_x_translation = struct.Struct("<B")
            (self.control_x_translation,) = struct_control_x_translation.unpack(buff[offset:(offset + 1)])
            self.control_x_translation = bool(self.control_x_translation)
            offset += 1
            struct_control_y_translation = struct.Struct("<B")
            (self.control_y_translation,) = struct_control_y_translation.unpack(buff[offset:(offset + 1)])
            self.control_y_translation = bool(self.control_y_translation)
            offset += 1
            struct_control_z_translation = struct.Struct("<B")
            (self.control_z_translation,) = struct_control_z_translation.unpack(buff[offset:(offset + 1)])
            self.control_z_translation = bool(self.control_z_translation)
            offset += 1
            struct_control_x_rotation = struct.Struct("<B")
            (self.control_x_rotation,) = struct_control_x_rotation.unpack(buff[offset:(offset + 1)])
            self.control_x_rotation = bool(self.control_x_rotation)
            offset += 1
            struct_control_y_rotation = struct.Struct("<B")
            (self.control_y_rotation,) = struct_control_y_rotation.unpack(buff[offset:(offset + 1)])
            self.control_y_rotation = bool(self.control_y_rotation)
            offset += 1
            struct_control_z_rotation = struct.Struct("<B")
            (self.control_z_rotation,) = struct_control_z_rotation.unpack(buff[offset:(offset + 1)])
            self.control_z_rotation = bool(self.control_z_rotation)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"control_x_translation":%s' % self.control_x_translation
        string_echo += ','
        string_echo += '"control_y_translation":%s' % self.control_y_translation
        string_echo += ','
        string_echo += '"control_z_translation":%s' % self.control_z_translation
        string_echo += ','
        string_echo += '"control_x_rotation":%s' % self.control_x_rotation
        string_echo += ','
        string_echo += '"control_y_rotation":%s' % self.control_y_rotation
        string_echo += ','
        string_echo += '"control_z_rotation":%s' % self.control_z_rotation
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ChangeControlDimensions"

    def getMD5(self):
        return "35b43a24f32e4654e4afa7596399fc3c"
    def getDef(self):
        return "bool control_x_translation\nbool control_y_translation\nbool control_z_translation\nbool control_x_rotation\nbool control_y_rotation\nbool control_z_rotation\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ChangeControlDimensionsResponse(mros.Message):
    __slots__ = ['__id__','success']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ChangeControlDimensionsResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
        else:
            self.__id__ = 0
            self.success = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ChangeControlDimensions"

    def getMD5(self):
        return "35b43a24f32e4654e4afa7596399fc3c"
    def getDef(self):
        return "bool success\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ChangeControlDimensions(object):
    Request = ChangeControlDimensionsRequest
    Response = ChangeControlDimensionsResponse

    __slots__ = ['request','response']
    _slot_types = ['ChangeControlDimensionsRequest','ChangeControlDimensionsResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ChangeControlDimensions, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

