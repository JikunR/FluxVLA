import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class GetPlannerParamsRequest(mros.Message):
    __slots__ = ['__id__','pipeline_id','planner_config','group']
    _slot_types = ['uint32','string','string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPlannerParamsRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.pipeline_id is None:
                self.pipeline_id = ''
            if self.planner_config is None:
                self.planner_config = ''
            if self.group is None:
                self.group = ''
        else:
            self.__id__ = 0
            self.pipeline_id = ''
            self.planner_config = ''
            self.group = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.pipeline_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.planner_config
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.group
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_pipeline_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.pipeline_id = buff[offset:(offset + length_pipeline_id)].decode('utf-8')
            else:
                self.pipeline_id = buff[offset:(offset + length_pipeline_id)]
            offset += length_pipeline_id
            (length_planner_config,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.planner_config = buff[offset:(offset + length_planner_config)].decode('utf-8')
            else:
                self.planner_config = buff[offset:(offset + length_planner_config)]
            offset += length_planner_config
            (length_group,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.group = buff[offset:(offset + length_group)].decode('utf-8')
            else:
                self.group = buff[offset:(offset + length_group)]
            offset += length_group
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        pipeline_id_x = self.pipeline_id
        pipeline_id_length = len(pipeline_id_x)
        if python3 or type(pipeline_id_x) == unicode:
            pipeline_id_x = pipeline_id_x.encode('utf-8')
            pipeline_id_length = len(pipeline_id_x)
        length += 4
        length += pipeline_id_length
        planner_config_x = self.planner_config
        planner_config_length = len(planner_config_x)
        if python3 or type(planner_config_x) == unicode:
            planner_config_x = planner_config_x.encode('utf-8')
            planner_config_length = len(planner_config_x)
        length += 4
        length += planner_config_length
        group_x = self.group
        group_length = len(group_x)
        if python3 or type(group_x) == unicode:
            group_x = group_x.encode('utf-8')
            group_length = len(group_x)
        length += 4
        length += group_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"pipeline_id":"%s"' % self.pipeline_id
        string_echo += ','
        string_echo += '"planner_config":"%s"' % self.planner_config
        string_echo += ','
        string_echo += '"group":"%s"' % self.group
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/GetPlannerParams"

    def getMD5(self):
        return "1b56b530c1107c60f0c9173e631d7bf5"
    def getDef(self):
        return "string pipeline_id\nstring planner_config\nstring group\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetPlannerParamsResponse(mros.Message):
    __slots__ = ['__id__','params']
    _slot_types = ['uint32','moveit_msgs/PlannerParams']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPlannerParamsResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.params is None:
                self.params = mros.moveit_msgs.msg.PlannerParams()
        else:
            self.__id__ = 0
            self.params = mros.moveit_msgs.msg.PlannerParams()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.params.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.params.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.params.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"params":'
        string_echo += self.params.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/GetPlannerParams"

    def getMD5(self):
        return "1b56b530c1107c60f0c9173e631d7bf5"
    def getDef(self):
        return "moveit_msgs/PlannerParams params\n================================================================================\nMSG: moveit_msgs/PlannerParams\nstring[] keys\nstring[] values\nstring[] descriptions\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetPlannerParams(object):
    Request = GetPlannerParamsRequest
    Response = GetPlannerParamsResponse

    __slots__ = ['request','response']
    _slot_types = ['GetPlannerParamsRequest','GetPlannerParamsResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetPlannerParams, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

