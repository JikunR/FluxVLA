import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class ExecuteKnownTrajectoryRequest(mros.Message):
    __slots__ = ['__id__','trajectory','wait_for_execution']
    _slot_types = ['uint32','moveit_msgs/RobotTrajectory','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ExecuteKnownTrajectoryRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.trajectory is None:
                self.trajectory = mros.moveit_msgs.msg.RobotTrajectory()
            if self.wait_for_execution is None:
                self.wait_for_execution = False
        else:
            self.__id__ = 0
            self.trajectory = mros.moveit_msgs.msg.RobotTrajectory()
            self.wait_for_execution = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.trajectory.serialize(buff)
            struct_wait_for_execution = struct.Struct("<B")
            buff.write(struct_wait_for_execution.pack(self.wait_for_execution))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.trajectory.deserialize(buff[offset:])
            struct_wait_for_execution = struct.Struct("<B")
            (self.wait_for_execution,) = struct_wait_for_execution.unpack(buff[offset:(offset + 1)])
            self.wait_for_execution = bool(self.wait_for_execution)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.trajectory.serializedLength()
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"trajectory":'
        string_echo += self.trajectory.echo()
        string_echo += ','
        string_echo += '"wait_for_execution":%s' % self.wait_for_execution
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ExecuteKnownTrajectory"

    def getMD5(self):
        return "af7da309bb25223035a7cfa762b8d4cd"
    def getDef(self):
        return "moveit_msgs/RobotTrajectory trajectory\nbool wait_for_execution\n================================================================================\nMSG: moveit_msgs/RobotTrajectory\ntrajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ExecuteKnownTrajectoryResponse(mros.Message):
    __slots__ = ['__id__','error_code']
    _slot_types = ['uint32','moveit_msgs/MoveItErrorCodes']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ExecuteKnownTrajectoryResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.error_code is None:
                self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()
        else:
            self.__id__ = 0
            self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.error_code.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.error_code.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.error_code.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"error_code":'
        string_echo += self.error_code.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ExecuteKnownTrajectory"

    def getMD5(self):
        return "af7da309bb25223035a7cfa762b8d4cd"
    def getDef(self):
        return "moveit_msgs/MoveItErrorCodes error_code\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ExecuteKnownTrajectory(object):
    Request = ExecuteKnownTrajectoryRequest
    Response = ExecuteKnownTrajectoryResponse

    __slots__ = ['request','response']
    _slot_types = ['ExecuteKnownTrajectoryRequest','ExecuteKnownTrajectoryResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ExecuteKnownTrajectory, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

