import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class DisplayRobotState(mros.Message):
    __slots__ = ['state','highlight_links','hide']
    _slot_types = ['moveit_msgs/RobotState','moveit_msgs/ObjectColor[]','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DisplayRobotState, self).__init__(*args, **kwds)
            if self.state is None:
                self.state = mros.moveit_msgs.msg.RobotState()
            if self.highlight_links is None:
                self.highlight_links = []
            if self.hide is None:
                self.hide = False
        else:
            self.state = mros.moveit_msgs.msg.RobotState()
            self.highlight_links = []
            self.hide = False

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.state.serialize(buff)
            highlight_links_length = len(self.highlight_links)
            buff.write(struct.pack('<I', highlight_links_length))
            offset += 4
            for i in range(0, highlight_links_length):
                offset += self.highlight_links[i].serialize(buff)
            struct_hide = struct.Struct("<B")
            buff.write(struct_hide.pack(self.hide))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.state.deserialize(buff[offset:])
            (highlight_links_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.highlight_links) != highlight_links_length:
                self.highlight_links = [mros.moveit_msgs.msg.ObjectColor() for _ in range(highlight_links_length)]
            for i in range(0, highlight_links_length):
                offset += self.highlight_links[i].deserialize(buff[offset:])
            struct_hide = struct.Struct("<B")
            (self.hide,) = struct_hide.unpack(buff[offset:(offset + 1)])
            self.hide = bool(self.hide)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.state.serializedLength()
        length += 4
        for i in range(0, highlight_links_length):
            length += self.highlight_links[i].serializedLength()
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"state":'
        string_echo += self.state.echo()
        string_echo += ','
        string_echo += '"highlight_links":['
        highlight_links_length = len(self.highlight_links)
        for i in range(0, highlight_links_length):
            if i == (highlight_links_length - 1): 
                string_echo += '{highlight_links%s":' % i
                string_echo += self.highlight_links[i].echo()
                string_echo += ''
            else:
                string_echo += '{highlight_links%s":' % i
                string_echo += self.highlight_links[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"hide":%s' % self.hide
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/DisplayRobotState"

    def getMD5(self):
        return "61c4e677a6fbbc83f0d5d9df2be85e3c"

    def getDef(self):
        return "moveit_msgs/RobotState state\nmoveit_msgs/ObjectColor[] highlight_links\nbool hide\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: moveit_msgs/ObjectColor\nstring id\nstd_msgs/ColorRGBA color\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: std_msgs/ColorRGBA\nfloat32 r\nfloat32 g\nfloat32 b\nfloat32 a\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

