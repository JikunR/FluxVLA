import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg

class CartesianTrajectory(mros.Message):
    __slots__ = ['header','tracked_frame','points']
    _slot_types = ['std_msgs/Header','string','moveit_msgs/CartesianTrajectoryPoint[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CartesianTrajectory, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.tracked_frame is None:
                self.tracked_frame = ''
            if self.points is None:
                self.points = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.tracked_frame = ''
            self.points = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            _x = self.tracked_frame
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            points_length = len(self.points)
            buff.write(struct.pack('<I', points_length))
            offset += 4
            for i in range(0, points_length):
                offset += self.points[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (length_tracked_frame,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.tracked_frame = buff[offset:(offset + length_tracked_frame)].decode('utf-8')
            else:
                self.tracked_frame = buff[offset:(offset + length_tracked_frame)]
            offset += length_tracked_frame
            (points_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.points) != points_length:
                self.points = [mros.moveit_msgs.msg.CartesianTrajectoryPoint() for _ in range(points_length)]
            for i in range(0, points_length):
                offset += self.points[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        tracked_frame_x = self.tracked_frame
        tracked_frame_length = len(tracked_frame_x)
        if python3 or type(tracked_frame_x) == unicode:
            tracked_frame_x = tracked_frame_x.encode('utf-8')
            tracked_frame_length = len(tracked_frame_x)
        length += 4
        length += tracked_frame_length
        length += 4
        for i in range(0, points_length):
            length += self.points[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"tracked_frame":"%s"' % self.tracked_frame
        string_echo += ','
        string_echo += '"points":['
        points_length = len(self.points)
        for i in range(0, points_length):
            if i == (points_length - 1): 
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ''
            else:
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/CartesianTrajectory"

    def getMD5(self):
        return "4886769850ce858fcceba546fd5c793b"

    def getDef(self):
        return "std_msgs/Header header\nstring tracked_frame\nmoveit_msgs/CartesianTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: moveit_msgs/CartesianTrajectoryPoint\nmoveit_msgs/CartesianPoint point\nduration time_from_start\n================================================================================\nMSG: moveit_msgs/CartesianPoint\ngeometry_msgs/Pose pose\ngeometry_msgs/Twist velocity\ngeometry_msgs/Accel acceleration\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Accel\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

