import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class ExecuteTrajectoryGoal(mros.Message):
    __slots__ = ['trajectory']
    _slot_types = ['moveit_msgs/RobotTrajectory']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ExecuteTrajectoryGoal, self).__init__(*args, **kwds)
            if self.trajectory is None:
                self.trajectory = mros.moveit_msgs.msg.RobotTrajectory()
        else:
            self.trajectory = mros.moveit_msgs.msg.RobotTrajectory()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.trajectory.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.trajectory.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.trajectory.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"trajectory":'
        string_echo += self.trajectory.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ExecuteTrajectoryGoal"

    def getMD5(self):
        return "054c09e62210d7faad2f9fffdad07b57"

    def getDef(self):
        return "moveit_msgs/RobotTrajectory trajectory\n================================================================================\nMSG: moveit_msgs/RobotTrajectory\ntrajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

