import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class OrientationConstraint(mros.Message):
    __slots__ = ['header','orientation','link_name','absolute_x_axis_tolerance','absolute_y_axis_tolerance','absolute_z_axis_tolerance','parameterization','weight']
    _slot_types = ['std_msgs/Header','geometry_msgs/Quaternion','string','float64','float64','float64','uint8','float64']

    XYZ_EULER_ANGLES = 0
    ROTATION_VECTOR = 1

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(OrientationConstraint, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.orientation is None:
                self.orientation = mros.geometry_msgs.msg.Quaternion()
            if self.link_name is None:
                self.link_name = ''
            if self.absolute_x_axis_tolerance is None:
                self.absolute_x_axis_tolerance = 0.
            if self.absolute_y_axis_tolerance is None:
                self.absolute_y_axis_tolerance = 0.
            if self.absolute_z_axis_tolerance is None:
                self.absolute_z_axis_tolerance = 0.
            if self.parameterization is None:
                self.parameterization = 0
            if self.weight is None:
                self.weight = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.orientation = mros.geometry_msgs.msg.Quaternion()
            self.link_name = ''
            self.absolute_x_axis_tolerance = 0.
            self.absolute_y_axis_tolerance = 0.
            self.absolute_z_axis_tolerance = 0.
            self.parameterization = 0
            self.weight = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.orientation.serialize(buff)
            _x = self.link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_absolute_x_axis_tolerance = struct.Struct("<d")
            buff.write(struct_absolute_x_axis_tolerance.pack(self.absolute_x_axis_tolerance))
            offset += 8
            struct_absolute_y_axis_tolerance = struct.Struct("<d")
            buff.write(struct_absolute_y_axis_tolerance.pack(self.absolute_y_axis_tolerance))
            offset += 8
            struct_absolute_z_axis_tolerance = struct.Struct("<d")
            buff.write(struct_absolute_z_axis_tolerance.pack(self.absolute_z_axis_tolerance))
            offset += 8
            struct_parameterization = struct.Struct("<B")
            buff.write(struct_parameterization.pack(self.parameterization))
            offset += 1
            struct_weight = struct.Struct("<d")
            buff.write(struct_weight.pack(self.weight))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.orientation.deserialize(buff[offset:])
            (length_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.link_name = buff[offset:(offset + length_link_name)].decode('utf-8')
            else:
                self.link_name = buff[offset:(offset + length_link_name)]
            offset += length_link_name
            struct_absolute_x_axis_tolerance = struct.Struct("<d")
            (self.absolute_x_axis_tolerance,) = struct_absolute_x_axis_tolerance.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_absolute_y_axis_tolerance = struct.Struct("<d")
            (self.absolute_y_axis_tolerance,) = struct_absolute_y_axis_tolerance.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_absolute_z_axis_tolerance = struct.Struct("<d")
            (self.absolute_z_axis_tolerance,) = struct_absolute_z_axis_tolerance.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_parameterization = struct.Struct("<B")
            (self.parameterization,) = struct_parameterization.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_weight = struct.Struct("<d")
            (self.weight,) = struct_weight.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.orientation.serializedLength()
        link_name_x = self.link_name
        link_name_length = len(link_name_x)
        if python3 or type(link_name_x) == unicode:
            link_name_x = link_name_x.encode('utf-8')
            link_name_length = len(link_name_x)
        length += 4
        length += link_name_length
        length += 8
        length += 8
        length += 8
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"orientation":'
        string_echo += self.orientation.echo()
        string_echo += ','
        string_echo += '"link_name":"%s"' % self.link_name
        string_echo += ','
        string_echo += '"absolute_x_axis_tolerance":%s' % self.absolute_x_axis_tolerance
        string_echo += ','
        string_echo += '"absolute_y_axis_tolerance":%s' % self.absolute_y_axis_tolerance
        string_echo += ','
        string_echo += '"absolute_z_axis_tolerance":%s' % self.absolute_z_axis_tolerance
        string_echo += ','
        string_echo += '"parameterization":%s' % self.parameterization
        string_echo += ','
        string_echo += '"weight":%s' % self.weight
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/OrientationConstraint"

    def getMD5(self):
        return "183479d9281e5b4f23dc584f711d8a64"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Quaternion orientation\nstring link_name\nfloat64 absolute_x_axis_tolerance\nfloat64 absolute_y_axis_tolerance\nfloat64 absolute_z_axis_tolerance\nuint8 parameterization\nuint8 XYZ_EULER_ANGLES=0\nuint8 ROTATION_VECTOR=1\nfloat64 weight\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

