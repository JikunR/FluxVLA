import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.actionlib_msgs.msg

class ExecuteTrajectoryActionResult(mros.Message):
    __slots__ = ['header','status','result']
    _slot_types = ['std_msgs/Header','actionlib_msgs/GoalStatus','moveit_msgs/ExecuteTrajectoryResult']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ExecuteTrajectoryActionResult, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.status is None:
                self.status = mros.actionlib_msgs.msg.GoalStatus()
            if self.result is None:
                self.result = mros.moveit_msgs.msg.ExecuteTrajectoryResult()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.status = mros.actionlib_msgs.msg.GoalStatus()
            self.result = mros.moveit_msgs.msg.ExecuteTrajectoryResult()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.status.serialize(buff)
            offset += self.result.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.status.deserialize(buff[offset:])
            offset += self.result.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.status.serializedLength()
        length += self.result.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ','
        string_echo += '"result":'
        string_echo += self.result.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ExecuteTrajectoryActionResult"

    def getMD5(self):
        return "2a052ef9772722c8338e057a61e60639"

    def getDef(self):
        return "std_msgs/Header header\nactionlib_msgs/GoalStatus status\nmoveit_msgs/ExecuteTrajectoryResult result\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalStatus\nactionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: moveit_msgs/ExecuteTrajectoryResult\nmoveit_msgs/MoveItErrorCodes error_code\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n"

_struct_I = struct.Struct('<I')

