import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class LinkPadding(mros.Message):
    __slots__ = ['link_name','padding']
    _slot_types = ['string','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(LinkPadding, self).__init__(*args, **kwds)
            if self.link_name is None:
                self.link_name = ''
            if self.padding is None:
                self.padding = 0.
        else:
            self.link_name = ''
            self.padding = 0.

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_padding = struct.Struct("<d")
            buff.write(struct_padding.pack(self.padding))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.link_name = buff[offset:(offset + length_link_name)].decode('utf-8')
            else:
                self.link_name = buff[offset:(offset + length_link_name)]
            offset += length_link_name
            struct_padding = struct.Struct("<d")
            (self.padding,) = struct_padding.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        link_name_x = self.link_name
        link_name_length = len(link_name_x)
        if python3 or type(link_name_x) == unicode:
            link_name_x = link_name_x.encode('utf-8')
            link_name_length = len(link_name_x)
        length += 4
        length += link_name_length
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"link_name":"%s"' % self.link_name
        string_echo += ','
        string_echo += '"padding":%s' % self.padding
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/LinkPadding"

    def getMD5(self):
        return "b3ea75670df55c696fedee97774d5947"

    def getDef(self):
        return "string link_name\nfloat64 padding\n"

_struct_I = struct.Struct('<I')

