import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.geometry_msgs.msg

class CartesianPoint(mros.Message):
    __slots__ = ['pose','velocity','acceleration']
    _slot_types = ['geometry_msgs/Pose','geometry_msgs/Twist','geometry_msgs/Accel']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CartesianPoint, self).__init__(*args, **kwds)
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
            if self.velocity is None:
                self.velocity = mros.geometry_msgs.msg.Twist()
            if self.acceleration is None:
                self.acceleration = mros.geometry_msgs.msg.Accel()
        else:
            self.pose = mros.geometry_msgs.msg.Pose()
            self.velocity = mros.geometry_msgs.msg.Twist()
            self.acceleration = mros.geometry_msgs.msg.Accel()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.pose.serialize(buff)
            offset += self.velocity.serialize(buff)
            offset += self.acceleration.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.pose.deserialize(buff[offset:])
            offset += self.velocity.deserialize(buff[offset:])
            offset += self.acceleration.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.pose.serializedLength()
        length += self.velocity.serializedLength()
        length += self.acceleration.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ','
        string_echo += '"velocity":'
        string_echo += self.velocity.echo()
        string_echo += ','
        string_echo += '"acceleration":'
        string_echo += self.acceleration.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/CartesianPoint"

    def getMD5(self):
        return "d3c213cdb4382c43adbff1f2dd2cf669"

    def getDef(self):
        return "geometry_msgs/Pose pose\ngeometry_msgs/Twist velocity\ngeometry_msgs/Accel acceleration\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Accel\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

