import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class JointConstraint(mros.Message):
    __slots__ = ['joint_name','position','tolerance_above','tolerance_below','weight']
    _slot_types = ['string','float64','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointConstraint, self).__init__(*args, **kwds)
            if self.joint_name is None:
                self.joint_name = ''
            if self.position is None:
                self.position = 0.
            if self.tolerance_above is None:
                self.tolerance_above = 0.
            if self.tolerance_below is None:
                self.tolerance_below = 0.
            if self.weight is None:
                self.weight = 0.
        else:
            self.joint_name = ''
            self.position = 0.
            self.tolerance_above = 0.
            self.tolerance_below = 0.
            self.weight = 0.

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.joint_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_position = struct.Struct("<d")
            buff.write(struct_position.pack(self.position))
            offset += 8
            struct_tolerance_above = struct.Struct("<d")
            buff.write(struct_tolerance_above.pack(self.tolerance_above))
            offset += 8
            struct_tolerance_below = struct.Struct("<d")
            buff.write(struct_tolerance_below.pack(self.tolerance_below))
            offset += 8
            struct_weight = struct.Struct("<d")
            buff.write(struct_weight.pack(self.weight))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_joint_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.joint_name = buff[offset:(offset + length_joint_name)].decode('utf-8')
            else:
                self.joint_name = buff[offset:(offset + length_joint_name)]
            offset += length_joint_name
            struct_position = struct.Struct("<d")
            (self.position,) = struct_position.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_tolerance_above = struct.Struct("<d")
            (self.tolerance_above,) = struct_tolerance_above.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_tolerance_below = struct.Struct("<d")
            (self.tolerance_below,) = struct_tolerance_below.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_weight = struct.Struct("<d")
            (self.weight,) = struct_weight.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        joint_name_x = self.joint_name
        joint_name_length = len(joint_name_x)
        if python3 or type(joint_name_x) == unicode:
            joint_name_x = joint_name_x.encode('utf-8')
            joint_name_length = len(joint_name_x)
        length += 4
        length += joint_name_length
        length += 8
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"joint_name":"%s"' % self.joint_name
        string_echo += ','
        string_echo += '"position":%s' % self.position
        string_echo += ','
        string_echo += '"tolerance_above":%s' % self.tolerance_above
        string_echo += ','
        string_echo += '"tolerance_below":%s' % self.tolerance_below
        string_echo += ','
        string_echo += '"weight":%s' % self.weight
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/JointConstraint"

    def getMD5(self):
        return "c02a15146bec0ce13564807805b008f0"

    def getDef(self):
        return "string joint_name\nfloat64 position\nfloat64 tolerance_above\nfloat64 tolerance_below\nfloat64 weight\n"

_struct_I = struct.Struct('<I')

