import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class Constraints(mros.Message):
    __slots__ = ['name','joint_constraints','position_constraints','orientation_constraints','visibility_constraints']
    _slot_types = ['string','moveit_msgs/JointConstraint[]','moveit_msgs/PositionConstraint[]','moveit_msgs/OrientationConstraint[]','moveit_msgs/VisibilityConstraint[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Constraints, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.joint_constraints is None:
                self.joint_constraints = []
            if self.position_constraints is None:
                self.position_constraints = []
            if self.orientation_constraints is None:
                self.orientation_constraints = []
            if self.visibility_constraints is None:
                self.visibility_constraints = []
        else:
            self.name = ''
            self.joint_constraints = []
            self.position_constraints = []
            self.orientation_constraints = []
            self.visibility_constraints = []

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            joint_constraints_length = len(self.joint_constraints)
            buff.write(struct.pack('<I', joint_constraints_length))
            offset += 4
            for i in range(0, joint_constraints_length):
                offset += self.joint_constraints[i].serialize(buff)
            position_constraints_length = len(self.position_constraints)
            buff.write(struct.pack('<I', position_constraints_length))
            offset += 4
            for i in range(0, position_constraints_length):
                offset += self.position_constraints[i].serialize(buff)
            orientation_constraints_length = len(self.orientation_constraints)
            buff.write(struct.pack('<I', orientation_constraints_length))
            offset += 4
            for i in range(0, orientation_constraints_length):
                offset += self.orientation_constraints[i].serialize(buff)
            visibility_constraints_length = len(self.visibility_constraints)
            buff.write(struct.pack('<I', visibility_constraints_length))
            offset += 4
            for i in range(0, visibility_constraints_length):
                offset += self.visibility_constraints[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (joint_constraints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.joint_constraints) != joint_constraints_length:
                self.joint_constraints = [mros.moveit_msgs.msg.JointConstraint() for _ in range(joint_constraints_length)]
            for i in range(0, joint_constraints_length):
                offset += self.joint_constraints[i].deserialize(buff[offset:])
            (position_constraints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.position_constraints) != position_constraints_length:
                self.position_constraints = [mros.moveit_msgs.msg.PositionConstraint() for _ in range(position_constraints_length)]
            for i in range(0, position_constraints_length):
                offset += self.position_constraints[i].deserialize(buff[offset:])
            (orientation_constraints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.orientation_constraints) != orientation_constraints_length:
                self.orientation_constraints = [mros.moveit_msgs.msg.OrientationConstraint() for _ in range(orientation_constraints_length)]
            for i in range(0, orientation_constraints_length):
                offset += self.orientation_constraints[i].deserialize(buff[offset:])
            (visibility_constraints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.visibility_constraints) != visibility_constraints_length:
                self.visibility_constraints = [mros.moveit_msgs.msg.VisibilityConstraint() for _ in range(visibility_constraints_length)]
            for i in range(0, visibility_constraints_length):
                offset += self.visibility_constraints[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        length += 4
        for i in range(0, joint_constraints_length):
            length += self.joint_constraints[i].serializedLength()
        length += 4
        for i in range(0, position_constraints_length):
            length += self.position_constraints[i].serializedLength()
        length += 4
        for i in range(0, orientation_constraints_length):
            length += self.orientation_constraints[i].serializedLength()
        length += 4
        for i in range(0, visibility_constraints_length):
            length += self.visibility_constraints[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"joint_constraints":['
        joint_constraints_length = len(self.joint_constraints)
        for i in range(0, joint_constraints_length):
            if i == (joint_constraints_length - 1): 
                string_echo += '{joint_constraints%s":' % i
                string_echo += self.joint_constraints[i].echo()
                string_echo += ''
            else:
                string_echo += '{joint_constraints%s":' % i
                string_echo += self.joint_constraints[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"position_constraints":['
        position_constraints_length = len(self.position_constraints)
        for i in range(0, position_constraints_length):
            if i == (position_constraints_length - 1): 
                string_echo += '{position_constraints%s":' % i
                string_echo += self.position_constraints[i].echo()
                string_echo += ''
            else:
                string_echo += '{position_constraints%s":' % i
                string_echo += self.position_constraints[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"orientation_constraints":['
        orientation_constraints_length = len(self.orientation_constraints)
        for i in range(0, orientation_constraints_length):
            if i == (orientation_constraints_length - 1): 
                string_echo += '{orientation_constraints%s":' % i
                string_echo += self.orientation_constraints[i].echo()
                string_echo += ''
            else:
                string_echo += '{orientation_constraints%s":' % i
                string_echo += self.orientation_constraints[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"visibility_constraints":['
        visibility_constraints_length = len(self.visibility_constraints)
        for i in range(0, visibility_constraints_length):
            if i == (visibility_constraints_length - 1): 
                string_echo += '{visibility_constraints%s":' % i
                string_echo += self.visibility_constraints[i].echo()
                string_echo += ''
            else:
                string_echo += '{visibility_constraints%s":' % i
                string_echo += self.visibility_constraints[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/Constraints"

    def getMD5(self):
        return "cfd22a10c51e0dc2b28d98772d2b55d5"

    def getDef(self):
        return "string name\nmoveit_msgs/JointConstraint[] joint_constraints\nmoveit_msgs/PositionConstraint[] position_constraints\nmoveit_msgs/OrientationConstraint[] orientation_constraints\nmoveit_msgs/VisibilityConstraint[] visibility_constraints\n================================================================================\nMSG: moveit_msgs/JointConstraint\nstring joint_name\nfloat64 position\nfloat64 tolerance_above\nfloat64 tolerance_below\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PositionConstraint\nstd_msgs/Header header\nstring link_name\ngeometry_msgs/Vector3 target_point_offset\nmoveit_msgs/BoundingVolume constraint_region\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/OrientationConstraint\nstd_msgs/Header header\ngeometry_msgs/Quaternion orientation\nstring link_name\nfloat64 absolute_x_axis_tolerance\nfloat64 absolute_y_axis_tolerance\nfloat64 absolute_z_axis_tolerance\nuint8 parameterization\nuint8 XYZ_EULER_ANGLES=0\nuint8 ROTATION_VECTOR=1\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/VisibilityConstraint\nfloat64 target_radius\ngeometry_msgs/PoseStamped target_pose\nint32 cone_sides\ngeometry_msgs/PoseStamped sensor_pose\nfloat64 max_view_angle\nfloat64 max_range_angle\nuint8 SENSOR_Z=0\nuint8 SENSOR_Y=1\nuint8 SENSOR_X=2\nuint8 sensor_view_direction\nfloat64 weight\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: moveit_msgs/BoundingVolume\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

