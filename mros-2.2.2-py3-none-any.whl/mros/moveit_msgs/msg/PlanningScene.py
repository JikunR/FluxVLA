import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.geometry_msgs.msg

class PlanningScene(mros.Message):
    __slots__ = ['name','robot_state','robot_model_name','fixed_frame_transforms','allowed_collision_matrix','link_padding','link_scale','object_colors','world','is_diff']
    _slot_types = ['string','moveit_msgs/RobotState','string','geometry_msgs/TransformStamped[]','moveit_msgs/AllowedCollisionMatrix','moveit_msgs/LinkPadding[]','moveit_msgs/LinkScale[]','moveit_msgs/ObjectColor[]','moveit_msgs/PlanningSceneWorld','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlanningScene, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.robot_state is None:
                self.robot_state = mros.moveit_msgs.msg.RobotState()
            if self.robot_model_name is None:
                self.robot_model_name = ''
            if self.fixed_frame_transforms is None:
                self.fixed_frame_transforms = []
            if self.allowed_collision_matrix is None:
                self.allowed_collision_matrix = mros.moveit_msgs.msg.AllowedCollisionMatrix()
            if self.link_padding is None:
                self.link_padding = []
            if self.link_scale is None:
                self.link_scale = []
            if self.object_colors is None:
                self.object_colors = []
            if self.world is None:
                self.world = mros.moveit_msgs.msg.PlanningSceneWorld()
            if self.is_diff is None:
                self.is_diff = False
        else:
            self.name = ''
            self.robot_state = mros.moveit_msgs.msg.RobotState()
            self.robot_model_name = ''
            self.fixed_frame_transforms = []
            self.allowed_collision_matrix = mros.moveit_msgs.msg.AllowedCollisionMatrix()
            self.link_padding = []
            self.link_scale = []
            self.object_colors = []
            self.world = mros.moveit_msgs.msg.PlanningSceneWorld()
            self.is_diff = False

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.robot_state.serialize(buff)
            _x = self.robot_model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            fixed_frame_transforms_length = len(self.fixed_frame_transforms)
            buff.write(struct.pack('<I', fixed_frame_transforms_length))
            offset += 4
            for i in range(0, fixed_frame_transforms_length):
                offset += self.fixed_frame_transforms[i].serialize(buff)
            offset += self.allowed_collision_matrix.serialize(buff)
            link_padding_length = len(self.link_padding)
            buff.write(struct.pack('<I', link_padding_length))
            offset += 4
            for i in range(0, link_padding_length):
                offset += self.link_padding[i].serialize(buff)
            link_scale_length = len(self.link_scale)
            buff.write(struct.pack('<I', link_scale_length))
            offset += 4
            for i in range(0, link_scale_length):
                offset += self.link_scale[i].serialize(buff)
            object_colors_length = len(self.object_colors)
            buff.write(struct.pack('<I', object_colors_length))
            offset += 4
            for i in range(0, object_colors_length):
                offset += self.object_colors[i].serialize(buff)
            offset += self.world.serialize(buff)
            struct_is_diff = struct.Struct("<B")
            buff.write(struct_is_diff.pack(self.is_diff))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            offset += self.robot_state.deserialize(buff[offset:])
            (length_robot_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.robot_model_name = buff[offset:(offset + length_robot_model_name)].decode('utf-8')
            else:
                self.robot_model_name = buff[offset:(offset + length_robot_model_name)]
            offset += length_robot_model_name
            (fixed_frame_transforms_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.fixed_frame_transforms) != fixed_frame_transforms_length:
                self.fixed_frame_transforms = [mros.geometry_msgs.msg.TransformStamped() for _ in range(fixed_frame_transforms_length)]
            for i in range(0, fixed_frame_transforms_length):
                offset += self.fixed_frame_transforms[i].deserialize(buff[offset:])
            offset += self.allowed_collision_matrix.deserialize(buff[offset:])
            (link_padding_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.link_padding) != link_padding_length:
                self.link_padding = [mros.moveit_msgs.msg.LinkPadding() for _ in range(link_padding_length)]
            for i in range(0, link_padding_length):
                offset += self.link_padding[i].deserialize(buff[offset:])
            (link_scale_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.link_scale) != link_scale_length:
                self.link_scale = [mros.moveit_msgs.msg.LinkScale() for _ in range(link_scale_length)]
            for i in range(0, link_scale_length):
                offset += self.link_scale[i].deserialize(buff[offset:])
            (object_colors_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.object_colors) != object_colors_length:
                self.object_colors = [mros.moveit_msgs.msg.ObjectColor() for _ in range(object_colors_length)]
            for i in range(0, object_colors_length):
                offset += self.object_colors[i].deserialize(buff[offset:])
            offset += self.world.deserialize(buff[offset:])
            struct_is_diff = struct.Struct("<B")
            (self.is_diff,) = struct_is_diff.unpack(buff[offset:(offset + 1)])
            self.is_diff = bool(self.is_diff)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        length += self.robot_state.serializedLength()
        robot_model_name_x = self.robot_model_name
        robot_model_name_length = len(robot_model_name_x)
        if python3 or type(robot_model_name_x) == unicode:
            robot_model_name_x = robot_model_name_x.encode('utf-8')
            robot_model_name_length = len(robot_model_name_x)
        length += 4
        length += robot_model_name_length
        length += 4
        for i in range(0, fixed_frame_transforms_length):
            length += self.fixed_frame_transforms[i].serializedLength()
        length += self.allowed_collision_matrix.serializedLength()
        length += 4
        for i in range(0, link_padding_length):
            length += self.link_padding[i].serializedLength()
        length += 4
        for i in range(0, link_scale_length):
            length += self.link_scale[i].serializedLength()
        length += 4
        for i in range(0, object_colors_length):
            length += self.object_colors[i].serializedLength()
        length += self.world.serializedLength()
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"robot_state":'
        string_echo += self.robot_state.echo()
        string_echo += ','
        string_echo += '"robot_model_name":"%s"' % self.robot_model_name
        string_echo += ','
        string_echo += '"fixed_frame_transforms":['
        fixed_frame_transforms_length = len(self.fixed_frame_transforms)
        for i in range(0, fixed_frame_transforms_length):
            if i == (fixed_frame_transforms_length - 1): 
                string_echo += '{fixed_frame_transforms%s":' % i
                string_echo += self.fixed_frame_transforms[i].echo()
                string_echo += ''
            else:
                string_echo += '{fixed_frame_transforms%s":' % i
                string_echo += self.fixed_frame_transforms[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"allowed_collision_matrix":'
        string_echo += self.allowed_collision_matrix.echo()
        string_echo += ','
        string_echo += '"link_padding":['
        link_padding_length = len(self.link_padding)
        for i in range(0, link_padding_length):
            if i == (link_padding_length - 1): 
                string_echo += '{link_padding%s":' % i
                string_echo += self.link_padding[i].echo()
                string_echo += ''
            else:
                string_echo += '{link_padding%s":' % i
                string_echo += self.link_padding[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"link_scale":['
        link_scale_length = len(self.link_scale)
        for i in range(0, link_scale_length):
            if i == (link_scale_length - 1): 
                string_echo += '{link_scale%s":' % i
                string_echo += self.link_scale[i].echo()
                string_echo += ''
            else:
                string_echo += '{link_scale%s":' % i
                string_echo += self.link_scale[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"object_colors":['
        object_colors_length = len(self.object_colors)
        for i in range(0, object_colors_length):
            if i == (object_colors_length - 1): 
                string_echo += '{object_colors%s":' % i
                string_echo += self.object_colors[i].echo()
                string_echo += ''
            else:
                string_echo += '{object_colors%s":' % i
                string_echo += self.object_colors[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"world":'
        string_echo += self.world.echo()
        string_echo += ','
        string_echo += '"is_diff":%s' % self.is_diff
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PlanningScene"

    def getMD5(self):
        return "acfc50bcfd6c7b978066bfa7c786002c"

    def getDef(self):
        return "string name\nmoveit_msgs/RobotState robot_state\nstring robot_model_name\ngeometry_msgs/TransformStamped[] fixed_frame_transforms\nmoveit_msgs/AllowedCollisionMatrix allowed_collision_matrix\nmoveit_msgs/LinkPadding[] link_padding\nmoveit_msgs/LinkScale[] link_scale\nmoveit_msgs/ObjectColor[] object_colors\nmoveit_msgs/PlanningSceneWorld world\nbool is_diff\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: geometry_msgs/TransformStamped\nstd_msgs/Header header\nstring child_frame_id\ngeometry_msgs/Transform transform\n================================================================================\nMSG: moveit_msgs/AllowedCollisionMatrix\nstring[] entry_names\nmoveit_msgs/AllowedCollisionEntry[] entry_values\nstring[] default_entry_names\nbool[] default_entry_values\n================================================================================\nMSG: moveit_msgs/LinkPadding\nstring link_name\nfloat64 padding\n================================================================================\nMSG: moveit_msgs/LinkScale\nstring link_name\nfloat64 scale\n================================================================================\nMSG: moveit_msgs/ObjectColor\nstring id\nstd_msgs/ColorRGBA color\n================================================================================\nMSG: moveit_msgs/PlanningSceneWorld\nmoveit_msgs/CollisionObject[] collision_objects\noctomap_msgs/OctomapWithPose octomap\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: moveit_msgs/AllowedCollisionEntry\nbool[] enabled\n================================================================================\nMSG: std_msgs/ColorRGBA\nfloat32 r\nfloat32 g\nfloat32 b\nfloat32 a\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: octomap_msgs/OctomapWithPose\nstd_msgs/Header header\ngeometry_msgs/Pose origin\noctomap_msgs/Octomap octomap\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: octomap_msgs/Octomap\nstd_msgs/Header header\nbool binary\nstring id\nfloat64 resolution\nint8[] data\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

