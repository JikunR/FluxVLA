import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.trajectory_msgs.msg

class GenericTrajectory(mros.Message):
    __slots__ = ['header','joint_trajectory','cartesian_trajectory']
    _slot_types = ['std_msgs/Header','trajectory_msgs/JointTrajectory[]','moveit_msgs/CartesianTrajectory[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GenericTrajectory, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.joint_trajectory is None:
                self.joint_trajectory = []
            if self.cartesian_trajectory is None:
                self.cartesian_trajectory = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.joint_trajectory = []
            self.cartesian_trajectory = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            joint_trajectory_length = len(self.joint_trajectory)
            buff.write(struct.pack('<I', joint_trajectory_length))
            offset += 4
            for i in range(0, joint_trajectory_length):
                offset += self.joint_trajectory[i].serialize(buff)
            cartesian_trajectory_length = len(self.cartesian_trajectory)
            buff.write(struct.pack('<I', cartesian_trajectory_length))
            offset += 4
            for i in range(0, cartesian_trajectory_length):
                offset += self.cartesian_trajectory[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (joint_trajectory_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.joint_trajectory) != joint_trajectory_length:
                self.joint_trajectory = [mros.trajectory_msgs.msg.JointTrajectory() for _ in range(joint_trajectory_length)]
            for i in range(0, joint_trajectory_length):
                offset += self.joint_trajectory[i].deserialize(buff[offset:])
            (cartesian_trajectory_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.cartesian_trajectory) != cartesian_trajectory_length:
                self.cartesian_trajectory = [mros.moveit_msgs.msg.CartesianTrajectory() for _ in range(cartesian_trajectory_length)]
            for i in range(0, cartesian_trajectory_length):
                offset += self.cartesian_trajectory[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, joint_trajectory_length):
            length += self.joint_trajectory[i].serializedLength()
        length += 4
        for i in range(0, cartesian_trajectory_length):
            length += self.cartesian_trajectory[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"joint_trajectory":['
        joint_trajectory_length = len(self.joint_trajectory)
        for i in range(0, joint_trajectory_length):
            if i == (joint_trajectory_length - 1): 
                string_echo += '{joint_trajectory%s":' % i
                string_echo += self.joint_trajectory[i].echo()
                string_echo += ''
            else:
                string_echo += '{joint_trajectory%s":' % i
                string_echo += self.joint_trajectory[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"cartesian_trajectory":['
        cartesian_trajectory_length = len(self.cartesian_trajectory)
        for i in range(0, cartesian_trajectory_length):
            if i == (cartesian_trajectory_length - 1): 
                string_echo += '{cartesian_trajectory%s":' % i
                string_echo += self.cartesian_trajectory[i].echo()
                string_echo += ''
            else:
                string_echo += '{cartesian_trajectory%s":' % i
                string_echo += self.cartesian_trajectory[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/GenericTrajectory"

    def getMD5(self):
        return "d68b5c73072efa2012238a77e49c2c58"

    def getDef(self):
        return "std_msgs/Header header\ntrajectory_msgs/JointTrajectory[] joint_trajectory\nmoveit_msgs/CartesianTrajectory[] cartesian_trajectory\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: moveit_msgs/CartesianTrajectory\nstd_msgs/Header header\nstring tracked_frame\nmoveit_msgs/CartesianTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: moveit_msgs/CartesianTrajectoryPoint\nmoveit_msgs/CartesianPoint point\nduration time_from_start\n================================================================================\nMSG: moveit_msgs/CartesianPoint\ngeometry_msgs/Pose pose\ngeometry_msgs/Twist velocity\ngeometry_msgs/Accel acceleration\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Accel\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

