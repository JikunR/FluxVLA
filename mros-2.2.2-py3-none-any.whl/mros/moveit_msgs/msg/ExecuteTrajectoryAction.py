import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class ExecuteTrajectoryAction(mros.Message):
    __slots__ = ['action_goal','action_result','action_feedback']
    _slot_types = ['moveit_msgs/ExecuteTrajectoryActionGoal','moveit_msgs/ExecuteTrajectoryActionResult','moveit_msgs/ExecuteTrajectoryActionFeedback']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ExecuteTrajectoryAction, self).__init__(*args, **kwds)
            if self.action_goal is None:
                self.action_goal = mros.moveit_msgs.msg.ExecuteTrajectoryActionGoal()
            if self.action_result is None:
                self.action_result = mros.moveit_msgs.msg.ExecuteTrajectoryActionResult()
            if self.action_feedback is None:
                self.action_feedback = mros.moveit_msgs.msg.ExecuteTrajectoryActionFeedback()
        else:
            self.action_goal = mros.moveit_msgs.msg.ExecuteTrajectoryActionGoal()
            self.action_result = mros.moveit_msgs.msg.ExecuteTrajectoryActionResult()
            self.action_feedback = mros.moveit_msgs.msg.ExecuteTrajectoryActionFeedback()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.serialize(buff)
            offset += self.action_result.serialize(buff)
            offset += self.action_feedback.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.deserialize(buff[offset:])
            offset += self.action_result.deserialize(buff[offset:])
            offset += self.action_feedback.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.action_goal.serializedLength()
        length += self.action_result.serializedLength()
        length += self.action_feedback.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"action_goal":'
        string_echo += self.action_goal.echo()
        string_echo += ','
        string_echo += '"action_result":'
        string_echo += self.action_result.echo()
        string_echo += ','
        string_echo += '"action_feedback":'
        string_echo += self.action_feedback.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ExecuteTrajectoryAction"

    def getMD5(self):
        return "add56f6df2e6f2ee8830e030d0953807"

    def getDef(self):
        return "moveit_msgs/ExecuteTrajectoryActionGoal action_goal\nmoveit_msgs/ExecuteTrajectoryActionResult action_result\nmoveit_msgs/ExecuteTrajectoryActionFeedback action_feedback\n================================================================================\nMSG: moveit_msgs/ExecuteTrajectoryActionGoal\nstd_msgs/Header header\nactionlib_msgs/GoalID goal_id\nmoveit_msgs/ExecuteTrajectoryGoal goal\n================================================================================\nMSG: moveit_msgs/ExecuteTrajectoryActionResult\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nmoveit_msgs/ExecuteTrajectoryResult result\n================================================================================\nMSG: moveit_msgs/ExecuteTrajectoryActionFeedback\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nmoveit_msgs/ExecuteTrajectoryFeedback feedback\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: moveit_msgs/ExecuteTrajectoryGoal\nmoveit_msgs/RobotTrajectory trajectory\n================================================================================\nMSG: actionlib_msgs/GoalStatus\nactionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: moveit_msgs/ExecuteTrajectoryResult\nmoveit_msgs/MoveItErrorCodes error_code\n================================================================================\nMSG: moveit_msgs/ExecuteTrajectoryFeedback\nstring state\n================================================================================\nMSG: moveit_msgs/RobotTrajectory\ntrajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

