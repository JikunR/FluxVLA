import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.geometry_msgs.msg

class PositionIKRequest(mros.Message):
    __slots__ = ['group_name','robot_state','constraints','avoid_collisions','ik_link_name','pose_stamped','ik_link_names','pose_stamped_vector','timeout']
    _slot_types = ['string','moveit_msgs/RobotState','moveit_msgs/Constraints','bool','string','geometry_msgs/PoseStamped','string[]','geometry_msgs/PoseStamped[]','Duration']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PositionIKRequest, self).__init__(*args, **kwds)
            if self.group_name is None:
                self.group_name = ''
            if self.robot_state is None:
                self.robot_state = mros.moveit_msgs.msg.RobotState()
            if self.constraints is None:
                self.constraints = mros.moveit_msgs.msg.Constraints()
            if self.avoid_collisions is None:
                self.avoid_collisions = False
            if self.ik_link_name is None:
                self.ik_link_name = ''
            if self.pose_stamped is None:
                self.pose_stamped = mros.geometry_msgs.msg.PoseStamped()
            if self.ik_link_names is None:
                self.ik_link_names = []
            if self.pose_stamped_vector is None:
                self.pose_stamped_vector = []
            if self.timeout is None:
                self.timeout = mros.Duration()
        else:
            self.group_name = ''
            self.robot_state = mros.moveit_msgs.msg.RobotState()
            self.constraints = mros.moveit_msgs.msg.Constraints()
            self.avoid_collisions = False
            self.ik_link_name = ''
            self.pose_stamped = mros.geometry_msgs.msg.PoseStamped()
            self.ik_link_names = []
            self.pose_stamped_vector = []
            self.timeout = mros.Duration()

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.group_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.robot_state.serialize(buff)
            offset += self.constraints.serialize(buff)
            struct_avoid_collisions = struct.Struct("<B")
            buff.write(struct_avoid_collisions.pack(self.avoid_collisions))
            offset += 1
            _x = self.ik_link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.pose_stamped.serialize(buff)
            ik_link_names_length = len(self.ik_link_names)
            buff.write(struct.pack('<I', ik_link_names_length))
            offset += 4
            for i in range(0, ik_link_names_length):
                _x = self.ik_link_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            pose_stamped_vector_length = len(self.pose_stamped_vector)
            buff.write(struct.pack('<I', pose_stamped_vector_length))
            offset += 4
            for i in range(0, pose_stamped_vector_length):
                offset += self.pose_stamped_vector[i].serialize(buff)
            buff.write(_struct_I.pack(self.timeout.sec))
            offset += 4
            buff.write(_struct_I.pack(self.timeout.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_group_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.group_name = buff[offset:(offset + length_group_name)].decode('utf-8')
            else:
                self.group_name = buff[offset:(offset + length_group_name)]
            offset += length_group_name
            offset += self.robot_state.deserialize(buff[offset:])
            offset += self.constraints.deserialize(buff[offset:])
            struct_avoid_collisions = struct.Struct("<B")
            (self.avoid_collisions,) = struct_avoid_collisions.unpack(buff[offset:(offset + 1)])
            self.avoid_collisions = bool(self.avoid_collisions)
            offset += 1
            (length_ik_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.ik_link_name = buff[offset:(offset + length_ik_link_name)].decode('utf-8')
            else:
                self.ik_link_name = buff[offset:(offset + length_ik_link_name)]
            offset += length_ik_link_name
            offset += self.pose_stamped.deserialize(buff[offset:])
            (ik_link_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.ik_link_names) != ik_link_names_length:
                self.ik_link_names = ['' for _ in range(ik_link_names_length)]
            for i in range(0, ik_link_names_length):
                (length_ik_link_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.ik_link_names[i] = buff[offset:(offset + length_ik_link_namesi)].decode('utf-8')
                else:
                    self.ik_link_names[i] = buff[offset:(offset + length_ik_link_namesi)]
                offset += length_ik_link_namesi
            (pose_stamped_vector_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.pose_stamped_vector) != pose_stamped_vector_length:
                self.pose_stamped_vector = [mros.geometry_msgs.msg.PoseStamped() for _ in range(pose_stamped_vector_length)]
            for i in range(0, pose_stamped_vector_length):
                offset += self.pose_stamped_vector[i].deserialize(buff[offset:])
            (self.timeout.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.timeout.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        group_name_x = self.group_name
        group_name_length = len(group_name_x)
        if python3 or type(group_name_x) == unicode:
            group_name_x = group_name_x.encode('utf-8')
            group_name_length = len(group_name_x)
        length += 4
        length += group_name_length
        length += self.robot_state.serializedLength()
        length += self.constraints.serializedLength()
        length += 1
        ik_link_name_x = self.ik_link_name
        ik_link_name_length = len(ik_link_name_x)
        if python3 or type(ik_link_name_x) == unicode:
            ik_link_name_x = ik_link_name_x.encode('utf-8')
            ik_link_name_length = len(ik_link_name_x)
        length += 4
        length += ik_link_name_length
        length += self.pose_stamped.serializedLength()
        length += 4
        for i in range(0, ik_link_names_length):
            ik_link_namesi_x = self.ik_link_names[i]
            ik_link_namesi_length = len(ik_link_namesi_x)
            if python3 or type(ik_link_namesi_x) == unicode:
                ik_link_namesi_x = ik_link_namesi_x.encode('utf-8')
                ik_link_namesi_length = len(ik_link_namesi_x)
            length += 4
            length += ik_link_namesi_length
        length += 4
        for i in range(0, pose_stamped_vector_length):
            length += self.pose_stamped_vector[i].serializedLength()
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"group_name":"%s"' % self.group_name
        string_echo += ','
        string_echo += '"robot_state":'
        string_echo += self.robot_state.echo()
        string_echo += ','
        string_echo += '"constraints":'
        string_echo += self.constraints.echo()
        string_echo += ','
        string_echo += '"avoid_collisions":%s' % self.avoid_collisions
        string_echo += ','
        string_echo += '"ik_link_name":"%s"' % self.ik_link_name
        string_echo += ','
        string_echo += '"pose_stamped":'
        string_echo += self.pose_stamped.echo()
        string_echo += ','
        string_echo += '"ik_link_names":['
        ik_link_names_length = len(self.ik_link_names)
        for i in range(0, ik_link_names_length):
            if i == (ik_link_names_length - 1): 
                string_echo += '"ik_link_names[i]":"%s"' % self.ik_link_names[i]
                string_echo += ''
            else:
                string_echo += '"ik_link_names[i]":"%s"' % self.ik_link_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"pose_stamped_vector":['
        pose_stamped_vector_length = len(self.pose_stamped_vector)
        for i in range(0, pose_stamped_vector_length):
            if i == (pose_stamped_vector_length - 1): 
                string_echo += '{pose_stamped_vector%s":' % i
                string_echo += self.pose_stamped_vector[i].echo()
                string_echo += ''
            else:
                string_echo += '{pose_stamped_vector%s":' % i
                string_echo += self.pose_stamped_vector[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"timeout.sec":%s,' % self.timeout.sec
        string_echo += '"timeout.nsec":%s' % self.timeout.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PositionIKRequest"

    def getMD5(self):
        return "cb7c3615ee4d29d023dfdc5950af0504"

    def getDef(self):
        return "string group_name\nmoveit_msgs/RobotState robot_state\nmoveit_msgs/Constraints constraints\nbool avoid_collisions\nstring ik_link_name\ngeometry_msgs/PoseStamped pose_stamped\nstring[] ik_link_names\ngeometry_msgs/PoseStamped[] pose_stamped_vector\nduration timeout\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: moveit_msgs/Constraints\nstring name\nmoveit_msgs/JointConstraint[] joint_constraints\nmoveit_msgs/PositionConstraint[] position_constraints\nmoveit_msgs/OrientationConstraint[] orientation_constraints\nmoveit_msgs/VisibilityConstraint[] visibility_constraints\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/JointConstraint\nstring joint_name\nfloat64 position\nfloat64 tolerance_above\nfloat64 tolerance_below\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PositionConstraint\nstd_msgs/Header header\nstring link_name\ngeometry_msgs/Vector3 target_point_offset\nmoveit_msgs/BoundingVolume constraint_region\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/OrientationConstraint\nstd_msgs/Header header\ngeometry_msgs/Quaternion orientation\nstring link_name\nfloat64 absolute_x_axis_tolerance\nfloat64 absolute_y_axis_tolerance\nfloat64 absolute_z_axis_tolerance\nuint8 parameterization\nuint8 XYZ_EULER_ANGLES=0\nuint8 ROTATION_VECTOR=1\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/VisibilityConstraint\nfloat64 target_radius\ngeometry_msgs/PoseStamped target_pose\nint32 cone_sides\ngeometry_msgs/PoseStamped sensor_pose\nfloat64 max_view_angle\nfloat64 max_range_angle\nuint8 SENSOR_Z=0\nuint8 SENSOR_Y=1\nuint8 SENSOR_X=2\nuint8 sensor_view_direction\nfloat64 weight\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: moveit_msgs/BoundingVolume\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

