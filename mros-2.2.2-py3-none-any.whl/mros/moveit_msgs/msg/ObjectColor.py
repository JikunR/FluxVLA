import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg

class ObjectColor(mros.Message):
    __slots__ = ['id','color']
    _slot_types = ['string','std_msgs/ColorRGBA']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ObjectColor, self).__init__(*args, **kwds)
            if self.id is None:
                self.id = ''
            if self.color is None:
                self.color = mros.std_msgs.msg.ColorRGBA()
        else:
            self.id = ''
            self.color = mros.std_msgs.msg.ColorRGBA()

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.color.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.id = buff[offset:(offset + length_id)].decode('utf-8')
            else:
                self.id = buff[offset:(offset + length_id)]
            offset += length_id
            offset += self.color.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        id_x = self.id
        id_length = len(id_x)
        if python3 or type(id_x) == unicode:
            id_x = id_x.encode('utf-8')
            id_length = len(id_x)
        length += 4
        length += id_length
        length += self.color.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"id":"%s"' % self.id
        string_echo += ','
        string_echo += '"color":'
        string_echo += self.color.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ObjectColor"

    def getMD5(self):
        return "ec3bd6f103430e64b2ae706a67d8488e"

    def getDef(self):
        return "string id\nstd_msgs/ColorRGBA color\n================================================================================\nMSG: std_msgs/ColorRGBA\nfloat32 r\nfloat32 g\nfloat32 b\nfloat32 a\n"

_struct_I = struct.Struct('<I')

