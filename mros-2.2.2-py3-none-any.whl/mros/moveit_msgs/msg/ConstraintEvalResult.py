import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class ConstraintEvalResult(mros.Message):
    __slots__ = ['result','distance']
    _slot_types = ['bool','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ConstraintEvalResult, self).__init__(*args, **kwds)
            if self.result is None:
                self.result = False
            if self.distance is None:
                self.distance = 0.
        else:
            self.result = False
            self.distance = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_result = struct.Struct("<B")
            buff.write(struct_result.pack(self.result))
            offset += 1
            struct_distance = struct.Struct("<d")
            buff.write(struct_distance.pack(self.distance))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_result = struct.Struct("<B")
            (self.result,) = struct_result.unpack(buff[offset:(offset + 1)])
            self.result = bool(self.result)
            offset += 1
            struct_distance = struct.Struct("<d")
            (self.distance,) = struct_distance.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"result":%s' % self.result
        string_echo += ','
        string_echo += '"distance":%s' % self.distance
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ConstraintEvalResult"

    def getMD5(self):
        return "093643083d24f6488cb5a868bd47c090"

    def getDef(self):
        return "bool result\nfloat64 distance\n"

_struct_I = struct.Struct('<I')

