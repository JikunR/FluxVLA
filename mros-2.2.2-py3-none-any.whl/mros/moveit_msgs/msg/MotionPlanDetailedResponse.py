import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class MotionPlanDetailedResponse(mros.Message):
    __slots__ = ['trajectory_start','group_name','trajectory','description','processing_time','error_code']
    _slot_types = ['moveit_msgs/RobotState','string','moveit_msgs/RobotTrajectory[]','string[]','float64[]','moveit_msgs/MoveItErrorCodes']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MotionPlanDetailedResponse, self).__init__(*args, **kwds)
            if self.trajectory_start is None:
                self.trajectory_start = mros.moveit_msgs.msg.RobotState()
            if self.group_name is None:
                self.group_name = ''
            if self.trajectory is None:
                self.trajectory = []
            if self.description is None:
                self.description = []
            if self.processing_time is None:
                self.processing_time = []
            if self.error_code is None:
                self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()
        else:
            self.trajectory_start = mros.moveit_msgs.msg.RobotState()
            self.group_name = ''
            self.trajectory = []
            self.description = []
            self.processing_time = []
            self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.trajectory_start.serialize(buff)
            _x = self.group_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            trajectory_length = len(self.trajectory)
            buff.write(struct.pack('<I', trajectory_length))
            offset += 4
            for i in range(0, trajectory_length):
                offset += self.trajectory[i].serialize(buff)
            description_length = len(self.description)
            buff.write(struct.pack('<I', description_length))
            offset += 4
            for i in range(0, description_length):
                _x = self.description[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            processing_time_length = len(self.processing_time)
            buff.write(struct.pack('<I', processing_time_length))
            buff.write(struct.pack(f'<{processing_time_length}d', *self.processing_time))
            offset += 4 + processing_time_length * 8
            offset += self.error_code.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.trajectory_start.deserialize(buff[offset:])
            (length_group_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.group_name = buff[offset:(offset + length_group_name)].decode('utf-8')
            else:
                self.group_name = buff[offset:(offset + length_group_name)]
            offset += length_group_name
            (trajectory_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.trajectory) != trajectory_length:
                self.trajectory = [mros.moveit_msgs.msg.RobotTrajectory() for _ in range(trajectory_length)]
            for i in range(0, trajectory_length):
                offset += self.trajectory[i].deserialize(buff[offset:])
            (description_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.description) != description_length:
                self.description = ['' for _ in range(description_length)]
            for i in range(0, description_length):
                (length_descriptioni,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.description[i] = buff[offset:(offset + length_descriptioni)].decode('utf-8')
                else:
                    self.description[i] = buff[offset:(offset + length_descriptioni)]
                offset += length_descriptioni
            (processing_time_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.processing_time = np.frombuffer(buff[offset:offset + processing_time_length * 8], dtype=np.float64)
            offset += processing_time_length * 8
            offset += self.error_code.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.trajectory_start.serializedLength()
        group_name_x = self.group_name
        group_name_length = len(group_name_x)
        if python3 or type(group_name_x) == unicode:
            group_name_x = group_name_x.encode('utf-8')
            group_name_length = len(group_name_x)
        length += 4
        length += group_name_length
        length += 4
        for i in range(0, trajectory_length):
            length += self.trajectory[i].serializedLength()
        length += 4
        for i in range(0, description_length):
            descriptioni_x = self.description[i]
            descriptioni_length = len(descriptioni_x)
            if python3 or type(descriptioni_x) == unicode:
                descriptioni_x = descriptioni_x.encode('utf-8')
                descriptioni_length = len(descriptioni_x)
            length += 4
            length += descriptioni_length
        length += 4
        length += len(self.processing_time) * 8
        length += self.error_code.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"trajectory_start":'
        string_echo += self.trajectory_start.echo()
        string_echo += ','
        string_echo += '"group_name":"%s"' % self.group_name
        string_echo += ','
        string_echo += '"trajectory":['
        trajectory_length = len(self.trajectory)
        for i in range(0, trajectory_length):
            if i == (trajectory_length - 1): 
                string_echo += '{trajectory%s":' % i
                string_echo += self.trajectory[i].echo()
                string_echo += ''
            else:
                string_echo += '{trajectory%s":' % i
                string_echo += self.trajectory[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"description":['
        description_length = len(self.description)
        for i in range(0, description_length):
            if i == (description_length - 1): 
                string_echo += '"description[i]":"%s"' % self.description[i]
                string_echo += ''
            else:
                string_echo += '"description[i]":"%s"' % self.description[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"processing_time":['
        processing_time_length = len(self.processing_time)
        for i in range(0, processing_time_length):
            if i == (processing_time_length - 1): 
                string_echo += '%s' % self.processing_time[i]
            else:
                string_echo += '%s,' % self.processing_time[i]
        string_echo += '],'
        string_echo += '"error_code":'
        string_echo += self.error_code.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/MotionPlanDetailedResponse"

    def getMD5(self):
        return "af67c260a61067b3866c6bbc624021cc"

    def getDef(self):
        return "moveit_msgs/RobotState trajectory_start\nstring group_name\nmoveit_msgs/RobotTrajectory[] trajectory\nstring[] description\nfloat64[] processing_time\nmoveit_msgs/MoveItErrorCodes error_code\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: moveit_msgs/RobotTrajectory\ntrajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

