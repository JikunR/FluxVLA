import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.trajectory_msgs.msg

class AttachedCollisionObject(mros.Message):
    __slots__ = ['link_name','object','touch_links','detach_posture','weight']
    _slot_types = ['string','moveit_msgs/CollisionObject','string[]','trajectory_msgs/JointTrajectory','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AttachedCollisionObject, self).__init__(*args, **kwds)
            if self.link_name is None:
                self.link_name = ''
            if self.object is None:
                self.object = mros.moveit_msgs.msg.CollisionObject()
            if self.touch_links is None:
                self.touch_links = []
            if self.detach_posture is None:
                self.detach_posture = mros.trajectory_msgs.msg.JointTrajectory()
            if self.weight is None:
                self.weight = 0.
        else:
            self.link_name = ''
            self.object = mros.moveit_msgs.msg.CollisionObject()
            self.touch_links = []
            self.detach_posture = mros.trajectory_msgs.msg.JointTrajectory()
            self.weight = 0.

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.object.serialize(buff)
            touch_links_length = len(self.touch_links)
            buff.write(struct.pack('<I', touch_links_length))
            offset += 4
            for i in range(0, touch_links_length):
                _x = self.touch_links[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            offset += self.detach_posture.serialize(buff)
            struct_weight = struct.Struct("<d")
            buff.write(struct_weight.pack(self.weight))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.link_name = buff[offset:(offset + length_link_name)].decode('utf-8')
            else:
                self.link_name = buff[offset:(offset + length_link_name)]
            offset += length_link_name
            offset += self.object.deserialize(buff[offset:])
            (touch_links_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.touch_links) != touch_links_length:
                self.touch_links = ['' for _ in range(touch_links_length)]
            for i in range(0, touch_links_length):
                (length_touch_linksi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.touch_links[i] = buff[offset:(offset + length_touch_linksi)].decode('utf-8')
                else:
                    self.touch_links[i] = buff[offset:(offset + length_touch_linksi)]
                offset += length_touch_linksi
            offset += self.detach_posture.deserialize(buff[offset:])
            struct_weight = struct.Struct("<d")
            (self.weight,) = struct_weight.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        link_name_x = self.link_name
        link_name_length = len(link_name_x)
        if python3 or type(link_name_x) == unicode:
            link_name_x = link_name_x.encode('utf-8')
            link_name_length = len(link_name_x)
        length += 4
        length += link_name_length
        length += self.object.serializedLength()
        length += 4
        for i in range(0, touch_links_length):
            touch_linksi_x = self.touch_links[i]
            touch_linksi_length = len(touch_linksi_x)
            if python3 or type(touch_linksi_x) == unicode:
                touch_linksi_x = touch_linksi_x.encode('utf-8')
                touch_linksi_length = len(touch_linksi_x)
            length += 4
            length += touch_linksi_length
        length += self.detach_posture.serializedLength()
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"link_name":"%s"' % self.link_name
        string_echo += ','
        string_echo += '"object":'
        string_echo += self.object.echo()
        string_echo += ','
        string_echo += '"touch_links":['
        touch_links_length = len(self.touch_links)
        for i in range(0, touch_links_length):
            if i == (touch_links_length - 1): 
                string_echo += '"touch_links[i]":"%s"' % self.touch_links[i]
                string_echo += ''
            else:
                string_echo += '"touch_links[i]":"%s"' % self.touch_links[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"detach_posture":'
        string_echo += self.detach_posture.echo()
        string_echo += ','
        string_echo += '"weight":%s' % self.weight
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/AttachedCollisionObject"

    def getMD5(self):
        return "30199ef516f64c8bc1edb1084ce4584e"

    def getDef(self):
        return "string link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

