import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg
import mros.object_recognition_msgs.msg
import mros.shape_msgs.msg

class CollisionObject(mros.Message):
    __slots__ = ['header','pose','id','type','primitives','primitive_poses','meshes','mesh_poses','planes','plane_poses','subframe_names','subframe_poses','operation']
    _slot_types = ['std_msgs/Header','geometry_msgs/Pose','string','object_recognition_msgs/ObjectType','shape_msgs/SolidPrimitive[]','geometry_msgs/Pose[]','shape_msgs/Mesh[]','geometry_msgs/Pose[]','shape_msgs/Plane[]','geometry_msgs/Pose[]','string[]','geometry_msgs/Pose[]','byte']

    ADD = 0
    REMOVE = 1
    APPEND = 2
    MOVE = 3

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CollisionObject, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
            if self.id is None:
                self.id = ''
            if self.type is None:
                self.type = mros.object_recognition_msgs.msg.ObjectType()
            if self.primitives is None:
                self.primitives = []
            if self.primitive_poses is None:
                self.primitive_poses = []
            if self.meshes is None:
                self.meshes = []
            if self.mesh_poses is None:
                self.mesh_poses = []
            if self.planes is None:
                self.planes = []
            if self.plane_poses is None:
                self.plane_poses = []
            if self.subframe_names is None:
                self.subframe_names = []
            if self.subframe_poses is None:
                self.subframe_poses = []
            if self.operation is None:
                self.operation = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.pose = mros.geometry_msgs.msg.Pose()
            self.id = ''
            self.type = mros.object_recognition_msgs.msg.ObjectType()
            self.primitives = []
            self.primitive_poses = []
            self.meshes = []
            self.mesh_poses = []
            self.planes = []
            self.plane_poses = []
            self.subframe_names = []
            self.subframe_poses = []
            self.operation = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.pose.serialize(buff)
            _x = self.id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.type.serialize(buff)
            primitives_length = len(self.primitives)
            buff.write(struct.pack('<I', primitives_length))
            offset += 4
            for i in range(0, primitives_length):
                offset += self.primitives[i].serialize(buff)
            primitive_poses_length = len(self.primitive_poses)
            buff.write(struct.pack('<I', primitive_poses_length))
            offset += 4
            for i in range(0, primitive_poses_length):
                offset += self.primitive_poses[i].serialize(buff)
            meshes_length = len(self.meshes)
            buff.write(struct.pack('<I', meshes_length))
            offset += 4
            for i in range(0, meshes_length):
                offset += self.meshes[i].serialize(buff)
            mesh_poses_length = len(self.mesh_poses)
            buff.write(struct.pack('<I', mesh_poses_length))
            offset += 4
            for i in range(0, mesh_poses_length):
                offset += self.mesh_poses[i].serialize(buff)
            planes_length = len(self.planes)
            buff.write(struct.pack('<I', planes_length))
            offset += 4
            for i in range(0, planes_length):
                offset += self.planes[i].serialize(buff)
            plane_poses_length = len(self.plane_poses)
            buff.write(struct.pack('<I', plane_poses_length))
            offset += 4
            for i in range(0, plane_poses_length):
                offset += self.plane_poses[i].serialize(buff)
            subframe_names_length = len(self.subframe_names)
            buff.write(struct.pack('<I', subframe_names_length))
            offset += 4
            for i in range(0, subframe_names_length):
                _x = self.subframe_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            subframe_poses_length = len(self.subframe_poses)
            buff.write(struct.pack('<I', subframe_poses_length))
            offset += 4
            for i in range(0, subframe_poses_length):
                offset += self.subframe_poses[i].serialize(buff)
            struct_operation = struct.Struct("<b")
            buff.write(struct_operation.pack(self.operation))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.pose.deserialize(buff[offset:])
            (length_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.id = buff[offset:(offset + length_id)].decode('utf-8')
            else:
                self.id = buff[offset:(offset + length_id)]
            offset += length_id
            offset += self.type.deserialize(buff[offset:])
            (primitives_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.primitives) != primitives_length:
                self.primitives = [mros.shape_msgs.msg.SolidPrimitive() for _ in range(primitives_length)]
            for i in range(0, primitives_length):
                offset += self.primitives[i].deserialize(buff[offset:])
            (primitive_poses_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.primitive_poses) != primitive_poses_length:
                self.primitive_poses = [mros.geometry_msgs.msg.Pose() for _ in range(primitive_poses_length)]
            for i in range(0, primitive_poses_length):
                offset += self.primitive_poses[i].deserialize(buff[offset:])
            (meshes_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.meshes) != meshes_length:
                self.meshes = [mros.shape_msgs.msg.Mesh() for _ in range(meshes_length)]
            for i in range(0, meshes_length):
                offset += self.meshes[i].deserialize(buff[offset:])
            (mesh_poses_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.mesh_poses) != mesh_poses_length:
                self.mesh_poses = [mros.geometry_msgs.msg.Pose() for _ in range(mesh_poses_length)]
            for i in range(0, mesh_poses_length):
                offset += self.mesh_poses[i].deserialize(buff[offset:])
            (planes_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.planes) != planes_length:
                self.planes = [mros.shape_msgs.msg.Plane() for _ in range(planes_length)]
            for i in range(0, planes_length):
                offset += self.planes[i].deserialize(buff[offset:])
            (plane_poses_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.plane_poses) != plane_poses_length:
                self.plane_poses = [mros.geometry_msgs.msg.Pose() for _ in range(plane_poses_length)]
            for i in range(0, plane_poses_length):
                offset += self.plane_poses[i].deserialize(buff[offset:])
            (subframe_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.subframe_names) != subframe_names_length:
                self.subframe_names = ['' for _ in range(subframe_names_length)]
            for i in range(0, subframe_names_length):
                (length_subframe_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.subframe_names[i] = buff[offset:(offset + length_subframe_namesi)].decode('utf-8')
                else:
                    self.subframe_names[i] = buff[offset:(offset + length_subframe_namesi)]
                offset += length_subframe_namesi
            (subframe_poses_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.subframe_poses) != subframe_poses_length:
                self.subframe_poses = [mros.geometry_msgs.msg.Pose() for _ in range(subframe_poses_length)]
            for i in range(0, subframe_poses_length):
                offset += self.subframe_poses[i].deserialize(buff[offset:])
            struct_operation = struct.Struct("<b")
            (self.operation,) = struct_operation.unpack(buff[offset:(offset + 1)])
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.pose.serializedLength()
        id_x = self.id
        id_length = len(id_x)
        if python3 or type(id_x) == unicode:
            id_x = id_x.encode('utf-8')
            id_length = len(id_x)
        length += 4
        length += id_length
        length += self.type.serializedLength()
        length += 4
        for i in range(0, primitives_length):
            length += self.primitives[i].serializedLength()
        length += 4
        for i in range(0, primitive_poses_length):
            length += self.primitive_poses[i].serializedLength()
        length += 4
        for i in range(0, meshes_length):
            length += self.meshes[i].serializedLength()
        length += 4
        for i in range(0, mesh_poses_length):
            length += self.mesh_poses[i].serializedLength()
        length += 4
        for i in range(0, planes_length):
            length += self.planes[i].serializedLength()
        length += 4
        for i in range(0, plane_poses_length):
            length += self.plane_poses[i].serializedLength()
        length += 4
        for i in range(0, subframe_names_length):
            subframe_namesi_x = self.subframe_names[i]
            subframe_namesi_length = len(subframe_namesi_x)
            if python3 or type(subframe_namesi_x) == unicode:
                subframe_namesi_x = subframe_namesi_x.encode('utf-8')
                subframe_namesi_length = len(subframe_namesi_x)
            length += 4
            length += subframe_namesi_length
        length += 4
        for i in range(0, subframe_poses_length):
            length += self.subframe_poses[i].serializedLength()
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ','
        string_echo += '"id":"%s"' % self.id
        string_echo += ','
        string_echo += '"type":'
        string_echo += self.type.echo()
        string_echo += ','
        string_echo += '"primitives":['
        primitives_length = len(self.primitives)
        for i in range(0, primitives_length):
            if i == (primitives_length - 1): 
                string_echo += '{primitives%s":' % i
                string_echo += self.primitives[i].echo()
                string_echo += ''
            else:
                string_echo += '{primitives%s":' % i
                string_echo += self.primitives[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"primitive_poses":['
        primitive_poses_length = len(self.primitive_poses)
        for i in range(0, primitive_poses_length):
            if i == (primitive_poses_length - 1): 
                string_echo += '{primitive_poses%s":' % i
                string_echo += self.primitive_poses[i].echo()
                string_echo += ''
            else:
                string_echo += '{primitive_poses%s":' % i
                string_echo += self.primitive_poses[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"meshes":['
        meshes_length = len(self.meshes)
        for i in range(0, meshes_length):
            if i == (meshes_length - 1): 
                string_echo += '{meshes%s":' % i
                string_echo += self.meshes[i].echo()
                string_echo += ''
            else:
                string_echo += '{meshes%s":' % i
                string_echo += self.meshes[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"mesh_poses":['
        mesh_poses_length = len(self.mesh_poses)
        for i in range(0, mesh_poses_length):
            if i == (mesh_poses_length - 1): 
                string_echo += '{mesh_poses%s":' % i
                string_echo += self.mesh_poses[i].echo()
                string_echo += ''
            else:
                string_echo += '{mesh_poses%s":' % i
                string_echo += self.mesh_poses[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"planes":['
        planes_length = len(self.planes)
        for i in range(0, planes_length):
            if i == (planes_length - 1): 
                string_echo += '{planes%s":' % i
                string_echo += self.planes[i].echo()
                string_echo += ''
            else:
                string_echo += '{planes%s":' % i
                string_echo += self.planes[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"plane_poses":['
        plane_poses_length = len(self.plane_poses)
        for i in range(0, plane_poses_length):
            if i == (plane_poses_length - 1): 
                string_echo += '{plane_poses%s":' % i
                string_echo += self.plane_poses[i].echo()
                string_echo += ''
            else:
                string_echo += '{plane_poses%s":' % i
                string_echo += self.plane_poses[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"subframe_names":['
        subframe_names_length = len(self.subframe_names)
        for i in range(0, subframe_names_length):
            if i == (subframe_names_length - 1): 
                string_echo += '"subframe_names[i]":"%s"' % self.subframe_names[i]
                string_echo += ''
            else:
                string_echo += '"subframe_names[i]":"%s"' % self.subframe_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"subframe_poses":['
        subframe_poses_length = len(self.subframe_poses)
        for i in range(0, subframe_poses_length):
            if i == (subframe_poses_length - 1): 
                string_echo += '{subframe_poses%s":' % i
                string_echo += self.subframe_poses[i].echo()
                string_echo += ''
            else:
                string_echo += '{subframe_poses%s":' % i
                string_echo += self.subframe_poses[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"operation":%s' % self.operation
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/CollisionObject"

    def getMD5(self):
        return "dbba710596087da521c07564160dfccb"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

