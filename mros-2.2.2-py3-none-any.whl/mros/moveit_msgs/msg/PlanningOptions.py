import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class PlanningOptions(mros.Message):
    __slots__ = ['planning_scene_diff','plan_only','look_around','look_around_attempts','max_safe_execution_cost','replan','replan_attempts','replan_delay']
    _slot_types = ['moveit_msgs/PlanningScene','bool','bool','int32','float64','bool','int32','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlanningOptions, self).__init__(*args, **kwds)
            if self.planning_scene_diff is None:
                self.planning_scene_diff = mros.moveit_msgs.msg.PlanningScene()
            if self.plan_only is None:
                self.plan_only = False
            if self.look_around is None:
                self.look_around = False
            if self.look_around_attempts is None:
                self.look_around_attempts = 0
            if self.max_safe_execution_cost is None:
                self.max_safe_execution_cost = 0.
            if self.replan is None:
                self.replan = False
            if self.replan_attempts is None:
                self.replan_attempts = 0
            if self.replan_delay is None:
                self.replan_delay = 0.
        else:
            self.planning_scene_diff = mros.moveit_msgs.msg.PlanningScene()
            self.plan_only = False
            self.look_around = False
            self.look_around_attempts = 0
            self.max_safe_execution_cost = 0.
            self.replan = False
            self.replan_attempts = 0
            self.replan_delay = 0.

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.planning_scene_diff.serialize(buff)
            struct_plan_only = struct.Struct("<B")
            buff.write(struct_plan_only.pack(self.plan_only))
            offset += 1
            struct_look_around = struct.Struct("<B")
            buff.write(struct_look_around.pack(self.look_around))
            offset += 1
            struct_look_around_attempts = struct.Struct("<i")
            buff.write(struct_look_around_attempts.pack(self.look_around_attempts))
            offset += 4
            struct_max_safe_execution_cost = struct.Struct("<d")
            buff.write(struct_max_safe_execution_cost.pack(self.max_safe_execution_cost))
            offset += 8
            struct_replan = struct.Struct("<B")
            buff.write(struct_replan.pack(self.replan))
            offset += 1
            struct_replan_attempts = struct.Struct("<i")
            buff.write(struct_replan_attempts.pack(self.replan_attempts))
            offset += 4
            struct_replan_delay = struct.Struct("<d")
            buff.write(struct_replan_delay.pack(self.replan_delay))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.planning_scene_diff.deserialize(buff[offset:])
            struct_plan_only = struct.Struct("<B")
            (self.plan_only,) = struct_plan_only.unpack(buff[offset:(offset + 1)])
            self.plan_only = bool(self.plan_only)
            offset += 1
            struct_look_around = struct.Struct("<B")
            (self.look_around,) = struct_look_around.unpack(buff[offset:(offset + 1)])
            self.look_around = bool(self.look_around)
            offset += 1
            struct_look_around_attempts = struct.Struct("<i")
            (self.look_around_attempts,) = struct_look_around_attempts.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_max_safe_execution_cost = struct.Struct("<d")
            (self.max_safe_execution_cost,) = struct_max_safe_execution_cost.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_replan = struct.Struct("<B")
            (self.replan,) = struct_replan.unpack(buff[offset:(offset + 1)])
            self.replan = bool(self.replan)
            offset += 1
            struct_replan_attempts = struct.Struct("<i")
            (self.replan_attempts,) = struct_replan_attempts.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_replan_delay = struct.Struct("<d")
            (self.replan_delay,) = struct_replan_delay.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.planning_scene_diff.serializedLength()
        length += 1
        length += 1
        length += 4
        length += 8
        length += 1
        length += 4
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"planning_scene_diff":'
        string_echo += self.planning_scene_diff.echo()
        string_echo += ','
        string_echo += '"plan_only":%s' % self.plan_only
        string_echo += ','
        string_echo += '"look_around":%s' % self.look_around
        string_echo += ','
        string_echo += '"look_around_attempts":%s' % self.look_around_attempts
        string_echo += ','
        string_echo += '"max_safe_execution_cost":%s' % self.max_safe_execution_cost
        string_echo += ','
        string_echo += '"replan":%s' % self.replan
        string_echo += ','
        string_echo += '"replan_attempts":%s' % self.replan_attempts
        string_echo += ','
        string_echo += '"replan_delay":%s' % self.replan_delay
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PlanningOptions"

    def getMD5(self):
        return "3134e041c806c7c2ff59948db4d57835"

    def getDef(self):
        return "moveit_msgs/PlanningScene planning_scene_diff\nbool plan_only\nbool look_around\nint32 look_around_attempts\nfloat64 max_safe_execution_cost\nbool replan\nint32 replan_attempts\nfloat64 replan_delay\n================================================================================\nMSG: moveit_msgs/PlanningScene\nstring name\nmoveit_msgs/RobotState robot_state\nstring robot_model_name\ngeometry_msgs/TransformStamped[] fixed_frame_transforms\nmoveit_msgs/AllowedCollisionMatrix allowed_collision_matrix\nmoveit_msgs/LinkPadding[] link_padding\nmoveit_msgs/LinkScale[] link_scale\nmoveit_msgs/ObjectColor[] object_colors\nmoveit_msgs/PlanningSceneWorld world\nbool is_diff\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: geometry_msgs/TransformStamped\nstd_msgs/Header header\nstring child_frame_id\ngeometry_msgs/Transform transform\n================================================================================\nMSG: moveit_msgs/AllowedCollisionMatrix\nstring[] entry_names\nmoveit_msgs/AllowedCollisionEntry[] entry_values\nstring[] default_entry_names\nbool[] default_entry_values\n================================================================================\nMSG: moveit_msgs/LinkPadding\nstring link_name\nfloat64 padding\n================================================================================\nMSG: moveit_msgs/LinkScale\nstring link_name\nfloat64 scale\n================================================================================\nMSG: moveit_msgs/ObjectColor\nstring id\nstd_msgs/ColorRGBA color\n================================================================================\nMSG: moveit_msgs/PlanningSceneWorld\nmoveit_msgs/CollisionObject[] collision_objects\noctomap_msgs/OctomapWithPose octomap\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: moveit_msgs/AllowedCollisionEntry\nbool[] enabled\n================================================================================\nMSG: std_msgs/ColorRGBA\nfloat32 r\nfloat32 g\nfloat32 b\nfloat32 a\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: octomap_msgs/OctomapWithPose\nstd_msgs/Header header\ngeometry_msgs/Pose origin\noctomap_msgs/Octomap octomap\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: octomap_msgs/Octomap\nstd_msgs/Header header\nbool binary\nstring id\nfloat64 resolution\nint8[] data\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

