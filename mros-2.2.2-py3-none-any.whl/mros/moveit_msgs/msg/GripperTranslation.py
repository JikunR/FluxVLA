import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.geometry_msgs.msg

class GripperTranslation(mros.Message):
    __slots__ = ['direction','desired_distance','min_distance']
    _slot_types = ['geometry_msgs/Vector3Stamped','float32','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GripperTranslation, self).__init__(*args, **kwds)
            if self.direction is None:
                self.direction = mros.geometry_msgs.msg.Vector3Stamped()
            if self.desired_distance is None:
                self.desired_distance = 0.
            if self.min_distance is None:
                self.min_distance = 0.
        else:
            self.direction = mros.geometry_msgs.msg.Vector3Stamped()
            self.desired_distance = 0.
            self.min_distance = 0.

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.direction.serialize(buff)
            struct_desired_distance = struct.Struct("<f")
            buff.write(struct_desired_distance.pack(self.desired_distance))
            offset += 4
            struct_min_distance = struct.Struct("<f")
            buff.write(struct_min_distance.pack(self.min_distance))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.direction.deserialize(buff[offset:])
            struct_desired_distance = struct.Struct("<f")
            (self.desired_distance,) = struct_desired_distance.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_min_distance = struct.Struct("<f")
            (self.min_distance,) = struct_min_distance.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.direction.serializedLength()
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"direction":'
        string_echo += self.direction.echo()
        string_echo += ','
        string_echo += '"desired_distance":%s' % self.desired_distance
        string_echo += ','
        string_echo += '"min_distance":%s' % self.min_distance
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/GripperTranslation"

    def getMD5(self):
        return "b53bc0ad0f717cdec3b0e42dec300121"

    def getDef(self):
        return "geometry_msgs/Vector3Stamped direction\nfloat32 desired_distance\nfloat32 min_distance\n================================================================================\nMSG: geometry_msgs/Vector3Stamped\nstd_msgs/Header header\ngeometry_msgs/Vector3 vector\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

