import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class MotionPlanRequest(mros.Message):
    __slots__ = ['workspace_parameters','start_state','goal_constraints','path_constraints','trajectory_constraints','reference_trajectories','pipeline_id','planner_id','group_name','num_planning_attempts','allowed_planning_time','max_velocity_scaling_factor','max_acceleration_scaling_factor','cartesian_speed_limited_link','max_cartesian_speed']
    _slot_types = ['moveit_msgs/WorkspaceParameters','moveit_msgs/RobotState','moveit_msgs/Constraints[]','moveit_msgs/Constraints','moveit_msgs/TrajectoryConstraints','moveit_msgs/GenericTrajectory[]','string','string','string','int32','float64','float64','float64','string','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MotionPlanRequest, self).__init__(*args, **kwds)
            if self.workspace_parameters is None:
                self.workspace_parameters = mros.moveit_msgs.msg.WorkspaceParameters()
            if self.start_state is None:
                self.start_state = mros.moveit_msgs.msg.RobotState()
            if self.goal_constraints is None:
                self.goal_constraints = []
            if self.path_constraints is None:
                self.path_constraints = mros.moveit_msgs.msg.Constraints()
            if self.trajectory_constraints is None:
                self.trajectory_constraints = mros.moveit_msgs.msg.TrajectoryConstraints()
            if self.reference_trajectories is None:
                self.reference_trajectories = []
            if self.pipeline_id is None:
                self.pipeline_id = ''
            if self.planner_id is None:
                self.planner_id = ''
            if self.group_name is None:
                self.group_name = ''
            if self.num_planning_attempts is None:
                self.num_planning_attempts = 0
            if self.allowed_planning_time is None:
                self.allowed_planning_time = 0.
            if self.max_velocity_scaling_factor is None:
                self.max_velocity_scaling_factor = 0.
            if self.max_acceleration_scaling_factor is None:
                self.max_acceleration_scaling_factor = 0.
            if self.cartesian_speed_limited_link is None:
                self.cartesian_speed_limited_link = ''
            if self.max_cartesian_speed is None:
                self.max_cartesian_speed = 0.
        else:
            self.workspace_parameters = mros.moveit_msgs.msg.WorkspaceParameters()
            self.start_state = mros.moveit_msgs.msg.RobotState()
            self.goal_constraints = []
            self.path_constraints = mros.moveit_msgs.msg.Constraints()
            self.trajectory_constraints = mros.moveit_msgs.msg.TrajectoryConstraints()
            self.reference_trajectories = []
            self.pipeline_id = ''
            self.planner_id = ''
            self.group_name = ''
            self.num_planning_attempts = 0
            self.allowed_planning_time = 0.
            self.max_velocity_scaling_factor = 0.
            self.max_acceleration_scaling_factor = 0.
            self.cartesian_speed_limited_link = ''
            self.max_cartesian_speed = 0.

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.workspace_parameters.serialize(buff)
            offset += self.start_state.serialize(buff)
            goal_constraints_length = len(self.goal_constraints)
            buff.write(struct.pack('<I', goal_constraints_length))
            offset += 4
            for i in range(0, goal_constraints_length):
                offset += self.goal_constraints[i].serialize(buff)
            offset += self.path_constraints.serialize(buff)
            offset += self.trajectory_constraints.serialize(buff)
            reference_trajectories_length = len(self.reference_trajectories)
            buff.write(struct.pack('<I', reference_trajectories_length))
            offset += 4
            for i in range(0, reference_trajectories_length):
                offset += self.reference_trajectories[i].serialize(buff)
            _x = self.pipeline_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.planner_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.group_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_num_planning_attempts = struct.Struct("<i")
            buff.write(struct_num_planning_attempts.pack(self.num_planning_attempts))
            offset += 4
            struct_allowed_planning_time = struct.Struct("<d")
            buff.write(struct_allowed_planning_time.pack(self.allowed_planning_time))
            offset += 8
            struct_max_velocity_scaling_factor = struct.Struct("<d")
            buff.write(struct_max_velocity_scaling_factor.pack(self.max_velocity_scaling_factor))
            offset += 8
            struct_max_acceleration_scaling_factor = struct.Struct("<d")
            buff.write(struct_max_acceleration_scaling_factor.pack(self.max_acceleration_scaling_factor))
            offset += 8
            _x = self.cartesian_speed_limited_link
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_max_cartesian_speed = struct.Struct("<d")
            buff.write(struct_max_cartesian_speed.pack(self.max_cartesian_speed))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.workspace_parameters.deserialize(buff[offset:])
            offset += self.start_state.deserialize(buff[offset:])
            (goal_constraints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.goal_constraints) != goal_constraints_length:
                self.goal_constraints = [mros.moveit_msgs.msg.Constraints() for _ in range(goal_constraints_length)]
            for i in range(0, goal_constraints_length):
                offset += self.goal_constraints[i].deserialize(buff[offset:])
            offset += self.path_constraints.deserialize(buff[offset:])
            offset += self.trajectory_constraints.deserialize(buff[offset:])
            (reference_trajectories_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.reference_trajectories) != reference_trajectories_length:
                self.reference_trajectories = [mros.moveit_msgs.msg.GenericTrajectory() for _ in range(reference_trajectories_length)]
            for i in range(0, reference_trajectories_length):
                offset += self.reference_trajectories[i].deserialize(buff[offset:])
            (length_pipeline_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.pipeline_id = buff[offset:(offset + length_pipeline_id)].decode('utf-8')
            else:
                self.pipeline_id = buff[offset:(offset + length_pipeline_id)]
            offset += length_pipeline_id
            (length_planner_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.planner_id = buff[offset:(offset + length_planner_id)].decode('utf-8')
            else:
                self.planner_id = buff[offset:(offset + length_planner_id)]
            offset += length_planner_id
            (length_group_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.group_name = buff[offset:(offset + length_group_name)].decode('utf-8')
            else:
                self.group_name = buff[offset:(offset + length_group_name)]
            offset += length_group_name
            struct_num_planning_attempts = struct.Struct("<i")
            (self.num_planning_attempts,) = struct_num_planning_attempts.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_allowed_planning_time = struct.Struct("<d")
            (self.allowed_planning_time,) = struct_allowed_planning_time.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_max_velocity_scaling_factor = struct.Struct("<d")
            (self.max_velocity_scaling_factor,) = struct_max_velocity_scaling_factor.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_max_acceleration_scaling_factor = struct.Struct("<d")
            (self.max_acceleration_scaling_factor,) = struct_max_acceleration_scaling_factor.unpack(buff[offset:(offset + 8)])
            offset += 8
            (length_cartesian_speed_limited_link,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.cartesian_speed_limited_link = buff[offset:(offset + length_cartesian_speed_limited_link)].decode('utf-8')
            else:
                self.cartesian_speed_limited_link = buff[offset:(offset + length_cartesian_speed_limited_link)]
            offset += length_cartesian_speed_limited_link
            struct_max_cartesian_speed = struct.Struct("<d")
            (self.max_cartesian_speed,) = struct_max_cartesian_speed.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.workspace_parameters.serializedLength()
        length += self.start_state.serializedLength()
        length += 4
        for i in range(0, goal_constraints_length):
            length += self.goal_constraints[i].serializedLength()
        length += self.path_constraints.serializedLength()
        length += self.trajectory_constraints.serializedLength()
        length += 4
        for i in range(0, reference_trajectories_length):
            length += self.reference_trajectories[i].serializedLength()
        pipeline_id_x = self.pipeline_id
        pipeline_id_length = len(pipeline_id_x)
        if python3 or type(pipeline_id_x) == unicode:
            pipeline_id_x = pipeline_id_x.encode('utf-8')
            pipeline_id_length = len(pipeline_id_x)
        length += 4
        length += pipeline_id_length
        planner_id_x = self.planner_id
        planner_id_length = len(planner_id_x)
        if python3 or type(planner_id_x) == unicode:
            planner_id_x = planner_id_x.encode('utf-8')
            planner_id_length = len(planner_id_x)
        length += 4
        length += planner_id_length
        group_name_x = self.group_name
        group_name_length = len(group_name_x)
        if python3 or type(group_name_x) == unicode:
            group_name_x = group_name_x.encode('utf-8')
            group_name_length = len(group_name_x)
        length += 4
        length += group_name_length
        length += 4
        length += 8
        length += 8
        length += 8
        cartesian_speed_limited_link_x = self.cartesian_speed_limited_link
        cartesian_speed_limited_link_length = len(cartesian_speed_limited_link_x)
        if python3 or type(cartesian_speed_limited_link_x) == unicode:
            cartesian_speed_limited_link_x = cartesian_speed_limited_link_x.encode('utf-8')
            cartesian_speed_limited_link_length = len(cartesian_speed_limited_link_x)
        length += 4
        length += cartesian_speed_limited_link_length
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"workspace_parameters":'
        string_echo += self.workspace_parameters.echo()
        string_echo += ','
        string_echo += '"start_state":'
        string_echo += self.start_state.echo()
        string_echo += ','
        string_echo += '"goal_constraints":['
        goal_constraints_length = len(self.goal_constraints)
        for i in range(0, goal_constraints_length):
            if i == (goal_constraints_length - 1): 
                string_echo += '{goal_constraints%s":' % i
                string_echo += self.goal_constraints[i].echo()
                string_echo += ''
            else:
                string_echo += '{goal_constraints%s":' % i
                string_echo += self.goal_constraints[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"path_constraints":'
        string_echo += self.path_constraints.echo()
        string_echo += ','
        string_echo += '"trajectory_constraints":'
        string_echo += self.trajectory_constraints.echo()
        string_echo += ','
        string_echo += '"reference_trajectories":['
        reference_trajectories_length = len(self.reference_trajectories)
        for i in range(0, reference_trajectories_length):
            if i == (reference_trajectories_length - 1): 
                string_echo += '{reference_trajectories%s":' % i
                string_echo += self.reference_trajectories[i].echo()
                string_echo += ''
            else:
                string_echo += '{reference_trajectories%s":' % i
                string_echo += self.reference_trajectories[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"pipeline_id":"%s"' % self.pipeline_id
        string_echo += ','
        string_echo += '"planner_id":"%s"' % self.planner_id
        string_echo += ','
        string_echo += '"group_name":"%s"' % self.group_name
        string_echo += ','
        string_echo += '"num_planning_attempts":%s' % self.num_planning_attempts
        string_echo += ','
        string_echo += '"allowed_planning_time":%s' % self.allowed_planning_time
        string_echo += ','
        string_echo += '"max_velocity_scaling_factor":%s' % self.max_velocity_scaling_factor
        string_echo += ','
        string_echo += '"max_acceleration_scaling_factor":%s' % self.max_acceleration_scaling_factor
        string_echo += ','
        string_echo += '"cartesian_speed_limited_link":"%s"' % self.cartesian_speed_limited_link
        string_echo += ','
        string_echo += '"max_cartesian_speed":%s' % self.max_cartesian_speed
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/MotionPlanRequest"

    def getMD5(self):
        return "83f3d7b1d47a538f7659e0de9dae7980"

    def getDef(self):
        return "moveit_msgs/WorkspaceParameters workspace_parameters\nmoveit_msgs/RobotState start_state\nmoveit_msgs/Constraints[] goal_constraints\nmoveit_msgs/Constraints path_constraints\nmoveit_msgs/TrajectoryConstraints trajectory_constraints\nmoveit_msgs/GenericTrajectory[] reference_trajectories\nstring pipeline_id\nstring planner_id\nstring group_name\nint32 num_planning_attempts\nfloat64 allowed_planning_time\nfloat64 max_velocity_scaling_factor\nfloat64 max_acceleration_scaling_factor\nstring cartesian_speed_limited_link\nfloat64 max_cartesian_speed\n================================================================================\nMSG: moveit_msgs/WorkspaceParameters\nstd_msgs/Header header\ngeometry_msgs/Vector3 min_corner\ngeometry_msgs/Vector3 max_corner\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: moveit_msgs/Constraints\nstring name\nmoveit_msgs/JointConstraint[] joint_constraints\nmoveit_msgs/PositionConstraint[] position_constraints\nmoveit_msgs/OrientationConstraint[] orientation_constraints\nmoveit_msgs/VisibilityConstraint[] visibility_constraints\n================================================================================\nMSG: moveit_msgs/TrajectoryConstraints\nmoveit_msgs/Constraints[] constraints\n================================================================================\nMSG: moveit_msgs/GenericTrajectory\nstd_msgs/Header header\ntrajectory_msgs/JointTrajectory[] joint_trajectory\nmoveit_msgs/CartesianTrajectory[] cartesian_trajectory\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/JointConstraint\nstring joint_name\nfloat64 position\nfloat64 tolerance_above\nfloat64 tolerance_below\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PositionConstraint\nstd_msgs/Header header\nstring link_name\ngeometry_msgs/Vector3 target_point_offset\nmoveit_msgs/BoundingVolume constraint_region\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/OrientationConstraint\nstd_msgs/Header header\ngeometry_msgs/Quaternion orientation\nstring link_name\nfloat64 absolute_x_axis_tolerance\nfloat64 absolute_y_axis_tolerance\nfloat64 absolute_z_axis_tolerance\nuint8 parameterization\nuint8 XYZ_EULER_ANGLES=0\nuint8 ROTATION_VECTOR=1\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/VisibilityConstraint\nfloat64 target_radius\ngeometry_msgs/PoseStamped target_pose\nint32 cone_sides\ngeometry_msgs/PoseStamped sensor_pose\nfloat64 max_view_angle\nfloat64 max_range_angle\nuint8 SENSOR_Z=0\nuint8 SENSOR_Y=1\nuint8 SENSOR_X=2\nuint8 sensor_view_direction\nfloat64 weight\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: moveit_msgs/CartesianTrajectory\nstd_msgs/Header header\nstring tracked_frame\nmoveit_msgs/CartesianTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: moveit_msgs/BoundingVolume\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: moveit_msgs/CartesianTrajectoryPoint\nmoveit_msgs/CartesianPoint point\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: moveit_msgs/CartesianPoint\ngeometry_msgs/Pose pose\ngeometry_msgs/Twist velocity\ngeometry_msgs/Accel acceleration\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n================================================================================\nMSG: geometry_msgs/Accel\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n"

_struct_I = struct.Struct('<I')

