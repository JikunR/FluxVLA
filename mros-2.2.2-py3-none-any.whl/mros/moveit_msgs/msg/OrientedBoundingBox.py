import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.geometry_msgs.msg

class OrientedBoundingBox(mros.Message):
    __slots__ = ['pose','extents']
    _slot_types = ['geometry_msgs/Pose','geometry_msgs/Point32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(OrientedBoundingBox, self).__init__(*args, **kwds)
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
            if self.extents is None:
                self.extents = mros.geometry_msgs.msg.Point32()
        else:
            self.pose = mros.geometry_msgs.msg.Pose()
            self.extents = mros.geometry_msgs.msg.Point32()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.pose.serialize(buff)
            offset += self.extents.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.pose.deserialize(buff[offset:])
            offset += self.extents.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.pose.serializedLength()
        length += self.extents.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ','
        string_echo += '"extents":'
        string_echo += self.extents.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/OrientedBoundingBox"

    def getMD5(self):
        return "da3bd98e7cb14efa4141367a9d886ee7"

    def getDef(self):
        return "geometry_msgs/Pose pose\ngeometry_msgs/Point32 extents\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point32\nfloat32 x\nfloat32 y\nfloat32 z\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

