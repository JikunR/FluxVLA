import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class JointLimits(mros.Message):
    __slots__ = ['joint_name','has_position_limits','min_position','max_position','has_velocity_limits','max_velocity','has_acceleration_limits','max_acceleration']
    _slot_types = ['string','bool','float64','float64','bool','float64','bool','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointLimits, self).__init__(*args, **kwds)
            if self.joint_name is None:
                self.joint_name = ''
            if self.has_position_limits is None:
                self.has_position_limits = False
            if self.min_position is None:
                self.min_position = 0.
            if self.max_position is None:
                self.max_position = 0.
            if self.has_velocity_limits is None:
                self.has_velocity_limits = False
            if self.max_velocity is None:
                self.max_velocity = 0.
            if self.has_acceleration_limits is None:
                self.has_acceleration_limits = False
            if self.max_acceleration is None:
                self.max_acceleration = 0.
        else:
            self.joint_name = ''
            self.has_position_limits = False
            self.min_position = 0.
            self.max_position = 0.
            self.has_velocity_limits = False
            self.max_velocity = 0.
            self.has_acceleration_limits = False
            self.max_acceleration = 0.

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.joint_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_has_position_limits = struct.Struct("<B")
            buff.write(struct_has_position_limits.pack(self.has_position_limits))
            offset += 1
            struct_min_position = struct.Struct("<d")
            buff.write(struct_min_position.pack(self.min_position))
            offset += 8
            struct_max_position = struct.Struct("<d")
            buff.write(struct_max_position.pack(self.max_position))
            offset += 8
            struct_has_velocity_limits = struct.Struct("<B")
            buff.write(struct_has_velocity_limits.pack(self.has_velocity_limits))
            offset += 1
            struct_max_velocity = struct.Struct("<d")
            buff.write(struct_max_velocity.pack(self.max_velocity))
            offset += 8
            struct_has_acceleration_limits = struct.Struct("<B")
            buff.write(struct_has_acceleration_limits.pack(self.has_acceleration_limits))
            offset += 1
            struct_max_acceleration = struct.Struct("<d")
            buff.write(struct_max_acceleration.pack(self.max_acceleration))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_joint_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.joint_name = buff[offset:(offset + length_joint_name)].decode('utf-8')
            else:
                self.joint_name = buff[offset:(offset + length_joint_name)]
            offset += length_joint_name
            struct_has_position_limits = struct.Struct("<B")
            (self.has_position_limits,) = struct_has_position_limits.unpack(buff[offset:(offset + 1)])
            self.has_position_limits = bool(self.has_position_limits)
            offset += 1
            struct_min_position = struct.Struct("<d")
            (self.min_position,) = struct_min_position.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_max_position = struct.Struct("<d")
            (self.max_position,) = struct_max_position.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_has_velocity_limits = struct.Struct("<B")
            (self.has_velocity_limits,) = struct_has_velocity_limits.unpack(buff[offset:(offset + 1)])
            self.has_velocity_limits = bool(self.has_velocity_limits)
            offset += 1
            struct_max_velocity = struct.Struct("<d")
            (self.max_velocity,) = struct_max_velocity.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_has_acceleration_limits = struct.Struct("<B")
            (self.has_acceleration_limits,) = struct_has_acceleration_limits.unpack(buff[offset:(offset + 1)])
            self.has_acceleration_limits = bool(self.has_acceleration_limits)
            offset += 1
            struct_max_acceleration = struct.Struct("<d")
            (self.max_acceleration,) = struct_max_acceleration.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        joint_name_x = self.joint_name
        joint_name_length = len(joint_name_x)
        if python3 or type(joint_name_x) == unicode:
            joint_name_x = joint_name_x.encode('utf-8')
            joint_name_length = len(joint_name_x)
        length += 4
        length += joint_name_length
        length += 1
        length += 8
        length += 8
        length += 1
        length += 8
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"joint_name":"%s"' % self.joint_name
        string_echo += ','
        string_echo += '"has_position_limits":%s' % self.has_position_limits
        string_echo += ','
        string_echo += '"min_position":%s' % self.min_position
        string_echo += ','
        string_echo += '"max_position":%s' % self.max_position
        string_echo += ','
        string_echo += '"has_velocity_limits":%s' % self.has_velocity_limits
        string_echo += ','
        string_echo += '"max_velocity":%s' % self.max_velocity
        string_echo += ','
        string_echo += '"has_acceleration_limits":%s' % self.has_acceleration_limits
        string_echo += ','
        string_echo += '"max_acceleration":%s' % self.max_acceleration
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/JointLimits"

    def getMD5(self):
        return "8ca618c7329ea46142cbc864a2efe856"

    def getDef(self):
        return "string joint_name\nbool has_position_limits\nfloat64 min_position\nfloat64 max_position\nbool has_velocity_limits\nfloat64 max_velocity\nbool has_acceleration_limits\nfloat64 max_acceleration\n"

_struct_I = struct.Struct('<I')

