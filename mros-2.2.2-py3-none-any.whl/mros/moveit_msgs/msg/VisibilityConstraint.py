import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.geometry_msgs.msg

class VisibilityConstraint(mros.Message):
    __slots__ = ['target_radius','target_pose','cone_sides','sensor_pose','max_view_angle','max_range_angle','sensor_view_direction','weight']
    _slot_types = ['float64','geometry_msgs/PoseStamped','int32','geometry_msgs/PoseStamped','float64','float64','uint8','float64']

    SENSOR_Z = 0
    SENSOR_Y = 1
    SENSOR_X = 2

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(VisibilityConstraint, self).__init__(*args, **kwds)
            if self.target_radius is None:
                self.target_radius = 0.
            if self.target_pose is None:
                self.target_pose = mros.geometry_msgs.msg.PoseStamped()
            if self.cone_sides is None:
                self.cone_sides = 0
            if self.sensor_pose is None:
                self.sensor_pose = mros.geometry_msgs.msg.PoseStamped()
            if self.max_view_angle is None:
                self.max_view_angle = 0.
            if self.max_range_angle is None:
                self.max_range_angle = 0.
            if self.sensor_view_direction is None:
                self.sensor_view_direction = 0
            if self.weight is None:
                self.weight = 0.
        else:
            self.target_radius = 0.
            self.target_pose = mros.geometry_msgs.msg.PoseStamped()
            self.cone_sides = 0
            self.sensor_pose = mros.geometry_msgs.msg.PoseStamped()
            self.max_view_angle = 0.
            self.max_range_angle = 0.
            self.sensor_view_direction = 0
            self.weight = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_target_radius = struct.Struct("<d")
            buff.write(struct_target_radius.pack(self.target_radius))
            offset += 8
            offset += self.target_pose.serialize(buff)
            struct_cone_sides = struct.Struct("<i")
            buff.write(struct_cone_sides.pack(self.cone_sides))
            offset += 4
            offset += self.sensor_pose.serialize(buff)
            struct_max_view_angle = struct.Struct("<d")
            buff.write(struct_max_view_angle.pack(self.max_view_angle))
            offset += 8
            struct_max_range_angle = struct.Struct("<d")
            buff.write(struct_max_range_angle.pack(self.max_range_angle))
            offset += 8
            struct_sensor_view_direction = struct.Struct("<B")
            buff.write(struct_sensor_view_direction.pack(self.sensor_view_direction))
            offset += 1
            struct_weight = struct.Struct("<d")
            buff.write(struct_weight.pack(self.weight))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_target_radius = struct.Struct("<d")
            (self.target_radius,) = struct_target_radius.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.target_pose.deserialize(buff[offset:])
            struct_cone_sides = struct.Struct("<i")
            (self.cone_sides,) = struct_cone_sides.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.sensor_pose.deserialize(buff[offset:])
            struct_max_view_angle = struct.Struct("<d")
            (self.max_view_angle,) = struct_max_view_angle.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_max_range_angle = struct.Struct("<d")
            (self.max_range_angle,) = struct_max_range_angle.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_sensor_view_direction = struct.Struct("<B")
            (self.sensor_view_direction,) = struct_sensor_view_direction.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_weight = struct.Struct("<d")
            (self.weight,) = struct_weight.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += self.target_pose.serializedLength()
        length += 4
        length += self.sensor_pose.serializedLength()
        length += 8
        length += 8
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"target_radius":%s' % self.target_radius
        string_echo += ','
        string_echo += '"target_pose":'
        string_echo += self.target_pose.echo()
        string_echo += ','
        string_echo += '"cone_sides":%s' % self.cone_sides
        string_echo += ','
        string_echo += '"sensor_pose":'
        string_echo += self.sensor_pose.echo()
        string_echo += ','
        string_echo += '"max_view_angle":%s' % self.max_view_angle
        string_echo += ','
        string_echo += '"max_range_angle":%s' % self.max_range_angle
        string_echo += ','
        string_echo += '"sensor_view_direction":%s' % self.sensor_view_direction
        string_echo += ','
        string_echo += '"weight":%s' % self.weight
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/VisibilityConstraint"

    def getMD5(self):
        return "62cda903bfe31ff2e5fcdc3810d577ad"

    def getDef(self):
        return "float64 target_radius\ngeometry_msgs/PoseStamped target_pose\nint32 cone_sides\ngeometry_msgs/PoseStamped sensor_pose\nfloat64 max_view_angle\nfloat64 max_range_angle\nuint8 SENSOR_Z=0\nuint8 SENSOR_Y=1\nuint8 SENSOR_X=2\nuint8 sensor_view_direction\nfloat64 weight\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

