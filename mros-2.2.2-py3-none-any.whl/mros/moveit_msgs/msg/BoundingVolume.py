import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.shape_msgs.msg
import mros.geometry_msgs.msg

class BoundingVolume(mros.Message):
    __slots__ = ['primitives','primitive_poses','meshes','mesh_poses']
    _slot_types = ['shape_msgs/SolidPrimitive[]','geometry_msgs/Pose[]','shape_msgs/Mesh[]','geometry_msgs/Pose[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(BoundingVolume, self).__init__(*args, **kwds)
            if self.primitives is None:
                self.primitives = []
            if self.primitive_poses is None:
                self.primitive_poses = []
            if self.meshes is None:
                self.meshes = []
            if self.mesh_poses is None:
                self.mesh_poses = []
        else:
            self.primitives = []
            self.primitive_poses = []
            self.meshes = []
            self.mesh_poses = []

    def serialize(self, buff):
        offset = 0
        try:
            primitives_length = len(self.primitives)
            buff.write(struct.pack('<I', primitives_length))
            offset += 4
            for i in range(0, primitives_length):
                offset += self.primitives[i].serialize(buff)
            primitive_poses_length = len(self.primitive_poses)
            buff.write(struct.pack('<I', primitive_poses_length))
            offset += 4
            for i in range(0, primitive_poses_length):
                offset += self.primitive_poses[i].serialize(buff)
            meshes_length = len(self.meshes)
            buff.write(struct.pack('<I', meshes_length))
            offset += 4
            for i in range(0, meshes_length):
                offset += self.meshes[i].serialize(buff)
            mesh_poses_length = len(self.mesh_poses)
            buff.write(struct.pack('<I', mesh_poses_length))
            offset += 4
            for i in range(0, mesh_poses_length):
                offset += self.mesh_poses[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (primitives_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.primitives) != primitives_length:
                self.primitives = [mros.shape_msgs.msg.SolidPrimitive() for _ in range(primitives_length)]
            for i in range(0, primitives_length):
                offset += self.primitives[i].deserialize(buff[offset:])
            (primitive_poses_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.primitive_poses) != primitive_poses_length:
                self.primitive_poses = [mros.geometry_msgs.msg.Pose() for _ in range(primitive_poses_length)]
            for i in range(0, primitive_poses_length):
                offset += self.primitive_poses[i].deserialize(buff[offset:])
            (meshes_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.meshes) != meshes_length:
                self.meshes = [mros.shape_msgs.msg.Mesh() for _ in range(meshes_length)]
            for i in range(0, meshes_length):
                offset += self.meshes[i].deserialize(buff[offset:])
            (mesh_poses_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.mesh_poses) != mesh_poses_length:
                self.mesh_poses = [mros.geometry_msgs.msg.Pose() for _ in range(mesh_poses_length)]
            for i in range(0, mesh_poses_length):
                offset += self.mesh_poses[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, primitives_length):
            length += self.primitives[i].serializedLength()
        length += 4
        for i in range(0, primitive_poses_length):
            length += self.primitive_poses[i].serializedLength()
        length += 4
        for i in range(0, meshes_length):
            length += self.meshes[i].serializedLength()
        length += 4
        for i in range(0, mesh_poses_length):
            length += self.mesh_poses[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"primitives":['
        primitives_length = len(self.primitives)
        for i in range(0, primitives_length):
            if i == (primitives_length - 1): 
                string_echo += '{primitives%s":' % i
                string_echo += self.primitives[i].echo()
                string_echo += ''
            else:
                string_echo += '{primitives%s":' % i
                string_echo += self.primitives[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"primitive_poses":['
        primitive_poses_length = len(self.primitive_poses)
        for i in range(0, primitive_poses_length):
            if i == (primitive_poses_length - 1): 
                string_echo += '{primitive_poses%s":' % i
                string_echo += self.primitive_poses[i].echo()
                string_echo += ''
            else:
                string_echo += '{primitive_poses%s":' % i
                string_echo += self.primitive_poses[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"meshes":['
        meshes_length = len(self.meshes)
        for i in range(0, meshes_length):
            if i == (meshes_length - 1): 
                string_echo += '{meshes%s":' % i
                string_echo += self.meshes[i].echo()
                string_echo += ''
            else:
                string_echo += '{meshes%s":' % i
                string_echo += self.meshes[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"mesh_poses":['
        mesh_poses_length = len(self.mesh_poses)
        for i in range(0, mesh_poses_length):
            if i == (mesh_poses_length - 1): 
                string_echo += '{mesh_poses%s":' % i
                string_echo += self.mesh_poses[i].echo()
                string_echo += ''
            else:
                string_echo += '{mesh_poses%s":' % i
                string_echo += self.mesh_poses[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/BoundingVolume"

    def getMD5(self):
        return "22db94010f39e9198032cb4a1aeda26e"

    def getDef(self):
        return "shape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

