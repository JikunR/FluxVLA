import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class MoveGroupSequenceFeedback(mros.Message):
    __slots__ = ['state']
    _slot_types = ['string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MoveGroupSequenceFeedback, self).__init__(*args, **kwds)
            if self.state is None:
                self.state = ''
        else:
            self.state = ''

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.state
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_state,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.state = buff[offset:(offset + length_state)].decode('utf-8')
            else:
                self.state = buff[offset:(offset + length_state)]
            offset += length_state
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        state_x = self.state
        state_length = len(state_x)
        if python3 or type(state_x) == unicode:
            state_x = state_x.encode('utf-8')
            state_length = len(state_x)
        length += 4
        length += state_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"state":"%s"' % self.state
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/MoveGroupSequenceFeedback"

    def getMD5(self):
        return "af6d3a99f0fbeb66d3248fa4b3e675fb"

    def getDef(self):
        return "string state\n"

_struct_I = struct.Struct('<I')

