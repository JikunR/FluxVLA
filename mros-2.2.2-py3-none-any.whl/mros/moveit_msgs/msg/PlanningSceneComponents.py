import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class PlanningSceneComponents(mros.Message):
    __slots__ = ['components']
    _slot_types = ['uint32']

    SCENE_SETTINGS = 1
    ROBOT_STATE = 2
    ROBOT_STATE_ATTACHED_OBJECTS = 4
    WORLD_OBJECT_NAMES = 8
    WORLD_OBJECT_GEOMETRY = 16
    OCTOMAP = 32
    TRANSFORMS = 64
    ALLOWED_COLLISION_MATRIX = 128
    LINK_PADDING_AND_SCALING = 256
    OBJECT_COLORS = 512

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlanningSceneComponents, self).__init__(*args, **kwds)
            if self.components is None:
                self.components = 0
        else:
            self.components = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.components))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.components,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"components":%s' % self.components
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PlanningSceneComponents"

    def getMD5(self):
        return "bc993e784476960b918b6e7ad5bb58ce"

    def getDef(self):
        return "uint32 SCENE_SETTINGS=1\nuint32 ROBOT_STATE=2\nuint32 ROBOT_STATE_ATTACHED_OBJECTS=4\nuint32 WORLD_OBJECT_NAMES=8\nuint32 WORLD_OBJECT_GEOMETRY=16\nuint32 OCTOMAP=32\nuint32 TRANSFORMS=64\nuint32 ALLOWED_COLLISION_MATRIX=128\nuint32 LINK_PADDING_AND_SCALING=256\nuint32 OBJECT_COLORS=512\nuint32 components\n"

_struct_I = struct.Struct('<I')

