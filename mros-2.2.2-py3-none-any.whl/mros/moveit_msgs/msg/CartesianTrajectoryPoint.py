import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class CartesianTrajectoryPoint(mros.Message):
    __slots__ = ['point','time_from_start']
    _slot_types = ['moveit_msgs/CartesianPoint','Duration']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CartesianTrajectoryPoint, self).__init__(*args, **kwds)
            if self.point is None:
                self.point = mros.moveit_msgs.msg.CartesianPoint()
            if self.time_from_start is None:
                self.time_from_start = mros.Duration()
        else:
            self.point = mros.moveit_msgs.msg.CartesianPoint()
            self.time_from_start = mros.Duration()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.point.serialize(buff)
            buff.write(_struct_I.pack(self.time_from_start.sec))
            offset += 4
            buff.write(_struct_I.pack(self.time_from_start.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.point.deserialize(buff[offset:])
            (self.time_from_start.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.time_from_start.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.point.serializedLength()
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"point":'
        string_echo += self.point.echo()
        string_echo += ','
        string_echo += '"time_from_start.sec":%s,' % self.time_from_start.sec
        string_echo += '"time_from_start.nsec":%s' % self.time_from_start.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/CartesianTrajectoryPoint"

    def getMD5(self):
        return "e996ea294f646e6911b3e85e624f5acf"

    def getDef(self):
        return "moveit_msgs/CartesianPoint point\nduration time_from_start\n================================================================================\nMSG: moveit_msgs/CartesianPoint\ngeometry_msgs/Pose pose\ngeometry_msgs/Twist velocity\ngeometry_msgs/Accel acceleration\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Accel\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

