import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class AllowedCollisionEntry(mros.Message):
    __slots__ = ['enabled']
    _slot_types = ['bool[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AllowedCollisionEntry, self).__init__(*args, **kwds)
            if self.enabled is None:
                self.enabled = []
        else:
            self.enabled = []

    def serialize(self, buff):
        offset = 0
        try:
            enabled_length = len(self.enabled)
            buff.write(struct.pack('<I', enabled_length))
            buff.write(struct.pack(f'<{enabled_length}B', *self.enabled))
            offset += 4 + enabled_length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (enabled_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.enabled = np.frombuffer(buff[offset:offset + enabled_length], dtype=np.uint8)
            offset += enabled_length
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += len(self.enabled)
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"enabled":['
        enabled_length = len(self.enabled)
        for i in range(0, enabled_length):
            if i == (enabled_length - 1): 
                string_echo += '%s' % self.enabled[i]
            else:
                string_echo += '%s,' % self.enabled[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/AllowedCollisionEntry"

    def getMD5(self):
        return "90d1ae1850840724bb043562fe3285fc"

    def getDef(self):
        return "bool[] enabled\n"

_struct_I = struct.Struct('<I')

