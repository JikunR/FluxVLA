import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class ContactInformation(mros.Message):
    __slots__ = ['header','position','normal','depth','contact_body_1','body_type_1','contact_body_2','body_type_2']
    _slot_types = ['std_msgs/Header','geometry_msgs/Point','geometry_msgs/Vector3','float64','string','uint32','string','uint32']

    ROBOT_LINK = 0
    WORLD_OBJECT = 1
    ROBOT_ATTACHED = 2

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ContactInformation, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.position is None:
                self.position = mros.geometry_msgs.msg.Point()
            if self.normal is None:
                self.normal = mros.geometry_msgs.msg.Vector3()
            if self.depth is None:
                self.depth = 0.
            if self.contact_body_1 is None:
                self.contact_body_1 = ''
            if self.body_type_1 is None:
                self.body_type_1 = 0
            if self.contact_body_2 is None:
                self.contact_body_2 = ''
            if self.body_type_2 is None:
                self.body_type_2 = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.position = mros.geometry_msgs.msg.Point()
            self.normal = mros.geometry_msgs.msg.Vector3()
            self.depth = 0.
            self.contact_body_1 = ''
            self.body_type_1 = 0
            self.contact_body_2 = ''
            self.body_type_2 = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.position.serialize(buff)
            offset += self.normal.serialize(buff)
            struct_depth = struct.Struct("<d")
            buff.write(struct_depth.pack(self.depth))
            offset += 8
            _x = self.contact_body_1
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(_struct_I.pack(self.body_type_1))
            offset += 4
            _x = self.contact_body_2
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(_struct_I.pack(self.body_type_2))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.position.deserialize(buff[offset:])
            offset += self.normal.deserialize(buff[offset:])
            struct_depth = struct.Struct("<d")
            (self.depth,) = struct_depth.unpack(buff[offset:(offset + 8)])
            offset += 8
            (length_contact_body_1,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.contact_body_1 = buff[offset:(offset + length_contact_body_1)].decode('utf-8')
            else:
                self.contact_body_1 = buff[offset:(offset + length_contact_body_1)]
            offset += length_contact_body_1
            (self.body_type_1,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_contact_body_2,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.contact_body_2 = buff[offset:(offset + length_contact_body_2)].decode('utf-8')
            else:
                self.contact_body_2 = buff[offset:(offset + length_contact_body_2)]
            offset += length_contact_body_2
            (self.body_type_2,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.position.serializedLength()
        length += self.normal.serializedLength()
        length += 8
        contact_body_1_x = self.contact_body_1
        contact_body_1_length = len(contact_body_1_x)
        if python3 or type(contact_body_1_x) == unicode:
            contact_body_1_x = contact_body_1_x.encode('utf-8')
            contact_body_1_length = len(contact_body_1_x)
        length += 4
        length += contact_body_1_length
        length += 4
        contact_body_2_x = self.contact_body_2
        contact_body_2_length = len(contact_body_2_x)
        if python3 or type(contact_body_2_x) == unicode:
            contact_body_2_x = contact_body_2_x.encode('utf-8')
            contact_body_2_length = len(contact_body_2_x)
        length += 4
        length += contact_body_2_length
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"position":'
        string_echo += self.position.echo()
        string_echo += ','
        string_echo += '"normal":'
        string_echo += self.normal.echo()
        string_echo += ','
        string_echo += '"depth":%s' % self.depth
        string_echo += ','
        string_echo += '"contact_body_1":"%s"' % self.contact_body_1
        string_echo += ','
        string_echo += '"body_type_1":%s' % self.body_type_1
        string_echo += ','
        string_echo += '"contact_body_2":"%s"' % self.contact_body_2
        string_echo += ','
        string_echo += '"body_type_2":%s' % self.body_type_2
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ContactInformation"

    def getMD5(self):
        return "116228ca08b0c286ec5ca32a50fdc17b"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Point position\ngeometry_msgs/Vector3 normal\nfloat64 depth\nstring contact_body_1\nuint32 body_type_1\nstring contact_body_2\nuint32 body_type_2\nuint32 ROBOT_LINK=0\nuint32 WORLD_OBJECT=1\nuint32 ROBOT_ATTACHED=2\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

