import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.octomap_msgs.msg

class PlanningSceneWorld(mros.Message):
    __slots__ = ['collision_objects','octomap']
    _slot_types = ['moveit_msgs/CollisionObject[]','octomap_msgs/OctomapWithPose']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlanningSceneWorld, self).__init__(*args, **kwds)
            if self.collision_objects is None:
                self.collision_objects = []
            if self.octomap is None:
                self.octomap = mros.octomap_msgs.msg.OctomapWithPose()
        else:
            self.collision_objects = []
            self.octomap = mros.octomap_msgs.msg.OctomapWithPose()

    def serialize(self, buff):
        offset = 0
        try:
            collision_objects_length = len(self.collision_objects)
            buff.write(struct.pack('<I', collision_objects_length))
            offset += 4
            for i in range(0, collision_objects_length):
                offset += self.collision_objects[i].serialize(buff)
            offset += self.octomap.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (collision_objects_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.collision_objects) != collision_objects_length:
                self.collision_objects = [mros.moveit_msgs.msg.CollisionObject() for _ in range(collision_objects_length)]
            for i in range(0, collision_objects_length):
                offset += self.collision_objects[i].deserialize(buff[offset:])
            offset += self.octomap.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, collision_objects_length):
            length += self.collision_objects[i].serializedLength()
        length += self.octomap.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"collision_objects":['
        collision_objects_length = len(self.collision_objects)
        for i in range(0, collision_objects_length):
            if i == (collision_objects_length - 1): 
                string_echo += '{collision_objects%s":' % i
                string_echo += self.collision_objects[i].echo()
                string_echo += ''
            else:
                string_echo += '{collision_objects%s":' % i
                string_echo += self.collision_objects[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"octomap":'
        string_echo += self.octomap.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PlanningSceneWorld"

    def getMD5(self):
        return "79457311445f53d410ab4e3781de8447"

    def getDef(self):
        return "moveit_msgs/CollisionObject[] collision_objects\noctomap_msgs/OctomapWithPose octomap\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: octomap_msgs/OctomapWithPose\nstd_msgs/Header header\ngeometry_msgs/Pose origin\noctomap_msgs/Octomap octomap\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: octomap_msgs/Octomap\nstd_msgs/Header header\nbool binary\nstring id\nfloat64 resolution\nint8[] data\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

