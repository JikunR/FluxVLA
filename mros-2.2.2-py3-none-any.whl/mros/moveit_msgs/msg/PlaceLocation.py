import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.trajectory_msgs.msg
import mros.geometry_msgs.msg

class PlaceLocation(mros.Message):
    __slots__ = ['id','post_place_posture','place_pose','quality','pre_place_approach','post_place_retreat','allowed_touch_objects']
    _slot_types = ['string','trajectory_msgs/JointTrajectory','geometry_msgs/PoseStamped','float64','moveit_msgs/GripperTranslation','moveit_msgs/GripperTranslation','string[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlaceLocation, self).__init__(*args, **kwds)
            if self.id is None:
                self.id = ''
            if self.post_place_posture is None:
                self.post_place_posture = mros.trajectory_msgs.msg.JointTrajectory()
            if self.place_pose is None:
                self.place_pose = mros.geometry_msgs.msg.PoseStamped()
            if self.quality is None:
                self.quality = 0.
            if self.pre_place_approach is None:
                self.pre_place_approach = mros.moveit_msgs.msg.GripperTranslation()
            if self.post_place_retreat is None:
                self.post_place_retreat = mros.moveit_msgs.msg.GripperTranslation()
            if self.allowed_touch_objects is None:
                self.allowed_touch_objects = []
        else:
            self.id = ''
            self.post_place_posture = mros.trajectory_msgs.msg.JointTrajectory()
            self.place_pose = mros.geometry_msgs.msg.PoseStamped()
            self.quality = 0.
            self.pre_place_approach = mros.moveit_msgs.msg.GripperTranslation()
            self.post_place_retreat = mros.moveit_msgs.msg.GripperTranslation()
            self.allowed_touch_objects = []

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.post_place_posture.serialize(buff)
            offset += self.place_pose.serialize(buff)
            struct_quality = struct.Struct("<d")
            buff.write(struct_quality.pack(self.quality))
            offset += 8
            offset += self.pre_place_approach.serialize(buff)
            offset += self.post_place_retreat.serialize(buff)
            allowed_touch_objects_length = len(self.allowed_touch_objects)
            buff.write(struct.pack('<I', allowed_touch_objects_length))
            offset += 4
            for i in range(0, allowed_touch_objects_length):
                _x = self.allowed_touch_objects[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.id = buff[offset:(offset + length_id)].decode('utf-8')
            else:
                self.id = buff[offset:(offset + length_id)]
            offset += length_id
            offset += self.post_place_posture.deserialize(buff[offset:])
            offset += self.place_pose.deserialize(buff[offset:])
            struct_quality = struct.Struct("<d")
            (self.quality,) = struct_quality.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.pre_place_approach.deserialize(buff[offset:])
            offset += self.post_place_retreat.deserialize(buff[offset:])
            (allowed_touch_objects_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.allowed_touch_objects) != allowed_touch_objects_length:
                self.allowed_touch_objects = ['' for _ in range(allowed_touch_objects_length)]
            for i in range(0, allowed_touch_objects_length):
                (length_allowed_touch_objectsi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.allowed_touch_objects[i] = buff[offset:(offset + length_allowed_touch_objectsi)].decode('utf-8')
                else:
                    self.allowed_touch_objects[i] = buff[offset:(offset + length_allowed_touch_objectsi)]
                offset += length_allowed_touch_objectsi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        id_x = self.id
        id_length = len(id_x)
        if python3 or type(id_x) == unicode:
            id_x = id_x.encode('utf-8')
            id_length = len(id_x)
        length += 4
        length += id_length
        length += self.post_place_posture.serializedLength()
        length += self.place_pose.serializedLength()
        length += 8
        length += self.pre_place_approach.serializedLength()
        length += self.post_place_retreat.serializedLength()
        length += 4
        for i in range(0, allowed_touch_objects_length):
            allowed_touch_objectsi_x = self.allowed_touch_objects[i]
            allowed_touch_objectsi_length = len(allowed_touch_objectsi_x)
            if python3 or type(allowed_touch_objectsi_x) == unicode:
                allowed_touch_objectsi_x = allowed_touch_objectsi_x.encode('utf-8')
                allowed_touch_objectsi_length = len(allowed_touch_objectsi_x)
            length += 4
            length += allowed_touch_objectsi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"id":"%s"' % self.id
        string_echo += ','
        string_echo += '"post_place_posture":'
        string_echo += self.post_place_posture.echo()
        string_echo += ','
        string_echo += '"place_pose":'
        string_echo += self.place_pose.echo()
        string_echo += ','
        string_echo += '"quality":%s' % self.quality
        string_echo += ','
        string_echo += '"pre_place_approach":'
        string_echo += self.pre_place_approach.echo()
        string_echo += ','
        string_echo += '"post_place_retreat":'
        string_echo += self.post_place_retreat.echo()
        string_echo += ','
        string_echo += '"allowed_touch_objects":['
        allowed_touch_objects_length = len(self.allowed_touch_objects)
        for i in range(0, allowed_touch_objects_length):
            if i == (allowed_touch_objects_length - 1): 
                string_echo += '"allowed_touch_objects[i]":"%s"' % self.allowed_touch_objects[i]
                string_echo += ''
            else:
                string_echo += '"allowed_touch_objects[i]":"%s"' % self.allowed_touch_objects[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PlaceLocation"

    def getMD5(self):
        return "7b53f032c68481686026c3e9223d0713"

    def getDef(self):
        return "string id\ntrajectory_msgs/JointTrajectory post_place_posture\ngeometry_msgs/PoseStamped place_pose\nfloat64 quality\nmoveit_msgs/GripperTranslation pre_place_approach\nmoveit_msgs/GripperTranslation post_place_retreat\nstring[] allowed_touch_objects\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: moveit_msgs/GripperTranslation\ngeometry_msgs/Vector3Stamped direction\nfloat32 desired_distance\nfloat32 min_distance\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Vector3Stamped\nstd_msgs/Header header\ngeometry_msgs/Vector3 vector\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

