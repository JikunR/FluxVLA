import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.actionlib_msgs.msg

class PickupActionResult(mros.Message):
    __slots__ = ['header','status','result']
    _slot_types = ['std_msgs/Header','actionlib_msgs/GoalStatus','moveit_msgs/PickupResult']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PickupActionResult, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.status is None:
                self.status = mros.actionlib_msgs.msg.GoalStatus()
            if self.result is None:
                self.result = mros.moveit_msgs.msg.PickupResult()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.status = mros.actionlib_msgs.msg.GoalStatus()
            self.result = mros.moveit_msgs.msg.PickupResult()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.status.serialize(buff)
            offset += self.result.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.status.deserialize(buff[offset:])
            offset += self.result.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.status.serializedLength()
        length += self.result.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ','
        string_echo += '"result":'
        string_echo += self.result.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PickupActionResult"

    def getMD5(self):
        return "189540b296d28419d294a1ba0f5dde17"

    def getDef(self):
        return "std_msgs/Header header\nactionlib_msgs/GoalStatus status\nmoveit_msgs/PickupResult result\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalStatus\nactionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: moveit_msgs/PickupResult\nmoveit_msgs/MoveItErrorCodes error_code\nmoveit_msgs/RobotState trajectory_start\nmoveit_msgs/RobotTrajectory[] trajectory_stages\nstring[] trajectory_descriptions\nmoveit_msgs/Grasp grasp\nfloat64 planning_time\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: moveit_msgs/RobotTrajectory\ntrajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: moveit_msgs/Grasp\nstring id\ntrajectory_msgs/JointTrajectory pre_grasp_posture\ntrajectory_msgs/JointTrajectory grasp_posture\ngeometry_msgs/PoseStamped grasp_pose\nfloat64 grasp_quality\nmoveit_msgs/GripperTranslation pre_grasp_approach\nmoveit_msgs/GripperTranslation post_grasp_retreat\nmoveit_msgs/GripperTranslation post_place_retreat\nfloat32 max_contact_force\nstring[] allowed_touch_objects\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: moveit_msgs/GripperTranslation\ngeometry_msgs/Vector3Stamped direction\nfloat32 desired_distance\nfloat32 min_distance\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Vector3Stamped\nstd_msgs/Header header\ngeometry_msgs/Vector3 vector\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

