import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class KinematicSolverInfo(mros.Message):
    __slots__ = ['joint_names','limits','link_names']
    _slot_types = ['string[]','moveit_msgs/JointLimits[]','string[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(KinematicSolverInfo, self).__init__(*args, **kwds)
            if self.joint_names is None:
                self.joint_names = []
            if self.limits is None:
                self.limits = []
            if self.link_names is None:
                self.link_names = []
        else:
            self.joint_names = []
            self.limits = []
            self.link_names = []

    def serialize(self, buff):
        offset = 0
        try:
            joint_names_length = len(self.joint_names)
            buff.write(struct.pack('<I', joint_names_length))
            offset += 4
            for i in range(0, joint_names_length):
                _x = self.joint_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            limits_length = len(self.limits)
            buff.write(struct.pack('<I', limits_length))
            offset += 4
            for i in range(0, limits_length):
                offset += self.limits[i].serialize(buff)
            link_names_length = len(self.link_names)
            buff.write(struct.pack('<I', link_names_length))
            offset += 4
            for i in range(0, link_names_length):
                _x = self.link_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (joint_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.joint_names) != joint_names_length:
                self.joint_names = ['' for _ in range(joint_names_length)]
            for i in range(0, joint_names_length):
                (length_joint_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)].decode('utf-8')
                else:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)]
                offset += length_joint_namesi
            (limits_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.limits) != limits_length:
                self.limits = [mros.moveit_msgs.msg.JointLimits() for _ in range(limits_length)]
            for i in range(0, limits_length):
                offset += self.limits[i].deserialize(buff[offset:])
            (link_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.link_names) != link_names_length:
                self.link_names = ['' for _ in range(link_names_length)]
            for i in range(0, link_names_length):
                (length_link_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.link_names[i] = buff[offset:(offset + length_link_namesi)].decode('utf-8')
                else:
                    self.link_names[i] = buff[offset:(offset + length_link_namesi)]
                offset += length_link_namesi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, joint_names_length):
            joint_namesi_x = self.joint_names[i]
            joint_namesi_length = len(joint_namesi_x)
            if python3 or type(joint_namesi_x) == unicode:
                joint_namesi_x = joint_namesi_x.encode('utf-8')
                joint_namesi_length = len(joint_namesi_x)
            length += 4
            length += joint_namesi_length
        length += 4
        for i in range(0, limits_length):
            length += self.limits[i].serializedLength()
        length += 4
        for i in range(0, link_names_length):
            link_namesi_x = self.link_names[i]
            link_namesi_length = len(link_namesi_x)
            if python3 or type(link_namesi_x) == unicode:
                link_namesi_x = link_namesi_x.encode('utf-8')
                link_namesi_length = len(link_namesi_x)
            length += 4
            length += link_namesi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"joint_names":['
        joint_names_length = len(self.joint_names)
        for i in range(0, joint_names_length):
            if i == (joint_names_length - 1): 
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ''
            else:
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"limits":['
        limits_length = len(self.limits)
        for i in range(0, limits_length):
            if i == (limits_length - 1): 
                string_echo += '{limits%s":' % i
                string_echo += self.limits[i].echo()
                string_echo += ''
            else:
                string_echo += '{limits%s":' % i
                string_echo += self.limits[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"link_names":['
        link_names_length = len(self.link_names)
        for i in range(0, link_names_length):
            if i == (link_names_length - 1): 
                string_echo += '"link_names[i]":"%s"' % self.link_names[i]
                string_echo += ''
            else:
                string_echo += '"link_names[i]":"%s"' % self.link_names[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/KinematicSolverInfo"

    def getMD5(self):
        return "cc048557c0f9795c392dd80f8bb00489"

    def getDef(self):
        return "string[] joint_names\nmoveit_msgs/JointLimits[] limits\nstring[] link_names\n================================================================================\nMSG: moveit_msgs/JointLimits\nstring joint_name\nbool has_position_limits\nfloat64 min_position\nfloat64 max_position\nbool has_velocity_limits\nfloat64 max_velocity\nbool has_acceleration_limits\nfloat64 max_acceleration\n"

_struct_I = struct.Struct('<I')

