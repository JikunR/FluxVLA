import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class PickupGoal(mros.Message):
    __slots__ = ['target_name','group_name','end_effector','possible_grasps','support_surface_name','allow_gripper_support_collision','attached_object_touch_links','minimize_object_distance','path_constraints','planner_id','allowed_touch_objects','allowed_planning_time','planning_options']
    _slot_types = ['string','string','string','moveit_msgs/Grasp[]','string','bool','string[]','bool','moveit_msgs/Constraints','string','string[]','float64','moveit_msgs/PlanningOptions']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PickupGoal, self).__init__(*args, **kwds)
            if self.target_name is None:
                self.target_name = ''
            if self.group_name is None:
                self.group_name = ''
            if self.end_effector is None:
                self.end_effector = ''
            if self.possible_grasps is None:
                self.possible_grasps = []
            if self.support_surface_name is None:
                self.support_surface_name = ''
            if self.allow_gripper_support_collision is None:
                self.allow_gripper_support_collision = False
            if self.attached_object_touch_links is None:
                self.attached_object_touch_links = []
            if self.minimize_object_distance is None:
                self.minimize_object_distance = False
            if self.path_constraints is None:
                self.path_constraints = mros.moveit_msgs.msg.Constraints()
            if self.planner_id is None:
                self.planner_id = ''
            if self.allowed_touch_objects is None:
                self.allowed_touch_objects = []
            if self.allowed_planning_time is None:
                self.allowed_planning_time = 0.
            if self.planning_options is None:
                self.planning_options = mros.moveit_msgs.msg.PlanningOptions()
        else:
            self.target_name = ''
            self.group_name = ''
            self.end_effector = ''
            self.possible_grasps = []
            self.support_surface_name = ''
            self.allow_gripper_support_collision = False
            self.attached_object_touch_links = []
            self.minimize_object_distance = False
            self.path_constraints = mros.moveit_msgs.msg.Constraints()
            self.planner_id = ''
            self.allowed_touch_objects = []
            self.allowed_planning_time = 0.
            self.planning_options = mros.moveit_msgs.msg.PlanningOptions()

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.target_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.group_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.end_effector
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            possible_grasps_length = len(self.possible_grasps)
            buff.write(struct.pack('<I', possible_grasps_length))
            offset += 4
            for i in range(0, possible_grasps_length):
                offset += self.possible_grasps[i].serialize(buff)
            _x = self.support_surface_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_allow_gripper_support_collision = struct.Struct("<B")
            buff.write(struct_allow_gripper_support_collision.pack(self.allow_gripper_support_collision))
            offset += 1
            attached_object_touch_links_length = len(self.attached_object_touch_links)
            buff.write(struct.pack('<I', attached_object_touch_links_length))
            offset += 4
            for i in range(0, attached_object_touch_links_length):
                _x = self.attached_object_touch_links[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            struct_minimize_object_distance = struct.Struct("<B")
            buff.write(struct_minimize_object_distance.pack(self.minimize_object_distance))
            offset += 1
            offset += self.path_constraints.serialize(buff)
            _x = self.planner_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            allowed_touch_objects_length = len(self.allowed_touch_objects)
            buff.write(struct.pack('<I', allowed_touch_objects_length))
            offset += 4
            for i in range(0, allowed_touch_objects_length):
                _x = self.allowed_touch_objects[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            struct_allowed_planning_time = struct.Struct("<d")
            buff.write(struct_allowed_planning_time.pack(self.allowed_planning_time))
            offset += 8
            offset += self.planning_options.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_target_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.target_name = buff[offset:(offset + length_target_name)].decode('utf-8')
            else:
                self.target_name = buff[offset:(offset + length_target_name)]
            offset += length_target_name
            (length_group_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.group_name = buff[offset:(offset + length_group_name)].decode('utf-8')
            else:
                self.group_name = buff[offset:(offset + length_group_name)]
            offset += length_group_name
            (length_end_effector,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.end_effector = buff[offset:(offset + length_end_effector)].decode('utf-8')
            else:
                self.end_effector = buff[offset:(offset + length_end_effector)]
            offset += length_end_effector
            (possible_grasps_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.possible_grasps) != possible_grasps_length:
                self.possible_grasps = [mros.moveit_msgs.msg.Grasp() for _ in range(possible_grasps_length)]
            for i in range(0, possible_grasps_length):
                offset += self.possible_grasps[i].deserialize(buff[offset:])
            (length_support_surface_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.support_surface_name = buff[offset:(offset + length_support_surface_name)].decode('utf-8')
            else:
                self.support_surface_name = buff[offset:(offset + length_support_surface_name)]
            offset += length_support_surface_name
            struct_allow_gripper_support_collision = struct.Struct("<B")
            (self.allow_gripper_support_collision,) = struct_allow_gripper_support_collision.unpack(buff[offset:(offset + 1)])
            self.allow_gripper_support_collision = bool(self.allow_gripper_support_collision)
            offset += 1
            (attached_object_touch_links_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.attached_object_touch_links) != attached_object_touch_links_length:
                self.attached_object_touch_links = ['' for _ in range(attached_object_touch_links_length)]
            for i in range(0, attached_object_touch_links_length):
                (length_attached_object_touch_linksi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.attached_object_touch_links[i] = buff[offset:(offset + length_attached_object_touch_linksi)].decode('utf-8')
                else:
                    self.attached_object_touch_links[i] = buff[offset:(offset + length_attached_object_touch_linksi)]
                offset += length_attached_object_touch_linksi
            struct_minimize_object_distance = struct.Struct("<B")
            (self.minimize_object_distance,) = struct_minimize_object_distance.unpack(buff[offset:(offset + 1)])
            self.minimize_object_distance = bool(self.minimize_object_distance)
            offset += 1
            offset += self.path_constraints.deserialize(buff[offset:])
            (length_planner_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.planner_id = buff[offset:(offset + length_planner_id)].decode('utf-8')
            else:
                self.planner_id = buff[offset:(offset + length_planner_id)]
            offset += length_planner_id
            (allowed_touch_objects_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.allowed_touch_objects) != allowed_touch_objects_length:
                self.allowed_touch_objects = ['' for _ in range(allowed_touch_objects_length)]
            for i in range(0, allowed_touch_objects_length):
                (length_allowed_touch_objectsi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.allowed_touch_objects[i] = buff[offset:(offset + length_allowed_touch_objectsi)].decode('utf-8')
                else:
                    self.allowed_touch_objects[i] = buff[offset:(offset + length_allowed_touch_objectsi)]
                offset += length_allowed_touch_objectsi
            struct_allowed_planning_time = struct.Struct("<d")
            (self.allowed_planning_time,) = struct_allowed_planning_time.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.planning_options.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        target_name_x = self.target_name
        target_name_length = len(target_name_x)
        if python3 or type(target_name_x) == unicode:
            target_name_x = target_name_x.encode('utf-8')
            target_name_length = len(target_name_x)
        length += 4
        length += target_name_length
        group_name_x = self.group_name
        group_name_length = len(group_name_x)
        if python3 or type(group_name_x) == unicode:
            group_name_x = group_name_x.encode('utf-8')
            group_name_length = len(group_name_x)
        length += 4
        length += group_name_length
        end_effector_x = self.end_effector
        end_effector_length = len(end_effector_x)
        if python3 or type(end_effector_x) == unicode:
            end_effector_x = end_effector_x.encode('utf-8')
            end_effector_length = len(end_effector_x)
        length += 4
        length += end_effector_length
        length += 4
        for i in range(0, possible_grasps_length):
            length += self.possible_grasps[i].serializedLength()
        support_surface_name_x = self.support_surface_name
        support_surface_name_length = len(support_surface_name_x)
        if python3 or type(support_surface_name_x) == unicode:
            support_surface_name_x = support_surface_name_x.encode('utf-8')
            support_surface_name_length = len(support_surface_name_x)
        length += 4
        length += support_surface_name_length
        length += 1
        length += 4
        for i in range(0, attached_object_touch_links_length):
            attached_object_touch_linksi_x = self.attached_object_touch_links[i]
            attached_object_touch_linksi_length = len(attached_object_touch_linksi_x)
            if python3 or type(attached_object_touch_linksi_x) == unicode:
                attached_object_touch_linksi_x = attached_object_touch_linksi_x.encode('utf-8')
                attached_object_touch_linksi_length = len(attached_object_touch_linksi_x)
            length += 4
            length += attached_object_touch_linksi_length
        length += 1
        length += self.path_constraints.serializedLength()
        planner_id_x = self.planner_id
        planner_id_length = len(planner_id_x)
        if python3 or type(planner_id_x) == unicode:
            planner_id_x = planner_id_x.encode('utf-8')
            planner_id_length = len(planner_id_x)
        length += 4
        length += planner_id_length
        length += 4
        for i in range(0, allowed_touch_objects_length):
            allowed_touch_objectsi_x = self.allowed_touch_objects[i]
            allowed_touch_objectsi_length = len(allowed_touch_objectsi_x)
            if python3 or type(allowed_touch_objectsi_x) == unicode:
                allowed_touch_objectsi_x = allowed_touch_objectsi_x.encode('utf-8')
                allowed_touch_objectsi_length = len(allowed_touch_objectsi_x)
            length += 4
            length += allowed_touch_objectsi_length
        length += 8
        length += self.planning_options.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"target_name":"%s"' % self.target_name
        string_echo += ','
        string_echo += '"group_name":"%s"' % self.group_name
        string_echo += ','
        string_echo += '"end_effector":"%s"' % self.end_effector
        string_echo += ','
        string_echo += '"possible_grasps":['
        possible_grasps_length = len(self.possible_grasps)
        for i in range(0, possible_grasps_length):
            if i == (possible_grasps_length - 1): 
                string_echo += '{possible_grasps%s":' % i
                string_echo += self.possible_grasps[i].echo()
                string_echo += ''
            else:
                string_echo += '{possible_grasps%s":' % i
                string_echo += self.possible_grasps[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"support_surface_name":"%s"' % self.support_surface_name
        string_echo += ','
        string_echo += '"allow_gripper_support_collision":%s' % self.allow_gripper_support_collision
        string_echo += ','
        string_echo += '"attached_object_touch_links":['
        attached_object_touch_links_length = len(self.attached_object_touch_links)
        for i in range(0, attached_object_touch_links_length):
            if i == (attached_object_touch_links_length - 1): 
                string_echo += '"attached_object_touch_links[i]":"%s"' % self.attached_object_touch_links[i]
                string_echo += ''
            else:
                string_echo += '"attached_object_touch_links[i]":"%s"' % self.attached_object_touch_links[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"minimize_object_distance":%s' % self.minimize_object_distance
        string_echo += ','
        string_echo += '"path_constraints":'
        string_echo += self.path_constraints.echo()
        string_echo += ','
        string_echo += '"planner_id":"%s"' % self.planner_id
        string_echo += ','
        string_echo += '"allowed_touch_objects":['
        allowed_touch_objects_length = len(self.allowed_touch_objects)
        for i in range(0, allowed_touch_objects_length):
            if i == (allowed_touch_objects_length - 1): 
                string_echo += '"allowed_touch_objects[i]":"%s"' % self.allowed_touch_objects[i]
                string_echo += ''
            else:
                string_echo += '"allowed_touch_objects[i]":"%s"' % self.allowed_touch_objects[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"allowed_planning_time":%s' % self.allowed_planning_time
        string_echo += ','
        string_echo += '"planning_options":'
        string_echo += self.planning_options.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PickupGoal"

    def getMD5(self):
        return "3a71f6f9bc6e640594ce6a411ccfe764"

    def getDef(self):
        return "string target_name\nstring group_name\nstring end_effector\nmoveit_msgs/Grasp[] possible_grasps\nstring support_surface_name\nbool allow_gripper_support_collision\nstring[] attached_object_touch_links\nbool minimize_object_distance\nmoveit_msgs/Constraints path_constraints\nstring planner_id\nstring[] allowed_touch_objects\nfloat64 allowed_planning_time\nmoveit_msgs/PlanningOptions planning_options\n================================================================================\nMSG: moveit_msgs/Grasp\nstring id\ntrajectory_msgs/JointTrajectory pre_grasp_posture\ntrajectory_msgs/JointTrajectory grasp_posture\ngeometry_msgs/PoseStamped grasp_pose\nfloat64 grasp_quality\nmoveit_msgs/GripperTranslation pre_grasp_approach\nmoveit_msgs/GripperTranslation post_grasp_retreat\nmoveit_msgs/GripperTranslation post_place_retreat\nfloat32 max_contact_force\nstring[] allowed_touch_objects\n================================================================================\nMSG: moveit_msgs/Constraints\nstring name\nmoveit_msgs/JointConstraint[] joint_constraints\nmoveit_msgs/PositionConstraint[] position_constraints\nmoveit_msgs/OrientationConstraint[] orientation_constraints\nmoveit_msgs/VisibilityConstraint[] visibility_constraints\n================================================================================\nMSG: moveit_msgs/PlanningOptions\nmoveit_msgs/PlanningScene planning_scene_diff\nbool plan_only\nbool look_around\nint32 look_around_attempts\nfloat64 max_safe_execution_cost\nbool replan\nint32 replan_attempts\nfloat64 replan_delay\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: moveit_msgs/GripperTranslation\ngeometry_msgs/Vector3Stamped direction\nfloat32 desired_distance\nfloat32 min_distance\n================================================================================\nMSG: moveit_msgs/JointConstraint\nstring joint_name\nfloat64 position\nfloat64 tolerance_above\nfloat64 tolerance_below\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PositionConstraint\nstd_msgs/Header header\nstring link_name\ngeometry_msgs/Vector3 target_point_offset\nmoveit_msgs/BoundingVolume constraint_region\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/OrientationConstraint\nstd_msgs/Header header\ngeometry_msgs/Quaternion orientation\nstring link_name\nfloat64 absolute_x_axis_tolerance\nfloat64 absolute_y_axis_tolerance\nfloat64 absolute_z_axis_tolerance\nuint8 parameterization\nuint8 XYZ_EULER_ANGLES=0\nuint8 ROTATION_VECTOR=1\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/VisibilityConstraint\nfloat64 target_radius\ngeometry_msgs/PoseStamped target_pose\nint32 cone_sides\ngeometry_msgs/PoseStamped sensor_pose\nfloat64 max_view_angle\nfloat64 max_range_angle\nuint8 SENSOR_Z=0\nuint8 SENSOR_Y=1\nuint8 SENSOR_X=2\nuint8 sensor_view_direction\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PlanningScene\nstring name\nmoveit_msgs/RobotState robot_state\nstring robot_model_name\ngeometry_msgs/TransformStamped[] fixed_frame_transforms\nmoveit_msgs/AllowedCollisionMatrix allowed_collision_matrix\nmoveit_msgs/LinkPadding[] link_padding\nmoveit_msgs/LinkScale[] link_scale\nmoveit_msgs/ObjectColor[] object_colors\nmoveit_msgs/PlanningSceneWorld world\nbool is_diff\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Vector3Stamped\nstd_msgs/Header header\ngeometry_msgs/Vector3 vector\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: moveit_msgs/BoundingVolume\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: geometry_msgs/TransformStamped\nstd_msgs/Header header\nstring child_frame_id\ngeometry_msgs/Transform transform\n================================================================================\nMSG: moveit_msgs/AllowedCollisionMatrix\nstring[] entry_names\nmoveit_msgs/AllowedCollisionEntry[] entry_values\nstring[] default_entry_names\nbool[] default_entry_values\n================================================================================\nMSG: moveit_msgs/LinkPadding\nstring link_name\nfloat64 padding\n================================================================================\nMSG: moveit_msgs/LinkScale\nstring link_name\nfloat64 scale\n================================================================================\nMSG: moveit_msgs/ObjectColor\nstring id\nstd_msgs/ColorRGBA color\n================================================================================\nMSG: moveit_msgs/PlanningSceneWorld\nmoveit_msgs/CollisionObject[] collision_objects\noctomap_msgs/OctomapWithPose octomap\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: moveit_msgs/AllowedCollisionEntry\nbool[] enabled\n================================================================================\nMSG: std_msgs/ColorRGBA\nfloat32 r\nfloat32 g\nfloat32 b\nfloat32 a\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: octomap_msgs/OctomapWithPose\nstd_msgs/Header header\ngeometry_msgs/Pose origin\noctomap_msgs/Octomap octomap\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: octomap_msgs/Octomap\nstd_msgs/Header header\nbool binary\nstring id\nfloat64 resolution\nint8[] data\n"

_struct_I = struct.Struct('<I')

