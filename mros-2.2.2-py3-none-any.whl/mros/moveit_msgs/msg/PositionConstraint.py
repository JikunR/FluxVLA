import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class PositionConstraint(mros.Message):
    __slots__ = ['header','link_name','target_point_offset','constraint_region','weight']
    _slot_types = ['std_msgs/Header','string','geometry_msgs/Vector3','moveit_msgs/BoundingVolume','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PositionConstraint, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.link_name is None:
                self.link_name = ''
            if self.target_point_offset is None:
                self.target_point_offset = mros.geometry_msgs.msg.Vector3()
            if self.constraint_region is None:
                self.constraint_region = mros.moveit_msgs.msg.BoundingVolume()
            if self.weight is None:
                self.weight = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.link_name = ''
            self.target_point_offset = mros.geometry_msgs.msg.Vector3()
            self.constraint_region = mros.moveit_msgs.msg.BoundingVolume()
            self.weight = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            _x = self.link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.target_point_offset.serialize(buff)
            offset += self.constraint_region.serialize(buff)
            struct_weight = struct.Struct("<d")
            buff.write(struct_weight.pack(self.weight))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (length_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.link_name = buff[offset:(offset + length_link_name)].decode('utf-8')
            else:
                self.link_name = buff[offset:(offset + length_link_name)]
            offset += length_link_name
            offset += self.target_point_offset.deserialize(buff[offset:])
            offset += self.constraint_region.deserialize(buff[offset:])
            struct_weight = struct.Struct("<d")
            (self.weight,) = struct_weight.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        link_name_x = self.link_name
        link_name_length = len(link_name_x)
        if python3 or type(link_name_x) == unicode:
            link_name_x = link_name_x.encode('utf-8')
            link_name_length = len(link_name_x)
        length += 4
        length += link_name_length
        length += self.target_point_offset.serializedLength()
        length += self.constraint_region.serializedLength()
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"link_name":"%s"' % self.link_name
        string_echo += ','
        string_echo += '"target_point_offset":'
        string_echo += self.target_point_offset.echo()
        string_echo += ','
        string_echo += '"constraint_region":'
        string_echo += self.constraint_region.echo()
        string_echo += ','
        string_echo += '"weight":%s' % self.weight
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PositionConstraint"

    def getMD5(self):
        return "c83edf208d87d3aa3169f47775a58e6a"

    def getDef(self):
        return "std_msgs/Header header\nstring link_name\ngeometry_msgs/Vector3 target_point_offset\nmoveit_msgs/BoundingVolume constraint_region\nfloat64 weight\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: moveit_msgs/BoundingVolume\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

