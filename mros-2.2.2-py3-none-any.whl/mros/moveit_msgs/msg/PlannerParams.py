import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class PlannerParams(mros.Message):
    __slots__ = ['keys','values','descriptions']
    _slot_types = ['string[]','string[]','string[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlannerParams, self).__init__(*args, **kwds)
            if self.keys is None:
                self.keys = []
            if self.values is None:
                self.values = []
            if self.descriptions is None:
                self.descriptions = []
        else:
            self.keys = []
            self.values = []
            self.descriptions = []

    def serialize(self, buff):
        offset = 0
        try:
            keys_length = len(self.keys)
            buff.write(struct.pack('<I', keys_length))
            offset += 4
            for i in range(0, keys_length):
                _x = self.keys[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            values_length = len(self.values)
            buff.write(struct.pack('<I', values_length))
            offset += 4
            for i in range(0, values_length):
                _x = self.values[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            descriptions_length = len(self.descriptions)
            buff.write(struct.pack('<I', descriptions_length))
            offset += 4
            for i in range(0, descriptions_length):
                _x = self.descriptions[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (keys_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.keys) != keys_length:
                self.keys = ['' for _ in range(keys_length)]
            for i in range(0, keys_length):
                (length_keysi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.keys[i] = buff[offset:(offset + length_keysi)].decode('utf-8')
                else:
                    self.keys[i] = buff[offset:(offset + length_keysi)]
                offset += length_keysi
            (values_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.values) != values_length:
                self.values = ['' for _ in range(values_length)]
            for i in range(0, values_length):
                (length_valuesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.values[i] = buff[offset:(offset + length_valuesi)].decode('utf-8')
                else:
                    self.values[i] = buff[offset:(offset + length_valuesi)]
                offset += length_valuesi
            (descriptions_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.descriptions) != descriptions_length:
                self.descriptions = ['' for _ in range(descriptions_length)]
            for i in range(0, descriptions_length):
                (length_descriptionsi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.descriptions[i] = buff[offset:(offset + length_descriptionsi)].decode('utf-8')
                else:
                    self.descriptions[i] = buff[offset:(offset + length_descriptionsi)]
                offset += length_descriptionsi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, keys_length):
            keysi_x = self.keys[i]
            keysi_length = len(keysi_x)
            if python3 or type(keysi_x) == unicode:
                keysi_x = keysi_x.encode('utf-8')
                keysi_length = len(keysi_x)
            length += 4
            length += keysi_length
        length += 4
        for i in range(0, values_length):
            valuesi_x = self.values[i]
            valuesi_length = len(valuesi_x)
            if python3 or type(valuesi_x) == unicode:
                valuesi_x = valuesi_x.encode('utf-8')
                valuesi_length = len(valuesi_x)
            length += 4
            length += valuesi_length
        length += 4
        for i in range(0, descriptions_length):
            descriptionsi_x = self.descriptions[i]
            descriptionsi_length = len(descriptionsi_x)
            if python3 or type(descriptionsi_x) == unicode:
                descriptionsi_x = descriptionsi_x.encode('utf-8')
                descriptionsi_length = len(descriptionsi_x)
            length += 4
            length += descriptionsi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"keys":['
        keys_length = len(self.keys)
        for i in range(0, keys_length):
            if i == (keys_length - 1): 
                string_echo += '"keys[i]":"%s"' % self.keys[i]
                string_echo += ''
            else:
                string_echo += '"keys[i]":"%s"' % self.keys[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"values":['
        values_length = len(self.values)
        for i in range(0, values_length):
            if i == (values_length - 1): 
                string_echo += '"values[i]":"%s"' % self.values[i]
                string_echo += ''
            else:
                string_echo += '"values[i]":"%s"' % self.values[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"descriptions":['
        descriptions_length = len(self.descriptions)
        for i in range(0, descriptions_length):
            if i == (descriptions_length - 1): 
                string_echo += '"descriptions[i]":"%s"' % self.descriptions[i]
                string_echo += ''
            else:
                string_echo += '"descriptions[i]":"%s"' % self.descriptions[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PlannerParams"

    def getMD5(self):
        return "cebdf4927996b9026bcf59a160d64145"

    def getDef(self):
        return "string[] keys\nstring[] values\nstring[] descriptions\n"

_struct_I = struct.Struct('<I')

