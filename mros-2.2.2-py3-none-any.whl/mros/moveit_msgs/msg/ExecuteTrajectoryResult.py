import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class ExecuteTrajectoryResult(mros.Message):
    __slots__ = ['error_code']
    _slot_types = ['moveit_msgs/MoveItErrorCodes']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ExecuteTrajectoryResult, self).__init__(*args, **kwds)
            if self.error_code is None:
                self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()
        else:
            self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.error_code.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.error_code.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.error_code.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"error_code":'
        string_echo += self.error_code.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/ExecuteTrajectoryResult"

    def getMD5(self):
        return "6a39f41e4bc445a437e9a0cabdd5ef5c"

    def getDef(self):
        return "moveit_msgs/MoveItErrorCodes error_code\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n"

_struct_I = struct.Struct('<I')

