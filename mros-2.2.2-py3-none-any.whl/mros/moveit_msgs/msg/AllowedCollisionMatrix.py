import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class AllowedCollisionMatrix(mros.Message):
    __slots__ = ['entry_names','entry_values','default_entry_names','default_entry_values']
    _slot_types = ['string[]','moveit_msgs/AllowedCollisionEntry[]','string[]','bool[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AllowedCollisionMatrix, self).__init__(*args, **kwds)
            if self.entry_names is None:
                self.entry_names = []
            if self.entry_values is None:
                self.entry_values = []
            if self.default_entry_names is None:
                self.default_entry_names = []
            if self.default_entry_values is None:
                self.default_entry_values = []
        else:
            self.entry_names = []
            self.entry_values = []
            self.default_entry_names = []
            self.default_entry_values = []

    def serialize(self, buff):
        offset = 0
        try:
            entry_names_length = len(self.entry_names)
            buff.write(struct.pack('<I', entry_names_length))
            offset += 4
            for i in range(0, entry_names_length):
                _x = self.entry_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            entry_values_length = len(self.entry_values)
            buff.write(struct.pack('<I', entry_values_length))
            offset += 4
            for i in range(0, entry_values_length):
                offset += self.entry_values[i].serialize(buff)
            default_entry_names_length = len(self.default_entry_names)
            buff.write(struct.pack('<I', default_entry_names_length))
            offset += 4
            for i in range(0, default_entry_names_length):
                _x = self.default_entry_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            default_entry_values_length = len(self.default_entry_values)
            buff.write(struct.pack('<I', default_entry_values_length))
            buff.write(struct.pack(f'<{default_entry_values_length}B', *self.default_entry_values))
            offset += 4 + default_entry_values_length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (entry_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.entry_names) != entry_names_length:
                self.entry_names = ['' for _ in range(entry_names_length)]
            for i in range(0, entry_names_length):
                (length_entry_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.entry_names[i] = buff[offset:(offset + length_entry_namesi)].decode('utf-8')
                else:
                    self.entry_names[i] = buff[offset:(offset + length_entry_namesi)]
                offset += length_entry_namesi
            (entry_values_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.entry_values) != entry_values_length:
                self.entry_values = [mros.moveit_msgs.msg.AllowedCollisionEntry() for _ in range(entry_values_length)]
            for i in range(0, entry_values_length):
                offset += self.entry_values[i].deserialize(buff[offset:])
            (default_entry_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.default_entry_names) != default_entry_names_length:
                self.default_entry_names = ['' for _ in range(default_entry_names_length)]
            for i in range(0, default_entry_names_length):
                (length_default_entry_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.default_entry_names[i] = buff[offset:(offset + length_default_entry_namesi)].decode('utf-8')
                else:
                    self.default_entry_names[i] = buff[offset:(offset + length_default_entry_namesi)]
                offset += length_default_entry_namesi
            (default_entry_values_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.default_entry_values = np.frombuffer(buff[offset:offset + default_entry_values_length], dtype=np.uint8)
            offset += default_entry_values_length
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, entry_names_length):
            entry_namesi_x = self.entry_names[i]
            entry_namesi_length = len(entry_namesi_x)
            if python3 or type(entry_namesi_x) == unicode:
                entry_namesi_x = entry_namesi_x.encode('utf-8')
                entry_namesi_length = len(entry_namesi_x)
            length += 4
            length += entry_namesi_length
        length += 4
        for i in range(0, entry_values_length):
            length += self.entry_values[i].serializedLength()
        length += 4
        for i in range(0, default_entry_names_length):
            default_entry_namesi_x = self.default_entry_names[i]
            default_entry_namesi_length = len(default_entry_namesi_x)
            if python3 or type(default_entry_namesi_x) == unicode:
                default_entry_namesi_x = default_entry_namesi_x.encode('utf-8')
                default_entry_namesi_length = len(default_entry_namesi_x)
            length += 4
            length += default_entry_namesi_length
        length += 4
        length += len(self.default_entry_values)
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"entry_names":['
        entry_names_length = len(self.entry_names)
        for i in range(0, entry_names_length):
            if i == (entry_names_length - 1): 
                string_echo += '"entry_names[i]":"%s"' % self.entry_names[i]
                string_echo += ''
            else:
                string_echo += '"entry_names[i]":"%s"' % self.entry_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"entry_values":['
        entry_values_length = len(self.entry_values)
        for i in range(0, entry_values_length):
            if i == (entry_values_length - 1): 
                string_echo += '{entry_values%s":' % i
                string_echo += self.entry_values[i].echo()
                string_echo += ''
            else:
                string_echo += '{entry_values%s":' % i
                string_echo += self.entry_values[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"default_entry_names":['
        default_entry_names_length = len(self.default_entry_names)
        for i in range(0, default_entry_names_length):
            if i == (default_entry_names_length - 1): 
                string_echo += '"default_entry_names[i]":"%s"' % self.default_entry_names[i]
                string_echo += ''
            else:
                string_echo += '"default_entry_names[i]":"%s"' % self.default_entry_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"default_entry_values":['
        default_entry_values_length = len(self.default_entry_values)
        for i in range(0, default_entry_values_length):
            if i == (default_entry_values_length - 1): 
                string_echo += '%s' % self.default_entry_values[i]
            else:
                string_echo += '%s,' % self.default_entry_values[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/AllowedCollisionMatrix"

    def getMD5(self):
        return "aedce13587eef0d79165a075659c1879"

    def getDef(self):
        return "string[] entry_names\nmoveit_msgs/AllowedCollisionEntry[] entry_values\nstring[] default_entry_names\nbool[] default_entry_values\n================================================================================\nMSG: moveit_msgs/AllowedCollisionEntry\nbool[] enabled\n"

_struct_I = struct.Struct('<I')

