import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class WorkspaceParameters(mros.Message):
    __slots__ = ['header','min_corner','max_corner']
    _slot_types = ['std_msgs/Header','geometry_msgs/Vector3','geometry_msgs/Vector3']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(WorkspaceParameters, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.min_corner is None:
                self.min_corner = mros.geometry_msgs.msg.Vector3()
            if self.max_corner is None:
                self.max_corner = mros.geometry_msgs.msg.Vector3()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.min_corner = mros.geometry_msgs.msg.Vector3()
            self.max_corner = mros.geometry_msgs.msg.Vector3()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.min_corner.serialize(buff)
            offset += self.max_corner.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.min_corner.deserialize(buff[offset:])
            offset += self.max_corner.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.min_corner.serializedLength()
        length += self.max_corner.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"min_corner":'
        string_echo += self.min_corner.echo()
        string_echo += ','
        string_echo += '"max_corner":'
        string_echo += self.max_corner.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/WorkspaceParameters"

    def getMD5(self):
        return "d639a834e7b1f927e9f1d6c30e920016"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Vector3 min_corner\ngeometry_msgs/Vector3 max_corner\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

