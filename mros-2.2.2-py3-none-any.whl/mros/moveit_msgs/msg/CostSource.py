import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.geometry_msgs.msg

class CostSource(mros.Message):
    __slots__ = ['cost_density','aabb_min','aabb_max']
    _slot_types = ['float64','geometry_msgs/Vector3','geometry_msgs/Vector3']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CostSource, self).__init__(*args, **kwds)
            if self.cost_density is None:
                self.cost_density = 0.
            if self.aabb_min is None:
                self.aabb_min = mros.geometry_msgs.msg.Vector3()
            if self.aabb_max is None:
                self.aabb_max = mros.geometry_msgs.msg.Vector3()
        else:
            self.cost_density = 0.
            self.aabb_min = mros.geometry_msgs.msg.Vector3()
            self.aabb_max = mros.geometry_msgs.msg.Vector3()

    def serialize(self, buff):
        offset = 0
        try:
            struct_cost_density = struct.Struct("<d")
            buff.write(struct_cost_density.pack(self.cost_density))
            offset += 8
            offset += self.aabb_min.serialize(buff)
            offset += self.aabb_max.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_cost_density = struct.Struct("<d")
            (self.cost_density,) = struct_cost_density.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.aabb_min.deserialize(buff[offset:])
            offset += self.aabb_max.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += self.aabb_min.serializedLength()
        length += self.aabb_max.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"cost_density":%s' % self.cost_density
        string_echo += ','
        string_echo += '"aabb_min":'
        string_echo += self.aabb_min.echo()
        string_echo += ','
        string_echo += '"aabb_max":'
        string_echo += self.aabb_max.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/CostSource"

    def getMD5(self):
        return "abb7e013237dacaaa8b97e704102f908"

    def getDef(self):
        return "float64 cost_density\ngeometry_msgs/Vector3 aabb_min\ngeometry_msgs/Vector3 aabb_max\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

