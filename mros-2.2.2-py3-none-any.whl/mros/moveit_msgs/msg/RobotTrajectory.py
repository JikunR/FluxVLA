import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.trajectory_msgs.msg

class RobotTrajectory(mros.Message):
    __slots__ = ['joint_trajectory','multi_dof_joint_trajectory']
    _slot_types = ['trajectory_msgs/JointTrajectory','trajectory_msgs/MultiDOFJointTrajectory']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotTrajectory, self).__init__(*args, **kwds)
            if self.joint_trajectory is None:
                self.joint_trajectory = mros.trajectory_msgs.msg.JointTrajectory()
            if self.multi_dof_joint_trajectory is None:
                self.multi_dof_joint_trajectory = mros.trajectory_msgs.msg.MultiDOFJointTrajectory()
        else:
            self.joint_trajectory = mros.trajectory_msgs.msg.JointTrajectory()
            self.multi_dof_joint_trajectory = mros.trajectory_msgs.msg.MultiDOFJointTrajectory()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.joint_trajectory.serialize(buff)
            offset += self.multi_dof_joint_trajectory.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.joint_trajectory.deserialize(buff[offset:])
            offset += self.multi_dof_joint_trajectory.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.joint_trajectory.serializedLength()
        length += self.multi_dof_joint_trajectory.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"joint_trajectory":'
        string_echo += self.joint_trajectory.echo()
        string_echo += ','
        string_echo += '"multi_dof_joint_trajectory":'
        string_echo += self.multi_dof_joint_trajectory.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/RobotTrajectory"

    def getMD5(self):
        return "dfa9556423d709a3729bcef664bddf67"

    def getDef(self):
        return "trajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

