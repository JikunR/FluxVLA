import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class PlannerInterfaceDescription(mros.Message):
    __slots__ = ['name','pipeline_id','planner_ids']
    _slot_types = ['string','string','string[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlannerInterfaceDescription, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.pipeline_id is None:
                self.pipeline_id = ''
            if self.planner_ids is None:
                self.planner_ids = []
        else:
            self.name = ''
            self.pipeline_id = ''
            self.planner_ids = []

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.pipeline_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            planner_ids_length = len(self.planner_ids)
            buff.write(struct.pack('<I', planner_ids_length))
            offset += 4
            for i in range(0, planner_ids_length):
                _x = self.planner_ids[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (length_pipeline_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.pipeline_id = buff[offset:(offset + length_pipeline_id)].decode('utf-8')
            else:
                self.pipeline_id = buff[offset:(offset + length_pipeline_id)]
            offset += length_pipeline_id
            (planner_ids_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.planner_ids) != planner_ids_length:
                self.planner_ids = ['' for _ in range(planner_ids_length)]
            for i in range(0, planner_ids_length):
                (length_planner_idsi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.planner_ids[i] = buff[offset:(offset + length_planner_idsi)].decode('utf-8')
                else:
                    self.planner_ids[i] = buff[offset:(offset + length_planner_idsi)]
                offset += length_planner_idsi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        pipeline_id_x = self.pipeline_id
        pipeline_id_length = len(pipeline_id_x)
        if python3 or type(pipeline_id_x) == unicode:
            pipeline_id_x = pipeline_id_x.encode('utf-8')
            pipeline_id_length = len(pipeline_id_x)
        length += 4
        length += pipeline_id_length
        length += 4
        for i in range(0, planner_ids_length):
            planner_idsi_x = self.planner_ids[i]
            planner_idsi_length = len(planner_idsi_x)
            if python3 or type(planner_idsi_x) == unicode:
                planner_idsi_x = planner_idsi_x.encode('utf-8')
                planner_idsi_length = len(planner_idsi_x)
            length += 4
            length += planner_idsi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"pipeline_id":"%s"' % self.pipeline_id
        string_echo += ','
        string_echo += '"planner_ids":['
        planner_ids_length = len(self.planner_ids)
        for i in range(0, planner_ids_length):
            if i == (planner_ids_length - 1): 
                string_echo += '"planner_ids[i]":"%s"' % self.planner_ids[i]
                string_echo += ''
            else:
                string_echo += '"planner_ids[i]":"%s"' % self.planner_ids[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PlannerInterfaceDescription"

    def getMD5(self):
        return "3b93afb00ba165a83730c4eb03cd1ab7"

    def getDef(self):
        return "string name\nstring pipeline_id\nstring[] planner_ids\n"

_struct_I = struct.Struct('<I')

