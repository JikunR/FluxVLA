import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.sensor_msgs.msg

class RobotState(mros.Message):
    __slots__ = ['joint_state','multi_dof_joint_state','attached_collision_objects','is_diff']
    _slot_types = ['sensor_msgs/JointState','sensor_msgs/MultiDOFJointState','moveit_msgs/AttachedCollisionObject[]','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotState, self).__init__(*args, **kwds)
            if self.joint_state is None:
                self.joint_state = mros.sensor_msgs.msg.JointState()
            if self.multi_dof_joint_state is None:
                self.multi_dof_joint_state = mros.sensor_msgs.msg.MultiDOFJointState()
            if self.attached_collision_objects is None:
                self.attached_collision_objects = []
            if self.is_diff is None:
                self.is_diff = False
        else:
            self.joint_state = mros.sensor_msgs.msg.JointState()
            self.multi_dof_joint_state = mros.sensor_msgs.msg.MultiDOFJointState()
            self.attached_collision_objects = []
            self.is_diff = False

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.joint_state.serialize(buff)
            offset += self.multi_dof_joint_state.serialize(buff)
            attached_collision_objects_length = len(self.attached_collision_objects)
            buff.write(struct.pack('<I', attached_collision_objects_length))
            offset += 4
            for i in range(0, attached_collision_objects_length):
                offset += self.attached_collision_objects[i].serialize(buff)
            struct_is_diff = struct.Struct("<B")
            buff.write(struct_is_diff.pack(self.is_diff))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.joint_state.deserialize(buff[offset:])
            offset += self.multi_dof_joint_state.deserialize(buff[offset:])
            (attached_collision_objects_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.attached_collision_objects) != attached_collision_objects_length:
                self.attached_collision_objects = [mros.moveit_msgs.msg.AttachedCollisionObject() for _ in range(attached_collision_objects_length)]
            for i in range(0, attached_collision_objects_length):
                offset += self.attached_collision_objects[i].deserialize(buff[offset:])
            struct_is_diff = struct.Struct("<B")
            (self.is_diff,) = struct_is_diff.unpack(buff[offset:(offset + 1)])
            self.is_diff = bool(self.is_diff)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.joint_state.serializedLength()
        length += self.multi_dof_joint_state.serializedLength()
        length += 4
        for i in range(0, attached_collision_objects_length):
            length += self.attached_collision_objects[i].serializedLength()
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"joint_state":'
        string_echo += self.joint_state.echo()
        string_echo += ','
        string_echo += '"multi_dof_joint_state":'
        string_echo += self.multi_dof_joint_state.echo()
        string_echo += ','
        string_echo += '"attached_collision_objects":['
        attached_collision_objects_length = len(self.attached_collision_objects)
        for i in range(0, attached_collision_objects_length):
            if i == (attached_collision_objects_length - 1): 
                string_echo += '{attached_collision_objects%s":' % i
                string_echo += self.attached_collision_objects[i].echo()
                string_echo += ''
            else:
                string_echo += '{attached_collision_objects%s":' % i
                string_echo += self.attached_collision_objects[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"is_diff":%s' % self.is_diff
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/RobotState"

    def getMD5(self):
        return "968156f4aa4cb4018f1f2293eebcea8f"

    def getDef(self):
        return "sensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

