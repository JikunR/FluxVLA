import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg
import mros.std_msgs.msg
import mros.actionlib_msgs.msg

class PickupActionGoal(mros.Message):
    __slots__ = ['header','goal_id','goal']
    _slot_types = ['std_msgs/Header','actionlib_msgs/GoalID','moveit_msgs/PickupGoal']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PickupActionGoal, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.goal_id is None:
                self.goal_id = mros.actionlib_msgs.msg.GoalID()
            if self.goal is None:
                self.goal = mros.moveit_msgs.msg.PickupGoal()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.goal_id = mros.actionlib_msgs.msg.GoalID()
            self.goal = mros.moveit_msgs.msg.PickupGoal()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.goal_id.serialize(buff)
            offset += self.goal.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.goal_id.deserialize(buff[offset:])
            offset += self.goal.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.goal_id.serializedLength()
        length += self.goal.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"goal_id":'
        string_echo += self.goal_id.echo()
        string_echo += ','
        string_echo += '"goal":'
        string_echo += self.goal.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/PickupActionGoal"

    def getMD5(self):
        return "83bb430d120a16fadf2ea3aad239f1d1"

    def getDef(self):
        return "std_msgs/Header header\nactionlib_msgs/GoalID goal_id\nmoveit_msgs/PickupGoal goal\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: moveit_msgs/PickupGoal\nstring target_name\nstring group_name\nstring end_effector\nmoveit_msgs/Grasp[] possible_grasps\nstring support_surface_name\nbool allow_gripper_support_collision\nstring[] attached_object_touch_links\nbool minimize_object_distance\nmoveit_msgs/Constraints path_constraints\nstring planner_id\nstring[] allowed_touch_objects\nfloat64 allowed_planning_time\nmoveit_msgs/PlanningOptions planning_options\n================================================================================\nMSG: moveit_msgs/Grasp\nstring id\ntrajectory_msgs/JointTrajectory pre_grasp_posture\ntrajectory_msgs/JointTrajectory grasp_posture\ngeometry_msgs/PoseStamped grasp_pose\nfloat64 grasp_quality\nmoveit_msgs/GripperTranslation pre_grasp_approach\nmoveit_msgs/GripperTranslation post_grasp_retreat\nmoveit_msgs/GripperTranslation post_place_retreat\nfloat32 max_contact_force\nstring[] allowed_touch_objects\n================================================================================\nMSG: moveit_msgs/Constraints\nstring name\nmoveit_msgs/JointConstraint[] joint_constraints\nmoveit_msgs/PositionConstraint[] position_constraints\nmoveit_msgs/OrientationConstraint[] orientation_constraints\nmoveit_msgs/VisibilityConstraint[] visibility_constraints\n================================================================================\nMSG: moveit_msgs/PlanningOptions\nmoveit_msgs/PlanningScene planning_scene_diff\nbool plan_only\nbool look_around\nint32 look_around_attempts\nfloat64 max_safe_execution_cost\nbool replan\nint32 replan_attempts\nfloat64 replan_delay\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: moveit_msgs/GripperTranslation\ngeometry_msgs/Vector3Stamped direction\nfloat32 desired_distance\nfloat32 min_distance\n================================================================================\nMSG: moveit_msgs/JointConstraint\nstring joint_name\nfloat64 position\nfloat64 tolerance_above\nfloat64 tolerance_below\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PositionConstraint\nstd_msgs/Header header\nstring link_name\ngeometry_msgs/Vector3 target_point_offset\nmoveit_msgs/BoundingVolume constraint_region\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/OrientationConstraint\nstd_msgs/Header header\ngeometry_msgs/Quaternion orientation\nstring link_name\nfloat64 absolute_x_axis_tolerance\nfloat64 absolute_y_axis_tolerance\nfloat64 absolute_z_axis_tolerance\nuint8 parameterization\nuint8 XYZ_EULER_ANGLES=0\nuint8 ROTATION_VECTOR=1\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/VisibilityConstraint\nfloat64 target_radius\ngeometry_msgs/PoseStamped target_pose\nint32 cone_sides\ngeometry_msgs/PoseStamped sensor_pose\nfloat64 max_view_angle\nfloat64 max_range_angle\nuint8 SENSOR_Z=0\nuint8 SENSOR_Y=1\nuint8 SENSOR_X=2\nuint8 sensor_view_direction\nfloat64 weight\n================================================================================\nMSG: moveit_msgs/PlanningScene\nstring name\nmoveit_msgs/RobotState robot_state\nstring robot_model_name\ngeometry_msgs/TransformStamped[] fixed_frame_transforms\nmoveit_msgs/AllowedCollisionMatrix allowed_collision_matrix\nmoveit_msgs/LinkPadding[] link_padding\nmoveit_msgs/LinkScale[] link_scale\nmoveit_msgs/ObjectColor[] object_colors\nmoveit_msgs/PlanningSceneWorld world\nbool is_diff\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Vector3Stamped\nstd_msgs/Header header\ngeometry_msgs/Vector3 vector\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: moveit_msgs/BoundingVolume\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: geometry_msgs/TransformStamped\nstd_msgs/Header header\nstring child_frame_id\ngeometry_msgs/Transform transform\n================================================================================\nMSG: moveit_msgs/AllowedCollisionMatrix\nstring[] entry_names\nmoveit_msgs/AllowedCollisionEntry[] entry_values\nstring[] default_entry_names\nbool[] default_entry_values\n================================================================================\nMSG: moveit_msgs/LinkPadding\nstring link_name\nfloat64 padding\n================================================================================\nMSG: moveit_msgs/LinkScale\nstring link_name\nfloat64 scale\n================================================================================\nMSG: moveit_msgs/ObjectColor\nstring id\nstd_msgs/ColorRGBA color\n================================================================================\nMSG: moveit_msgs/PlanningSceneWorld\nmoveit_msgs/CollisionObject[] collision_objects\noctomap_msgs/OctomapWithPose octomap\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: moveit_msgs/AllowedCollisionEntry\nbool[] enabled\n================================================================================\nMSG: std_msgs/ColorRGBA\nfloat32 r\nfloat32 g\nfloat32 b\nfloat32 a\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: octomap_msgs/OctomapWithPose\nstd_msgs/Header header\ngeometry_msgs/Pose origin\noctomap_msgs/Octomap octomap\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: octomap_msgs/Octomap\nstd_msgs/Header header\nbool binary\nstring id\nfloat64 resolution\nint8[] data\n"

_struct_I = struct.Struct('<I')

