import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.moveit_msgs.msg

class MotionSequenceResponse(mros.Message):
    __slots__ = ['error_code','sequence_start','planned_trajectories','planning_time']
    _slot_types = ['moveit_msgs/MoveItErrorCodes','moveit_msgs/RobotState','moveit_msgs/RobotTrajectory[]','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MotionSequenceResponse, self).__init__(*args, **kwds)
            if self.error_code is None:
                self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()
            if self.sequence_start is None:
                self.sequence_start = mros.moveit_msgs.msg.RobotState()
            if self.planned_trajectories is None:
                self.planned_trajectories = []
            if self.planning_time is None:
                self.planning_time = 0.
        else:
            self.error_code = mros.moveit_msgs.msg.MoveItErrorCodes()
            self.sequence_start = mros.moveit_msgs.msg.RobotState()
            self.planned_trajectories = []
            self.planning_time = 0.

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.error_code.serialize(buff)
            offset += self.sequence_start.serialize(buff)
            planned_trajectories_length = len(self.planned_trajectories)
            buff.write(struct.pack('<I', planned_trajectories_length))
            offset += 4
            for i in range(0, planned_trajectories_length):
                offset += self.planned_trajectories[i].serialize(buff)
            struct_planning_time = struct.Struct("<d")
            buff.write(struct_planning_time.pack(self.planning_time))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.error_code.deserialize(buff[offset:])
            offset += self.sequence_start.deserialize(buff[offset:])
            (planned_trajectories_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.planned_trajectories) != planned_trajectories_length:
                self.planned_trajectories = [mros.moveit_msgs.msg.RobotTrajectory() for _ in range(planned_trajectories_length)]
            for i in range(0, planned_trajectories_length):
                offset += self.planned_trajectories[i].deserialize(buff[offset:])
            struct_planning_time = struct.Struct("<d")
            (self.planning_time,) = struct_planning_time.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.error_code.serializedLength()
        length += self.sequence_start.serializedLength()
        length += 4
        for i in range(0, planned_trajectories_length):
            length += self.planned_trajectories[i].serializedLength()
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"error_code":'
        string_echo += self.error_code.echo()
        string_echo += ','
        string_echo += '"sequence_start":'
        string_echo += self.sequence_start.echo()
        string_echo += ','
        string_echo += '"planned_trajectories":['
        planned_trajectories_length = len(self.planned_trajectories)
        for i in range(0, planned_trajectories_length):
            if i == (planned_trajectories_length - 1): 
                string_echo += '{planned_trajectories%s":' % i
                string_echo += self.planned_trajectories[i].echo()
                string_echo += ''
            else:
                string_echo += '{planned_trajectories%s":' % i
                string_echo += self.planned_trajectories[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"planning_time":%s' % self.planning_time
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "moveit_msgs/MotionSequenceResponse"

    def getMD5(self):
        return "6c3d81f7909577545c3c382f38a163e2"

    def getDef(self):
        return "moveit_msgs/MoveItErrorCodes error_code\nmoveit_msgs/RobotState sequence_start\nmoveit_msgs/RobotTrajectory[] planned_trajectories\nfloat64 planning_time\n================================================================================\nMSG: moveit_msgs/MoveItErrorCodes\nint32 val\nint32 SUCCESS=1\nint32 FAILURE=99999\nint32 PLANNING_FAILED=-1\nint32 INVALID_MOTION_PLAN=-2\nint32 MOTION_PLAN_INVALIDATED_BY_ENVIRONMENT_CHANGE=-3\nint32 CONTROL_FAILED=-4\nint32 UNABLE_TO_AQUIRE_SENSOR_DATA=-5\nint32 TIMED_OUT=-6\nint32 PREEMPTED=-7\nint32 START_STATE_IN_COLLISION=-10\nint32 START_STATE_VIOLATES_PATH_CONSTRAINTS=-11\nint32 START_STATE_INVALID=-26\nint32 GOAL_IN_COLLISION=-12\nint32 GOAL_VIOLATES_PATH_CONSTRAINTS=-13\nint32 GOAL_CONSTRAINTS_VIOLATED=-14\nint32 GOAL_STATE_INVALID=-27\nint32 UNRECOGNIZED_GOAL_TYPE=-28\nint32 INVALID_GROUP_NAME=-15\nint32 INVALID_GOAL_CONSTRAINTS=-16\nint32 INVALID_ROBOT_STATE=-17\nint32 INVALID_LINK_NAME=-18\nint32 INVALID_OBJECT_NAME=-19\nint32 FRAME_TRANSFORM_FAILURE=-21\nint32 COLLISION_CHECKING_UNAVAILABLE=-22\nint32 ROBOT_STATE_STALE=-23\nint32 SENSOR_INFO_STALE=-24\nint32 COMMUNICATION_FAILURE=-25\nint32 CRASH=-29\nint32 ABORT=-30\nint32 NO_IK_SOLUTION=-31\n================================================================================\nMSG: moveit_msgs/RobotState\nsensor_msgs/JointState joint_state\nsensor_msgs/MultiDOFJointState multi_dof_joint_state\nmoveit_msgs/AttachedCollisionObject[] attached_collision_objects\nbool is_diff\n================================================================================\nMSG: moveit_msgs/RobotTrajectory\ntrajectory_msgs/JointTrajectory joint_trajectory\ntrajectory_msgs/MultiDOFJointTrajectory multi_dof_joint_trajectory\n================================================================================\nMSG: sensor_msgs/JointState\nstd_msgs/Header header\nstring[] name\nfloat64[] position\nfloat64[] velocity\nfloat64[] effort\n================================================================================\nMSG: sensor_msgs/MultiDOFJointState\nstd_msgs/Header header\nstring[] joint_names\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: moveit_msgs/AttachedCollisionObject\nstring link_name\nmoveit_msgs/CollisionObject object\nstring[] touch_links\ntrajectory_msgs/JointTrajectory detach_posture\nfloat64 weight\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/MultiDOFJointTrajectoryPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Transform\ngeometry_msgs/Vector3 translation\ngeometry_msgs/Quaternion rotation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: moveit_msgs/CollisionObject\nstd_msgs/Header header\ngeometry_msgs/Pose pose\nstring id\nobject_recognition_msgs/ObjectType type\nshape_msgs/SolidPrimitive[] primitives\ngeometry_msgs/Pose[] primitive_poses\nshape_msgs/Mesh[] meshes\ngeometry_msgs/Pose[] mesh_poses\nshape_msgs/Plane[] planes\ngeometry_msgs/Pose[] plane_poses\nstring[] subframe_names\ngeometry_msgs/Pose[] subframe_poses\nbyte ADD=0\nbyte REMOVE=1\nbyte APPEND=2\nbyte MOVE=3\nbyte operation\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: trajectory_msgs/MultiDOFJointTrajectoryPoint\ngeometry_msgs/Transform[] transforms\ngeometry_msgs/Twist[] velocities\ngeometry_msgs/Twist[] accelerations\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: object_recognition_msgs/ObjectType\nstring key\nstring db\n================================================================================\nMSG: shape_msgs/SolidPrimitive\nuint8 BOX=1\nuint8 SPHERE=2\nuint8 CYLINDER=3\nuint8 CONE=4\nuint8 type\nfloat64[] dimensions\nuint8 BOX_X=0\nuint8 BOX_Y=1\nuint8 BOX_Z=2\nuint8 SPHERE_RADIUS=0\nuint8 CYLINDER_HEIGHT=0\nuint8 CYLINDER_RADIUS=1\nuint8 CONE_HEIGHT=0\nuint8 CONE_RADIUS=1\n================================================================================\nMSG: shape_msgs/Mesh\nshape_msgs/MeshTriangle[] triangles\ngeometry_msgs/Point[] vertices\n================================================================================\nMSG: shape_msgs/Plane\nfloat64[4] coef\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: shape_msgs/MeshTriangle\nuint32[3] vertex_indices\n"

_struct_I = struct.Struct('<I')

