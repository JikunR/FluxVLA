import sys
import mros


class ServiceServer(object):
    __slots__ = ['topic_name', 'user_callback', 'data_req_class', 'data_resp_class', 'req_msg_orig', 'req_message_type',
                 'req_md5sum', 'req_msg_def', 'req_sub', 'resp_pub']

    def __init__(self, topic_name: str, user_callback, data_req_class, data_resp_class):
        self.topic_name = topic_name
        self.user_callback = user_callback

        self.data_req_class = data_req_class
        self.data_resp_class = data_resp_class

        self.req_msg_orig = self.data_req_class()
        self.req_message_type = self.req_msg_orig.getType()
        self.req_md5sum = self.req_msg_orig.getMD5()
        self.req_msg_def = self.req_msg_orig.getDef()

        self.req_sub = mros.subscribe(self.topic_name + "|svc", self.data_req_class, self.callback)
        self.resp_pub = mros.advertise(self.topic_name + "|srv", self.data_resp_class)

    def callback(self, req_msg):
        resp_msg = self.data_resp_class()
        self.user_callback(req_msg, resp_msg)
        resp_msg.setID(req_msg.getID())
        self.resp_pub.publish(resp_msg)

    def getMsgType(self):
        return self.req_message_type

    def getMsgMD5(self):
        return self.req_md5sum

    def negotiated(self):
        return (self.req_sub.negotiated() and self.resp_pub.negotiated())
