import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.costmap_2d.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class VoxelGrid(mros.Message):
    __slots__ = ['header','data','origin','resolutions','size_x','size_y','size_z']
    _slot_types = ['std_msgs/Header','uint32[]','geometry_msgs/Point32','geometry_msgs/Vector3','uint32','uint32','uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(VoxelGrid, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.data is None:
                self.data = []
            if self.origin is None:
                self.origin = mros.geometry_msgs.msg.Point32()
            if self.resolutions is None:
                self.resolutions = mros.geometry_msgs.msg.Vector3()
            if self.size_x is None:
                self.size_x = 0
            if self.size_y is None:
                self.size_y = 0
            if self.size_z is None:
                self.size_z = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.data = []
            self.origin = mros.geometry_msgs.msg.Point32()
            self.resolutions = mros.geometry_msgs.msg.Vector3()
            self.size_x = 0
            self.size_y = 0
            self.size_z = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            data_length = len(self.data)
            buff.write(struct.pack('<I', data_length))
            buff.write(struct.pack(f'<{data_length}I', *self.data))
            offset += 4 + data_length * 4
            offset += self.origin.serialize(buff)
            offset += self.resolutions.serialize(buff)
            buff.write(_struct_I.pack(self.size_x))
            offset += 4
            buff.write(_struct_I.pack(self.size_y))
            offset += 4
            buff.write(_struct_I.pack(self.size_z))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (data_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.data = np.frombuffer(buff[offset:offset + data_length * 4], dtype=np.uint32)
            offset += data_length * 4
            offset += self.origin.deserialize(buff[offset:])
            offset += self.resolutions.deserialize(buff[offset:])
            (self.size_x,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.size_y,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.size_z,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.data) * 4
        length += self.origin.serializedLength()
        length += self.resolutions.serializedLength()
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"data":['
        data_length = len(self.data)
        for i in range(0, data_length):
            if i == (data_length - 1): 
                string_echo += '%s' % self.data[i]
            else:
                string_echo += '%s,' % self.data[i]
        string_echo += '],'
        string_echo += '"origin":'
        string_echo += self.origin.echo()
        string_echo += ','
        string_echo += '"resolutions":'
        string_echo += self.resolutions.echo()
        string_echo += ','
        string_echo += '"size_x":%s' % self.size_x
        string_echo += ','
        string_echo += '"size_y":%s' % self.size_y
        string_echo += ','
        string_echo += '"size_z":%s' % self.size_z
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "costmap_2d/VoxelGrid"

    def getMD5(self):
        return "48a040827e1322073d78ece5a497029c"

    def getDef(self):
        return "std_msgs/Header header\nuint32[] data\ngeometry_msgs/Point32 origin\ngeometry_msgs/Vector3 resolutions\nuint32 size_x\nuint32 size_y\nuint32 size_z\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Point32\nfloat32 x\nfloat32 y\nfloat32 z\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

