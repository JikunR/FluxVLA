import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.lio_sam.msg
import mros.std_msgs.msg
import mros.sensor_msgs.msg

class cloud_info(mros.Message):
    __slots__ = ['header','startRingIndex','endRingIndex','pointColInd','pointRange','imuAvailable','odomAvailable','imuRollInit','imuPitchInit','imuYawInit','initialGuessX','initialGuessY','initialGuessZ','initialGuessRoll','initialGuessPitch','initialGuessYaw','cloud_deskewed','cloud_corner','cloud_surface']
    _slot_types = ['std_msgs/Header','int32[]','int32[]','int32[]','float32[]','int64','int64','float32','float32','float32','float32','float32','float32','float32','float32','float32','sensor_msgs/PointCloud2','sensor_msgs/PointCloud2','sensor_msgs/PointCloud2']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(cloud_info, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.startRingIndex is None:
                self.startRingIndex = []
            if self.endRingIndex is None:
                self.endRingIndex = []
            if self.pointColInd is None:
                self.pointColInd = []
            if self.pointRange is None:
                self.pointRange = []
            if self.imuAvailable is None:
                self.imuAvailable = 0
            if self.odomAvailable is None:
                self.odomAvailable = 0
            if self.imuRollInit is None:
                self.imuRollInit = 0.
            if self.imuPitchInit is None:
                self.imuPitchInit = 0.
            if self.imuYawInit is None:
                self.imuYawInit = 0.
            if self.initialGuessX is None:
                self.initialGuessX = 0.
            if self.initialGuessY is None:
                self.initialGuessY = 0.
            if self.initialGuessZ is None:
                self.initialGuessZ = 0.
            if self.initialGuessRoll is None:
                self.initialGuessRoll = 0.
            if self.initialGuessPitch is None:
                self.initialGuessPitch = 0.
            if self.initialGuessYaw is None:
                self.initialGuessYaw = 0.
            if self.cloud_deskewed is None:
                self.cloud_deskewed = mros.sensor_msgs.msg.PointCloud2()
            if self.cloud_corner is None:
                self.cloud_corner = mros.sensor_msgs.msg.PointCloud2()
            if self.cloud_surface is None:
                self.cloud_surface = mros.sensor_msgs.msg.PointCloud2()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.startRingIndex = []
            self.endRingIndex = []
            self.pointColInd = []
            self.pointRange = []
            self.imuAvailable = 0
            self.odomAvailable = 0
            self.imuRollInit = 0.
            self.imuPitchInit = 0.
            self.imuYawInit = 0.
            self.initialGuessX = 0.
            self.initialGuessY = 0.
            self.initialGuessZ = 0.
            self.initialGuessRoll = 0.
            self.initialGuessPitch = 0.
            self.initialGuessYaw = 0.
            self.cloud_deskewed = mros.sensor_msgs.msg.PointCloud2()
            self.cloud_corner = mros.sensor_msgs.msg.PointCloud2()
            self.cloud_surface = mros.sensor_msgs.msg.PointCloud2()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            startRingIndex_length = len(self.startRingIndex)
            buff.write(struct.pack('<I', startRingIndex_length))
            buff.write(struct.pack(f'<{startRingIndex_length}i', *self.startRingIndex))
            offset += 4 + startRingIndex_length * 4
            endRingIndex_length = len(self.endRingIndex)
            buff.write(struct.pack('<I', endRingIndex_length))
            buff.write(struct.pack(f'<{endRingIndex_length}i', *self.endRingIndex))
            offset += 4 + endRingIndex_length * 4
            pointColInd_length = len(self.pointColInd)
            buff.write(struct.pack('<I', pointColInd_length))
            buff.write(struct.pack(f'<{pointColInd_length}i', *self.pointColInd))
            offset += 4 + pointColInd_length * 4
            pointRange_length = len(self.pointRange)
            buff.write(struct.pack('<I', pointRange_length))
            buff.write(struct.pack(f'<{pointRange_length}f', *self.pointRange))
            offset += 4 + pointRange_length * 4
            struct_imuAvailable = struct.Struct("<q")
            buff.write(struct_imuAvailable.pack(self.imuAvailable))
            offset += 8
            struct_odomAvailable = struct.Struct("<q")
            buff.write(struct_odomAvailable.pack(self.odomAvailable))
            offset += 8
            struct_imuRollInit = struct.Struct("<f")
            buff.write(struct_imuRollInit.pack(self.imuRollInit))
            offset += 4
            struct_imuPitchInit = struct.Struct("<f")
            buff.write(struct_imuPitchInit.pack(self.imuPitchInit))
            offset += 4
            struct_imuYawInit = struct.Struct("<f")
            buff.write(struct_imuYawInit.pack(self.imuYawInit))
            offset += 4
            struct_initialGuessX = struct.Struct("<f")
            buff.write(struct_initialGuessX.pack(self.initialGuessX))
            offset += 4
            struct_initialGuessY = struct.Struct("<f")
            buff.write(struct_initialGuessY.pack(self.initialGuessY))
            offset += 4
            struct_initialGuessZ = struct.Struct("<f")
            buff.write(struct_initialGuessZ.pack(self.initialGuessZ))
            offset += 4
            struct_initialGuessRoll = struct.Struct("<f")
            buff.write(struct_initialGuessRoll.pack(self.initialGuessRoll))
            offset += 4
            struct_initialGuessPitch = struct.Struct("<f")
            buff.write(struct_initialGuessPitch.pack(self.initialGuessPitch))
            offset += 4
            struct_initialGuessYaw = struct.Struct("<f")
            buff.write(struct_initialGuessYaw.pack(self.initialGuessYaw))
            offset += 4
            offset += self.cloud_deskewed.serialize(buff)
            offset += self.cloud_corner.serialize(buff)
            offset += self.cloud_surface.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (startRingIndex_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.startRingIndex = np.frombuffer(buff[offset:offset + startRingIndex_length * 4], dtype=np.int32)
            offset += startRingIndex_length * 4
            (endRingIndex_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.endRingIndex = np.frombuffer(buff[offset:offset + endRingIndex_length * 4], dtype=np.int32)
            offset += endRingIndex_length * 4
            (pointColInd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.pointColInd = np.frombuffer(buff[offset:offset + pointColInd_length * 4], dtype=np.int32)
            offset += pointColInd_length * 4
            (pointRange_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.pointRange = np.frombuffer(buff[offset:offset + pointRange_length * 4], dtype=np.float32)
            offset += pointRange_length * 4
            struct_imuAvailable = struct.Struct("<q")
            (self.imuAvailable,) = struct_imuAvailable.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_odomAvailable = struct.Struct("<q")
            (self.odomAvailable,) = struct_odomAvailable.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_imuRollInit = struct.Struct("<f")
            (self.imuRollInit,) = struct_imuRollInit.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_imuPitchInit = struct.Struct("<f")
            (self.imuPitchInit,) = struct_imuPitchInit.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_imuYawInit = struct.Struct("<f")
            (self.imuYawInit,) = struct_imuYawInit.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_initialGuessX = struct.Struct("<f")
            (self.initialGuessX,) = struct_initialGuessX.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_initialGuessY = struct.Struct("<f")
            (self.initialGuessY,) = struct_initialGuessY.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_initialGuessZ = struct.Struct("<f")
            (self.initialGuessZ,) = struct_initialGuessZ.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_initialGuessRoll = struct.Struct("<f")
            (self.initialGuessRoll,) = struct_initialGuessRoll.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_initialGuessPitch = struct.Struct("<f")
            (self.initialGuessPitch,) = struct_initialGuessPitch.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_initialGuessYaw = struct.Struct("<f")
            (self.initialGuessYaw,) = struct_initialGuessYaw.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.cloud_deskewed.deserialize(buff[offset:])
            offset += self.cloud_corner.deserialize(buff[offset:])
            offset += self.cloud_surface.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.startRingIndex) * 4
        length += 4
        length += len(self.endRingIndex) * 4
        length += 4
        length += len(self.pointColInd) * 4
        length += 4
        length += len(self.pointRange) * 4
        length += 8
        length += 8
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += self.cloud_deskewed.serializedLength()
        length += self.cloud_corner.serializedLength()
        length += self.cloud_surface.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"startRingIndex":['
        startRingIndex_length = len(self.startRingIndex)
        for i in range(0, startRingIndex_length):
            if i == (startRingIndex_length - 1): 
                string_echo += '%s' % self.startRingIndex[i]
            else:
                string_echo += '%s,' % self.startRingIndex[i]
        string_echo += '],'
        string_echo += '"endRingIndex":['
        endRingIndex_length = len(self.endRingIndex)
        for i in range(0, endRingIndex_length):
            if i == (endRingIndex_length - 1): 
                string_echo += '%s' % self.endRingIndex[i]
            else:
                string_echo += '%s,' % self.endRingIndex[i]
        string_echo += '],'
        string_echo += '"pointColInd":['
        pointColInd_length = len(self.pointColInd)
        for i in range(0, pointColInd_length):
            if i == (pointColInd_length - 1): 
                string_echo += '%s' % self.pointColInd[i]
            else:
                string_echo += '%s,' % self.pointColInd[i]
        string_echo += '],'
        string_echo += '"pointRange":['
        pointRange_length = len(self.pointRange)
        for i in range(0, pointRange_length):
            if i == (pointRange_length - 1): 
                string_echo += '%s' % self.pointRange[i]
            else:
                string_echo += '%s,' % self.pointRange[i]
        string_echo += '],'
        string_echo += '"imuAvailable":%s' % self.imuAvailable
        string_echo += ','
        string_echo += '"odomAvailable":%s' % self.odomAvailable
        string_echo += ','
        string_echo += '"imuRollInit":%s' % self.imuRollInit
        string_echo += ','
        string_echo += '"imuPitchInit":%s' % self.imuPitchInit
        string_echo += ','
        string_echo += '"imuYawInit":%s' % self.imuYawInit
        string_echo += ','
        string_echo += '"initialGuessX":%s' % self.initialGuessX
        string_echo += ','
        string_echo += '"initialGuessY":%s' % self.initialGuessY
        string_echo += ','
        string_echo += '"initialGuessZ":%s' % self.initialGuessZ
        string_echo += ','
        string_echo += '"initialGuessRoll":%s' % self.initialGuessRoll
        string_echo += ','
        string_echo += '"initialGuessPitch":%s' % self.initialGuessPitch
        string_echo += ','
        string_echo += '"initialGuessYaw":%s' % self.initialGuessYaw
        string_echo += ','
        string_echo += '"cloud_deskewed":'
        string_echo += self.cloud_deskewed.echo()
        string_echo += ','
        string_echo += '"cloud_corner":'
        string_echo += self.cloud_corner.echo()
        string_echo += ','
        string_echo += '"cloud_surface":'
        string_echo += self.cloud_surface.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "lio_sam/cloud_info"

    def getMD5(self):
        return "50b728f6fcea6789af5feea0b14f80fe"

    def getDef(self):
        return "std_msgs/Header header\nint32[] startRingIndex\nint32[] endRingIndex\nint32[] pointColInd\nfloat32[] pointRange\nint64 imuAvailable\nint64 odomAvailable\nfloat32 imuRollInit\nfloat32 imuPitchInit\nfloat32 imuYawInit\nfloat32 initialGuessX\nfloat32 initialGuessY\nfloat32 initialGuessZ\nfloat32 initialGuessRoll\nfloat32 initialGuessPitch\nfloat32 initialGuessYaw\nsensor_msgs/PointCloud2 cloud_deskewed\nsensor_msgs/PointCloud2 cloud_corner\nsensor_msgs/PointCloud2 cloud_surface\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: sensor_msgs/PointCloud2\nstd_msgs/Header header\nuint32 height\nuint32 width\nsensor_msgs/PointField[] fields\nbool is_bigendian\nuint32 point_step\nuint32 row_step\nuint8[] data\nbool is_dense\n================================================================================\nMSG: sensor_msgs/PointField\nuint8 INT8    = 1\nuint8 UINT8   = 2\nuint8 INT16   = 3\nuint8 UINT16  = 4\nuint8 INT32   = 5\nuint8 UINT32  = 6\nuint8 FLOAT32 = 7\nuint8 FLOAT64 = 8\nstring name\nuint32 offset\nuint8 datatype\nuint32 count\n"

_struct_I = struct.Struct('<I')

