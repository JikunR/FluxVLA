import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class JointStatus(mros.Message):
    __slots__ = ['stamp','deviceid','run_time','enable','error','zero','limit_min','limit_max','tool_size','mode','state','play_state','log_path']
    _slot_types = ['int64','string','int64','int32[6]','string[6]','float32[6]','float32[6]','float32[6]','float32[3]','int32','int32','int32','string']

    MODE_ANGLE =  1
    MODE_VELOCITY =  3
    MODE_CURRENT =  4
    STATE_IDLE =  1
    STATE_STARTED =  2
    STATE_PAUSED =  3
    STATE_RESUMED =  4
    STATE_STOPED =  5
    STATE_SHUTDOWN =  6
    PLAY_STATE_IDLE =  0
    PLAY_STATE_STARTED =  1
    PLAY_STATE_FAILED =  2
    PLAY_STATE_FINISHED =  3

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointStatus, self).__init__(*args, **kwds)
            if self.stamp is None:
                self.stamp = 0
            if self.deviceid is None:
                self.deviceid = ''
            if self.run_time is None:
                self.run_time = 0
            if self.enable is None:
                self.enable = [0 for x in range(0, 6)]
            if self.error is None:
                self.error = ['' for x in range(0, 6)]
            if self.zero is None:
                self.zero = [0. for x in range(0, 6)]
            if self.limit_min is None:
                self.limit_min = [0. for x in range(0, 6)]
            if self.limit_max is None:
                self.limit_max = [0. for x in range(0, 6)]
            if self.tool_size is None:
                self.tool_size = [0. for x in range(0, 3)]
            if self.mode is None:
                self.mode = 0
            if self.state is None:
                self.state = 0
            if self.play_state is None:
                self.play_state = 0
            if self.log_path is None:
                self.log_path = ''
        else:
            self.stamp = 0
            self.deviceid = ''
            self.run_time = 0
            self.enable = [0 for x in range(0, 6)]
            self.error = ['' for x in range(0, 6)]
            self.zero = [0. for x in range(0, 6)]
            self.limit_min = [0. for x in range(0, 6)]
            self.limit_max = [0. for x in range(0, 6)]
            self.tool_size = [0. for x in range(0, 3)]
            self.mode = 0
            self.state = 0
            self.play_state = 0
            self.log_path = ''

    def serialize(self, buff):
        offset = 0
        try:
            struct_stamp = struct.Struct("<q")
            buff.write(struct_stamp.pack(self.stamp))
            offset += 8
            _x = self.deviceid
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_run_time = struct.Struct("<q")
            buff.write(struct_run_time.pack(self.run_time))
            offset += 8
            buff.write(struct.pack(f'<{6}i', *self.enable))
            offset += 6 * 4
            for i in range(0, 6):
                _x = self.error[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            buff.write(struct.pack(f'<{6}f', *self.zero))
            offset += 6 * 4
            buff.write(struct.pack(f'<{6}f', *self.limit_min))
            offset += 6 * 4
            buff.write(struct.pack(f'<{6}f', *self.limit_max))
            offset += 6 * 4
            buff.write(struct.pack(f'<{3}f', *self.tool_size))
            offset += 3 * 4
            struct_mode = struct.Struct("<i")
            buff.write(struct_mode.pack(self.mode))
            offset += 4
            struct_state = struct.Struct("<i")
            buff.write(struct_state.pack(self.state))
            offset += 4
            struct_play_state = struct.Struct("<i")
            buff.write(struct_play_state.pack(self.play_state))
            offset += 4
            _x = self.log_path
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_stamp = struct.Struct("<q")
            (self.stamp,) = struct_stamp.unpack(buff[offset:(offset + 8)])
            offset += 8
            (length_deviceid,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.deviceid = buff[offset:(offset + length_deviceid)].decode('utf-8')
            else:
                self.deviceid = buff[offset:(offset + length_deviceid)]
            offset += length_deviceid
            struct_run_time = struct.Struct("<q")
            (self.run_time,) = struct_run_time.unpack(buff[offset:(offset + 8)])
            offset += 8
            self.enable = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.int32)
            offset += 6 * 4
            for i in range(0, 6):
                (length_errori,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.error[i] = buff[offset:(offset + length_errori)].decode('utf-8')
                else:
                    self.error[i] = buff[offset:(offset + length_errori)]
                offset += length_errori
            self.zero = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.limit_min = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.limit_max = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.tool_size = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            struct_mode = struct.Struct("<i")
            (self.mode,) = struct_mode.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_state = struct.Struct("<i")
            (self.state,) = struct_state.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_play_state = struct.Struct("<i")
            (self.play_state,) = struct_play_state.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_log_path,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.log_path = buff[offset:(offset + length_log_path)].decode('utf-8')
            else:
                self.log_path = buff[offset:(offset + length_log_path)]
            offset += length_log_path
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        deviceid_x = self.deviceid
        deviceid_length = len(deviceid_x)
        if python3 or type(deviceid_x) == unicode:
            deviceid_x = deviceid_x.encode('utf-8')
            deviceid_length = len(deviceid_x)
        length += 4
        length += deviceid_length
        length += 8
        length += 6 * 4
        for i in range(0, 6):
            errori_x = self.error[i]
            errori_length = len(errori_x)
            if python3 or type(errori_x) == unicode:
                errori_x = errori_x.encode('utf-8')
                errori_length = len(errori_x)
            length += 4
            length += errori_length
        length += 6 * 4
        length += 6 * 4
        length += 6 * 4
        length += 3 * 4
        length += 4
        length += 4
        length += 4
        log_path_x = self.log_path
        log_path_length = len(log_path_x)
        if python3 or type(log_path_x) == unicode:
            log_path_x = log_path_x.encode('utf-8')
            log_path_length = len(log_path_x)
        length += 4
        length += log_path_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"stamp":%s' % self.stamp
        string_echo += ','
        string_echo += '"deviceid":"%s"' % self.deviceid
        string_echo += ','
        string_echo += '"run_time":%s' % self.run_time
        string_echo += ','
        string_echo += '"enable":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.enable[i]
            else:
                string_echo += '%s,' % self.enable[i]
        string_echo += '],'
        string_echo += '"error":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '"error[i]":"%s"' % self.error[i]
                string_echo += ''
            else:
                string_echo += '"error[i]":"%s"' % self.error[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"zero":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.zero[i]
            else:
                string_echo += '%s,' % self.zero[i]
        string_echo += '],'
        string_echo += '"limit_min":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.limit_min[i]
            else:
                string_echo += '%s,' % self.limit_min[i]
        string_echo += '],'
        string_echo += '"limit_max":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.limit_max[i]
            else:
                string_echo += '%s,' % self.limit_max[i]
        string_echo += '],'
        string_echo += '"tool_size":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.tool_size[i]
            else:
                string_echo += '%s,' % self.tool_size[i]
        string_echo += '],'
        string_echo += '"mode":%s' % self.mode
        string_echo += ','
        string_echo += '"state":%s' % self.state
        string_echo += ','
        string_echo += '"play_state":%s' % self.play_state
        string_echo += ','
        string_echo += '"log_path":"%s"' % self.log_path
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/JointStatus"

    def getMD5(self):
        return "45ad0038f02003358fe0dfc06f395181"

    def getDef(self):
        return "int64 stamp\nstring deviceid\nint64 run_time\nint32[6] enable\nstring[6] error\nfloat32[6] zero\nfloat32[6] limit_min\nfloat32[6] limit_max\nfloat32[3] tool_size\nint32 MODE_ANGLE    = 1\nint32 MODE_VELOCITY = 3\nint32 MODE_CURRENT  = 4\nint32 mode\nint32 STATE_IDLE      = 1\nint32 STATE_STARTED   = 2\nint32 STATE_PAUSED    = 3\nint32 STATE_RESUMED   = 4\nint32 STATE_STOPED    = 5\nint32 STATE_SHUTDOWN  = 6\nint32 state\nint32 PLAY_STATE_IDLE      = 0\nint32 PLAY_STATE_STARTED   = 1\nint32 PLAY_STATE_FAILED    = 2\nint32 PLAY_STATE_FINISHED  = 3\nint32 play_state\nstring log_path\n"

_struct_I = struct.Struct('<I')

