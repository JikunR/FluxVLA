import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class JointData(mros.Message):
    __slots__ = ['stamp','deviceid','angle','velocity','current']
    _slot_types = ['int64','string','float32[6]','float32[6]','float32[6]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointData, self).__init__(*args, **kwds)
            if self.stamp is None:
                self.stamp = 0
            if self.deviceid is None:
                self.deviceid = ''
            if self.angle is None:
                self.angle = [0. for x in range(0, 6)]
            if self.velocity is None:
                self.velocity = [0. for x in range(0, 6)]
            if self.current is None:
                self.current = [0. for x in range(0, 6)]
        else:
            self.stamp = 0
            self.deviceid = ''
            self.angle = [0. for x in range(0, 6)]
            self.velocity = [0. for x in range(0, 6)]
            self.current = [0. for x in range(0, 6)]

    def serialize(self, buff):
        offset = 0
        try:
            struct_stamp = struct.Struct("<q")
            buff.write(struct_stamp.pack(self.stamp))
            offset += 8
            _x = self.deviceid
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(struct.pack(f'<{6}f', *self.angle))
            offset += 6 * 4
            buff.write(struct.pack(f'<{6}f', *self.velocity))
            offset += 6 * 4
            buff.write(struct.pack(f'<{6}f', *self.current))
            offset += 6 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_stamp = struct.Struct("<q")
            (self.stamp,) = struct_stamp.unpack(buff[offset:(offset + 8)])
            offset += 8
            (length_deviceid,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.deviceid = buff[offset:(offset + length_deviceid)].decode('utf-8')
            else:
                self.deviceid = buff[offset:(offset + length_deviceid)]
            offset += length_deviceid
            self.angle = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.velocity = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.current = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        deviceid_x = self.deviceid
        deviceid_length = len(deviceid_x)
        if python3 or type(deviceid_x) == unicode:
            deviceid_x = deviceid_x.encode('utf-8')
            deviceid_length = len(deviceid_x)
        length += 4
        length += deviceid_length
        length += 6 * 4
        length += 6 * 4
        length += 6 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"stamp":%s' % self.stamp
        string_echo += ','
        string_echo += '"deviceid":"%s"' % self.deviceid
        string_echo += ','
        string_echo += '"angle":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.angle[i]
            else:
                string_echo += '%s,' % self.angle[i]
        string_echo += '],'
        string_echo += '"velocity":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.velocity[i]
            else:
                string_echo += '%s,' % self.velocity[i]
        string_echo += '],'
        string_echo += '"current":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.current[i]
            else:
                string_echo += '%s,' % self.current[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/JointData"

    def getMD5(self):
        return "d17bc79a498488bca00b006c2ebe2bc8"

    def getDef(self):
        return "int64 stamp\nstring deviceid\nfloat32[6] angle\nfloat32[6] velocity\nfloat32[6] current\n"

_struct_I = struct.Struct('<I')

