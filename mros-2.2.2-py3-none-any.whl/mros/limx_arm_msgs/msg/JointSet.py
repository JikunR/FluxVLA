import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class JointSet(mros.Message):
    __slots__ = ['stamp','deviceid','action','mode','data']
    _slot_types = ['int64','string','int32','int32','float32[6]']

    ACTION_IDLE =  0
    ACTION_START =  1
    ACTION_PAUSE =  2
    ACTION_RESUME =  3
    ACTION_STOP =  4
    ACTION_ENABLE_MOTOR =  5
    ACTION_SET_ZERO =  6
    ACTION_SET_LIMIT_MIN =  7
    ACTION_SET_LIMIT_MAX =  8
    ACTION_SET_POSITION =  9
    ACTION_SET_MODE =  10
    ACTION_SET_TOOL_SIZE =  11
    ACTION_START_DRAG =  12
    ACTION_STOP_DRAG =  13
    ACTION_PLAYER_START =  14
    ACTION_PLAYER_STOP =  15
    ACTION_SET_CARTESIAN_POSITION =  16
    MODE_ANGLE =  1
    MODE_VELOCITY =  3
    MODE_CURRENT =  4

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointSet, self).__init__(*args, **kwds)
            if self.stamp is None:
                self.stamp = 0
            if self.deviceid is None:
                self.deviceid = ''
            if self.action is None:
                self.action = 0
            if self.mode is None:
                self.mode = 0
            if self.data is None:
                self.data = [0. for x in range(0, 6)]
        else:
            self.stamp = 0
            self.deviceid = ''
            self.action = 0
            self.mode = 0
            self.data = [0. for x in range(0, 6)]

    def serialize(self, buff):
        offset = 0
        try:
            struct_stamp = struct.Struct("<q")
            buff.write(struct_stamp.pack(self.stamp))
            offset += 8
            _x = self.deviceid
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_action = struct.Struct("<i")
            buff.write(struct_action.pack(self.action))
            offset += 4
            struct_mode = struct.Struct("<i")
            buff.write(struct_mode.pack(self.mode))
            offset += 4
            buff.write(struct.pack(f'<{6}f', *self.data))
            offset += 6 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_stamp = struct.Struct("<q")
            (self.stamp,) = struct_stamp.unpack(buff[offset:(offset + 8)])
            offset += 8
            (length_deviceid,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.deviceid = buff[offset:(offset + length_deviceid)].decode('utf-8')
            else:
                self.deviceid = buff[offset:(offset + length_deviceid)]
            offset += length_deviceid
            struct_action = struct.Struct("<i")
            (self.action,) = struct_action.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_mode = struct.Struct("<i")
            (self.mode,) = struct_mode.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.data = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        deviceid_x = self.deviceid
        deviceid_length = len(deviceid_x)
        if python3 or type(deviceid_x) == unicode:
            deviceid_x = deviceid_x.encode('utf-8')
            deviceid_length = len(deviceid_x)
        length += 4
        length += deviceid_length
        length += 4
        length += 4
        length += 6 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"stamp":%s' % self.stamp
        string_echo += ','
        string_echo += '"deviceid":"%s"' % self.deviceid
        string_echo += ','
        string_echo += '"action":%s' % self.action
        string_echo += ','
        string_echo += '"mode":%s' % self.mode
        string_echo += ','
        string_echo += '"data":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.data[i]
            else:
                string_echo += '%s,' % self.data[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/JointSet"

    def getMD5(self):
        return "342a69737258a9dd1a3f1a350ffdea87"

    def getDef(self):
        return "int64 stamp\nstring deviceid\nint32 ACTION_IDLE           = 0\nint32 ACTION_START          = 1\nint32 ACTION_PAUSE          = 2\nint32 ACTION_RESUME         = 3\nint32 ACTION_STOP           = 4\nint32 ACTION_ENABLE_MOTOR   = 5\nint32 ACTION_SET_ZERO       = 6\nint32 ACTION_SET_LIMIT_MIN  = 7\nint32 ACTION_SET_LIMIT_MAX  = 8\nint32 ACTION_SET_POSITION   = 9\nint32 ACTION_SET_MODE       = 10\nint32 ACTION_SET_TOOL_SIZE  = 11\nint32 ACTION_START_DRAG     = 12\nint32 ACTION_STOP_DRAG      = 13\nint32 ACTION_PLAYER_START   = 14\nint32 ACTION_PLAYER_STOP    = 15\nint32 ACTION_SET_CARTESIAN_POSITION = 16\nint32 action\nint32 MODE_ANGLE    = 1\nint32 MODE_VELOCITY = 3\nint32 MODE_CURRENT  = 4\nint32 mode\nfloat32[6] data\n"

_struct_I = struct.Struct('<I')

