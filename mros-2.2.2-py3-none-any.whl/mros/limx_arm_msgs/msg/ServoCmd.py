import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class ServoCmd(mros.Message):
    __slots__ = ['functionName','left_arm_pos','right_arm_pos']
    _slot_types = ['string','float32[7]','float32[7]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ServoCmd, self).__init__(*args, **kwds)
            if self.functionName is None:
                self.functionName = ''
            if self.left_arm_pos is None:
                self.left_arm_pos = [0. for x in range(0, 7)]
            if self.right_arm_pos is None:
                self.right_arm_pos = [0. for x in range(0, 7)]
        else:
            self.functionName = ''
            self.left_arm_pos = [0. for x in range(0, 7)]
            self.right_arm_pos = [0. for x in range(0, 7)]

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.functionName
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(struct.pack(f'<{7}f', *self.left_arm_pos))
            offset += 7 * 4
            buff.write(struct.pack(f'<{7}f', *self.right_arm_pos))
            offset += 7 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_functionName,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.functionName = buff[offset:(offset + length_functionName)].decode('utf-8')
            else:
                self.functionName = buff[offset:(offset + length_functionName)]
            offset += length_functionName
            self.left_arm_pos = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
            self.right_arm_pos = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        functionName_x = self.functionName
        functionName_length = len(functionName_x)
        if python3 or type(functionName_x) == unicode:
            functionName_x = functionName_x.encode('utf-8')
            functionName_length = len(functionName_x)
        length += 4
        length += functionName_length
        length += 7 * 4
        length += 7 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"functionName":"%s"' % self.functionName
        string_echo += ','
        string_echo += '"left_arm_pos":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.left_arm_pos[i]
            else:
                string_echo += '%s,' % self.left_arm_pos[i]
        string_echo += '],'
        string_echo += '"right_arm_pos":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.right_arm_pos[i]
            else:
                string_echo += '%s,' % self.right_arm_pos[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/ServoCmd"

    def getMD5(self):
        return "9baa32abc430b8109110d02971ccd3a2"

    def getDef(self):
        return "string functionName\nfloat32[7] left_arm_pos\nfloat32[7] right_arm_pos\n"

_struct_I = struct.Struct('<I')

