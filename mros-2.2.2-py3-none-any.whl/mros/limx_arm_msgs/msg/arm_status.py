import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class arm_status(mros.Message):
    __slots__ = ['left_joints','right_joints','left_endEffector','right_endEffector','ik_statu']
    _slot_types = ['float64[]','float64[]','float64[7]','float64[7]','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(arm_status, self).__init__(*args, **kwds)
            if self.left_joints is None:
                self.left_joints = []
            if self.right_joints is None:
                self.right_joints = []
            if self.left_endEffector is None:
                self.left_endEffector = [0. for x in range(0, 7)]
            if self.right_endEffector is None:
                self.right_endEffector = [0. for x in range(0, 7)]
            if self.ik_statu is None:
                self.ik_statu = 0
        else:
            self.left_joints = []
            self.right_joints = []
            self.left_endEffector = [0. for x in range(0, 7)]
            self.right_endEffector = [0. for x in range(0, 7)]
            self.ik_statu = 0

    def serialize(self, buff):
        offset = 0
        try:
            left_joints_length = len(self.left_joints)
            buff.write(struct.pack('<I', left_joints_length))
            buff.write(struct.pack(f'<{left_joints_length}d', *self.left_joints))
            offset += 4 + left_joints_length * 8
            right_joints_length = len(self.right_joints)
            buff.write(struct.pack('<I', right_joints_length))
            buff.write(struct.pack(f'<{right_joints_length}d', *self.right_joints))
            offset += 4 + right_joints_length * 8
            buff.write(struct.pack(f'<{7}d', *self.left_endEffector))
            offset += 7 * 8
            buff.write(struct.pack(f'<{7}d', *self.right_endEffector))
            offset += 7 * 8
            struct_ik_statu = struct.Struct("<i")
            buff.write(struct_ik_statu.pack(self.ik_statu))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (left_joints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.left_joints = np.frombuffer(buff[offset:offset + left_joints_length * 8], dtype=np.float64)
            offset += left_joints_length * 8
            (right_joints_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.right_joints = np.frombuffer(buff[offset:offset + right_joints_length * 8], dtype=np.float64)
            offset += right_joints_length * 8
            self.left_endEffector = np.frombuffer(buff[offset:offset + 7 * 8], dtype=np.float64)
            offset += 7 * 8
            self.right_endEffector = np.frombuffer(buff[offset:offset + 7 * 8], dtype=np.float64)
            offset += 7 * 8
            struct_ik_statu = struct.Struct("<i")
            (self.ik_statu,) = struct_ik_statu.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += len(self.left_joints) * 8
        length += 4
        length += len(self.right_joints) * 8
        length += 7 * 8
        length += 7 * 8
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"left_joints":['
        left_joints_length = len(self.left_joints)
        for i in range(0, left_joints_length):
            if i == (left_joints_length - 1): 
                string_echo += '%s' % self.left_joints[i]
            else:
                string_echo += '%s,' % self.left_joints[i]
        string_echo += '],'
        string_echo += '"right_joints":['
        right_joints_length = len(self.right_joints)
        for i in range(0, right_joints_length):
            if i == (right_joints_length - 1): 
                string_echo += '%s' % self.right_joints[i]
            else:
                string_echo += '%s,' % self.right_joints[i]
        string_echo += '],'
        string_echo += '"left_endEffector":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.left_endEffector[i]
            else:
                string_echo += '%s,' % self.left_endEffector[i]
        string_echo += '],'
        string_echo += '"right_endEffector":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.right_endEffector[i]
            else:
                string_echo += '%s,' % self.right_endEffector[i]
        string_echo += '],'
        string_echo += '"ik_statu":%s' % self.ik_statu
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/arm_status"

    def getMD5(self):
        return "ab1b8cc2dd2d4b67c6f12443dc6788e6"

    def getDef(self):
        return "float64[] left_joints\nfloat64[] right_joints\nfloat64[7] left_endEffector\nfloat64[7] right_endEffector\nint32 ik_statu\n"

_struct_I = struct.Struct('<I')

