import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class motionRequest(mros.Message):
    __slots__ = ['__id__','left_arm_pos','right_arm_pos','duration_time']
    _slot_types = ['uint32','float32[7]','float32[7]','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(motionRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.left_arm_pos is None:
                self.left_arm_pos = [0. for x in range(0, 7)]
            if self.right_arm_pos is None:
                self.right_arm_pos = [0. for x in range(0, 7)]
            if self.duration_time is None:
                self.duration_time = 0.
        else:
            self.__id__ = 0
            self.left_arm_pos = [0. for x in range(0, 7)]
            self.right_arm_pos = [0. for x in range(0, 7)]
            self.duration_time = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(struct.pack(f'<{7}f', *self.left_arm_pos))
            offset += 7 * 4
            buff.write(struct.pack(f'<{7}f', *self.right_arm_pos))
            offset += 7 * 4
            struct_duration_time = struct.Struct("<f")
            buff.write(struct_duration_time.pack(self.duration_time))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.left_arm_pos = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
            self.right_arm_pos = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
            struct_duration_time = struct.Struct("<f")
            (self.duration_time,) = struct_duration_time.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 7 * 4
        length += 7 * 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"left_arm_pos":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.left_arm_pos[i]
            else:
                string_echo += '%s,' % self.left_arm_pos[i]
        string_echo += '],'
        string_echo += '"right_arm_pos":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.right_arm_pos[i]
            else:
                string_echo += '%s,' % self.right_arm_pos[i]
        string_echo += '],'
        string_echo += '"duration_time":%s' % self.duration_time
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/motion"

    def getMD5(self):
        return "8f1c1118d46310f55cbaa0a387118cdb"
    def getDef(self):
        return "float32[7] left_arm_pos\nfloat32[7] right_arm_pos\nfloat32 duration_time\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class motionResponse(mros.Message):
    __slots__ = ['__id__','status']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(motionResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = 0
        else:
            self.__id__ = 0
            self.status = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_status = struct.Struct("<i")
            buff.write(struct_status.pack(self.status))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_status = struct.Struct("<i")
            (self.status,) = struct_status.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":%s' % self.status
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/motion"

    def getMD5(self):
        return "8f1c1118d46310f55cbaa0a387118cdb"
    def getDef(self):
        return "int32 status\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class motion(object):
    Request = motionRequest
    Response = motionResponse

    __slots__ = ['request','response']
    _slot_types = ['motionRequest','motionResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(motion, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

