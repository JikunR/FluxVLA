import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class desire_posRequest(mros.Message):
    __slots__ = ['__id__','taskNum','desire_pos','co_control']
    _slot_types = ['uint32','int32','float32[6]','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(desire_posRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.taskNum is None:
                self.taskNum = 0
            if self.desire_pos is None:
                self.desire_pos = [0. for x in range(0, 6)]
            if self.co_control is None:
                self.co_control = False
        else:
            self.__id__ = 0
            self.taskNum = 0
            self.desire_pos = [0. for x in range(0, 6)]
            self.co_control = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_taskNum = struct.Struct("<i")
            buff.write(struct_taskNum.pack(self.taskNum))
            offset += 4
            buff.write(struct.pack(f'<{6}f', *self.desire_pos))
            offset += 6 * 4
            struct_co_control = struct.Struct("<B")
            buff.write(struct_co_control.pack(self.co_control))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_taskNum = struct.Struct("<i")
            (self.taskNum,) = struct_taskNum.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.desire_pos = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            struct_co_control = struct.Struct("<B")
            (self.co_control,) = struct_co_control.unpack(buff[offset:(offset + 1)])
            self.co_control = bool(self.co_control)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        length += 6 * 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"taskNum":%s' % self.taskNum
        string_echo += ','
        string_echo += '"desire_pos":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.desire_pos[i]
            else:
                string_echo += '%s,' % self.desire_pos[i]
        string_echo += '],'
        string_echo += '"co_control":%s' % self.co_control
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/desire_pos"

    def getMD5(self):
        return "66df596b0ec651af3f62afa42d52c21b"
    def getDef(self):
        return "int32 taskNum\nfloat32[6] desire_pos\nbool co_control\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class desire_posResponse(mros.Message):
    __slots__ = ['__id__','status']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(desire_posResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = False
        else:
            self.__id__ = 0
            self.status = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_status = struct.Struct("<B")
            buff.write(struct_status.pack(self.status))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_status = struct.Struct("<B")
            (self.status,) = struct_status.unpack(buff[offset:(offset + 1)])
            self.status = bool(self.status)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":%s' % self.status
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/desire_pos"

    def getMD5(self):
        return "66df596b0ec651af3f62afa42d52c21b"
    def getDef(self):
        return "bool status\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class desire_pos(object):
    Request = desire_posRequest
    Response = desire_posResponse

    __slots__ = ['request','response']
    _slot_types = ['desire_posRequest','desire_posResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(desire_pos, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

