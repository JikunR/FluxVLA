import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class gripperRequest(mros.Message):
    __slots__ = ['__id__','initial','dis','force']
    _slot_types = ['uint32','bool','int32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(gripperRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.initial is None:
                self.initial = False
            if self.dis is None:
                self.dis = 0
            if self.force is None:
                self.force = 0
        else:
            self.__id__ = 0
            self.initial = False
            self.dis = 0
            self.force = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_initial = struct.Struct("<B")
            buff.write(struct_initial.pack(self.initial))
            offset += 1
            struct_dis = struct.Struct("<i")
            buff.write(struct_dis.pack(self.dis))
            offset += 4
            struct_force = struct.Struct("<i")
            buff.write(struct_force.pack(self.force))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_initial = struct.Struct("<B")
            (self.initial,) = struct_initial.unpack(buff[offset:(offset + 1)])
            self.initial = bool(self.initial)
            offset += 1
            struct_dis = struct.Struct("<i")
            (self.dis,) = struct_dis.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_force = struct.Struct("<i")
            (self.force,) = struct_force.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"initial":%s' % self.initial
        string_echo += ','
        string_echo += '"dis":%s' % self.dis
        string_echo += ','
        string_echo += '"force":%s' % self.force
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/gripper"

    def getMD5(self):
        return "0f92630af2d2a713e88b3235d577ea49"
    def getDef(self):
        return "bool initial\nint32 dis\nint32 force\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class gripperResponse(mros.Message):
    __slots__ = ['__id__','status']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(gripperResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = 0
        else:
            self.__id__ = 0
            self.status = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_status = struct.Struct("<i")
            buff.write(struct_status.pack(self.status))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_status = struct.Struct("<i")
            (self.status,) = struct_status.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":%s' % self.status
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/gripper"

    def getMD5(self):
        return "0f92630af2d2a713e88b3235d577ea49"
    def getDef(self):
        return "int32 status\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class gripper(object):
    Request = gripperRequest
    Response = gripperResponse

    __slots__ = ['request','response']
    _slot_types = ['gripperRequest','gripperResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(gripper, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

