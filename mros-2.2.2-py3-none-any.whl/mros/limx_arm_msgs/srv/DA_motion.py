import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.limx_arm_msgs.msg

class DA_motionRequest(mros.Message):
    __slots__ = ['__id__','functionName','left_arm_pos','right_arm_pos','speed','left_arm_joints','right_arm_joints','headPos']
    _slot_types = ['uint32','string','float32[7]','float32[7]','float32','float32[7]','float32[7]','float32[2]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DA_motionRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.functionName is None:
                self.functionName = ''
            if self.left_arm_pos is None:
                self.left_arm_pos = [0. for x in range(0, 7)]
            if self.right_arm_pos is None:
                self.right_arm_pos = [0. for x in range(0, 7)]
            if self.speed is None:
                self.speed = 0.
            if self.left_arm_joints is None:
                self.left_arm_joints = [0. for x in range(0, 7)]
            if self.right_arm_joints is None:
                self.right_arm_joints = [0. for x in range(0, 7)]
            if self.headPos is None:
                self.headPos = [0. for x in range(0, 2)]
        else:
            self.__id__ = 0
            self.functionName = ''
            self.left_arm_pos = [0. for x in range(0, 7)]
            self.right_arm_pos = [0. for x in range(0, 7)]
            self.speed = 0.
            self.left_arm_joints = [0. for x in range(0, 7)]
            self.right_arm_joints = [0. for x in range(0, 7)]
            self.headPos = [0. for x in range(0, 2)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.functionName
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(struct.pack(f'<{7}f', *self.left_arm_pos))
            offset += 7 * 4
            buff.write(struct.pack(f'<{7}f', *self.right_arm_pos))
            offset += 7 * 4
            struct_speed = struct.Struct("<f")
            buff.write(struct_speed.pack(self.speed))
            offset += 4
            buff.write(struct.pack(f'<{7}f', *self.left_arm_joints))
            offset += 7 * 4
            buff.write(struct.pack(f'<{7}f', *self.right_arm_joints))
            offset += 7 * 4
            buff.write(struct.pack(f'<{2}f', *self.headPos))
            offset += 2 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_functionName,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.functionName = buff[offset:(offset + length_functionName)].decode('utf-8')
            else:
                self.functionName = buff[offset:(offset + length_functionName)]
            offset += length_functionName
            self.left_arm_pos = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
            self.right_arm_pos = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
            struct_speed = struct.Struct("<f")
            (self.speed,) = struct_speed.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.left_arm_joints = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
            self.right_arm_joints = np.frombuffer(buff[offset:offset + 7 * 4], dtype=np.float32)
            offset += 7 * 4
            self.headPos = np.frombuffer(buff[offset:offset + 2 * 4], dtype=np.float32)
            offset += 2 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        functionName_x = self.functionName
        functionName_length = len(functionName_x)
        if python3 or type(functionName_x) == unicode:
            functionName_x = functionName_x.encode('utf-8')
            functionName_length = len(functionName_x)
        length += 4
        length += functionName_length
        length += 7 * 4
        length += 7 * 4
        length += 4
        length += 7 * 4
        length += 7 * 4
        length += 2 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"functionName":"%s"' % self.functionName
        string_echo += ','
        string_echo += '"left_arm_pos":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.left_arm_pos[i]
            else:
                string_echo += '%s,' % self.left_arm_pos[i]
        string_echo += '],'
        string_echo += '"right_arm_pos":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.right_arm_pos[i]
            else:
                string_echo += '%s,' % self.right_arm_pos[i]
        string_echo += '],'
        string_echo += '"speed":%s' % self.speed
        string_echo += ','
        string_echo += '"left_arm_joints":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.left_arm_joints[i]
            else:
                string_echo += '%s,' % self.left_arm_joints[i]
        string_echo += '],'
        string_echo += '"right_arm_joints":['
        for i in range(0, 7):
            if i == (7 - 1): 
                string_echo += '%s' % self.right_arm_joints[i]
            else:
                string_echo += '%s,' % self.right_arm_joints[i]
        string_echo += '],'
        string_echo += '"headPos":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.headPos[i]
            else:
                string_echo += '%s,' % self.headPos[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/DA_motion"

    def getMD5(self):
        return "6513938defdd69ca721d029105170004"
    def getDef(self):
        return "string functionName\nfloat32[7] left_arm_pos\nfloat32[7] right_arm_pos\nfloat32 speed\nfloat32[7] left_arm_joints\nfloat32[7] right_arm_joints\nfloat32[2] headPos\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class DA_motionResponse(mros.Message):
    __slots__ = ['__id__','status']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DA_motionResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = 0
        else:
            self.__id__ = 0
            self.status = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_status = struct.Struct("<i")
            buff.write(struct_status.pack(self.status))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_status = struct.Struct("<i")
            (self.status,) = struct_status.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":%s' % self.status
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "limx_arm_msgs/DA_motion"

    def getMD5(self):
        return "6513938defdd69ca721d029105170004"
    def getDef(self):
        return "int32 status\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class DA_motion(object):
    Request = DA_motionRequest
    Response = DA_motionResponse

    __slots__ = ['request','response']
    _slot_types = ['DA_motionRequest','DA_motionResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DA_motion, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

