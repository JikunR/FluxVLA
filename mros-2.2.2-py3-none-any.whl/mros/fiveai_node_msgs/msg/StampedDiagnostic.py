import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.fiveai_node_msgs.msg

class StampedDiagnostic(mros.Message):
    __slots__ = ['status','stamp','key','value']
    _slot_types = ['uint8','Time','string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StampedDiagnostic, self).__init__(*args, **kwds)
            if self.status is None:
                self.status = 0
            if self.stamp is None:
                self.stamp = mros.Time()
            if self.key is None:
                self.key = ''
            if self.value is None:
                self.value = ''
        else:
            self.status = 0
            self.stamp = mros.Time()
            self.key = ''
            self.value = ''

    def serialize(self, buff):
        offset = 0
        try:
            struct_status = struct.Struct("<B")
            buff.write(struct_status.pack(self.status))
            offset += 1
            buff.write(_struct_I.pack(self.stamp.sec))
            offset += 4
            buff.write(_struct_I.pack(self.stamp.nsec))
            offset += 4
            _x = self.key
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.value
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_status = struct.Struct("<B")
            (self.status,) = struct_status.unpack(buff[offset:(offset + 1)])
            offset += 1
            (self.stamp.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.stamp.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_key,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.key = buff[offset:(offset + length_key)].decode('utf-8')
            else:
                self.key = buff[offset:(offset + length_key)]
            offset += length_key
            (length_value,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.value = buff[offset:(offset + length_value)].decode('utf-8')
            else:
                self.value = buff[offset:(offset + length_value)]
            offset += length_value
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 4
        length += 4
        key_x = self.key
        key_length = len(key_x)
        if python3 or type(key_x) == unicode:
            key_x = key_x.encode('utf-8')
            key_length = len(key_x)
        length += 4
        length += key_length
        value_x = self.value
        value_length = len(value_x)
        if python3 or type(value_x) == unicode:
            value_x = value_x.encode('utf-8')
            value_length = len(value_x)
        length += 4
        length += value_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"status":%s' % self.status
        string_echo += ','
        string_echo += '"stamp.sec":%s,' % self.stamp.sec
        string_echo += '"stamp.nsec":%s' % self.stamp.nsec
        string_echo += ','
        string_echo += '"key":"%s"' % self.key
        string_echo += ','
        string_echo += '"value":"%s"' % self.value
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "fiveai_node_msgs/StampedDiagnostic"

    def getMD5(self):
        return "4c9a0215524c9823c9603755e4dea484"

    def getDef(self):
        return "uint8 status\ntime stamp\nstring key\nstring value\n"

_struct_I = struct.Struct('<I')

