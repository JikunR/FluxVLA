import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.fiveai_node_msgs.msg

class NodeDiagnostics(mros.Message):
    __slots__ = ['diagnostics']
    _slot_types = ['fiveai_node_msgs/StampedDiagnostic[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(NodeDiagnostics, self).__init__(*args, **kwds)
            if self.diagnostics is None:
                self.diagnostics = []
        else:
            self.diagnostics = []

    def serialize(self, buff):
        offset = 0
        try:
            diagnostics_length = len(self.diagnostics)
            buff.write(struct.pack('<I', diagnostics_length))
            offset += 4
            for i in range(0, diagnostics_length):
                offset += self.diagnostics[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (diagnostics_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.diagnostics) != diagnostics_length:
                self.diagnostics = [mros.fiveai_node_msgs.msg.StampedDiagnostic() for _ in range(diagnostics_length)]
            for i in range(0, diagnostics_length):
                offset += self.diagnostics[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, diagnostics_length):
            length += self.diagnostics[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"diagnostics":['
        diagnostics_length = len(self.diagnostics)
        for i in range(0, diagnostics_length):
            if i == (diagnostics_length - 1): 
                string_echo += '{diagnostics%s":' % i
                string_echo += self.diagnostics[i].echo()
                string_echo += ''
            else:
                string_echo += '{diagnostics%s":' % i
                string_echo += self.diagnostics[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "fiveai_node_msgs/NodeDiagnostics"

    def getMD5(self):
        return "37fa8ec5030feca8ff782b4851cc90a7"

    def getDef(self):
        return "fiveai_node_msgs/StampedDiagnostic[] diagnostics\n================================================================================\nMSG: fiveai_node_msgs/StampedDiagnostic\nuint8 status\ntime stamp\nstring key\nstring value\n"

_struct_I = struct.Struct('<I')

