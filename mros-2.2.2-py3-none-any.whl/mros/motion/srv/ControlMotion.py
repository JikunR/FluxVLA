import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.motion.msg

class ControlMotionRequest(mros.Message):
    __slots__ = ['__id__','motion_cmd']
    _slot_types = ['uint32','int8']

    MOTION_IDLE =  0  
    MOTION_INIT =  1  
    MOTION_SIT_DOWN =  2  
    MOTION_STAND_UP =  3  
    MOTION_FOOT =  4  
    MOTION_WHEEL =  5  
    MOTION_FOOT_WHEEL =  6  
    MOTION_UP_STAIRS =  7  
    MOTION_DW_STAIRS =  8  
    MOTION_EMGY_STOP =  9  
    MOTION_PAUSE =  10 
    MOTION_RESUME =  11 
    MOTION_CANCEL =  12 
    MOTION_FINISH =  13 
    MOTION_MAX =  14 
    MOTION_EX_UP_STAIRS_VISION_ON =  15 
    MOTION_EX_DW_STAIRS_VISION_ON =  16 
    MOTION_EX_VISION_OFF =  17 
    MOTION_EX_MAX =  18 

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControlMotionRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.motion_cmd is None:
                self.motion_cmd = 0
        else:
            self.__id__ = 0
            self.motion_cmd = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_motion_cmd = struct.Struct("<b")
            buff.write(struct_motion_cmd.pack(self.motion_cmd))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_motion_cmd = struct.Struct("<b")
            (self.motion_cmd,) = struct_motion_cmd.unpack(buff[offset:(offset + 1)])
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"motion_cmd":%s' % self.motion_cmd
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "motion/ControlMotion"

    def getMD5(self):
        return "5a27c37067b61301060f3adddf1086c2"
    def getDef(self):
        return "int8 MOTION_IDLE      = 0\nint8 MOTION_INIT      = 1\nint8 MOTION_SIT_DOWN  = 2\nint8 MOTION_STAND_UP  = 3\nint8 MOTION_FOOT      = 4\nint8 MOTION_WHEEL     = 5\nint8 MOTION_FOOT_WHEEL= 6\nint8 MOTION_UP_STAIRS = 7\nint8 MOTION_DW_STAIRS = 8\nint8 MOTION_EMGY_STOP = 9\nint8 MOTION_PAUSE     = 10\nint8 MOTION_RESUME    = 11\nint8 MOTION_CANCEL    = 12\nint8 MOTION_FINISH    = 13\nint8 MOTION_MAX       = 14\nint8 MOTION_EX_UP_STAIRS_VISION_ON  = 15\nint8 MOTION_EX_DW_STAIRS_VISION_ON  = 16\nint8 MOTION_EX_VISION_OFF           = 17\nint8 MOTION_EX_MAX    = 18\nint8 motion_cmd\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ControlMotionResponse(mros.Message):
    __slots__ = ['__id__','result','msg']
    _slot_types = ['uint32','int8','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControlMotionResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.result is None:
                self.result = 0
            if self.msg is None:
                self.msg = ''
        else:
            self.__id__ = 0
            self.result = 0
            self.msg = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_result = struct.Struct("<b")
            buff.write(struct_result.pack(self.result))
            offset += 1
            _x = self.msg
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_result = struct.Struct("<b")
            (self.result,) = struct_result.unpack(buff[offset:(offset + 1)])
            offset += 1
            (length_msg,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.msg = buff[offset:(offset + length_msg)].decode('utf-8')
            else:
                self.msg = buff[offset:(offset + length_msg)]
            offset += length_msg
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        msg_x = self.msg
        msg_length = len(msg_x)
        if python3 or type(msg_x) == unicode:
            msg_x = msg_x.encode('utf-8')
            msg_length = len(msg_x)
        length += 4
        length += msg_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"result":%s' % self.result
        string_echo += ','
        string_echo += '"msg":"%s"' % self.msg
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "motion/ControlMotion"

    def getMD5(self):
        return "5a27c37067b61301060f3adddf1086c2"
    def getDef(self):
        return "int8 result\nstring msg\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ControlMotion(object):
    Request = ControlMotionRequest
    Response = ControlMotionResponse

    __slots__ = ['request','response']
    _slot_types = ['ControlMotionRequest','ControlMotionResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControlMotion, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

