import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.motion.msg

class ControlMotionWLRequest(mros.Message):
    __slots__ = ['__id__','cmd']
    _slot_types = ['uint32','int32']

    PAUSE =  1 
    RESUME =  2 
    CANCEL =  3 
    FINISH =  4 
    IDLE =  5  
    CHECK_SELF =  6  
    CALIBRATE_JOINT =  7  
    RETURN_HOME =  8  
    EMGY_STOP =  9  
    SIT_DOWN =  10 
    STAND_UP =  11 
    POSTURE =  12 
    ALIGN_STAIRS =  13 
    UP_STAIRS =  14 
    DW_STAIRS =  15 
    LOCK_POSE =  16 
    MODE_VISION =  17 
    MODE_LEGGED =  18 
    MODE_WHEELED =  19 
    MODE_FIX_WHEEL =  20 
    MODE_DRIVING =  21 
    MARK_TIME =  22 
    STOP_MARK_TIME =  23 
    MODE_POSTURE =  24 
    MAX =  25
    TEST_JOINT_TORQUE =  100 
    TEST_GRAVITY_COMPENSATION =  101 
    TEST_STANCE_PD =  102 
    TEST_SWING_WBC =  103 
    TEST_SWING_NMPC =  104 
    TEST_LOWER_BODY =  105 
    TEST_SLOP =  106 
    TEST_FLAG_STONE =  107 
    TEST_COBBLES_STONE =  108 
    TEST_SPEED_BUMPS =  109 
    TEST_WHEEL_DRIVING =  110 
    TEST_STRETCH =  111 
    TEST_CROSSCURB =  112 
    TEST_DRIVING_DIRECTION_SWITCH =  113 
    TEST_DOWN_SLOP =  114 
    TEST_ADJUSTMENT =  115 
    TEST_FINE_ADJUSTMENT =  116 
    TEST_ACTION1 =  200 
    TEST_ACTION2 =  201
    TEST_ACTION3 =  202
    TEST_ACTION4 =  203

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControlMotionWLRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.cmd is None:
                self.cmd = 0
        else:
            self.__id__ = 0
            self.cmd = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_cmd = struct.Struct("<i")
            buff.write(struct_cmd.pack(self.cmd))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_cmd = struct.Struct("<i")
            (self.cmd,) = struct_cmd.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"cmd":%s' % self.cmd
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "motion/ControlMotionWL"

    def getMD5(self):
        return "c9f315af133312bb94634ba9747b10a2"
    def getDef(self):
        return "int32 PAUSE        = 1\nint32 RESUME       = 2\nint32 CANCEL       = 3\nint32 FINISH       = 4\nint32 IDLE         = 5\nint32 CHECK_SELF   = 6\nint32 CALIBRATE_JOINT = 7\nint32 RETURN_HOME  = 8\nint32 EMGY_STOP    = 9\nint32 SIT_DOWN     = 10\nint32 STAND_UP     = 11\nint32 POSTURE      = 12\nint32 ALIGN_STAIRS = 13\nint32 UP_STAIRS    = 14\nint32 DW_STAIRS    = 15\nint32 LOCK_POSE    = 16\nint32 MODE_VISION     = 17\nint32 MODE_LEGGED     = 18\nint32 MODE_WHEELED    = 19\nint32 MODE_FIX_WHEEL  = 20\nint32 MODE_DRIVING    = 21\nint32 MARK_TIME       = 22\nint32 STOP_MARK_TIME  = 23\nint32 MODE_POSTURE    = 24\nint32 MAX             = 25\nint32 TEST_JOINT_TORQUE           = 100\nint32 TEST_GRAVITY_COMPENSATION   = 101\nint32 TEST_STANCE_PD              = 102\nint32 TEST_SWING_WBC              = 103\nint32 TEST_SWING_NMPC             = 104\nint32 TEST_LOWER_BODY             = 105\nint32 TEST_SLOP                   = 106\nint32 TEST_FLAG_STONE             = 107\nint32 TEST_COBBLES_STONE          = 108\nint32 TEST_SPEED_BUMPS            = 109\nint32 TEST_WHEEL_DRIVING               = 110\nint32 TEST_STRETCH                     = 111\nint32 TEST_CROSSCURB                   = 112\nint32 TEST_DRIVING_DIRECTION_SWITCH    = 113\nint32 TEST_DOWN_SLOP                   = 114\nint32 TEST_ADJUSTMENT                  = 115\nint32 TEST_FINE_ADJUSTMENT             = 116\nint32 TEST_ACTION1      = 200\nint32 TEST_ACTION2      = 201\nint32 TEST_ACTION3      = 202\nint32 TEST_ACTION4      = 203\nint32 cmd\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ControlMotionWLResponse(mros.Message):
    __slots__ = ['__id__','result','msg']
    _slot_types = ['uint32','int32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControlMotionWLResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.result is None:
                self.result = 0
            if self.msg is None:
                self.msg = ''
        else:
            self.__id__ = 0
            self.result = 0
            self.msg = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_result = struct.Struct("<i")
            buff.write(struct_result.pack(self.result))
            offset += 4
            _x = self.msg
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_result = struct.Struct("<i")
            (self.result,) = struct_result.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_msg,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.msg = buff[offset:(offset + length_msg)].decode('utf-8')
            else:
                self.msg = buff[offset:(offset + length_msg)]
            offset += length_msg
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        msg_x = self.msg
        msg_length = len(msg_x)
        if python3 or type(msg_x) == unicode:
            msg_x = msg_x.encode('utf-8')
            msg_length = len(msg_x)
        length += 4
        length += msg_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"result":%s' % self.result
        string_echo += ','
        string_echo += '"msg":"%s"' % self.msg
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "motion/ControlMotionWL"

    def getMD5(self):
        return "c9f315af133312bb94634ba9747b10a2"
    def getDef(self):
        return "int32 result\nstring msg\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ControlMotionWL(object):
    Request = ControlMotionWLRequest
    Response = ControlMotionWLResponse

    __slots__ = ['request','response']
    _slot_types = ['ControlMotionWLRequest','ControlMotionWLResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControlMotionWL, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

