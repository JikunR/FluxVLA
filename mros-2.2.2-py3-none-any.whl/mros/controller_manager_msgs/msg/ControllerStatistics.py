import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_manager_msgs.msg

class ControllerStatistics(mros.Message):
    __slots__ = ['name','type','timestamp','running','max_time','mean_time','variance_time','num_control_loop_overruns','time_last_control_loop_overrun']
    _slot_types = ['string','string','Time','bool','Duration','Duration','Duration','int32','Time']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControllerStatistics, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.type is None:
                self.type = ''
            if self.timestamp is None:
                self.timestamp = mros.Time()
            if self.running is None:
                self.running = False
            if self.max_time is None:
                self.max_time = mros.Duration()
            if self.mean_time is None:
                self.mean_time = mros.Duration()
            if self.variance_time is None:
                self.variance_time = mros.Duration()
            if self.num_control_loop_overruns is None:
                self.num_control_loop_overruns = 0
            if self.time_last_control_loop_overrun is None:
                self.time_last_control_loop_overrun = mros.Time()
        else:
            self.name = ''
            self.type = ''
            self.timestamp = mros.Time()
            self.running = False
            self.max_time = mros.Duration()
            self.mean_time = mros.Duration()
            self.variance_time = mros.Duration()
            self.num_control_loop_overruns = 0
            self.time_last_control_loop_overrun = mros.Time()

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.type
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(_struct_I.pack(self.timestamp.sec))
            offset += 4
            buff.write(_struct_I.pack(self.timestamp.nsec))
            offset += 4
            struct_running = struct.Struct("<B")
            buff.write(struct_running.pack(self.running))
            offset += 1
            buff.write(_struct_I.pack(self.max_time.sec))
            offset += 4
            buff.write(_struct_I.pack(self.max_time.nsec))
            offset += 4
            buff.write(_struct_I.pack(self.mean_time.sec))
            offset += 4
            buff.write(_struct_I.pack(self.mean_time.nsec))
            offset += 4
            buff.write(_struct_I.pack(self.variance_time.sec))
            offset += 4
            buff.write(_struct_I.pack(self.variance_time.nsec))
            offset += 4
            struct_num_control_loop_overruns = struct.Struct("<i")
            buff.write(struct_num_control_loop_overruns.pack(self.num_control_loop_overruns))
            offset += 4
            buff.write(_struct_I.pack(self.time_last_control_loop_overrun.sec))
            offset += 4
            buff.write(_struct_I.pack(self.time_last_control_loop_overrun.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (length_type,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.type = buff[offset:(offset + length_type)].decode('utf-8')
            else:
                self.type = buff[offset:(offset + length_type)]
            offset += length_type
            (self.timestamp.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.timestamp.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_running = struct.Struct("<B")
            (self.running,) = struct_running.unpack(buff[offset:(offset + 1)])
            self.running = bool(self.running)
            offset += 1
            (self.max_time.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.max_time.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.mean_time.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.mean_time.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.variance_time.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.variance_time.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_num_control_loop_overruns = struct.Struct("<i")
            (self.num_control_loop_overruns,) = struct_num_control_loop_overruns.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.time_last_control_loop_overrun.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.time_last_control_loop_overrun.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        type_x = self.type
        type_length = len(type_x)
        if python3 or type(type_x) == unicode:
            type_x = type_x.encode('utf-8')
            type_length = len(type_x)
        length += 4
        length += type_length
        length += 4
        length += 4
        length += 1
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"type":"%s"' % self.type
        string_echo += ','
        string_echo += '"timestamp.sec":%s,' % self.timestamp.sec
        string_echo += '"timestamp.nsec":%s' % self.timestamp.nsec
        string_echo += ','
        string_echo += '"running":%s' % self.running
        string_echo += ','
        string_echo += '"max_time.sec":%s,' % self.max_time.sec
        string_echo += '"max_time.nsec":%s' % self.max_time.nsec
        string_echo += ','
        string_echo += '"mean_time.sec":%s,' % self.mean_time.sec
        string_echo += '"mean_time.nsec":%s' % self.mean_time.nsec
        string_echo += ','
        string_echo += '"variance_time.sec":%s,' % self.variance_time.sec
        string_echo += '"variance_time.nsec":%s' % self.variance_time.nsec
        string_echo += ','
        string_echo += '"num_control_loop_overruns":%s' % self.num_control_loop_overruns
        string_echo += ','
        string_echo += '"time_last_control_loop_overrun.sec":%s,' % self.time_last_control_loop_overrun.sec
        string_echo += '"time_last_control_loop_overrun.nsec":%s' % self.time_last_control_loop_overrun.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/ControllerStatistics"

    def getMD5(self):
        return "697780c372c8d8597a1436d0e2ad3ba8"

    def getDef(self):
        return "string name\nstring type\ntime timestamp\nbool running\nduration max_time\nduration mean_time\nduration variance_time\nint32 num_control_loop_overruns\ntime time_last_control_loop_overrun\n"

_struct_I = struct.Struct('<I')

