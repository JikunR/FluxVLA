import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_manager_msgs.msg
import mros.std_msgs.msg

class ControllersStatistics(mros.Message):
    __slots__ = ['header','controller']
    _slot_types = ['std_msgs/Header','controller_manager_msgs/ControllerStatistics[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControllersStatistics, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.controller is None:
                self.controller = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.controller = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            controller_length = len(self.controller)
            buff.write(struct.pack('<I', controller_length))
            offset += 4
            for i in range(0, controller_length):
                offset += self.controller[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (controller_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.controller) != controller_length:
                self.controller = [mros.controller_manager_msgs.msg.ControllerStatistics() for _ in range(controller_length)]
            for i in range(0, controller_length):
                offset += self.controller[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, controller_length):
            length += self.controller[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"controller":['
        controller_length = len(self.controller)
        for i in range(0, controller_length):
            if i == (controller_length - 1): 
                string_echo += '{controller%s":' % i
                string_echo += self.controller[i].echo()
                string_echo += ''
            else:
                string_echo += '{controller%s":' % i
                string_echo += self.controller[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/ControllersStatistics"

    def getMD5(self):
        return "a154c347736773e3700d1719105df29d"

    def getDef(self):
        return "std_msgs/Header header\ncontroller_manager_msgs/ControllerStatistics[] controller\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: controller_manager_msgs/ControllerStatistics\nstring name\nstring type\ntime timestamp\nbool running\nduration max_time\nduration mean_time\nduration variance_time\nint32 num_control_loop_overruns\ntime time_last_control_loop_overrun\n"

_struct_I = struct.Struct('<I')

