import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_manager_msgs.msg

class HardwareInterfaceResources(mros.Message):
    __slots__ = ['hardware_interface','resources']
    _slot_types = ['string','string[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HardwareInterfaceResources, self).__init__(*args, **kwds)
            if self.hardware_interface is None:
                self.hardware_interface = ''
            if self.resources is None:
                self.resources = []
        else:
            self.hardware_interface = ''
            self.resources = []

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.hardware_interface
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            resources_length = len(self.resources)
            buff.write(struct.pack('<I', resources_length))
            offset += 4
            for i in range(0, resources_length):
                _x = self.resources[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_hardware_interface,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.hardware_interface = buff[offset:(offset + length_hardware_interface)].decode('utf-8')
            else:
                self.hardware_interface = buff[offset:(offset + length_hardware_interface)]
            offset += length_hardware_interface
            (resources_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.resources) != resources_length:
                self.resources = ['' for _ in range(resources_length)]
            for i in range(0, resources_length):
                (length_resourcesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.resources[i] = buff[offset:(offset + length_resourcesi)].decode('utf-8')
                else:
                    self.resources[i] = buff[offset:(offset + length_resourcesi)]
                offset += length_resourcesi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        hardware_interface_x = self.hardware_interface
        hardware_interface_length = len(hardware_interface_x)
        if python3 or type(hardware_interface_x) == unicode:
            hardware_interface_x = hardware_interface_x.encode('utf-8')
            hardware_interface_length = len(hardware_interface_x)
        length += 4
        length += hardware_interface_length
        length += 4
        for i in range(0, resources_length):
            resourcesi_x = self.resources[i]
            resourcesi_length = len(resourcesi_x)
            if python3 or type(resourcesi_x) == unicode:
                resourcesi_x = resourcesi_x.encode('utf-8')
                resourcesi_length = len(resourcesi_x)
            length += 4
            length += resourcesi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"hardware_interface":"%s"' % self.hardware_interface
        string_echo += ','
        string_echo += '"resources":['
        resources_length = len(self.resources)
        for i in range(0, resources_length):
            if i == (resources_length - 1): 
                string_echo += '"resources[i]":"%s"' % self.resources[i]
                string_echo += ''
            else:
                string_echo += '"resources[i]":"%s"' % self.resources[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/HardwareInterfaceResources"

    def getMD5(self):
        return "f25b55cbf1d1f76e82e5ec9e83f76258"

    def getDef(self):
        return "string hardware_interface\nstring[] resources\n"

_struct_I = struct.Struct('<I')

