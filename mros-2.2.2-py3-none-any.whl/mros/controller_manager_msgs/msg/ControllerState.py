import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_manager_msgs.msg

class ControllerState(mros.Message):
    __slots__ = ['name','state','type','claimed_resources']
    _slot_types = ['string','string','string','controller_manager_msgs/HardwareInterfaceResources[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ControllerState, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.state is None:
                self.state = ''
            if self.type is None:
                self.type = ''
            if self.claimed_resources is None:
                self.claimed_resources = []
        else:
            self.name = ''
            self.state = ''
            self.type = ''
            self.claimed_resources = []

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.state
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.type
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            claimed_resources_length = len(self.claimed_resources)
            buff.write(struct.pack('<I', claimed_resources_length))
            offset += 4
            for i in range(0, claimed_resources_length):
                offset += self.claimed_resources[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (length_state,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.state = buff[offset:(offset + length_state)].decode('utf-8')
            else:
                self.state = buff[offset:(offset + length_state)]
            offset += length_state
            (length_type,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.type = buff[offset:(offset + length_type)].decode('utf-8')
            else:
                self.type = buff[offset:(offset + length_type)]
            offset += length_type
            (claimed_resources_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.claimed_resources) != claimed_resources_length:
                self.claimed_resources = [mros.controller_manager_msgs.msg.HardwareInterfaceResources() for _ in range(claimed_resources_length)]
            for i in range(0, claimed_resources_length):
                offset += self.claimed_resources[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        state_x = self.state
        state_length = len(state_x)
        if python3 or type(state_x) == unicode:
            state_x = state_x.encode('utf-8')
            state_length = len(state_x)
        length += 4
        length += state_length
        type_x = self.type
        type_length = len(type_x)
        if python3 or type(type_x) == unicode:
            type_x = type_x.encode('utf-8')
            type_length = len(type_x)
        length += 4
        length += type_length
        length += 4
        for i in range(0, claimed_resources_length):
            length += self.claimed_resources[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"state":"%s"' % self.state
        string_echo += ','
        string_echo += '"type":"%s"' % self.type
        string_echo += ','
        string_echo += '"claimed_resources":['
        claimed_resources_length = len(self.claimed_resources)
        for i in range(0, claimed_resources_length):
            if i == (claimed_resources_length - 1): 
                string_echo += '{claimed_resources%s":' % i
                string_echo += self.claimed_resources[i].echo()
                string_echo += ''
            else:
                string_echo += '{claimed_resources%s":' % i
                string_echo += self.claimed_resources[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/ControllerState"

    def getMD5(self):
        return "aeb6b261d97793ab74099a3740245272"

    def getDef(self):
        return "string name\nstring state\nstring type\ncontroller_manager_msgs/HardwareInterfaceResources[] claimed_resources\n================================================================================\nMSG: controller_manager_msgs/HardwareInterfaceResources\nstring hardware_interface\nstring[] resources\n"

_struct_I = struct.Struct('<I')

