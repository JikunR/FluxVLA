import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_manager_msgs.msg

class SwitchControllerRequest(mros.Message):
    __slots__ = ['__id__','start_controllers','stop_controllers','strictness','start_asap','timeout']
    _slot_types = ['uint32','string[]','string[]','int32','bool','float64']

    BEST_EFFORT = 1
    STRICT = 2

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SwitchControllerRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.start_controllers is None:
                self.start_controllers = []
            if self.stop_controllers is None:
                self.stop_controllers = []
            if self.strictness is None:
                self.strictness = 0
            if self.start_asap is None:
                self.start_asap = False
            if self.timeout is None:
                self.timeout = 0.
        else:
            self.__id__ = 0
            self.start_controllers = []
            self.stop_controllers = []
            self.strictness = 0
            self.start_asap = False
            self.timeout = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            start_controllers_length = len(self.start_controllers)
            buff.write(struct.pack('<I', start_controllers_length))
            offset += 4
            for i in range(0, start_controllers_length):
                _x = self.start_controllers[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            stop_controllers_length = len(self.stop_controllers)
            buff.write(struct.pack('<I', stop_controllers_length))
            offset += 4
            for i in range(0, stop_controllers_length):
                _x = self.stop_controllers[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            struct_strictness = struct.Struct("<i")
            buff.write(struct_strictness.pack(self.strictness))
            offset += 4
            struct_start_asap = struct.Struct("<B")
            buff.write(struct_start_asap.pack(self.start_asap))
            offset += 1
            struct_timeout = struct.Struct("<d")
            buff.write(struct_timeout.pack(self.timeout))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (start_controllers_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.start_controllers) != start_controllers_length:
                self.start_controllers = ['' for _ in range(start_controllers_length)]
            for i in range(0, start_controllers_length):
                (length_start_controllersi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.start_controllers[i] = buff[offset:(offset + length_start_controllersi)].decode('utf-8')
                else:
                    self.start_controllers[i] = buff[offset:(offset + length_start_controllersi)]
                offset += length_start_controllersi
            (stop_controllers_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.stop_controllers) != stop_controllers_length:
                self.stop_controllers = ['' for _ in range(stop_controllers_length)]
            for i in range(0, stop_controllers_length):
                (length_stop_controllersi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.stop_controllers[i] = buff[offset:(offset + length_stop_controllersi)].decode('utf-8')
                else:
                    self.stop_controllers[i] = buff[offset:(offset + length_stop_controllersi)]
                offset += length_stop_controllersi
            struct_strictness = struct.Struct("<i")
            (self.strictness,) = struct_strictness.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_start_asap = struct.Struct("<B")
            (self.start_asap,) = struct_start_asap.unpack(buff[offset:(offset + 1)])
            self.start_asap = bool(self.start_asap)
            offset += 1
            struct_timeout = struct.Struct("<d")
            (self.timeout,) = struct_timeout.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, start_controllers_length):
            start_controllersi_x = self.start_controllers[i]
            start_controllersi_length = len(start_controllersi_x)
            if python3 or type(start_controllersi_x) == unicode:
                start_controllersi_x = start_controllersi_x.encode('utf-8')
                start_controllersi_length = len(start_controllersi_x)
            length += 4
            length += start_controllersi_length
        length += 4
        for i in range(0, stop_controllers_length):
            stop_controllersi_x = self.stop_controllers[i]
            stop_controllersi_length = len(stop_controllersi_x)
            if python3 or type(stop_controllersi_x) == unicode:
                stop_controllersi_x = stop_controllersi_x.encode('utf-8')
                stop_controllersi_length = len(stop_controllersi_x)
            length += 4
            length += stop_controllersi_length
        length += 4
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"start_controllers":['
        start_controllers_length = len(self.start_controllers)
        for i in range(0, start_controllers_length):
            if i == (start_controllers_length - 1): 
                string_echo += '"start_controllers[i]":"%s"' % self.start_controllers[i]
                string_echo += ''
            else:
                string_echo += '"start_controllers[i]":"%s"' % self.start_controllers[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"stop_controllers":['
        stop_controllers_length = len(self.stop_controllers)
        for i in range(0, stop_controllers_length):
            if i == (stop_controllers_length - 1): 
                string_echo += '"stop_controllers[i]":"%s"' % self.stop_controllers[i]
                string_echo += ''
            else:
                string_echo += '"stop_controllers[i]":"%s"' % self.stop_controllers[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"strictness":%s' % self.strictness
        string_echo += ','
        string_echo += '"start_asap":%s' % self.start_asap
        string_echo += ','
        string_echo += '"timeout":%s' % self.timeout
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/SwitchController"

    def getMD5(self):
        return "b29a7abc673b2c54c14b54e50f8d06a5"
    def getDef(self):
        return "string[] start_controllers\nstring[] stop_controllers\nint32 strictness\nint32 BEST_EFFORT=1\nint32 STRICT=2\nbool start_asap\nfloat64 timeout\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SwitchControllerResponse(mros.Message):
    __slots__ = ['__id__','ok']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SwitchControllerResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.ok is None:
                self.ok = False
        else:
            self.__id__ = 0
            self.ok = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_ok = struct.Struct("<B")
            buff.write(struct_ok.pack(self.ok))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_ok = struct.Struct("<B")
            (self.ok,) = struct_ok.unpack(buff[offset:(offset + 1)])
            self.ok = bool(self.ok)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"ok":%s' % self.ok
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/SwitchController"

    def getMD5(self):
        return "b29a7abc673b2c54c14b54e50f8d06a5"
    def getDef(self):
        return "bool ok\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SwitchController(object):
    Request = SwitchControllerRequest
    Response = SwitchControllerResponse

    __slots__ = ['request','response']
    _slot_types = ['SwitchControllerRequest','SwitchControllerResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SwitchController, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

