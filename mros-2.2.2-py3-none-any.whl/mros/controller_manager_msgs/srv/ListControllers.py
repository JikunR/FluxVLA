import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_manager_msgs.msg

class ListControllersRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListControllersRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/ListControllers"

    def getMD5(self):
        return "1341feb2e63fa791f855565d0da950d8"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ListControllersResponse(mros.Message):
    __slots__ = ['__id__','controller']
    _slot_types = ['uint32','controller_manager_msgs/ControllerState[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListControllersResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.controller is None:
                self.controller = []
        else:
            self.__id__ = 0
            self.controller = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            controller_length = len(self.controller)
            buff.write(struct.pack('<I', controller_length))
            offset += 4
            for i in range(0, controller_length):
                offset += self.controller[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (controller_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.controller) != controller_length:
                self.controller = [mros.controller_manager_msgs.msg.ControllerState() for _ in range(controller_length)]
            for i in range(0, controller_length):
                offset += self.controller[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, controller_length):
            length += self.controller[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"controller":['
        controller_length = len(self.controller)
        for i in range(0, controller_length):
            if i == (controller_length - 1): 
                string_echo += '{controller%s":' % i
                string_echo += self.controller[i].echo()
                string_echo += ''
            else:
                string_echo += '{controller%s":' % i
                string_echo += self.controller[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_manager_msgs/ListControllers"

    def getMD5(self):
        return "1341feb2e63fa791f855565d0da950d8"
    def getDef(self):
        return "controller_manager_msgs/ControllerState[] controller\n================================================================================\nMSG: controller_manager_msgs/ControllerState\nstring name\nstring state\nstring type\ncontroller_manager_msgs/HardwareInterfaceResources[] claimed_resources\n================================================================================\nMSG: controller_manager_msgs/HardwareInterfaceResources\nstring hardware_interface\nstring[] resources\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ListControllers(object):
    Request = ListControllersRequest
    Response = ListControllersResponse

    __slots__ = ['request','response']
    _slot_types = ['ListControllersRequest','ListControllersResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListControllers, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

