import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg

class ODEJointProperties(mros.Message):
    __slots__ = ['damping','hiStop','loStop','erp','cfm','stop_erp','stop_cfm','fudge_factor','fmax','vel']
    _slot_types = ['float64[]','float64[]','float64[]','float64[]','float64[]','float64[]','float64[]','float64[]','float64[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ODEJointProperties, self).__init__(*args, **kwds)
            if self.damping is None:
                self.damping = []
            if self.hiStop is None:
                self.hiStop = []
            if self.loStop is None:
                self.loStop = []
            if self.erp is None:
                self.erp = []
            if self.cfm is None:
                self.cfm = []
            if self.stop_erp is None:
                self.stop_erp = []
            if self.stop_cfm is None:
                self.stop_cfm = []
            if self.fudge_factor is None:
                self.fudge_factor = []
            if self.fmax is None:
                self.fmax = []
            if self.vel is None:
                self.vel = []
        else:
            self.damping = []
            self.hiStop = []
            self.loStop = []
            self.erp = []
            self.cfm = []
            self.stop_erp = []
            self.stop_cfm = []
            self.fudge_factor = []
            self.fmax = []
            self.vel = []

    def serialize(self, buff):
        offset = 0
        try:
            damping_length = len(self.damping)
            buff.write(struct.pack('<I', damping_length))
            buff.write(struct.pack(f'<{damping_length}d', *self.damping))
            offset += 4 + damping_length * 8
            hiStop_length = len(self.hiStop)
            buff.write(struct.pack('<I', hiStop_length))
            buff.write(struct.pack(f'<{hiStop_length}d', *self.hiStop))
            offset += 4 + hiStop_length * 8
            loStop_length = len(self.loStop)
            buff.write(struct.pack('<I', loStop_length))
            buff.write(struct.pack(f'<{loStop_length}d', *self.loStop))
            offset += 4 + loStop_length * 8
            erp_length = len(self.erp)
            buff.write(struct.pack('<I', erp_length))
            buff.write(struct.pack(f'<{erp_length}d', *self.erp))
            offset += 4 + erp_length * 8
            cfm_length = len(self.cfm)
            buff.write(struct.pack('<I', cfm_length))
            buff.write(struct.pack(f'<{cfm_length}d', *self.cfm))
            offset += 4 + cfm_length * 8
            stop_erp_length = len(self.stop_erp)
            buff.write(struct.pack('<I', stop_erp_length))
            buff.write(struct.pack(f'<{stop_erp_length}d', *self.stop_erp))
            offset += 4 + stop_erp_length * 8
            stop_cfm_length = len(self.stop_cfm)
            buff.write(struct.pack('<I', stop_cfm_length))
            buff.write(struct.pack(f'<{stop_cfm_length}d', *self.stop_cfm))
            offset += 4 + stop_cfm_length * 8
            fudge_factor_length = len(self.fudge_factor)
            buff.write(struct.pack('<I', fudge_factor_length))
            buff.write(struct.pack(f'<{fudge_factor_length}d', *self.fudge_factor))
            offset += 4 + fudge_factor_length * 8
            fmax_length = len(self.fmax)
            buff.write(struct.pack('<I', fmax_length))
            buff.write(struct.pack(f'<{fmax_length}d', *self.fmax))
            offset += 4 + fmax_length * 8
            vel_length = len(self.vel)
            buff.write(struct.pack('<I', vel_length))
            buff.write(struct.pack(f'<{vel_length}d', *self.vel))
            offset += 4 + vel_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (damping_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.damping = np.frombuffer(buff[offset:offset + damping_length * 8], dtype=np.float64)
            offset += damping_length * 8
            (hiStop_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.hiStop = np.frombuffer(buff[offset:offset + hiStop_length * 8], dtype=np.float64)
            offset += hiStop_length * 8
            (loStop_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.loStop = np.frombuffer(buff[offset:offset + loStop_length * 8], dtype=np.float64)
            offset += loStop_length * 8
            (erp_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.erp = np.frombuffer(buff[offset:offset + erp_length * 8], dtype=np.float64)
            offset += erp_length * 8
            (cfm_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.cfm = np.frombuffer(buff[offset:offset + cfm_length * 8], dtype=np.float64)
            offset += cfm_length * 8
            (stop_erp_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.stop_erp = np.frombuffer(buff[offset:offset + stop_erp_length * 8], dtype=np.float64)
            offset += stop_erp_length * 8
            (stop_cfm_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.stop_cfm = np.frombuffer(buff[offset:offset + stop_cfm_length * 8], dtype=np.float64)
            offset += stop_cfm_length * 8
            (fudge_factor_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.fudge_factor = np.frombuffer(buff[offset:offset + fudge_factor_length * 8], dtype=np.float64)
            offset += fudge_factor_length * 8
            (fmax_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.fmax = np.frombuffer(buff[offset:offset + fmax_length * 8], dtype=np.float64)
            offset += fmax_length * 8
            (vel_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.vel = np.frombuffer(buff[offset:offset + vel_length * 8], dtype=np.float64)
            offset += vel_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += len(self.damping) * 8
        length += 4
        length += len(self.hiStop) * 8
        length += 4
        length += len(self.loStop) * 8
        length += 4
        length += len(self.erp) * 8
        length += 4
        length += len(self.cfm) * 8
        length += 4
        length += len(self.stop_erp) * 8
        length += 4
        length += len(self.stop_cfm) * 8
        length += 4
        length += len(self.fudge_factor) * 8
        length += 4
        length += len(self.fmax) * 8
        length += 4
        length += len(self.vel) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"damping":['
        damping_length = len(self.damping)
        for i in range(0, damping_length):
            if i == (damping_length - 1): 
                string_echo += '%s' % self.damping[i]
            else:
                string_echo += '%s,' % self.damping[i]
        string_echo += '],'
        string_echo += '"hiStop":['
        hiStop_length = len(self.hiStop)
        for i in range(0, hiStop_length):
            if i == (hiStop_length - 1): 
                string_echo += '%s' % self.hiStop[i]
            else:
                string_echo += '%s,' % self.hiStop[i]
        string_echo += '],'
        string_echo += '"loStop":['
        loStop_length = len(self.loStop)
        for i in range(0, loStop_length):
            if i == (loStop_length - 1): 
                string_echo += '%s' % self.loStop[i]
            else:
                string_echo += '%s,' % self.loStop[i]
        string_echo += '],'
        string_echo += '"erp":['
        erp_length = len(self.erp)
        for i in range(0, erp_length):
            if i == (erp_length - 1): 
                string_echo += '%s' % self.erp[i]
            else:
                string_echo += '%s,' % self.erp[i]
        string_echo += '],'
        string_echo += '"cfm":['
        cfm_length = len(self.cfm)
        for i in range(0, cfm_length):
            if i == (cfm_length - 1): 
                string_echo += '%s' % self.cfm[i]
            else:
                string_echo += '%s,' % self.cfm[i]
        string_echo += '],'
        string_echo += '"stop_erp":['
        stop_erp_length = len(self.stop_erp)
        for i in range(0, stop_erp_length):
            if i == (stop_erp_length - 1): 
                string_echo += '%s' % self.stop_erp[i]
            else:
                string_echo += '%s,' % self.stop_erp[i]
        string_echo += '],'
        string_echo += '"stop_cfm":['
        stop_cfm_length = len(self.stop_cfm)
        for i in range(0, stop_cfm_length):
            if i == (stop_cfm_length - 1): 
                string_echo += '%s' % self.stop_cfm[i]
            else:
                string_echo += '%s,' % self.stop_cfm[i]
        string_echo += '],'
        string_echo += '"fudge_factor":['
        fudge_factor_length = len(self.fudge_factor)
        for i in range(0, fudge_factor_length):
            if i == (fudge_factor_length - 1): 
                string_echo += '%s' % self.fudge_factor[i]
            else:
                string_echo += '%s,' % self.fudge_factor[i]
        string_echo += '],'
        string_echo += '"fmax":['
        fmax_length = len(self.fmax)
        for i in range(0, fmax_length):
            if i == (fmax_length - 1): 
                string_echo += '%s' % self.fmax[i]
            else:
                string_echo += '%s,' % self.fmax[i]
        string_echo += '],'
        string_echo += '"vel":['
        vel_length = len(self.vel)
        for i in range(0, vel_length):
            if i == (vel_length - 1): 
                string_echo += '%s' % self.vel[i]
            else:
                string_echo += '%s,' % self.vel[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/ODEJointProperties"

    def getMD5(self):
        return "1b744c32a920af979f53afe2f9c3511f"

    def getDef(self):
        return "float64[] damping\nfloat64[] hiStop\nfloat64[] loStop\nfloat64[] erp\nfloat64[] cfm\nfloat64[] stop_erp\nfloat64[] stop_cfm\nfloat64[] fudge_factor\nfloat64[] fmax\nfloat64[] vel\n"

_struct_I = struct.Struct('<I')

