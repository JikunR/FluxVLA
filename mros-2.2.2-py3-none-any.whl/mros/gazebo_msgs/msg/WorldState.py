import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class WorldState(mros.Message):
    __slots__ = ['header','name','pose','twist','wrench']
    _slot_types = ['std_msgs/Header','string[]','geometry_msgs/Pose[]','geometry_msgs/Twist[]','geometry_msgs/Wrench[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(WorldState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.name is None:
                self.name = []
            if self.pose is None:
                self.pose = []
            if self.twist is None:
                self.twist = []
            if self.wrench is None:
                self.wrench = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.name = []
            self.pose = []
            self.twist = []
            self.wrench = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            name_length = len(self.name)
            buff.write(struct.pack('<I', name_length))
            offset += 4
            for i in range(0, name_length):
                _x = self.name[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            pose_length = len(self.pose)
            buff.write(struct.pack('<I', pose_length))
            offset += 4
            for i in range(0, pose_length):
                offset += self.pose[i].serialize(buff)
            twist_length = len(self.twist)
            buff.write(struct.pack('<I', twist_length))
            offset += 4
            for i in range(0, twist_length):
                offset += self.twist[i].serialize(buff)
            wrench_length = len(self.wrench)
            buff.write(struct.pack('<I', wrench_length))
            offset += 4
            for i in range(0, wrench_length):
                offset += self.wrench[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (name_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.name) != name_length:
                self.name = ['' for _ in range(name_length)]
            for i in range(0, name_length):
                (length_namei,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.name[i] = buff[offset:(offset + length_namei)].decode('utf-8')
                else:
                    self.name[i] = buff[offset:(offset + length_namei)]
                offset += length_namei
            (pose_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.pose) != pose_length:
                self.pose = [mros.geometry_msgs.msg.Pose() for _ in range(pose_length)]
            for i in range(0, pose_length):
                offset += self.pose[i].deserialize(buff[offset:])
            (twist_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.twist) != twist_length:
                self.twist = [mros.geometry_msgs.msg.Twist() for _ in range(twist_length)]
            for i in range(0, twist_length):
                offset += self.twist[i].deserialize(buff[offset:])
            (wrench_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.wrench) != wrench_length:
                self.wrench = [mros.geometry_msgs.msg.Wrench() for _ in range(wrench_length)]
            for i in range(0, wrench_length):
                offset += self.wrench[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, name_length):
            namei_x = self.name[i]
            namei_length = len(namei_x)
            if python3 or type(namei_x) == unicode:
                namei_x = namei_x.encode('utf-8')
                namei_length = len(namei_x)
            length += 4
            length += namei_length
        length += 4
        for i in range(0, pose_length):
            length += self.pose[i].serializedLength()
        length += 4
        for i in range(0, twist_length):
            length += self.twist[i].serializedLength()
        length += 4
        for i in range(0, wrench_length):
            length += self.wrench[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"name":['
        name_length = len(self.name)
        for i in range(0, name_length):
            if i == (name_length - 1): 
                string_echo += '"name[i]":"%s"' % self.name[i]
                string_echo += ''
            else:
                string_echo += '"name[i]":"%s"' % self.name[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"pose":['
        pose_length = len(self.pose)
        for i in range(0, pose_length):
            if i == (pose_length - 1): 
                string_echo += '{pose%s":' % i
                string_echo += self.pose[i].echo()
                string_echo += ''
            else:
                string_echo += '{pose%s":' % i
                string_echo += self.pose[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"twist":['
        twist_length = len(self.twist)
        for i in range(0, twist_length):
            if i == (twist_length - 1): 
                string_echo += '{twist%s":' % i
                string_echo += self.twist[i].echo()
                string_echo += ''
            else:
                string_echo += '{twist%s":' % i
                string_echo += self.twist[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"wrench":['
        wrench_length = len(self.wrench)
        for i in range(0, wrench_length):
            if i == (wrench_length - 1): 
                string_echo += '{wrench%s":' % i
                string_echo += self.wrench[i].echo()
                string_echo += ''
            else:
                string_echo += '{wrench%s":' % i
                string_echo += self.wrench[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/WorldState"

    def getMD5(self):
        return "de1a9de3ab7ba97ac0e9ec01a4eb481e"

    def getDef(self):
        return "std_msgs/Header header\nstring[] name\ngeometry_msgs/Pose[] pose\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Wrench[] wrench\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

