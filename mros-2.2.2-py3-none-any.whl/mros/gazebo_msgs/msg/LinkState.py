import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg
import mros.geometry_msgs.msg

class LinkState(mros.Message):
    __slots__ = ['link_name','pose','twist','reference_frame']
    _slot_types = ['string','geometry_msgs/Pose','geometry_msgs/Twist','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(LinkState, self).__init__(*args, **kwds)
            if self.link_name is None:
                self.link_name = ''
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
            if self.twist is None:
                self.twist = mros.geometry_msgs.msg.Twist()
            if self.reference_frame is None:
                self.reference_frame = ''
        else:
            self.link_name = ''
            self.pose = mros.geometry_msgs.msg.Pose()
            self.twist = mros.geometry_msgs.msg.Twist()
            self.reference_frame = ''

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.pose.serialize(buff)
            offset += self.twist.serialize(buff)
            _x = self.reference_frame
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.link_name = buff[offset:(offset + length_link_name)].decode('utf-8')
            else:
                self.link_name = buff[offset:(offset + length_link_name)]
            offset += length_link_name
            offset += self.pose.deserialize(buff[offset:])
            offset += self.twist.deserialize(buff[offset:])
            (length_reference_frame,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.reference_frame = buff[offset:(offset + length_reference_frame)].decode('utf-8')
            else:
                self.reference_frame = buff[offset:(offset + length_reference_frame)]
            offset += length_reference_frame
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        link_name_x = self.link_name
        link_name_length = len(link_name_x)
        if python3 or type(link_name_x) == unicode:
            link_name_x = link_name_x.encode('utf-8')
            link_name_length = len(link_name_x)
        length += 4
        length += link_name_length
        length += self.pose.serializedLength()
        length += self.twist.serializedLength()
        reference_frame_x = self.reference_frame
        reference_frame_length = len(reference_frame_x)
        if python3 or type(reference_frame_x) == unicode:
            reference_frame_x = reference_frame_x.encode('utf-8')
            reference_frame_length = len(reference_frame_x)
        length += 4
        length += reference_frame_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"link_name":"%s"' % self.link_name
        string_echo += ','
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ','
        string_echo += '"twist":'
        string_echo += self.twist.echo()
        string_echo += ','
        string_echo += '"reference_frame":"%s"' % self.reference_frame
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/LinkState"

    def getMD5(self):
        return "0818ebbf28ce3a08d48ab1eaa7309ebe"

    def getDef(self):
        return "string link_name\ngeometry_msgs/Pose pose\ngeometry_msgs/Twist twist\nstring reference_frame\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

