import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg
import mros.geometry_msgs.msg

class ContactState(mros.Message):
    __slots__ = ['info','collision1_name','collision2_name','wrenches','total_wrench','contact_positions','contact_normals','depths']
    _slot_types = ['string','string','string','geometry_msgs/Wrench[]','geometry_msgs/Wrench','geometry_msgs/Vector3[]','geometry_msgs/Vector3[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ContactState, self).__init__(*args, **kwds)
            if self.info is None:
                self.info = ''
            if self.collision1_name is None:
                self.collision1_name = ''
            if self.collision2_name is None:
                self.collision2_name = ''
            if self.wrenches is None:
                self.wrenches = []
            if self.total_wrench is None:
                self.total_wrench = mros.geometry_msgs.msg.Wrench()
            if self.contact_positions is None:
                self.contact_positions = []
            if self.contact_normals is None:
                self.contact_normals = []
            if self.depths is None:
                self.depths = []
        else:
            self.info = ''
            self.collision1_name = ''
            self.collision2_name = ''
            self.wrenches = []
            self.total_wrench = mros.geometry_msgs.msg.Wrench()
            self.contact_positions = []
            self.contact_normals = []
            self.depths = []

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.info
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.collision1_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.collision2_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            wrenches_length = len(self.wrenches)
            buff.write(struct.pack('<I', wrenches_length))
            offset += 4
            for i in range(0, wrenches_length):
                offset += self.wrenches[i].serialize(buff)
            offset += self.total_wrench.serialize(buff)
            contact_positions_length = len(self.contact_positions)
            buff.write(struct.pack('<I', contact_positions_length))
            offset += 4
            for i in range(0, contact_positions_length):
                offset += self.contact_positions[i].serialize(buff)
            contact_normals_length = len(self.contact_normals)
            buff.write(struct.pack('<I', contact_normals_length))
            offset += 4
            for i in range(0, contact_normals_length):
                offset += self.contact_normals[i].serialize(buff)
            depths_length = len(self.depths)
            buff.write(struct.pack('<I', depths_length))
            buff.write(struct.pack(f'<{depths_length}d', *self.depths))
            offset += 4 + depths_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_info,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.info = buff[offset:(offset + length_info)].decode('utf-8')
            else:
                self.info = buff[offset:(offset + length_info)]
            offset += length_info
            (length_collision1_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.collision1_name = buff[offset:(offset + length_collision1_name)].decode('utf-8')
            else:
                self.collision1_name = buff[offset:(offset + length_collision1_name)]
            offset += length_collision1_name
            (length_collision2_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.collision2_name = buff[offset:(offset + length_collision2_name)].decode('utf-8')
            else:
                self.collision2_name = buff[offset:(offset + length_collision2_name)]
            offset += length_collision2_name
            (wrenches_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.wrenches) != wrenches_length:
                self.wrenches = [mros.geometry_msgs.msg.Wrench() for _ in range(wrenches_length)]
            for i in range(0, wrenches_length):
                offset += self.wrenches[i].deserialize(buff[offset:])
            offset += self.total_wrench.deserialize(buff[offset:])
            (contact_positions_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.contact_positions) != contact_positions_length:
                self.contact_positions = [mros.geometry_msgs.msg.Vector3() for _ in range(contact_positions_length)]
            for i in range(0, contact_positions_length):
                offset += self.contact_positions[i].deserialize(buff[offset:])
            (contact_normals_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.contact_normals) != contact_normals_length:
                self.contact_normals = [mros.geometry_msgs.msg.Vector3() for _ in range(contact_normals_length)]
            for i in range(0, contact_normals_length):
                offset += self.contact_normals[i].deserialize(buff[offset:])
            (depths_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.depths = np.frombuffer(buff[offset:offset + depths_length * 8], dtype=np.float64)
            offset += depths_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        info_x = self.info
        info_length = len(info_x)
        if python3 or type(info_x) == unicode:
            info_x = info_x.encode('utf-8')
            info_length = len(info_x)
        length += 4
        length += info_length
        collision1_name_x = self.collision1_name
        collision1_name_length = len(collision1_name_x)
        if python3 or type(collision1_name_x) == unicode:
            collision1_name_x = collision1_name_x.encode('utf-8')
            collision1_name_length = len(collision1_name_x)
        length += 4
        length += collision1_name_length
        collision2_name_x = self.collision2_name
        collision2_name_length = len(collision2_name_x)
        if python3 or type(collision2_name_x) == unicode:
            collision2_name_x = collision2_name_x.encode('utf-8')
            collision2_name_length = len(collision2_name_x)
        length += 4
        length += collision2_name_length
        length += 4
        for i in range(0, wrenches_length):
            length += self.wrenches[i].serializedLength()
        length += self.total_wrench.serializedLength()
        length += 4
        for i in range(0, contact_positions_length):
            length += self.contact_positions[i].serializedLength()
        length += 4
        for i in range(0, contact_normals_length):
            length += self.contact_normals[i].serializedLength()
        length += 4
        length += len(self.depths) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"info":"%s"' % self.info
        string_echo += ','
        string_echo += '"collision1_name":"%s"' % self.collision1_name
        string_echo += ','
        string_echo += '"collision2_name":"%s"' % self.collision2_name
        string_echo += ','
        string_echo += '"wrenches":['
        wrenches_length = len(self.wrenches)
        for i in range(0, wrenches_length):
            if i == (wrenches_length - 1): 
                string_echo += '{wrenches%s":' % i
                string_echo += self.wrenches[i].echo()
                string_echo += ''
            else:
                string_echo += '{wrenches%s":' % i
                string_echo += self.wrenches[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"total_wrench":'
        string_echo += self.total_wrench.echo()
        string_echo += ','
        string_echo += '"contact_positions":['
        contact_positions_length = len(self.contact_positions)
        for i in range(0, contact_positions_length):
            if i == (contact_positions_length - 1): 
                string_echo += '{contact_positions%s":' % i
                string_echo += self.contact_positions[i].echo()
                string_echo += ''
            else:
                string_echo += '{contact_positions%s":' % i
                string_echo += self.contact_positions[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"contact_normals":['
        contact_normals_length = len(self.contact_normals)
        for i in range(0, contact_normals_length):
            if i == (contact_normals_length - 1): 
                string_echo += '{contact_normals%s":' % i
                string_echo += self.contact_normals[i].echo()
                string_echo += ''
            else:
                string_echo += '{contact_normals%s":' % i
                string_echo += self.contact_normals[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"depths":['
        depths_length = len(self.depths)
        for i in range(0, depths_length):
            if i == (depths_length - 1): 
                string_echo += '%s' % self.depths[i]
            else:
                string_echo += '%s,' % self.depths[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/ContactState"

    def getMD5(self):
        return "48c0ffb054b8c444f870cecea1ee50d9"

    def getDef(self):
        return "string info\nstring collision1_name\nstring collision2_name\ngeometry_msgs/Wrench[] wrenches\ngeometry_msgs/Wrench total_wrench\ngeometry_msgs/Vector3[] contact_positions\ngeometry_msgs/Vector3[] contact_normals\nfloat64[] depths\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

