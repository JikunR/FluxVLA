import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg
import mros.std_msgs.msg

class ContactsState(mros.Message):
    __slots__ = ['header','states']
    _slot_types = ['std_msgs/Header','gazebo_msgs/ContactState[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ContactsState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.states is None:
                self.states = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.states = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            states_length = len(self.states)
            buff.write(struct.pack('<I', states_length))
            offset += 4
            for i in range(0, states_length):
                offset += self.states[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (states_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.states) != states_length:
                self.states = [mros.gazebo_msgs.msg.ContactState() for _ in range(states_length)]
            for i in range(0, states_length):
                offset += self.states[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, states_length):
            length += self.states[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"states":['
        states_length = len(self.states)
        for i in range(0, states_length):
            if i == (states_length - 1): 
                string_echo += '{states%s":' % i
                string_echo += self.states[i].echo()
                string_echo += ''
            else:
                string_echo += '{states%s":' % i
                string_echo += self.states[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/ContactsState"

    def getMD5(self):
        return "acbcb1601a8e525bf72509f18e6f668d"

    def getDef(self):
        return "std_msgs/Header header\ngazebo_msgs/ContactState[] states\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: gazebo_msgs/ContactState\nstring info\nstring collision1_name\nstring collision2_name\ngeometry_msgs/Wrench[] wrenches\ngeometry_msgs/Wrench total_wrench\ngeometry_msgs/Vector3[] contact_positions\ngeometry_msgs/Vector3[] contact_normals\nfloat64[] depths\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

