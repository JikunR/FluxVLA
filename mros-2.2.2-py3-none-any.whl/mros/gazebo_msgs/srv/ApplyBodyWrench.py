import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.gazebo_msgs.msg

class ApplyBodyWrenchRequest(mros.Message):
    __slots__ = ['__id__','body_name','reference_frame','reference_point','wrench','start_time','duration']
    _slot_types = ['uint32','string','string','geometry_msgs/Point','geometry_msgs/Wrench','Time','Duration']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ApplyBodyWrenchRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.body_name is None:
                self.body_name = ''
            if self.reference_frame is None:
                self.reference_frame = ''
            if self.reference_point is None:
                self.reference_point = mros.geometry_msgs.msg.Point()
            if self.wrench is None:
                self.wrench = mros.geometry_msgs.msg.Wrench()
            if self.start_time is None:
                self.start_time = mros.Time()
            if self.duration is None:
                self.duration = mros.Duration()
        else:
            self.__id__ = 0
            self.body_name = ''
            self.reference_frame = ''
            self.reference_point = mros.geometry_msgs.msg.Point()
            self.wrench = mros.geometry_msgs.msg.Wrench()
            self.start_time = mros.Time()
            self.duration = mros.Duration()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.body_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.reference_frame
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.reference_point.serialize(buff)
            offset += self.wrench.serialize(buff)
            buff.write(_struct_I.pack(self.start_time.sec))
            offset += 4
            buff.write(_struct_I.pack(self.start_time.nsec))
            offset += 4
            buff.write(_struct_I.pack(self.duration.sec))
            offset += 4
            buff.write(_struct_I.pack(self.duration.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_body_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.body_name = buff[offset:(offset + length_body_name)].decode('utf-8')
            else:
                self.body_name = buff[offset:(offset + length_body_name)]
            offset += length_body_name
            (length_reference_frame,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.reference_frame = buff[offset:(offset + length_reference_frame)].decode('utf-8')
            else:
                self.reference_frame = buff[offset:(offset + length_reference_frame)]
            offset += length_reference_frame
            offset += self.reference_point.deserialize(buff[offset:])
            offset += self.wrench.deserialize(buff[offset:])
            (self.start_time.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.start_time.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.duration.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.duration.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        body_name_x = self.body_name
        body_name_length = len(body_name_x)
        if python3 or type(body_name_x) == unicode:
            body_name_x = body_name_x.encode('utf-8')
            body_name_length = len(body_name_x)
        length += 4
        length += body_name_length
        reference_frame_x = self.reference_frame
        reference_frame_length = len(reference_frame_x)
        if python3 or type(reference_frame_x) == unicode:
            reference_frame_x = reference_frame_x.encode('utf-8')
            reference_frame_length = len(reference_frame_x)
        length += 4
        length += reference_frame_length
        length += self.reference_point.serializedLength()
        length += self.wrench.serializedLength()
        length += 4
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"body_name":"%s"' % self.body_name
        string_echo += ','
        string_echo += '"reference_frame":"%s"' % self.reference_frame
        string_echo += ','
        string_echo += '"reference_point":'
        string_echo += self.reference_point.echo()
        string_echo += ','
        string_echo += '"wrench":'
        string_echo += self.wrench.echo()
        string_echo += ','
        string_echo += '"start_time.sec":%s,' % self.start_time.sec
        string_echo += '"start_time.nsec":%s' % self.start_time.nsec
        string_echo += ','
        string_echo += '"duration.sec":%s,' % self.duration.sec
        string_echo += '"duration.nsec":%s' % self.duration.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/ApplyBodyWrench"

    def getMD5(self):
        return "585b9f9618aa0581b207e2f2d90866bc"
    def getDef(self):
        return "string body_name\nstring reference_frame\ngeometry_msgs/Point reference_point\ngeometry_msgs/Wrench wrench\ntime start_time\nduration duration\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Wrench\ngeometry_msgs/Vector3 force\ngeometry_msgs/Vector3 torque\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ApplyBodyWrenchResponse(mros.Message):
    __slots__ = ['__id__','success','status_message']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ApplyBodyWrenchResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/ApplyBodyWrench"

    def getMD5(self):
        return "585b9f9618aa0581b207e2f2d90866bc"
    def getDef(self):
        return "bool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ApplyBodyWrench(object):
    Request = ApplyBodyWrenchRequest
    Response = ApplyBodyWrenchResponse

    __slots__ = ['request','response']
    _slot_types = ['ApplyBodyWrenchRequest','ApplyBodyWrenchResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ApplyBodyWrench, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

