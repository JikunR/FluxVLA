import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.gazebo_msgs.msg

class GetLinkPropertiesRequest(mros.Message):
    __slots__ = ['__id__','link_name']
    _slot_types = ['uint32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetLinkPropertiesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.link_name is None:
                self.link_name = ''
        else:
            self.__id__ = 0
            self.link_name = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.link_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_link_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.link_name = buff[offset:(offset + length_link_name)].decode('utf-8')
            else:
                self.link_name = buff[offset:(offset + length_link_name)]
            offset += length_link_name
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        link_name_x = self.link_name
        link_name_length = len(link_name_x)
        if python3 or type(link_name_x) == unicode:
            link_name_x = link_name_x.encode('utf-8')
            link_name_length = len(link_name_x)
        length += 4
        length += link_name_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"link_name":"%s"' % self.link_name
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetLinkProperties"

    def getMD5(self):
        return "0e06a70386d0ee3fb880c02f23fcd821"
    def getDef(self):
        return "string link_name\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetLinkPropertiesResponse(mros.Message):
    __slots__ = ['__id__','com','gravity_mode','mass','ixx','ixy','ixz','iyy','iyz','izz','success','status_message']
    _slot_types = ['uint32','geometry_msgs/Pose','bool','float64','float64','float64','float64','float64','float64','float64','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetLinkPropertiesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.com is None:
                self.com = mros.geometry_msgs.msg.Pose()
            if self.gravity_mode is None:
                self.gravity_mode = False
            if self.mass is None:
                self.mass = 0.
            if self.ixx is None:
                self.ixx = 0.
            if self.ixy is None:
                self.ixy = 0.
            if self.ixz is None:
                self.ixz = 0.
            if self.iyy is None:
                self.iyy = 0.
            if self.iyz is None:
                self.iyz = 0.
            if self.izz is None:
                self.izz = 0.
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.com = mros.geometry_msgs.msg.Pose()
            self.gravity_mode = False
            self.mass = 0.
            self.ixx = 0.
            self.ixy = 0.
            self.ixz = 0.
            self.iyy = 0.
            self.iyz = 0.
            self.izz = 0.
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.com.serialize(buff)
            struct_gravity_mode = struct.Struct("<B")
            buff.write(struct_gravity_mode.pack(self.gravity_mode))
            offset += 1
            struct_mass = struct.Struct("<d")
            buff.write(struct_mass.pack(self.mass))
            offset += 8
            struct_ixx = struct.Struct("<d")
            buff.write(struct_ixx.pack(self.ixx))
            offset += 8
            struct_ixy = struct.Struct("<d")
            buff.write(struct_ixy.pack(self.ixy))
            offset += 8
            struct_ixz = struct.Struct("<d")
            buff.write(struct_ixz.pack(self.ixz))
            offset += 8
            struct_iyy = struct.Struct("<d")
            buff.write(struct_iyy.pack(self.iyy))
            offset += 8
            struct_iyz = struct.Struct("<d")
            buff.write(struct_iyz.pack(self.iyz))
            offset += 8
            struct_izz = struct.Struct("<d")
            buff.write(struct_izz.pack(self.izz))
            offset += 8
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.com.deserialize(buff[offset:])
            struct_gravity_mode = struct.Struct("<B")
            (self.gravity_mode,) = struct_gravity_mode.unpack(buff[offset:(offset + 1)])
            self.gravity_mode = bool(self.gravity_mode)
            offset += 1
            struct_mass = struct.Struct("<d")
            (self.mass,) = struct_mass.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_ixx = struct.Struct("<d")
            (self.ixx,) = struct_ixx.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_ixy = struct.Struct("<d")
            (self.ixy,) = struct_ixy.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_ixz = struct.Struct("<d")
            (self.ixz,) = struct_ixz.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_iyy = struct.Struct("<d")
            (self.iyy,) = struct_iyy.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_iyz = struct.Struct("<d")
            (self.iyz,) = struct_iyz.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_izz = struct.Struct("<d")
            (self.izz,) = struct_izz.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.com.serializedLength()
        length += 1
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"com":'
        string_echo += self.com.echo()
        string_echo += ','
        string_echo += '"gravity_mode":%s' % self.gravity_mode
        string_echo += ','
        string_echo += '"mass":%s' % self.mass
        string_echo += ','
        string_echo += '"ixx":%s' % self.ixx
        string_echo += ','
        string_echo += '"ixy":%s' % self.ixy
        string_echo += ','
        string_echo += '"ixz":%s' % self.ixz
        string_echo += ','
        string_echo += '"iyy":%s' % self.iyy
        string_echo += ','
        string_echo += '"iyz":%s' % self.iyz
        string_echo += ','
        string_echo += '"izz":%s' % self.izz
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetLinkProperties"

    def getMD5(self):
        return "0e06a70386d0ee3fb880c02f23fcd821"
    def getDef(self):
        return "geometry_msgs/Pose com\nbool gravity_mode\nfloat64 mass\nfloat64 ixx\nfloat64 ixy\nfloat64 ixz\nfloat64 iyy\nfloat64 iyz\nfloat64 izz\nbool success\nstring status_message\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetLinkProperties(object):
    Request = GetLinkPropertiesRequest
    Response = GetLinkPropertiesResponse

    __slots__ = ['request','response']
    _slot_types = ['GetLinkPropertiesRequest','GetLinkPropertiesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetLinkProperties, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

