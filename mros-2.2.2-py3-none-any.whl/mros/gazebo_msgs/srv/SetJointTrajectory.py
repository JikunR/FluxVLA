import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.trajectory_msgs.msg
import mros.gazebo_msgs.msg

class SetJointTrajectoryRequest(mros.Message):
    __slots__ = ['__id__','model_name','joint_trajectory','model_pose','set_model_pose','disable_physics_updates']
    _slot_types = ['uint32','string','trajectory_msgs/JointTrajectory','geometry_msgs/Pose','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetJointTrajectoryRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.model_name is None:
                self.model_name = ''
            if self.joint_trajectory is None:
                self.joint_trajectory = mros.trajectory_msgs.msg.JointTrajectory()
            if self.model_pose is None:
                self.model_pose = mros.geometry_msgs.msg.Pose()
            if self.set_model_pose is None:
                self.set_model_pose = False
            if self.disable_physics_updates is None:
                self.disable_physics_updates = False
        else:
            self.__id__ = 0
            self.model_name = ''
            self.joint_trajectory = mros.trajectory_msgs.msg.JointTrajectory()
            self.model_pose = mros.geometry_msgs.msg.Pose()
            self.set_model_pose = False
            self.disable_physics_updates = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.joint_trajectory.serialize(buff)
            offset += self.model_pose.serialize(buff)
            struct_set_model_pose = struct.Struct("<B")
            buff.write(struct_set_model_pose.pack(self.set_model_pose))
            offset += 1
            struct_disable_physics_updates = struct.Struct("<B")
            buff.write(struct_disable_physics_updates.pack(self.disable_physics_updates))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.model_name = buff[offset:(offset + length_model_name)].decode('utf-8')
            else:
                self.model_name = buff[offset:(offset + length_model_name)]
            offset += length_model_name
            offset += self.joint_trajectory.deserialize(buff[offset:])
            offset += self.model_pose.deserialize(buff[offset:])
            struct_set_model_pose = struct.Struct("<B")
            (self.set_model_pose,) = struct_set_model_pose.unpack(buff[offset:(offset + 1)])
            self.set_model_pose = bool(self.set_model_pose)
            offset += 1
            struct_disable_physics_updates = struct.Struct("<B")
            (self.disable_physics_updates,) = struct_disable_physics_updates.unpack(buff[offset:(offset + 1)])
            self.disable_physics_updates = bool(self.disable_physics_updates)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        model_name_x = self.model_name
        model_name_length = len(model_name_x)
        if python3 or type(model_name_x) == unicode:
            model_name_x = model_name_x.encode('utf-8')
            model_name_length = len(model_name_x)
        length += 4
        length += model_name_length
        length += self.joint_trajectory.serializedLength()
        length += self.model_pose.serializedLength()
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"model_name":"%s"' % self.model_name
        string_echo += ','
        string_echo += '"joint_trajectory":'
        string_echo += self.joint_trajectory.echo()
        string_echo += ','
        string_echo += '"model_pose":'
        string_echo += self.model_pose.echo()
        string_echo += ','
        string_echo += '"set_model_pose":%s' % self.set_model_pose
        string_echo += ','
        string_echo += '"disable_physics_updates":%s' % self.disable_physics_updates
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetJointTrajectory"

    def getMD5(self):
        return "88f5c10979e3f9649d5ae87a3b12aa65"
    def getDef(self):
        return "string model_name\ntrajectory_msgs/JointTrajectory joint_trajectory\ngeometry_msgs/Pose model_pose\nbool set_model_pose\nbool disable_physics_updates\n================================================================================\nMSG: trajectory_msgs/JointTrajectory\nstd_msgs/Header header\nstring[] joint_names\ntrajectory_msgs/JointTrajectoryPoint[] points\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: trajectory_msgs/JointTrajectoryPoint\nfloat64[] positions\nfloat64[] velocities\nfloat64[] accelerations\nfloat64[] effort\nduration time_from_start\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetJointTrajectoryResponse(mros.Message):
    __slots__ = ['__id__','success','status_message']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetJointTrajectoryResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetJointTrajectory"

    def getMD5(self):
        return "88f5c10979e3f9649d5ae87a3b12aa65"
    def getDef(self):
        return "bool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetJointTrajectory(object):
    Request = SetJointTrajectoryRequest
    Response = SetJointTrajectoryResponse

    __slots__ = ['request','response']
    _slot_types = ['SetJointTrajectoryRequest','SetJointTrajectoryResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetJointTrajectory, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

