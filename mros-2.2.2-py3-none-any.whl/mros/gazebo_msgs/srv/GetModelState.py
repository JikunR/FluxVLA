import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.gazebo_msgs.msg

class GetModelStateRequest(mros.Message):
    __slots__ = ['__id__','model_name','relative_entity_name']
    _slot_types = ['uint32','string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetModelStateRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.model_name is None:
                self.model_name = ''
            if self.relative_entity_name is None:
                self.relative_entity_name = ''
        else:
            self.__id__ = 0
            self.model_name = ''
            self.relative_entity_name = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.relative_entity_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.model_name = buff[offset:(offset + length_model_name)].decode('utf-8')
            else:
                self.model_name = buff[offset:(offset + length_model_name)]
            offset += length_model_name
            (length_relative_entity_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.relative_entity_name = buff[offset:(offset + length_relative_entity_name)].decode('utf-8')
            else:
                self.relative_entity_name = buff[offset:(offset + length_relative_entity_name)]
            offset += length_relative_entity_name
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        model_name_x = self.model_name
        model_name_length = len(model_name_x)
        if python3 or type(model_name_x) == unicode:
            model_name_x = model_name_x.encode('utf-8')
            model_name_length = len(model_name_x)
        length += 4
        length += model_name_length
        relative_entity_name_x = self.relative_entity_name
        relative_entity_name_length = len(relative_entity_name_x)
        if python3 or type(relative_entity_name_x) == unicode:
            relative_entity_name_x = relative_entity_name_x.encode('utf-8')
            relative_entity_name_length = len(relative_entity_name_x)
        length += 4
        length += relative_entity_name_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"model_name":"%s"' % self.model_name
        string_echo += ','
        string_echo += '"relative_entity_name":"%s"' % self.relative_entity_name
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetModelState"

    def getMD5(self):
        return "af0f702011820738976b120226dc9d96"
    def getDef(self):
        return "string model_name\nstring relative_entity_name\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetModelStateResponse(mros.Message):
    __slots__ = ['__id__','pose','twist','success','status_message']
    _slot_types = ['uint32','geometry_msgs/Pose','geometry_msgs/Twist','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetModelStateResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
            if self.twist is None:
                self.twist = mros.geometry_msgs.msg.Twist()
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.pose = mros.geometry_msgs.msg.Pose()
            self.twist = mros.geometry_msgs.msg.Twist()
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.pose.serialize(buff)
            offset += self.twist.serialize(buff)
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.pose.deserialize(buff[offset:])
            offset += self.twist.deserialize(buff[offset:])
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.pose.serializedLength()
        length += self.twist.serializedLength()
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ','
        string_echo += '"twist":'
        string_echo += self.twist.echo()
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetModelState"

    def getMD5(self):
        return "af0f702011820738976b120226dc9d96"
    def getDef(self):
        return "geometry_msgs/Pose pose\ngeometry_msgs/Twist twist\nbool success\nstring status_message\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetModelState(object):
    Request = GetModelStateRequest
    Response = GetModelStateResponse

    __slots__ = ['request','response']
    _slot_types = ['GetModelStateRequest','GetModelStateResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetModelState, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

