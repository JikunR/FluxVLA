import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg

class SetModelConfigurationRequest(mros.Message):
    __slots__ = ['__id__','model_name','urdf_param_name','joint_names','joint_positions']
    _slot_types = ['uint32','string','string','string[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetModelConfigurationRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.model_name is None:
                self.model_name = ''
            if self.urdf_param_name is None:
                self.urdf_param_name = ''
            if self.joint_names is None:
                self.joint_names = []
            if self.joint_positions is None:
                self.joint_positions = []
        else:
            self.__id__ = 0
            self.model_name = ''
            self.urdf_param_name = ''
            self.joint_names = []
            self.joint_positions = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.urdf_param_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            joint_names_length = len(self.joint_names)
            buff.write(struct.pack('<I', joint_names_length))
            offset += 4
            for i in range(0, joint_names_length):
                _x = self.joint_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            joint_positions_length = len(self.joint_positions)
            buff.write(struct.pack('<I', joint_positions_length))
            buff.write(struct.pack(f'<{joint_positions_length}d', *self.joint_positions))
            offset += 4 + joint_positions_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.model_name = buff[offset:(offset + length_model_name)].decode('utf-8')
            else:
                self.model_name = buff[offset:(offset + length_model_name)]
            offset += length_model_name
            (length_urdf_param_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.urdf_param_name = buff[offset:(offset + length_urdf_param_name)].decode('utf-8')
            else:
                self.urdf_param_name = buff[offset:(offset + length_urdf_param_name)]
            offset += length_urdf_param_name
            (joint_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.joint_names) != joint_names_length:
                self.joint_names = ['' for _ in range(joint_names_length)]
            for i in range(0, joint_names_length):
                (length_joint_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)].decode('utf-8')
                else:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)]
                offset += length_joint_namesi
            (joint_positions_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.joint_positions = np.frombuffer(buff[offset:offset + joint_positions_length * 8], dtype=np.float64)
            offset += joint_positions_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        model_name_x = self.model_name
        model_name_length = len(model_name_x)
        if python3 or type(model_name_x) == unicode:
            model_name_x = model_name_x.encode('utf-8')
            model_name_length = len(model_name_x)
        length += 4
        length += model_name_length
        urdf_param_name_x = self.urdf_param_name
        urdf_param_name_length = len(urdf_param_name_x)
        if python3 or type(urdf_param_name_x) == unicode:
            urdf_param_name_x = urdf_param_name_x.encode('utf-8')
            urdf_param_name_length = len(urdf_param_name_x)
        length += 4
        length += urdf_param_name_length
        length += 4
        for i in range(0, joint_names_length):
            joint_namesi_x = self.joint_names[i]
            joint_namesi_length = len(joint_namesi_x)
            if python3 or type(joint_namesi_x) == unicode:
                joint_namesi_x = joint_namesi_x.encode('utf-8')
                joint_namesi_length = len(joint_namesi_x)
            length += 4
            length += joint_namesi_length
        length += 4
        length += len(self.joint_positions) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"model_name":"%s"' % self.model_name
        string_echo += ','
        string_echo += '"urdf_param_name":"%s"' % self.urdf_param_name
        string_echo += ','
        string_echo += '"joint_names":['
        joint_names_length = len(self.joint_names)
        for i in range(0, joint_names_length):
            if i == (joint_names_length - 1): 
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ''
            else:
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"joint_positions":['
        joint_positions_length = len(self.joint_positions)
        for i in range(0, joint_positions_length):
            if i == (joint_positions_length - 1): 
                string_echo += '%s' % self.joint_positions[i]
            else:
                string_echo += '%s,' % self.joint_positions[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetModelConfiguration"

    def getMD5(self):
        return "10e3139d3b669c40afc057d38956fff7"
    def getDef(self):
        return "string model_name\nstring urdf_param_name\nstring[] joint_names\nfloat64[] joint_positions\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetModelConfigurationResponse(mros.Message):
    __slots__ = ['__id__','success','status_message']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetModelConfigurationResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetModelConfiguration"

    def getMD5(self):
        return "10e3139d3b669c40afc057d38956fff7"
    def getDef(self):
        return "bool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetModelConfiguration(object):
    Request = SetModelConfigurationRequest
    Response = SetModelConfigurationResponse

    __slots__ = ['request','response']
    _slot_types = ['SetModelConfigurationRequest','SetModelConfigurationResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetModelConfiguration, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

