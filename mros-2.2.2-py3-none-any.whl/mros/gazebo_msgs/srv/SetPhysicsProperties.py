import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.gazebo_msgs.msg

class SetPhysicsPropertiesRequest(mros.Message):
    __slots__ = ['__id__','time_step','max_update_rate','gravity','ode_config']
    _slot_types = ['uint32','float64','float64','geometry_msgs/Vector3','gazebo_msgs/ODEPhysics']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetPhysicsPropertiesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.time_step is None:
                self.time_step = 0.
            if self.max_update_rate is None:
                self.max_update_rate = 0.
            if self.gravity is None:
                self.gravity = mros.geometry_msgs.msg.Vector3()
            if self.ode_config is None:
                self.ode_config = mros.gazebo_msgs.msg.ODEPhysics()
        else:
            self.__id__ = 0
            self.time_step = 0.
            self.max_update_rate = 0.
            self.gravity = mros.geometry_msgs.msg.Vector3()
            self.ode_config = mros.gazebo_msgs.msg.ODEPhysics()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_time_step = struct.Struct("<d")
            buff.write(struct_time_step.pack(self.time_step))
            offset += 8
            struct_max_update_rate = struct.Struct("<d")
            buff.write(struct_max_update_rate.pack(self.max_update_rate))
            offset += 8
            offset += self.gravity.serialize(buff)
            offset += self.ode_config.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_time_step = struct.Struct("<d")
            (self.time_step,) = struct_time_step.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_max_update_rate = struct.Struct("<d")
            (self.max_update_rate,) = struct_max_update_rate.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.gravity.deserialize(buff[offset:])
            offset += self.ode_config.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 8
        length += 8
        length += self.gravity.serializedLength()
        length += self.ode_config.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"time_step":%s' % self.time_step
        string_echo += ','
        string_echo += '"max_update_rate":%s' % self.max_update_rate
        string_echo += ','
        string_echo += '"gravity":'
        string_echo += self.gravity.echo()
        string_echo += ','
        string_echo += '"ode_config":'
        string_echo += self.ode_config.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetPhysicsProperties"

    def getMD5(self):
        return "97e2057080558ce4730434b5fae75c91"
    def getDef(self):
        return "float64 time_step\nfloat64 max_update_rate\ngeometry_msgs/Vector3 gravity\ngazebo_msgs/ODEPhysics ode_config\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: gazebo_msgs/ODEPhysics\nbool auto_disable_bodies\nuint32 sor_pgs_precon_iters\nuint32 sor_pgs_iters\nfloat64 sor_pgs_w\nfloat64 sor_pgs_rms_error_tol\nfloat64 contact_surface_layer\nfloat64 contact_max_correcting_vel\nfloat64 cfm\nfloat64 erp\nuint32 max_contacts\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetPhysicsPropertiesResponse(mros.Message):
    __slots__ = ['__id__','success','status_message']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetPhysicsPropertiesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetPhysicsProperties"

    def getMD5(self):
        return "97e2057080558ce4730434b5fae75c91"
    def getDef(self):
        return "bool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetPhysicsProperties(object):
    Request = SetPhysicsPropertiesRequest
    Response = SetPhysicsPropertiesResponse

    __slots__ = ['request','response']
    _slot_types = ['SetPhysicsPropertiesRequest','SetPhysicsPropertiesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetPhysicsProperties, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

