import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg

class DeleteModelRequest(mros.Message):
    __slots__ = ['__id__','model_name']
    _slot_types = ['uint32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DeleteModelRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.model_name is None:
                self.model_name = ''
        else:
            self.__id__ = 0
            self.model_name = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.model_name = buff[offset:(offset + length_model_name)].decode('utf-8')
            else:
                self.model_name = buff[offset:(offset + length_model_name)]
            offset += length_model_name
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        model_name_x = self.model_name
        model_name_length = len(model_name_x)
        if python3 or type(model_name_x) == unicode:
            model_name_x = model_name_x.encode('utf-8')
            model_name_length = len(model_name_x)
        length += 4
        length += model_name_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"model_name":"%s"' % self.model_name
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/DeleteModel"

    def getMD5(self):
        return "9ce56b4e9e54616de25d796dc972a262"
    def getDef(self):
        return "string model_name\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class DeleteModelResponse(mros.Message):
    __slots__ = ['__id__','success','status_message']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DeleteModelResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/DeleteModel"

    def getMD5(self):
        return "9ce56b4e9e54616de25d796dc972a262"
    def getDef(self):
        return "bool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class DeleteModel(object):
    Request = DeleteModelRequest
    Response = DeleteModelResponse

    __slots__ = ['request','response']
    _slot_types = ['DeleteModelRequest','DeleteModelResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DeleteModel, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

