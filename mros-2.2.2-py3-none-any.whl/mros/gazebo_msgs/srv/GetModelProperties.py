import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg

class GetModelPropertiesRequest(mros.Message):
    __slots__ = ['__id__','model_name']
    _slot_types = ['uint32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetModelPropertiesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.model_name is None:
                self.model_name = ''
        else:
            self.__id__ = 0
            self.model_name = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.model_name = buff[offset:(offset + length_model_name)].decode('utf-8')
            else:
                self.model_name = buff[offset:(offset + length_model_name)]
            offset += length_model_name
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        model_name_x = self.model_name
        model_name_length = len(model_name_x)
        if python3 or type(model_name_x) == unicode:
            model_name_x = model_name_x.encode('utf-8')
            model_name_length = len(model_name_x)
        length += 4
        length += model_name_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"model_name":"%s"' % self.model_name
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetModelProperties"

    def getMD5(self):
        return "5717f7bd34ed990fa80e28b3015027a3"
    def getDef(self):
        return "string model_name\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetModelPropertiesResponse(mros.Message):
    __slots__ = ['__id__','parent_model_name','canonical_body_name','body_names','geom_names','joint_names','child_model_names','is_static','success','status_message']
    _slot_types = ['uint32','string','string','string[]','string[]','string[]','string[]','bool','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetModelPropertiesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.parent_model_name is None:
                self.parent_model_name = ''
            if self.canonical_body_name is None:
                self.canonical_body_name = ''
            if self.body_names is None:
                self.body_names = []
            if self.geom_names is None:
                self.geom_names = []
            if self.joint_names is None:
                self.joint_names = []
            if self.child_model_names is None:
                self.child_model_names = []
            if self.is_static is None:
                self.is_static = False
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.parent_model_name = ''
            self.canonical_body_name = ''
            self.body_names = []
            self.geom_names = []
            self.joint_names = []
            self.child_model_names = []
            self.is_static = False
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.parent_model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.canonical_body_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            body_names_length = len(self.body_names)
            buff.write(struct.pack('<I', body_names_length))
            offset += 4
            for i in range(0, body_names_length):
                _x = self.body_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            geom_names_length = len(self.geom_names)
            buff.write(struct.pack('<I', geom_names_length))
            offset += 4
            for i in range(0, geom_names_length):
                _x = self.geom_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            joint_names_length = len(self.joint_names)
            buff.write(struct.pack('<I', joint_names_length))
            offset += 4
            for i in range(0, joint_names_length):
                _x = self.joint_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            child_model_names_length = len(self.child_model_names)
            buff.write(struct.pack('<I', child_model_names_length))
            offset += 4
            for i in range(0, child_model_names_length):
                _x = self.child_model_names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            struct_is_static = struct.Struct("<B")
            buff.write(struct_is_static.pack(self.is_static))
            offset += 1
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_parent_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.parent_model_name = buff[offset:(offset + length_parent_model_name)].decode('utf-8')
            else:
                self.parent_model_name = buff[offset:(offset + length_parent_model_name)]
            offset += length_parent_model_name
            (length_canonical_body_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.canonical_body_name = buff[offset:(offset + length_canonical_body_name)].decode('utf-8')
            else:
                self.canonical_body_name = buff[offset:(offset + length_canonical_body_name)]
            offset += length_canonical_body_name
            (body_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.body_names) != body_names_length:
                self.body_names = ['' for _ in range(body_names_length)]
            for i in range(0, body_names_length):
                (length_body_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.body_names[i] = buff[offset:(offset + length_body_namesi)].decode('utf-8')
                else:
                    self.body_names[i] = buff[offset:(offset + length_body_namesi)]
                offset += length_body_namesi
            (geom_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.geom_names) != geom_names_length:
                self.geom_names = ['' for _ in range(geom_names_length)]
            for i in range(0, geom_names_length):
                (length_geom_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.geom_names[i] = buff[offset:(offset + length_geom_namesi)].decode('utf-8')
                else:
                    self.geom_names[i] = buff[offset:(offset + length_geom_namesi)]
                offset += length_geom_namesi
            (joint_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.joint_names) != joint_names_length:
                self.joint_names = ['' for _ in range(joint_names_length)]
            for i in range(0, joint_names_length):
                (length_joint_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)].decode('utf-8')
                else:
                    self.joint_names[i] = buff[offset:(offset + length_joint_namesi)]
                offset += length_joint_namesi
            (child_model_names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.child_model_names) != child_model_names_length:
                self.child_model_names = ['' for _ in range(child_model_names_length)]
            for i in range(0, child_model_names_length):
                (length_child_model_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.child_model_names[i] = buff[offset:(offset + length_child_model_namesi)].decode('utf-8')
                else:
                    self.child_model_names[i] = buff[offset:(offset + length_child_model_namesi)]
                offset += length_child_model_namesi
            struct_is_static = struct.Struct("<B")
            (self.is_static,) = struct_is_static.unpack(buff[offset:(offset + 1)])
            self.is_static = bool(self.is_static)
            offset += 1
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        parent_model_name_x = self.parent_model_name
        parent_model_name_length = len(parent_model_name_x)
        if python3 or type(parent_model_name_x) == unicode:
            parent_model_name_x = parent_model_name_x.encode('utf-8')
            parent_model_name_length = len(parent_model_name_x)
        length += 4
        length += parent_model_name_length
        canonical_body_name_x = self.canonical_body_name
        canonical_body_name_length = len(canonical_body_name_x)
        if python3 or type(canonical_body_name_x) == unicode:
            canonical_body_name_x = canonical_body_name_x.encode('utf-8')
            canonical_body_name_length = len(canonical_body_name_x)
        length += 4
        length += canonical_body_name_length
        length += 4
        for i in range(0, body_names_length):
            body_namesi_x = self.body_names[i]
            body_namesi_length = len(body_namesi_x)
            if python3 or type(body_namesi_x) == unicode:
                body_namesi_x = body_namesi_x.encode('utf-8')
                body_namesi_length = len(body_namesi_x)
            length += 4
            length += body_namesi_length
        length += 4
        for i in range(0, geom_names_length):
            geom_namesi_x = self.geom_names[i]
            geom_namesi_length = len(geom_namesi_x)
            if python3 or type(geom_namesi_x) == unicode:
                geom_namesi_x = geom_namesi_x.encode('utf-8')
                geom_namesi_length = len(geom_namesi_x)
            length += 4
            length += geom_namesi_length
        length += 4
        for i in range(0, joint_names_length):
            joint_namesi_x = self.joint_names[i]
            joint_namesi_length = len(joint_namesi_x)
            if python3 or type(joint_namesi_x) == unicode:
                joint_namesi_x = joint_namesi_x.encode('utf-8')
                joint_namesi_length = len(joint_namesi_x)
            length += 4
            length += joint_namesi_length
        length += 4
        for i in range(0, child_model_names_length):
            child_model_namesi_x = self.child_model_names[i]
            child_model_namesi_length = len(child_model_namesi_x)
            if python3 or type(child_model_namesi_x) == unicode:
                child_model_namesi_x = child_model_namesi_x.encode('utf-8')
                child_model_namesi_length = len(child_model_namesi_x)
            length += 4
            length += child_model_namesi_length
        length += 1
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"parent_model_name":"%s"' % self.parent_model_name
        string_echo += ','
        string_echo += '"canonical_body_name":"%s"' % self.canonical_body_name
        string_echo += ','
        string_echo += '"body_names":['
        body_names_length = len(self.body_names)
        for i in range(0, body_names_length):
            if i == (body_names_length - 1): 
                string_echo += '"body_names[i]":"%s"' % self.body_names[i]
                string_echo += ''
            else:
                string_echo += '"body_names[i]":"%s"' % self.body_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"geom_names":['
        geom_names_length = len(self.geom_names)
        for i in range(0, geom_names_length):
            if i == (geom_names_length - 1): 
                string_echo += '"geom_names[i]":"%s"' % self.geom_names[i]
                string_echo += ''
            else:
                string_echo += '"geom_names[i]":"%s"' % self.geom_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"joint_names":['
        joint_names_length = len(self.joint_names)
        for i in range(0, joint_names_length):
            if i == (joint_names_length - 1): 
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ''
            else:
                string_echo += '"joint_names[i]":"%s"' % self.joint_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"child_model_names":['
        child_model_names_length = len(self.child_model_names)
        for i in range(0, child_model_names_length):
            if i == (child_model_names_length - 1): 
                string_echo += '"child_model_names[i]":"%s"' % self.child_model_names[i]
                string_echo += ''
            else:
                string_echo += '"child_model_names[i]":"%s"' % self.child_model_names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"is_static":%s' % self.is_static
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetModelProperties"

    def getMD5(self):
        return "5717f7bd34ed990fa80e28b3015027a3"
    def getDef(self):
        return "string parent_model_name\nstring canonical_body_name\nstring[] body_names\nstring[] geom_names\nstring[] joint_names\nstring[] child_model_names\nbool is_static\nbool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetModelProperties(object):
    Request = GetModelPropertiesRequest
    Response = GetModelPropertiesResponse

    __slots__ = ['request','response']
    _slot_types = ['GetModelPropertiesRequest','GetModelPropertiesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetModelProperties, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

