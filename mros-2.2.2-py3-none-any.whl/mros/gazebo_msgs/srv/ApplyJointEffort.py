import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg

class ApplyJointEffortRequest(mros.Message):
    __slots__ = ['__id__','joint_name','effort','start_time','duration']
    _slot_types = ['uint32','string','float64','Time','Duration']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ApplyJointEffortRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.joint_name is None:
                self.joint_name = ''
            if self.effort is None:
                self.effort = 0.
            if self.start_time is None:
                self.start_time = mros.Time()
            if self.duration is None:
                self.duration = mros.Duration()
        else:
            self.__id__ = 0
            self.joint_name = ''
            self.effort = 0.
            self.start_time = mros.Time()
            self.duration = mros.Duration()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.joint_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_effort = struct.Struct("<d")
            buff.write(struct_effort.pack(self.effort))
            offset += 8
            buff.write(_struct_I.pack(self.start_time.sec))
            offset += 4
            buff.write(_struct_I.pack(self.start_time.nsec))
            offset += 4
            buff.write(_struct_I.pack(self.duration.sec))
            offset += 4
            buff.write(_struct_I.pack(self.duration.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_joint_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.joint_name = buff[offset:(offset + length_joint_name)].decode('utf-8')
            else:
                self.joint_name = buff[offset:(offset + length_joint_name)]
            offset += length_joint_name
            struct_effort = struct.Struct("<d")
            (self.effort,) = struct_effort.unpack(buff[offset:(offset + 8)])
            offset += 8
            (self.start_time.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.start_time.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.duration.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.duration.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        joint_name_x = self.joint_name
        joint_name_length = len(joint_name_x)
        if python3 or type(joint_name_x) == unicode:
            joint_name_x = joint_name_x.encode('utf-8')
            joint_name_length = len(joint_name_x)
        length += 4
        length += joint_name_length
        length += 8
        length += 4
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"joint_name":"%s"' % self.joint_name
        string_echo += ','
        string_echo += '"effort":%s' % self.effort
        string_echo += ','
        string_echo += '"start_time.sec":%s,' % self.start_time.sec
        string_echo += '"start_time.nsec":%s' % self.start_time.nsec
        string_echo += ','
        string_echo += '"duration.sec":%s,' % self.duration.sec
        string_echo += '"duration.nsec":%s' % self.duration.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/ApplyJointEffort"

    def getMD5(self):
        return "c0039811b8cc919490b3cff748cdf46b"
    def getDef(self):
        return "string joint_name\nfloat64 effort\ntime start_time\nduration duration\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ApplyJointEffortResponse(mros.Message):
    __slots__ = ['__id__','success','status_message']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ApplyJointEffortResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/ApplyJointEffort"

    def getMD5(self):
        return "c0039811b8cc919490b3cff748cdf46b"
    def getDef(self):
        return "bool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ApplyJointEffort(object):
    Request = ApplyJointEffortRequest
    Response = ApplyJointEffortResponse

    __slots__ = ['request','response']
    _slot_types = ['ApplyJointEffortRequest','ApplyJointEffortResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ApplyJointEffort, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

