import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg

class SetLinkStateRequest(mros.Message):
    __slots__ = ['__id__','link_state']
    _slot_types = ['uint32','gazebo_msgs/LinkState']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetLinkStateRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.link_state is None:
                self.link_state = mros.gazebo_msgs.msg.LinkState()
        else:
            self.__id__ = 0
            self.link_state = mros.gazebo_msgs.msg.LinkState()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.link_state.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.link_state.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.link_state.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"link_state":'
        string_echo += self.link_state.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetLinkState"

    def getMD5(self):
        return "8a5146eb66ae4d26b0860b08f3f271be"
    def getDef(self):
        return "gazebo_msgs/LinkState link_state\n================================================================================\nMSG: gazebo_msgs/LinkState\nstring link_name\ngeometry_msgs/Pose pose\ngeometry_msgs/Twist twist\nstring reference_frame\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetLinkStateResponse(mros.Message):
    __slots__ = ['__id__','success','status_message']
    _slot_types = ['uint32','bool','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetLinkStateResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/SetLinkState"

    def getMD5(self):
        return "8a5146eb66ae4d26b0860b08f3f271be"
    def getDef(self):
        return "bool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetLinkState(object):
    Request = SetLinkStateRequest
    Response = SetLinkStateResponse

    __slots__ = ['request','response']
    _slot_types = ['SetLinkStateRequest','SetLinkStateResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetLinkState, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

