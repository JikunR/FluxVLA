import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.gazebo_msgs.msg

class GetJointPropertiesRequest(mros.Message):
    __slots__ = ['__id__','joint_name']
    _slot_types = ['uint32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetJointPropertiesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.joint_name is None:
                self.joint_name = ''
        else:
            self.__id__ = 0
            self.joint_name = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.joint_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_joint_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.joint_name = buff[offset:(offset + length_joint_name)].decode('utf-8')
            else:
                self.joint_name = buff[offset:(offset + length_joint_name)]
            offset += length_joint_name
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        joint_name_x = self.joint_name
        joint_name_length = len(joint_name_x)
        if python3 or type(joint_name_x) == unicode:
            joint_name_x = joint_name_x.encode('utf-8')
            joint_name_length = len(joint_name_x)
        length += 4
        length += joint_name_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"joint_name":"%s"' % self.joint_name
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetJointProperties"

    def getMD5(self):
        return "7b30be900f50aa21efec4a0ec92d91c9"
    def getDef(self):
        return "string joint_name\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetJointPropertiesResponse(mros.Message):
    __slots__ = ['__id__','type','damping','position','rate','success','status_message']
    _slot_types = ['uint32','uint8','float64[]','float64[]','float64[]','bool','string']

    REVOLUTE =  0                
    CONTINUOUS =  1                
    PRISMATIC =  2                
    FIXED =  3                
    BALL =  4                
    UNIVERSAL =  5                

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetJointPropertiesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.type is None:
                self.type = 0
            if self.damping is None:
                self.damping = []
            if self.position is None:
                self.position = []
            if self.rate is None:
                self.rate = []
            if self.success is None:
                self.success = False
            if self.status_message is None:
                self.status_message = ''
        else:
            self.__id__ = 0
            self.type = 0
            self.damping = []
            self.position = []
            self.rate = []
            self.success = False
            self.status_message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_type = struct.Struct("<B")
            buff.write(struct_type.pack(self.type))
            offset += 1
            damping_length = len(self.damping)
            buff.write(struct.pack('<I', damping_length))
            buff.write(struct.pack(f'<{damping_length}d', *self.damping))
            offset += 4 + damping_length * 8
            position_length = len(self.position)
            buff.write(struct.pack('<I', position_length))
            buff.write(struct.pack(f'<{position_length}d', *self.position))
            offset += 4 + position_length * 8
            rate_length = len(self.rate)
            buff.write(struct.pack('<I', rate_length))
            buff.write(struct.pack(f'<{rate_length}d', *self.rate))
            offset += 4 + rate_length * 8
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
            _x = self.status_message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_type = struct.Struct("<B")
            (self.type,) = struct_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            (damping_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.damping = np.frombuffer(buff[offset:offset + damping_length * 8], dtype=np.float64)
            offset += damping_length * 8
            (position_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.position = np.frombuffer(buff[offset:offset + position_length * 8], dtype=np.float64)
            offset += position_length * 8
            (rate_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.rate = np.frombuffer(buff[offset:offset + rate_length * 8], dtype=np.float64)
            offset += rate_length * 8
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
            (length_status_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.status_message = buff[offset:(offset + length_status_message)].decode('utf-8')
            else:
                self.status_message = buff[offset:(offset + length_status_message)]
            offset += length_status_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        length += 4
        length += len(self.damping) * 8
        length += 4
        length += len(self.position) * 8
        length += 4
        length += len(self.rate) * 8
        length += 1
        status_message_x = self.status_message
        status_message_length = len(status_message_x)
        if python3 or type(status_message_x) == unicode:
            status_message_x = status_message_x.encode('utf-8')
            status_message_length = len(status_message_x)
        length += 4
        length += status_message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"type":%s' % self.type
        string_echo += ','
        string_echo += '"damping":['
        damping_length = len(self.damping)
        for i in range(0, damping_length):
            if i == (damping_length - 1): 
                string_echo += '%s' % self.damping[i]
            else:
                string_echo += '%s,' % self.damping[i]
        string_echo += '],'
        string_echo += '"position":['
        position_length = len(self.position)
        for i in range(0, position_length):
            if i == (position_length - 1): 
                string_echo += '%s' % self.position[i]
            else:
                string_echo += '%s,' % self.position[i]
        string_echo += '],'
        string_echo += '"rate":['
        rate_length = len(self.rate)
        for i in range(0, rate_length):
            if i == (rate_length - 1): 
                string_echo += '%s' % self.rate[i]
            else:
                string_echo += '%s,' % self.rate[i]
        string_echo += '],'
        string_echo += '"success":%s' % self.success
        string_echo += ','
        string_echo += '"status_message":"%s"' % self.status_message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "gazebo_msgs/GetJointProperties"

    def getMD5(self):
        return "7b30be900f50aa21efec4a0ec92d91c9"
    def getDef(self):
        return "uint8 type\nuint8 REVOLUTE    = 0\nuint8 CONTINUOUS  = 1\nuint8 PRISMATIC   = 2\nuint8 FIXED       = 3\nuint8 BALL        = 4\nuint8 UNIVERSAL   = 5\nfloat64[] damping\nfloat64[] position\nfloat64[] rate\nbool success\nstring status_message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetJointProperties(object):
    Request = GetJointPropertiesRequest
    Response = GetJointPropertiesResponse

    __slots__ = ['request','response']
    _slot_types = ['GetJointPropertiesRequest','GetJointPropertiesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetJointProperties, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

