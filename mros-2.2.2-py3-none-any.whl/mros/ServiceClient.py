import sys
import copy
import threading
import random
import mros


class ServiceClient(mros.Subscriber):
    __slots__ = ['topic_name', 'data_req_class', 'data_resp_class', 'resp_msg_orig', 'resp_message_type', 'resp_md5sum', 'resp_msg_def',
                 'req_pub', 'resq_sub', 'req_id', 'call_mutex', 'call_cond', 'call_req', 'call_resp', 'call_wait']

    def __init__(self, topic_name: str, data_req_class, data_resp_class):
        self.topic_name = topic_name
        self.data_req_class = data_req_class
        self.data_resp_class = data_resp_class

        self.resp_msg_orig = self.data_resp_class()
        self.resp_message_type = self.resp_msg_orig.getType()
        self.resp_md5sum = self.resp_msg_orig.getMD5()
        self.resp_msg_def = self.resp_msg_orig.getDef()

        self.resq_sub = mros.subscribe(self.topic_name + "|srv", self.data_resp_class, self.callback)
        self.req_pub = mros.advertise(self.topic_name + "|svc", self.data_req_class)

        self.req_id = -1
        self.call_mutex = threading.Lock()
        self.call_cond = threading.Condition()
        self.call_req = None
        self.call_resp = None
        self.call_wait = True

    def call(self, request, response, duration=3):
        self.call_mutex.acquire()
        self.call_cond.acquire()
        if not mros.ok():
            self.call_req = self.call_resp = None
            self.call_cond.release()
            self.call_mutex.release()
            return False

        self.call_req = request
        self.call_resp = response
        self.call_wait = True

        self.call_req.setID(random.randint(100000000, 999999999))

        if self.req_pub.publish(self.call_req) <= 0:
            self.call_req = self.call_resp = None
            self.call_cond.release()
            self.call_mutex.release()
            return False
        self.call_cond.wait(duration)
        self.call_req = self.call_resp = None
        result = not self.call_wait
        self.call_cond.release()
        self.call_mutex.release()
        return result

    def callback(self, resp_msg):
        self.call_cond.acquire()
        if self.call_req != None and self.call_resp != None:
            resp_id = resp_msg.getID()
            req_id = self.call_req.getID()
            if resp_id == req_id:
                for slot in self.call_resp.__slots__:
                  setattr(self.call_resp, slot, getattr(resp_msg, slot))
                self.call_wait = False
                self.call_cond.notify_all()
        self.call_cond.release()

    def getMsgType(self):
        return self.resp_message_type

    def getMsgMD5(self):
        return self.resp_md5sum

    def negotiated(self):
        return self.req_pub.getNumSubscribers() > 0
