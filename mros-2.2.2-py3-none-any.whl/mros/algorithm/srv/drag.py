import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.algorithm.msg

class dragRequest(mros.Message):
    __slots__ = ['__id__','ifOpenDragTeach']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(dragRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.ifOpenDragTeach is None:
                self.ifOpenDragTeach = False
        else:
            self.__id__ = 0
            self.ifOpenDragTeach = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_ifOpenDragTeach = struct.Struct("<B")
            buff.write(struct_ifOpenDragTeach.pack(self.ifOpenDragTeach))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_ifOpenDragTeach = struct.Struct("<B")
            (self.ifOpenDragTeach,) = struct_ifOpenDragTeach.unpack(buff[offset:(offset + 1)])
            self.ifOpenDragTeach = bool(self.ifOpenDragTeach)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"ifOpenDragTeach":%s' % self.ifOpenDragTeach
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/drag"

    def getMD5(self):
        return "cc73ad7559c78bc567198caa8f23c8bb"
    def getDef(self):
        return "bool ifOpenDragTeach\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class dragResponse(mros.Message):
    __slots__ = ['__id__','executionStatus']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(dragResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.executionStatus is None:
                self.executionStatus = False
        else:
            self.__id__ = 0
            self.executionStatus = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_executionStatus = struct.Struct("<B")
            buff.write(struct_executionStatus.pack(self.executionStatus))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_executionStatus = struct.Struct("<B")
            (self.executionStatus,) = struct_executionStatus.unpack(buff[offset:(offset + 1)])
            self.executionStatus = bool(self.executionStatus)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"executionStatus":%s' % self.executionStatus
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/drag"

    def getMD5(self):
        return "cc73ad7559c78bc567198caa8f23c8bb"
    def getDef(self):
        return "bool executionStatus\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class drag(object):
    Request = dragRequest
    Response = dragResponse

    __slots__ = ['request','response']
    _slot_types = ['dragRequest','dragResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(drag, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

