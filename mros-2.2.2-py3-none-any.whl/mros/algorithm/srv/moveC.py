import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.algorithm.msg

class moveCRequest(mros.Message):
    __slots__ = ['__id__','p1','p2','vLimt']
    _slot_types = ['uint32','float32[6]','float32[6]','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveCRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.p1 is None:
                self.p1 = [0. for x in range(0, 6)]
            if self.p2 is None:
                self.p2 = [0. for x in range(0, 6)]
            if self.vLimt is None:
                self.vLimt = 0.
        else:
            self.__id__ = 0
            self.p1 = [0. for x in range(0, 6)]
            self.p2 = [0. for x in range(0, 6)]
            self.vLimt = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(struct.pack(f'<{6}f', *self.p1))
            offset += 6 * 4
            buff.write(struct.pack(f'<{6}f', *self.p2))
            offset += 6 * 4
            struct_vLimt = struct.Struct("<f")
            buff.write(struct_vLimt.pack(self.vLimt))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.p1 = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.p2 = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            struct_vLimt = struct.Struct("<f")
            (self.vLimt,) = struct_vLimt.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 6 * 4
        length += 6 * 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"p1":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.p1[i]
            else:
                string_echo += '%s,' % self.p1[i]
        string_echo += '],'
        string_echo += '"p2":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.p2[i]
            else:
                string_echo += '%s,' % self.p2[i]
        string_echo += '],'
        string_echo += '"vLimt":%s' % self.vLimt
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveC"

    def getMD5(self):
        return "14c1d983ec8ba153827de1b2a58476bf"
    def getDef(self):
        return "float32[6] p1\nfloat32[6] p2\nfloat32 vLimt\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class moveCResponse(mros.Message):
    __slots__ = ['__id__','executionStatus']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveCResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.executionStatus is None:
                self.executionStatus = 0
        else:
            self.__id__ = 0
            self.executionStatus = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_executionStatus = struct.Struct("<i")
            buff.write(struct_executionStatus.pack(self.executionStatus))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_executionStatus = struct.Struct("<i")
            (self.executionStatus,) = struct_executionStatus.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"executionStatus":%s' % self.executionStatus
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveC"

    def getMD5(self):
        return "14c1d983ec8ba153827de1b2a58476bf"
    def getDef(self):
        return "int32 executionStatus\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class moveC(object):
    Request = moveCRequest
    Response = moveCResponse

    __slots__ = ['request','response']
    _slot_types = ['moveCRequest','moveCResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveC, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

