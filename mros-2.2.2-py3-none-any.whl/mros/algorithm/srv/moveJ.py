import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.algorithm.msg

class moveJRequest(mros.Message):
    __slots__ = ['__id__','joints','totalTime','ifABSmove']
    _slot_types = ['uint32','float32[6]','float32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveJRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.joints is None:
                self.joints = [0. for x in range(0, 6)]
            if self.totalTime is None:
                self.totalTime = 0.
            if self.ifABSmove is None:
                self.ifABSmove = False
        else:
            self.__id__ = 0
            self.joints = [0. for x in range(0, 6)]
            self.totalTime = 0.
            self.ifABSmove = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(struct.pack(f'<{6}f', *self.joints))
            offset += 6 * 4
            struct_totalTime = struct.Struct("<f")
            buff.write(struct_totalTime.pack(self.totalTime))
            offset += 4
            struct_ifABSmove = struct.Struct("<B")
            buff.write(struct_ifABSmove.pack(self.ifABSmove))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.joints = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            struct_totalTime = struct.Struct("<f")
            (self.totalTime,) = struct_totalTime.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_ifABSmove = struct.Struct("<B")
            (self.ifABSmove,) = struct_ifABSmove.unpack(buff[offset:(offset + 1)])
            self.ifABSmove = bool(self.ifABSmove)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 6 * 4
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"joints":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.joints[i]
            else:
                string_echo += '%s,' % self.joints[i]
        string_echo += '],'
        string_echo += '"totalTime":%s' % self.totalTime
        string_echo += ','
        string_echo += '"ifABSmove":%s' % self.ifABSmove
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveJ"

    def getMD5(self):
        return "81765171b634159b0ca8e65d233950ea"
    def getDef(self):
        return "float32[6] joints\nfloat32 totalTime\nbool ifABSmove\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class moveJResponse(mros.Message):
    __slots__ = ['__id__','executionStatus']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveJResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.executionStatus is None:
                self.executionStatus = False
        else:
            self.__id__ = 0
            self.executionStatus = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_executionStatus = struct.Struct("<B")
            buff.write(struct_executionStatus.pack(self.executionStatus))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_executionStatus = struct.Struct("<B")
            (self.executionStatus,) = struct_executionStatus.unpack(buff[offset:(offset + 1)])
            self.executionStatus = bool(self.executionStatus)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"executionStatus":%s' % self.executionStatus
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveJ"

    def getMD5(self):
        return "81765171b634159b0ca8e65d233950ea"
    def getDef(self):
        return "bool executionStatus\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class moveJ(object):
    Request = moveJRequest
    Response = moveJResponse

    __slots__ = ['request','response']
    _slot_types = ['moveJRequest','moveJResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveJ, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

