import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.algorithm.msg

class moveLRequest(mros.Message):
    __slots__ = ['__id__','targetPos','vLimt']
    _slot_types = ['uint32','float32[6]','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveLRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.targetPos is None:
                self.targetPos = [0. for x in range(0, 6)]
            if self.vLimt is None:
                self.vLimt = 0.
        else:
            self.__id__ = 0
            self.targetPos = [0. for x in range(0, 6)]
            self.vLimt = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(struct.pack(f'<{6}f', *self.targetPos))
            offset += 6 * 4
            struct_vLimt = struct.Struct("<f")
            buff.write(struct_vLimt.pack(self.vLimt))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.targetPos = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            struct_vLimt = struct.Struct("<f")
            (self.vLimt,) = struct_vLimt.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 6 * 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"targetPos":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.targetPos[i]
            else:
                string_echo += '%s,' % self.targetPos[i]
        string_echo += '],'
        string_echo += '"vLimt":%s' % self.vLimt
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveL"

    def getMD5(self):
        return "846e7166b3b19a3a999415bf9e0ea2e4"
    def getDef(self):
        return "float32[6] targetPos\nfloat32 vLimt\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class moveLResponse(mros.Message):
    __slots__ = ['__id__','executionStatus']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveLResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.executionStatus is None:
                self.executionStatus = 0
        else:
            self.__id__ = 0
            self.executionStatus = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_executionStatus = struct.Struct("<i")
            buff.write(struct_executionStatus.pack(self.executionStatus))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_executionStatus = struct.Struct("<i")
            (self.executionStatus,) = struct_executionStatus.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"executionStatus":%s' % self.executionStatus
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveL"

    def getMD5(self):
        return "846e7166b3b19a3a999415bf9e0ea2e4"
    def getDef(self):
        return "int32 executionStatus\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class moveL(object):
    Request = moveLRequest
    Response = moveLResponse

    __slots__ = ['request','response']
    _slot_types = ['moveLRequest','moveLResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveL, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

