import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.algorithm.msg

class movePRequest(mros.Message):
    __slots__ = ['__id__','pos','totalTime']
    _slot_types = ['uint32','float32[6]','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(movePRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.pos is None:
                self.pos = [0. for x in range(0, 6)]
            if self.totalTime is None:
                self.totalTime = 0.
        else:
            self.__id__ = 0
            self.pos = [0. for x in range(0, 6)]
            self.totalTime = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(struct.pack(f'<{6}f', *self.pos))
            offset += 6 * 4
            struct_totalTime = struct.Struct("<f")
            buff.write(struct_totalTime.pack(self.totalTime))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.pos = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            struct_totalTime = struct.Struct("<f")
            (self.totalTime,) = struct_totalTime.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 6 * 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"pos":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.pos[i]
            else:
                string_echo += '%s,' % self.pos[i]
        string_echo += '],'
        string_echo += '"totalTime":%s' % self.totalTime
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveP"

    def getMD5(self):
        return "1e848888f920f74ff5f2ff27e0e8bee9"
    def getDef(self):
        return "float32[6] pos\nfloat32 totalTime\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class movePResponse(mros.Message):
    __slots__ = ['__id__','executionStatus']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(movePResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.executionStatus is None:
                self.executionStatus = 0
        else:
            self.__id__ = 0
            self.executionStatus = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_executionStatus = struct.Struct("<i")
            buff.write(struct_executionStatus.pack(self.executionStatus))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_executionStatus = struct.Struct("<i")
            (self.executionStatus,) = struct_executionStatus.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"executionStatus":%s' % self.executionStatus
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "algorithm/moveP"

    def getMD5(self):
        return "1e848888f920f74ff5f2ff27e0e8bee9"
    def getDef(self):
        return "int32 executionStatus\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class moveP(object):
    Request = movePRequest
    Response = movePResponse

    __slots__ = ['request','response']
    _slot_types = ['movePRequest','movePResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(moveP, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

