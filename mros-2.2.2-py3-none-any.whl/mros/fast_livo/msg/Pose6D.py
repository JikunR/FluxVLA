import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.fast_livo.msg

class Pose6D(mros.Message):
    __slots__ = ['offset_time','acc','gyr','vel','pos','rot']
    _slot_types = ['float64','float64[3]','float64[3]','float64[3]','float64[3]','float64[9]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Pose6D, self).__init__(*args, **kwds)
            if self.offset_time is None:
                self.offset_time = 0.
            if self.acc is None:
                self.acc = [0. for x in range(0, 3)]
            if self.gyr is None:
                self.gyr = [0. for x in range(0, 3)]
            if self.vel is None:
                self.vel = [0. for x in range(0, 3)]
            if self.pos is None:
                self.pos = [0. for x in range(0, 3)]
            if self.rot is None:
                self.rot = [0. for x in range(0, 9)]
        else:
            self.offset_time = 0.
            self.acc = [0. for x in range(0, 3)]
            self.gyr = [0. for x in range(0, 3)]
            self.vel = [0. for x in range(0, 3)]
            self.pos = [0. for x in range(0, 3)]
            self.rot = [0. for x in range(0, 9)]

    def serialize(self, buff):
        offset = 0
        try:
            struct_offset_time = struct.Struct("<d")
            buff.write(struct_offset_time.pack(self.offset_time))
            offset += 8
            buff.write(struct.pack(f'<{3}d', *self.acc))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.gyr))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.vel))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.pos))
            offset += 3 * 8
            buff.write(struct.pack(f'<{9}d', *self.rot))
            offset += 9 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_offset_time = struct.Struct("<d")
            (self.offset_time,) = struct_offset_time.unpack(buff[offset:(offset + 8)])
            offset += 8
            self.acc = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.gyr = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.vel = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.pos = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.rot = np.frombuffer(buff[offset:offset + 9 * 8], dtype=np.float64)
            offset += 9 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 9 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"offset_time":%s' % self.offset_time
        string_echo += ','
        string_echo += '"acc":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.acc[i]
            else:
                string_echo += '%s,' % self.acc[i]
        string_echo += '],'
        string_echo += '"gyr":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.gyr[i]
            else:
                string_echo += '%s,' % self.gyr[i]
        string_echo += '],'
        string_echo += '"vel":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.vel[i]
            else:
                string_echo += '%s,' % self.vel[i]
        string_echo += '],'
        string_echo += '"pos":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.pos[i]
            else:
                string_echo += '%s,' % self.pos[i]
        string_echo += '],'
        string_echo += '"rot":['
        for i in range(0, 9):
            if i == (9 - 1): 
                string_echo += '%s' % self.rot[i]
            else:
                string_echo += '%s,' % self.rot[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "fast_livo/Pose6D"

    def getMD5(self):
        return "ab486e9c24704038320abf9ff59003d2"

    def getDef(self):
        return "float64 offset_time\nfloat64[3] acc\nfloat64[3] gyr\nfloat64[3] vel\nfloat64[3] pos\nfloat64[9] rot\n"

_struct_I = struct.Struct('<I')

