import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.fast_livo.msg
import mros.std_msgs.msg

class States(mros.Message):
    __slots__ = ['header','rot_end','pos_end','vel_end','bias_gyr','bias_acc','gravity','cov']
    _slot_types = ['std_msgs/Header','float64[]','float64[]','float64[]','float64[]','float64[]','float64[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(States, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.rot_end is None:
                self.rot_end = []
            if self.pos_end is None:
                self.pos_end = []
            if self.vel_end is None:
                self.vel_end = []
            if self.bias_gyr is None:
                self.bias_gyr = []
            if self.bias_acc is None:
                self.bias_acc = []
            if self.gravity is None:
                self.gravity = []
            if self.cov is None:
                self.cov = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.rot_end = []
            self.pos_end = []
            self.vel_end = []
            self.bias_gyr = []
            self.bias_acc = []
            self.gravity = []
            self.cov = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            rot_end_length = len(self.rot_end)
            buff.write(struct.pack('<I', rot_end_length))
            buff.write(struct.pack(f'<{rot_end_length}d', *self.rot_end))
            offset += 4 + rot_end_length * 8
            pos_end_length = len(self.pos_end)
            buff.write(struct.pack('<I', pos_end_length))
            buff.write(struct.pack(f'<{pos_end_length}d', *self.pos_end))
            offset += 4 + pos_end_length * 8
            vel_end_length = len(self.vel_end)
            buff.write(struct.pack('<I', vel_end_length))
            buff.write(struct.pack(f'<{vel_end_length}d', *self.vel_end))
            offset += 4 + vel_end_length * 8
            bias_gyr_length = len(self.bias_gyr)
            buff.write(struct.pack('<I', bias_gyr_length))
            buff.write(struct.pack(f'<{bias_gyr_length}d', *self.bias_gyr))
            offset += 4 + bias_gyr_length * 8
            bias_acc_length = len(self.bias_acc)
            buff.write(struct.pack('<I', bias_acc_length))
            buff.write(struct.pack(f'<{bias_acc_length}d', *self.bias_acc))
            offset += 4 + bias_acc_length * 8
            gravity_length = len(self.gravity)
            buff.write(struct.pack('<I', gravity_length))
            buff.write(struct.pack(f'<{gravity_length}d', *self.gravity))
            offset += 4 + gravity_length * 8
            cov_length = len(self.cov)
            buff.write(struct.pack('<I', cov_length))
            buff.write(struct.pack(f'<{cov_length}d', *self.cov))
            offset += 4 + cov_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (rot_end_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.rot_end = np.frombuffer(buff[offset:offset + rot_end_length * 8], dtype=np.float64)
            offset += rot_end_length * 8
            (pos_end_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.pos_end = np.frombuffer(buff[offset:offset + pos_end_length * 8], dtype=np.float64)
            offset += pos_end_length * 8
            (vel_end_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.vel_end = np.frombuffer(buff[offset:offset + vel_end_length * 8], dtype=np.float64)
            offset += vel_end_length * 8
            (bias_gyr_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.bias_gyr = np.frombuffer(buff[offset:offset + bias_gyr_length * 8], dtype=np.float64)
            offset += bias_gyr_length * 8
            (bias_acc_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.bias_acc = np.frombuffer(buff[offset:offset + bias_acc_length * 8], dtype=np.float64)
            offset += bias_acc_length * 8
            (gravity_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.gravity = np.frombuffer(buff[offset:offset + gravity_length * 8], dtype=np.float64)
            offset += gravity_length * 8
            (cov_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.cov = np.frombuffer(buff[offset:offset + cov_length * 8], dtype=np.float64)
            offset += cov_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.rot_end) * 8
        length += 4
        length += len(self.pos_end) * 8
        length += 4
        length += len(self.vel_end) * 8
        length += 4
        length += len(self.bias_gyr) * 8
        length += 4
        length += len(self.bias_acc) * 8
        length += 4
        length += len(self.gravity) * 8
        length += 4
        length += len(self.cov) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"rot_end":['
        rot_end_length = len(self.rot_end)
        for i in range(0, rot_end_length):
            if i == (rot_end_length - 1): 
                string_echo += '%s' % self.rot_end[i]
            else:
                string_echo += '%s,' % self.rot_end[i]
        string_echo += '],'
        string_echo += '"pos_end":['
        pos_end_length = len(self.pos_end)
        for i in range(0, pos_end_length):
            if i == (pos_end_length - 1): 
                string_echo += '%s' % self.pos_end[i]
            else:
                string_echo += '%s,' % self.pos_end[i]
        string_echo += '],'
        string_echo += '"vel_end":['
        vel_end_length = len(self.vel_end)
        for i in range(0, vel_end_length):
            if i == (vel_end_length - 1): 
                string_echo += '%s' % self.vel_end[i]
            else:
                string_echo += '%s,' % self.vel_end[i]
        string_echo += '],'
        string_echo += '"bias_gyr":['
        bias_gyr_length = len(self.bias_gyr)
        for i in range(0, bias_gyr_length):
            if i == (bias_gyr_length - 1): 
                string_echo += '%s' % self.bias_gyr[i]
            else:
                string_echo += '%s,' % self.bias_gyr[i]
        string_echo += '],'
        string_echo += '"bias_acc":['
        bias_acc_length = len(self.bias_acc)
        for i in range(0, bias_acc_length):
            if i == (bias_acc_length - 1): 
                string_echo += '%s' % self.bias_acc[i]
            else:
                string_echo += '%s,' % self.bias_acc[i]
        string_echo += '],'
        string_echo += '"gravity":['
        gravity_length = len(self.gravity)
        for i in range(0, gravity_length):
            if i == (gravity_length - 1): 
                string_echo += '%s' % self.gravity[i]
            else:
                string_echo += '%s,' % self.gravity[i]
        string_echo += '],'
        string_echo += '"cov":['
        cov_length = len(self.cov)
        for i in range(0, cov_length):
            if i == (cov_length - 1): 
                string_echo += '%s' % self.cov[i]
            else:
                string_echo += '%s,' % self.cov[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "fast_livo/States"

    def getMD5(self):
        return "4a896a0d8c07506c836e98c3fa512a5e"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[] rot_end\nfloat64[] pos_end\nfloat64[] vel_end\nfloat64[] bias_gyr\nfloat64[] bias_acc\nfloat64[] gravity\nfloat64[] cov\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

