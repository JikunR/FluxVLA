﻿import requests
from openai import OpenAI
from openai import AzureOpenAI

# Send prompt to OpenAI model & get response.
# Requires prompt, API key, base URL, and model. Others are optional.
def call_openai(
    prompt: str,
    api_key: str,
    base_url: str,
    model: str,
    system_prompt: str = "You are a helpful assistant.",
    temperature: float = 0.7,
    max_tokens: int = 256,
    top_p: float = 1,
    frequency_penalty: float = 0,
    presence_penalty: float = 0
) -> str:
    try:
        # Initialize OpenAI client
        client = OpenAI(
            base_url=base_url,
            api_key=api_key
        )
        # Call OpenAI chat completion API
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty
        )
        # Extract response content safely
        return response.choices[0].message.content if response.choices and response.choices[0].message else ""
    except Exception as e:
        # Print error if API call fails
        print(f"An error occurred: {e}")
        return ""


# Send prompt to Ollama model & get response.
# Requires prompt, base URL, and model. Others are optional.
def call_ollama(
    prompt: str,
    base_url: str,
    model: str,
    system_prompt: str = "You are a helpful assistant.",
    temperature: float = 0.7,
    max_tokens: int = 256,
    top_p: float = 1,
    frequency_penalty: float = 0,
    presence_penalty: float = 0
) -> str:
    try:
        # Prepare the data to send to Ollama API
        data = {
            "model": model,
            "prompt": f"{system_prompt}\n{prompt}",
            "temperature": temperature,
            "max_tokens": max_tokens,
            "top_p": top_p,
            "frequency_penalty": frequency_penalty,
            "presence_penalty": presence_penalty,
            "stream": False
        }

        # Send a POST request to the Ollama API
        response = requests.post(base_url + "/api/generate", json=data)

        # Check if the request was successful
        if response.status_code == 200:
            result = response.json()
            return result.get("response", "")
        else:
            print(f"Request failed with status code: {response.status_code}, Error: {response.text}")
            return ""
    except Exception as e:
        # Print error if API call fails
        print(f"An error occurred: {e}")
        return ""

# Send prompt to Azure OpenAI model & get response.
# Requires prompt, API key, base URL, model, and API version. Others are optional.
def call_azure_openai(
    prompt: str,
    api_key: str,
    azure_endpoint: str,
    model: str,
    api_version: str,
    system_prompt: str = "You are a helpful assistant.",
    temperature: float = 0.7,
    max_tokens: int = 256,
    top_p: float = 1,
    frequency_penalty: float = 0,
    presence_penalty: float = 0
) -> str:
    try:
        # Initialize Azure OpenAI client
        client = AzureOpenAI(
            api_key=api_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version
        )
        # Call Azure OpenAI chat completion API
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty
        )
        # Extract response content safely
        return response.choices[0].message.content if response.choices and response.choices[0].message else ""
    except Exception as e:
        # Print error if API call fails
        print(f"An error occurred: {e}")
        return ""


# Send prompt to DeepSeek model & get response.
# Requires prompt, API key, base URL, and model. Others are optional.
def call_deepseek(
    prompt: str,
    api_key: str,
    base_url: str,
    model: str,
    system_prompt: str = "You are a helpful assistant.",
    temperature: float = 0.7,
    max_tokens: int = 256,
    top_p: float = 1,
    frequency_penalty: float = 0,
    presence_penalty: float = 0
) -> str:
    try:
        # Initialize DeepSeek client
        client = OpenAI(
            base_url=base_url,
            api_key=api_key
        )
        # Call DeepSeek chat completion API
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty
        )
        # Extract response content safely
        return response.choices[0].message.content if response.choices and response.choices[0].message else ""
    except Exception as e:
        # Print error if API call fails
        print(f"An error occurred: {e}")
        return ""
