﻿from typing import Union
import traceback
import mros.flow.pocket as pocket

def build_mermaid(start: Union[pocket.BaseNode, pocket.Flow]) -> str:
    ids = {}
    visited = set()
    lines = ["graph LR"]
    counter = 1

    def get_id(node):
        nonlocal counter
        if node not in ids:
            ids[node] = f"N{counter}"
            counter += 1
        return ids[node]

    def link(a, b):
        lines.append(f"    {a} --> {b}")

    def walk(node, parent=None):
        if node in visited:
            if parent:
                link(parent, get_id(node))
            return
        visited.add(node)

        if isinstance(node, pocket.Flow):
            if node.start and parent:
                link(parent, get_id(node.start))
            lines.append(f"\n    subgraph sub_pocket.Flow_{get_id(node)}[{node.__class__.__name__}]")
            if node.start:
                walk(node.start)
            for nxt in node.successors.values():
                if node.start:
                    walk(nxt, get_id(node.start))
                elif parent:
                    link(parent, get_id(nxt))
                else:
                    walk(nxt)
            lines.append("    end\n")
        else:
            node_id = get_id(node)
            lines.append(f"    {node_id}[\"{node.__class__.__name__}\"]")
            if parent:
                link(parent, node_id)
            for nxt in node.successors.values():
                walk(nxt, node_id)

    walk(start)
    return "\n".join(lines)
