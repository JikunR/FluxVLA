import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.livox_ros_driver.msg

class CustomPoint(mros.Message):
    __slots__ = ['offset_time','x','y','z','reflectivity','tag','line']
    _slot_types = ['uint32','float32','float32','float32','uint8','uint8','uint8']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CustomPoint, self).__init__(*args, **kwds)
            if self.offset_time is None:
                self.offset_time = 0
            if self.x is None:
                self.x = 0.
            if self.y is None:
                self.y = 0.
            if self.z is None:
                self.z = 0.
            if self.reflectivity is None:
                self.reflectivity = 0
            if self.tag is None:
                self.tag = 0
            if self.line is None:
                self.line = 0
        else:
            self.offset_time = 0
            self.x = 0.
            self.y = 0.
            self.z = 0.
            self.reflectivity = 0
            self.tag = 0
            self.line = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.offset_time))
            offset += 4
            struct_x = struct.Struct("<f")
            buff.write(struct_x.pack(self.x))
            offset += 4
            struct_y = struct.Struct("<f")
            buff.write(struct_y.pack(self.y))
            offset += 4
            struct_z = struct.Struct("<f")
            buff.write(struct_z.pack(self.z))
            offset += 4
            struct_reflectivity = struct.Struct("<B")
            buff.write(struct_reflectivity.pack(self.reflectivity))
            offset += 1
            struct_tag = struct.Struct("<B")
            buff.write(struct_tag.pack(self.tag))
            offset += 1
            struct_line = struct.Struct("<B")
            buff.write(struct_line.pack(self.line))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.offset_time,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_x = struct.Struct("<f")
            (self.x,) = struct_x.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_y = struct.Struct("<f")
            (self.y,) = struct_y.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_z = struct.Struct("<f")
            (self.z,) = struct_z.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_reflectivity = struct.Struct("<B")
            (self.reflectivity,) = struct_reflectivity.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_tag = struct.Struct("<B")
            (self.tag,) = struct_tag.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_line = struct.Struct("<B")
            (self.line,) = struct_line.unpack(buff[offset:(offset + 1)])
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        length += 4
        length += 4
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"offset_time":%s' % self.offset_time
        string_echo += ','
        string_echo += '"x":%s' % self.x
        string_echo += ','
        string_echo += '"y":%s' % self.y
        string_echo += ','
        string_echo += '"z":%s' % self.z
        string_echo += ','
        string_echo += '"reflectivity":%s' % self.reflectivity
        string_echo += ','
        string_echo += '"tag":%s' % self.tag
        string_echo += ','
        string_echo += '"line":%s' % self.line
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "livox_ros_driver/CustomPoint"

    def getMD5(self):
        return "109a3cc548bb1f96626be89a5008bd6d"

    def getDef(self):
        return "uint32 offset_time\nfloat32 x\nfloat32 y\nfloat32 z\nuint8 reflectivity\nuint8 tag\nuint8 line\n"

_struct_I = struct.Struct('<I')

