import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotStates(mros.Message):
    __slots__ = ['header','qState','qdState','currentState','dc_voltage']
    _slot_types = ['std_msgs/Header','float64[]','float64[]','float64[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotStates, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qState is None:
                self.qState = []
            if self.qdState is None:
                self.qdState = []
            if self.currentState is None:
                self.currentState = []
            if self.dc_voltage is None:
                self.dc_voltage = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qState = []
            self.qdState = []
            self.currentState = []
            self.dc_voltage = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            qState_length = len(self.qState)
            buff.write(struct.pack('<I', qState_length))
            buff.write(struct.pack(f'<{qState_length}d', *self.qState))
            offset += 4 + qState_length * 8
            qdState_length = len(self.qdState)
            buff.write(struct.pack('<I', qdState_length))
            buff.write(struct.pack(f'<{qdState_length}d', *self.qdState))
            offset += 4 + qdState_length * 8
            currentState_length = len(self.currentState)
            buff.write(struct.pack('<I', currentState_length))
            buff.write(struct.pack(f'<{currentState_length}d', *self.currentState))
            offset += 4 + currentState_length * 8
            dc_voltage_length = len(self.dc_voltage)
            buff.write(struct.pack('<I', dc_voltage_length))
            buff.write(struct.pack(f'<{dc_voltage_length}d', *self.dc_voltage))
            offset += 4 + dc_voltage_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (qState_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qState = np.frombuffer(buff[offset:offset + qState_length * 8], dtype=np.float64)
            offset += qState_length * 8
            (qdState_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qdState = np.frombuffer(buff[offset:offset + qdState_length * 8], dtype=np.float64)
            offset += qdState_length * 8
            (currentState_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.currentState = np.frombuffer(buff[offset:offset + currentState_length * 8], dtype=np.float64)
            offset += currentState_length * 8
            (dc_voltage_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.dc_voltage = np.frombuffer(buff[offset:offset + dc_voltage_length * 8], dtype=np.float64)
            offset += dc_voltage_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.qState) * 8
        length += 4
        length += len(self.qdState) * 8
        length += 4
        length += len(self.currentState) * 8
        length += 4
        length += len(self.dc_voltage) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qState":['
        qState_length = len(self.qState)
        for i in range(0, qState_length):
            if i == (qState_length - 1): 
                string_echo += '%s' % self.qState[i]
            else:
                string_echo += '%s,' % self.qState[i]
        string_echo += '],'
        string_echo += '"qdState":['
        qdState_length = len(self.qdState)
        for i in range(0, qdState_length):
            if i == (qdState_length - 1): 
                string_echo += '%s' % self.qdState[i]
            else:
                string_echo += '%s,' % self.qdState[i]
        string_echo += '],'
        string_echo += '"currentState":['
        currentState_length = len(self.currentState)
        for i in range(0, currentState_length):
            if i == (currentState_length - 1): 
                string_echo += '%s' % self.currentState[i]
            else:
                string_echo += '%s,' % self.currentState[i]
        string_echo += '],'
        string_echo += '"dc_voltage":['
        dc_voltage_length = len(self.dc_voltage)
        for i in range(0, dc_voltage_length):
            if i == (dc_voltage_length - 1): 
                string_echo += '%s' % self.dc_voltage[i]
            else:
                string_echo += '%s,' % self.dc_voltage[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotStates"

    def getMD5(self):
        return "748c76d013bb313462f43a126f028859"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[] qState\nfloat64[] qdState\nfloat64[] currentState\nfloat64[] dc_voltage\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

