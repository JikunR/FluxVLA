import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class TestMsg(mros.Message):
    __slots__ = ['header','tau_1','tau_2','tau_3','tau_4','tau_5']
    _slot_types = ['std_msgs/Header','float32[16]','float32[16]','float32[16]','float32[16]','float32[16]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestMsg, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.tau_1 is None:
                self.tau_1 = [0. for x in range(0, 16)]
            if self.tau_2 is None:
                self.tau_2 = [0. for x in range(0, 16)]
            if self.tau_3 is None:
                self.tau_3 = [0. for x in range(0, 16)]
            if self.tau_4 is None:
                self.tau_4 = [0. for x in range(0, 16)]
            if self.tau_5 is None:
                self.tau_5 = [0. for x in range(0, 16)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.tau_1 = [0. for x in range(0, 16)]
            self.tau_2 = [0. for x in range(0, 16)]
            self.tau_3 = [0. for x in range(0, 16)]
            self.tau_4 = [0. for x in range(0, 16)]
            self.tau_5 = [0. for x in range(0, 16)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{16}f', *self.tau_1))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.tau_2))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.tau_3))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.tau_4))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.tau_5))
            offset += 16 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.tau_1 = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.tau_2 = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.tau_3 = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.tau_4 = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.tau_5 = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 16 * 4
        length += 16 * 4
        length += 16 * 4
        length += 16 * 4
        length += 16 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"tau_1":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.tau_1[i]
            else:
                string_echo += '%s,' % self.tau_1[i]
        string_echo += '],'
        string_echo += '"tau_2":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.tau_2[i]
            else:
                string_echo += '%s,' % self.tau_2[i]
        string_echo += '],'
        string_echo += '"tau_3":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.tau_3[i]
            else:
                string_echo += '%s,' % self.tau_3[i]
        string_echo += '],'
        string_echo += '"tau_4":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.tau_4[i]
            else:
                string_echo += '%s,' % self.tau_4[i]
        string_echo += '],'
        string_echo += '"tau_5":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.tau_5[i]
            else:
                string_echo += '%s,' % self.tau_5[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/TestMsg"

    def getMD5(self):
        return "c61352d4fc03955082286e4c165ea73a"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[16] tau_1\nfloat32[16] tau_2\nfloat32[16] tau_3\nfloat32[16] tau_4\nfloat32[16] tau_5\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

