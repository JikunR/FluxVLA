import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class JointsStateBiped(mros.Message):
    __slots__ = ['header','qpos','qvel','qacc','tau']
    _slot_types = ['std_msgs/Header','float32[10]','float32[10]','float32[10]','float32[10]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointsStateBiped, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qpos is None:
                self.qpos = [0. for x in range(0, 10)]
            if self.qvel is None:
                self.qvel = [0. for x in range(0, 10)]
            if self.qacc is None:
                self.qacc = [0. for x in range(0, 10)]
            if self.tau is None:
                self.tau = [0. for x in range(0, 10)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qpos = [0. for x in range(0, 10)]
            self.qvel = [0. for x in range(0, 10)]
            self.qacc = [0. for x in range(0, 10)]
            self.tau = [0. for x in range(0, 10)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{10}f', *self.qpos))
            offset += 10 * 4
            buff.write(struct.pack(f'<{10}f', *self.qvel))
            offset += 10 * 4
            buff.write(struct.pack(f'<{10}f', *self.qacc))
            offset += 10 * 4
            buff.write(struct.pack(f'<{10}f', *self.tau))
            offset += 10 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.qpos = np.frombuffer(buff[offset:offset + 10 * 4], dtype=np.float32)
            offset += 10 * 4
            self.qvel = np.frombuffer(buff[offset:offset + 10 * 4], dtype=np.float32)
            offset += 10 * 4
            self.qacc = np.frombuffer(buff[offset:offset + 10 * 4], dtype=np.float32)
            offset += 10 * 4
            self.tau = np.frombuffer(buff[offset:offset + 10 * 4], dtype=np.float32)
            offset += 10 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 10 * 4
        length += 10 * 4
        length += 10 * 4
        length += 10 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qpos":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.qpos[i]
            else:
                string_echo += '%s,' % self.qpos[i]
        string_echo += '],'
        string_echo += '"qvel":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.qvel[i]
            else:
                string_echo += '%s,' % self.qvel[i]
        string_echo += '],'
        string_echo += '"qacc":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.qacc[i]
            else:
                string_echo += '%s,' % self.qacc[i]
        string_echo += '],'
        string_echo += '"tau":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.tau[i]
            else:
                string_echo += '%s,' % self.tau[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/JointsStateBiped"

    def getMD5(self):
        return "992cbbb1fc6b93c4c13480b4573d7237"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[10] qpos\nfloat32[10] qvel\nfloat32[10] qacc\nfloat32[10] tau\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

