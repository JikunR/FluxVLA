import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RCCmdStamped(mros.Message):
    __slots__ = ['header','mode','vx','vy','w','damping','gait','standup','sitdown','vision_mode','stairup','stairdown','navi_mode','swing_test','cruise']
    _slot_types = ['std_msgs/Header','int8','float64','float64','float64','bool','int8','bool','bool','int8','bool','bool','int8','bool','bool']

    IDLE_MODE =  0  
    NAVI_MODE =  1  
    USER_MODE =  2  
    MANUAL_MODE =  3  
    GAIT_NONE =  0
    GAIT_STAND =  1
    GAIT_TROT_WALK =  2
    VISION_NONE =  0
    NO_VISION =  1
    LOCAL_VISION =  2
    VISION =  3
    NAVI_NONE =  0
    NAVI_GROUND =  1
    NAVI_UP_FORWARD =  2
    NAVI_DOWN_BACKWARD =  3
    NAVI_PRE_UP =  4
    NAVI_PRE_DOWN =  5
    NAVI_LAND_STAIR =  6
    NAVI_PAUSE =  7
    NAVI_ROTATE =  8
    NAVI_DOWN_FORWARD =  9

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RCCmdStamped, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.mode is None:
                self.mode = 0
            if self.vx is None:
                self.vx = 0.
            if self.vy is None:
                self.vy = 0.
            if self.w is None:
                self.w = 0.
            if self.damping is None:
                self.damping = False
            if self.gait is None:
                self.gait = 0
            if self.standup is None:
                self.standup = False
            if self.sitdown is None:
                self.sitdown = False
            if self.vision_mode is None:
                self.vision_mode = 0
            if self.stairup is None:
                self.stairup = False
            if self.stairdown is None:
                self.stairdown = False
            if self.navi_mode is None:
                self.navi_mode = 0
            if self.swing_test is None:
                self.swing_test = False
            if self.cruise is None:
                self.cruise = False
        else:
            self.header = mros.std_msgs.msg.Header()
            self.mode = 0
            self.vx = 0.
            self.vy = 0.
            self.w = 0.
            self.damping = False
            self.gait = 0
            self.standup = False
            self.sitdown = False
            self.vision_mode = 0
            self.stairup = False
            self.stairdown = False
            self.navi_mode = 0
            self.swing_test = False
            self.cruise = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_mode = struct.Struct("<b")
            buff.write(struct_mode.pack(self.mode))
            offset += 1
            struct_vx = struct.Struct("<d")
            buff.write(struct_vx.pack(self.vx))
            offset += 8
            struct_vy = struct.Struct("<d")
            buff.write(struct_vy.pack(self.vy))
            offset += 8
            struct_w = struct.Struct("<d")
            buff.write(struct_w.pack(self.w))
            offset += 8
            struct_damping = struct.Struct("<B")
            buff.write(struct_damping.pack(self.damping))
            offset += 1
            struct_gait = struct.Struct("<b")
            buff.write(struct_gait.pack(self.gait))
            offset += 1
            struct_standup = struct.Struct("<B")
            buff.write(struct_standup.pack(self.standup))
            offset += 1
            struct_sitdown = struct.Struct("<B")
            buff.write(struct_sitdown.pack(self.sitdown))
            offset += 1
            struct_vision_mode = struct.Struct("<b")
            buff.write(struct_vision_mode.pack(self.vision_mode))
            offset += 1
            struct_stairup = struct.Struct("<B")
            buff.write(struct_stairup.pack(self.stairup))
            offset += 1
            struct_stairdown = struct.Struct("<B")
            buff.write(struct_stairdown.pack(self.stairdown))
            offset += 1
            struct_navi_mode = struct.Struct("<b")
            buff.write(struct_navi_mode.pack(self.navi_mode))
            offset += 1
            struct_swing_test = struct.Struct("<B")
            buff.write(struct_swing_test.pack(self.swing_test))
            offset += 1
            struct_cruise = struct.Struct("<B")
            buff.write(struct_cruise.pack(self.cruise))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_mode = struct.Struct("<b")
            (self.mode,) = struct_mode.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_vx = struct.Struct("<d")
            (self.vx,) = struct_vx.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_vy = struct.Struct("<d")
            (self.vy,) = struct_vy.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_w = struct.Struct("<d")
            (self.w,) = struct_w.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_damping = struct.Struct("<B")
            (self.damping,) = struct_damping.unpack(buff[offset:(offset + 1)])
            self.damping = bool(self.damping)
            offset += 1
            struct_gait = struct.Struct("<b")
            (self.gait,) = struct_gait.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_standup = struct.Struct("<B")
            (self.standup,) = struct_standup.unpack(buff[offset:(offset + 1)])
            self.standup = bool(self.standup)
            offset += 1
            struct_sitdown = struct.Struct("<B")
            (self.sitdown,) = struct_sitdown.unpack(buff[offset:(offset + 1)])
            self.sitdown = bool(self.sitdown)
            offset += 1
            struct_vision_mode = struct.Struct("<b")
            (self.vision_mode,) = struct_vision_mode.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_stairup = struct.Struct("<B")
            (self.stairup,) = struct_stairup.unpack(buff[offset:(offset + 1)])
            self.stairup = bool(self.stairup)
            offset += 1
            struct_stairdown = struct.Struct("<B")
            (self.stairdown,) = struct_stairdown.unpack(buff[offset:(offset + 1)])
            self.stairdown = bool(self.stairdown)
            offset += 1
            struct_navi_mode = struct.Struct("<b")
            (self.navi_mode,) = struct_navi_mode.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_swing_test = struct.Struct("<B")
            (self.swing_test,) = struct_swing_test.unpack(buff[offset:(offset + 1)])
            self.swing_test = bool(self.swing_test)
            offset += 1
            struct_cruise = struct.Struct("<B")
            (self.cruise,) = struct_cruise.unpack(buff[offset:(offset + 1)])
            self.cruise = bool(self.cruise)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 8
        length += 8
        length += 8
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"mode":%s' % self.mode
        string_echo += ','
        string_echo += '"vx":%s' % self.vx
        string_echo += ','
        string_echo += '"vy":%s' % self.vy
        string_echo += ','
        string_echo += '"w":%s' % self.w
        string_echo += ','
        string_echo += '"damping":%s' % self.damping
        string_echo += ','
        string_echo += '"gait":%s' % self.gait
        string_echo += ','
        string_echo += '"standup":%s' % self.standup
        string_echo += ','
        string_echo += '"sitdown":%s' % self.sitdown
        string_echo += ','
        string_echo += '"vision_mode":%s' % self.vision_mode
        string_echo += ','
        string_echo += '"stairup":%s' % self.stairup
        string_echo += ','
        string_echo += '"stairdown":%s' % self.stairdown
        string_echo += ','
        string_echo += '"navi_mode":%s' % self.navi_mode
        string_echo += ','
        string_echo += '"swing_test":%s' % self.swing_test
        string_echo += ','
        string_echo += '"cruise":%s' % self.cruise
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RCCmdStamped"

    def getMD5(self):
        return "cb92ef9a5f527c5fa02b4b5096689a38"

    def getDef(self):
        return "std_msgs/Header header\nint8 IDLE_MODE    = 0\nint8 NAVI_MODE    = 1\nint8 USER_MODE    = 2\nint8 MANUAL_MODE  = 3\nint8 mode\nfloat64 vx\nfloat64 vy\nfloat64 w\nbool damping\nint8 GAIT_NONE = 0\nint8 GAIT_STAND = 1\nint8 GAIT_TROT_WALK = 2\nint8 gait\nbool standup\nbool sitdown\nint8 VISION_NONE  = 0\nint8 NO_VISION   = 1\nint8 LOCAL_VISION = 2\nint8 VISION       = 3\nint8 vision_mode\nbool stairup\nbool stairdown\nint8 NAVI_NONE = 0\nint8 NAVI_GROUND = 1\nint8 NAVI_UP_FORWARD = 2\nint8 NAVI_DOWN_BACKWARD = 3\nint8 NAVI_PRE_UP = 4\nint8 NAVI_PRE_DOWN = 5\nint8 NAVI_LAND_STAIR = 6\nint8 NAVI_PAUSE = 7\nint8 NAVI_ROTATE = 8\nint8 NAVI_DOWN_FORWARD = 9\nint8 navi_mode\nbool swing_test\nbool cruise\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

