import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class DebugInfo(mros.Message):
    __slots__ = ['header','pFootholds','pSwingTraj','foothold_planner_state','swing_planner_state','foot_planner_time','cmd_velocity','planned_velocity','considered_plane','selected_plane_id','foot_attracted','RHFootholds','CoMtrajectory','time','traj_control_point']
    _slot_types = ['std_msgs/Header','float64[12]','float64[600]','bool','int16','float64','float64','float64[3]','mros.controller_msgs.msg.ConsideredPlane[4]','int16[4]','int8[4]','float64[12]','float64[150]','int64','float64[24]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DebugInfo, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.pFootholds is None:
                self.pFootholds = [0. for x in range(0, 12)]
            if self.pSwingTraj is None:
                self.pSwingTraj = [0. for x in range(0, 600)]
            if self.foothold_planner_state is None:
                self.foothold_planner_state = False
            if self.swing_planner_state is None:
                self.swing_planner_state = 0
            if self.foot_planner_time is None:
                self.foot_planner_time = 0.
            if self.cmd_velocity is None:
                self.cmd_velocity = 0.
            if self.planned_velocity is None:
                self.planned_velocity = [0. for x in range(0, 3)]
            if self.considered_plane is None:
                self.considered_plane = [mros.controller_msgs.msg.ConsideredPlane() for x in range(0, 4)]
            if self.selected_plane_id is None:
                self.selected_plane_id = [0 for x in range(0, 4)]
            if self.foot_attracted is None:
                self.foot_attracted = [0 for x in range(0, 4)]
            if self.RHFootholds is None:
                self.RHFootholds = [0. for x in range(0, 12)]
            if self.CoMtrajectory is None:
                self.CoMtrajectory = [0. for x in range(0, 150)]
            if self.time is None:
                self.time = 0
            if self.traj_control_point is None:
                self.traj_control_point = [0. for x in range(0, 24)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.pFootholds = [0. for x in range(0, 12)]
            self.pSwingTraj = [0. for x in range(0, 600)]
            self.foothold_planner_state = False
            self.swing_planner_state = 0
            self.foot_planner_time = 0.
            self.cmd_velocity = 0.
            self.planned_velocity = [0. for x in range(0, 3)]
            self.considered_plane = [mros.controller_msgs.msg.ConsideredPlane() for x in range(0, 4)]
            self.selected_plane_id = [0 for x in range(0, 4)]
            self.foot_attracted = [0 for x in range(0, 4)]
            self.RHFootholds = [0. for x in range(0, 12)]
            self.CoMtrajectory = [0. for x in range(0, 150)]
            self.time = 0
            self.traj_control_point = [0. for x in range(0, 24)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{12}d', *self.pFootholds))
            offset += 12 * 8
            buff.write(struct.pack(f'<{600}d', *self.pSwingTraj))
            offset += 600 * 8
            struct_foothold_planner_state = struct.Struct("<B")
            buff.write(struct_foothold_planner_state.pack(self.foothold_planner_state))
            offset += 1
            struct_swing_planner_state = struct.Struct("<h")
            buff.write(struct_swing_planner_state.pack(self.swing_planner_state))
            offset += 2
            struct_foot_planner_time = struct.Struct("<d")
            buff.write(struct_foot_planner_time.pack(self.foot_planner_time))
            offset += 8
            struct_cmd_velocity = struct.Struct("<d")
            buff.write(struct_cmd_velocity.pack(self.cmd_velocity))
            offset += 8
            buff.write(struct.pack(f'<{3}d', *self.planned_velocity))
            offset += 3 * 8
            for i in range(0, 4):
                offset += self.considered_plane[i].serialize(buff)
            buff.write(struct.pack(f'<{4}h', *self.selected_plane_id))
            offset += 4 * 2
            buff.write(struct.pack(f'<{4}b', *self.foot_attracted))
            offset += 4
            buff.write(struct.pack(f'<{12}d', *self.RHFootholds))
            offset += 12 * 8
            buff.write(struct.pack(f'<{150}d', *self.CoMtrajectory))
            offset += 150 * 8
            struct_time = struct.Struct("<q")
            buff.write(struct_time.pack(self.time))
            offset += 8
            buff.write(struct.pack(f'<{24}d', *self.traj_control_point))
            offset += 24 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.pFootholds = np.frombuffer(buff[offset:offset + 12 * 8], dtype=np.float64)
            offset += 12 * 8
            self.pSwingTraj = np.frombuffer(buff[offset:offset + 600 * 8], dtype=np.float64)
            offset += 600 * 8
            struct_foothold_planner_state = struct.Struct("<B")
            (self.foothold_planner_state,) = struct_foothold_planner_state.unpack(buff[offset:(offset + 1)])
            self.foothold_planner_state = bool(self.foothold_planner_state)
            offset += 1
            struct_swing_planner_state = struct.Struct("<h")
            (self.swing_planner_state,) = struct_swing_planner_state.unpack(buff[offset:(offset + 2)])
            offset += 2
            struct_foot_planner_time = struct.Struct("<d")
            (self.foot_planner_time,) = struct_foot_planner_time.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_cmd_velocity = struct.Struct("<d")
            (self.cmd_velocity,) = struct_cmd_velocity.unpack(buff[offset:(offset + 8)])
            offset += 8
            self.planned_velocity = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            for i in range(0, 4):
                offset += self.considered_plane[i].deserialize(buff[offset:])
            self.selected_plane_id = np.frombuffer(buff[offset:offset + 4 * 2], dtype=np.int16)
            offset += 4 * 2
            self.foot_attracted = np.frombuffer(buff[offset:offset + 4], dtype=np.int8)
            offset += 4
            self.RHFootholds = np.frombuffer(buff[offset:offset + 12 * 8], dtype=np.float64)
            offset += 12 * 8
            self.CoMtrajectory = np.frombuffer(buff[offset:offset + 150 * 8], dtype=np.float64)
            offset += 150 * 8
            struct_time = struct.Struct("<q")
            (self.time,) = struct_time.unpack(buff[offset:(offset + 8)])
            offset += 8
            self.traj_control_point = np.frombuffer(buff[offset:offset + 24 * 8], dtype=np.float64)
            offset += 24 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 12 * 8
        length += 600 * 8
        length += 1
        length += 2
        length += 8
        length += 8
        length += 3 * 8
        for i in range(0, 4):
            length += self.considered_plane[i].serializedLength()
        length += 4 * 2
        length += 4
        length += 12 * 8
        length += 150 * 8
        length += 8
        length += 24 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"pFootholds":['
        for i in range(0, 12):
            if i == (12 - 1): 
                string_echo += '%s' % self.pFootholds[i]
            else:
                string_echo += '%s,' % self.pFootholds[i]
        string_echo += '],'
        string_echo += '"pSwingTraj":['
        for i in range(0, 600):
            if i == (600 - 1): 
                string_echo += '%s' % self.pSwingTraj[i]
            else:
                string_echo += '%s,' % self.pSwingTraj[i]
        string_echo += '],'
        string_echo += '"foothold_planner_state":%s' % self.foothold_planner_state
        string_echo += ','
        string_echo += '"swing_planner_state":%s' % self.swing_planner_state
        string_echo += ','
        string_echo += '"foot_planner_time":%s' % self.foot_planner_time
        string_echo += ','
        string_echo += '"cmd_velocity":%s' % self.cmd_velocity
        string_echo += ','
        string_echo += '"planned_velocity":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.planned_velocity[i]
            else:
                string_echo += '%s,' % self.planned_velocity[i]
        string_echo += '],'
        string_echo += '"considered_plane":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '{considered_plane%s":' % i
                string_echo += self.considered_plane[i].echo()
                string_echo += ''
            else:
                string_echo += '{considered_plane%s":' % i
                string_echo += self.considered_plane[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"selected_plane_id":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.selected_plane_id[i]
            else:
                string_echo += '%s,' % self.selected_plane_id[i]
        string_echo += '],'
        string_echo += '"foot_attracted":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.foot_attracted[i]
            else:
                string_echo += '%s,' % self.foot_attracted[i]
        string_echo += '],'
        string_echo += '"RHFootholds":['
        for i in range(0, 12):
            if i == (12 - 1): 
                string_echo += '%s' % self.RHFootholds[i]
            else:
                string_echo += '%s,' % self.RHFootholds[i]
        string_echo += '],'
        string_echo += '"CoMtrajectory":['
        for i in range(0, 150):
            if i == (150 - 1): 
                string_echo += '%s' % self.CoMtrajectory[i]
            else:
                string_echo += '%s,' % self.CoMtrajectory[i]
        string_echo += '],'
        string_echo += '"time":%s' % self.time
        string_echo += ','
        string_echo += '"traj_control_point":['
        for i in range(0, 24):
            if i == (24 - 1): 
                string_echo += '%s' % self.traj_control_point[i]
            else:
                string_echo += '%s,' % self.traj_control_point[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/DebugInfo"

    def getMD5(self):
        return "8a111f1b147a54d2d0e7c6cab25c948b"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[12] pFootholds\nfloat64[600] pSwingTraj\nbool foothold_planner_state\nint16 swing_planner_state\nfloat64 foot_planner_time\nfloat64 cmd_velocity\nfloat64[3] planned_velocity\ncontroller_msgs/ConsideredPlane[4] considered_plane\nint16[4] selected_plane_id\nint8[4] foot_attracted\nfloat64[12] RHFootholds\nfloat64[150] CoMtrajectory\nint64 time\nfloat64[24] traj_control_point\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: controller_msgs/ConsideredPlane\nstd_msgs/Header header\nint16 num\nint16[] id\n"

_struct_I = struct.Struct('<I')

