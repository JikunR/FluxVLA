import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class HighLevelCmdPointFoot(mros.Message):
    __slots__ = ['Header','vxCmd','vyCmd','vyawCmd']
    _slot_types = ['std_msgs/Header','float32','float32','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HighLevelCmdPointFoot, self).__init__(*args, **kwds)
            if self.Header is None:
                self.Header = mros.std_msgs.msg.Header()
            if self.vxCmd is None:
                self.vxCmd = 0.
            if self.vyCmd is None:
                self.vyCmd = 0.
            if self.vyawCmd is None:
                self.vyawCmd = 0.
        else:
            self.Header = mros.std_msgs.msg.Header()
            self.vxCmd = 0.
            self.vyCmd = 0.
            self.vyawCmd = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.Header.seq, self.Header.stamp.sec, self.Header.stamp.nsec))
            offset += 4 * 3
            _x = self.Header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_vxCmd = struct.Struct("<f")
            buff.write(struct_vxCmd.pack(self.vxCmd))
            offset += 4
            struct_vyCmd = struct.Struct("<f")
            buff.write(struct_vyCmd.pack(self.vyCmd))
            offset += 4
            struct_vyawCmd = struct.Struct("<f")
            buff.write(struct_vyawCmd.pack(self.vyawCmd))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.Header.seq, self.Header.stamp.sec, self.Header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.Header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.Header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_vxCmd = struct.Struct("<f")
            (self.vxCmd,) = struct_vxCmd.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_vyCmd = struct.Struct("<f")
            (self.vyCmd,) = struct_vyCmd.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_vyawCmd = struct.Struct("<f")
            (self.vyawCmd,) = struct_vyawCmd.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.Header.serializedLength()
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"Header":'
        string_echo += self.Header.echo()
        string_echo += ','
        string_echo += '"vxCmd":%s' % self.vxCmd
        string_echo += ','
        string_echo += '"vyCmd":%s' % self.vyCmd
        string_echo += ','
        string_echo += '"vyawCmd":%s' % self.vyawCmd
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/HighLevelCmdPointFoot"

    def getMD5(self):
        return "2eeff3267cce3a3f8af4aa5de1578bb1"

    def getDef(self):
        return "std_msgs/Header Header\nfloat32 vxCmd\nfloat32 vyCmd\nfloat32 vyawCmd\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

