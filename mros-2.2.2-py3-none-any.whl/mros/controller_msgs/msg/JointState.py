import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class JointState(mros.Message):
    __slots__ = ['header','names','q','v','vd','tau','na']
    _slot_types = ['std_msgs/Header','string[]','float32[]','float32[]','float32[]','float32[]','uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.names is None:
                self.names = []
            if self.q is None:
                self.q = []
            if self.v is None:
                self.v = []
            if self.vd is None:
                self.vd = []
            if self.tau is None:
                self.tau = []
            if self.na is None:
                self.na = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.names = []
            self.q = []
            self.v = []
            self.vd = []
            self.tau = []
            self.na = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            names_length = len(self.names)
            buff.write(struct.pack('<I', names_length))
            offset += 4
            for i in range(0, names_length):
                _x = self.names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            q_length = len(self.q)
            buff.write(struct.pack('<I', q_length))
            buff.write(struct.pack(f'<{q_length}f', *self.q))
            offset += 4 + q_length * 4
            v_length = len(self.v)
            buff.write(struct.pack('<I', v_length))
            buff.write(struct.pack(f'<{v_length}f', *self.v))
            offset += 4 + v_length * 4
            vd_length = len(self.vd)
            buff.write(struct.pack('<I', vd_length))
            buff.write(struct.pack(f'<{vd_length}f', *self.vd))
            offset += 4 + vd_length * 4
            tau_length = len(self.tau)
            buff.write(struct.pack('<I', tau_length))
            buff.write(struct.pack(f'<{tau_length}f', *self.tau))
            offset += 4 + tau_length * 4
            buff.write(_struct_I.pack(self.na))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.names) != names_length:
                self.names = ['' for _ in range(names_length)]
            for i in range(0, names_length):
                (length_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.names[i] = buff[offset:(offset + length_namesi)].decode('utf-8')
                else:
                    self.names[i] = buff[offset:(offset + length_namesi)]
                offset += length_namesi
            (q_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.q = np.frombuffer(buff[offset:offset + q_length * 4], dtype=np.float32)
            offset += q_length * 4
            (v_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.v = np.frombuffer(buff[offset:offset + v_length * 4], dtype=np.float32)
            offset += v_length * 4
            (vd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.vd = np.frombuffer(buff[offset:offset + vd_length * 4], dtype=np.float32)
            offset += vd_length * 4
            (tau_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.tau = np.frombuffer(buff[offset:offset + tau_length * 4], dtype=np.float32)
            offset += tau_length * 4
            (self.na,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, names_length):
            namesi_x = self.names[i]
            namesi_length = len(namesi_x)
            if python3 or type(namesi_x) == unicode:
                namesi_x = namesi_x.encode('utf-8')
                namesi_length = len(namesi_x)
            length += 4
            length += namesi_length
        length += 4
        length += len(self.q) * 4
        length += 4
        length += len(self.v) * 4
        length += 4
        length += len(self.vd) * 4
        length += 4
        length += len(self.tau) * 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"names":['
        names_length = len(self.names)
        for i in range(0, names_length):
            if i == (names_length - 1): 
                string_echo += '"names[i]":"%s"' % self.names[i]
                string_echo += ''
            else:
                string_echo += '"names[i]":"%s"' % self.names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"q":['
        q_length = len(self.q)
        for i in range(0, q_length):
            if i == (q_length - 1): 
                string_echo += '%s' % self.q[i]
            else:
                string_echo += '%s,' % self.q[i]
        string_echo += '],'
        string_echo += '"v":['
        v_length = len(self.v)
        for i in range(0, v_length):
            if i == (v_length - 1): 
                string_echo += '%s' % self.v[i]
            else:
                string_echo += '%s,' % self.v[i]
        string_echo += '],'
        string_echo += '"vd":['
        vd_length = len(self.vd)
        for i in range(0, vd_length):
            if i == (vd_length - 1): 
                string_echo += '%s' % self.vd[i]
            else:
                string_echo += '%s,' % self.vd[i]
        string_echo += '],'
        string_echo += '"tau":['
        tau_length = len(self.tau)
        for i in range(0, tau_length):
            if i == (tau_length - 1): 
                string_echo += '%s' % self.tau[i]
            else:
                string_echo += '%s,' % self.tau[i]
        string_echo += '],'
        string_echo += '"na":%s' % self.na
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/JointState"

    def getMD5(self):
        return "0d1d997e638ba23ee585b83a152596fe"

    def getDef(self):
        return "std_msgs/Header header\nstring[] names\nfloat32[] q\nfloat32[] v\nfloat32[] vd\nfloat32[] tau\nuint32 na\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

