import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class Pose(mros.Message):
    __slots__ = ['header','pos','quat']
    _slot_types = ['std_msgs/Header','float64[3]','float64[4]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Pose, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.pos is None:
                self.pos = [0. for x in range(0, 3)]
            if self.quat is None:
                self.quat = [0. for x in range(0, 4)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.pos = [0. for x in range(0, 3)]
            self.quat = [0. for x in range(0, 4)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{3}d', *self.pos))
            offset += 3 * 8
            buff.write(struct.pack(f'<{4}d', *self.quat))
            offset += 4 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.pos = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.quat = np.frombuffer(buff[offset:offset + 4 * 8], dtype=np.float64)
            offset += 4 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 3 * 8
        length += 4 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"pos":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.pos[i]
            else:
                string_echo += '%s,' % self.pos[i]
        string_echo += '],'
        string_echo += '"quat":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.quat[i]
            else:
                string_echo += '%s,' % self.quat[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/Pose"

    def getMD5(self):
        return "acf4b6103598281c478ef929f8951d1b"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[3] pos\nfloat64[4] quat\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

