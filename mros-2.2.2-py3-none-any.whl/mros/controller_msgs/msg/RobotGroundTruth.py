import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotGroundTruth(mros.Message):
    __slots__ = ['header','true_pos','true_vel']
    _slot_types = ['std_msgs/Header','float64[3]','float64[3]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotGroundTruth, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.true_pos is None:
                self.true_pos = [0. for x in range(0, 3)]
            if self.true_vel is None:
                self.true_vel = [0. for x in range(0, 3)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.true_pos = [0. for x in range(0, 3)]
            self.true_vel = [0. for x in range(0, 3)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{3}d', *self.true_pos))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.true_vel))
            offset += 3 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.true_pos = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.true_vel = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 3 * 8
        length += 3 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"true_pos":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.true_pos[i]
            else:
                string_echo += '%s,' % self.true_pos[i]
        string_echo += '],'
        string_echo += '"true_vel":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.true_vel[i]
            else:
                string_echo += '%s,' % self.true_vel[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotGroundTruth"

    def getMD5(self):
        return "138bf58a114f10bd2a66b719b24f38e2"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[3] true_pos\nfloat64[3] true_vel\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

