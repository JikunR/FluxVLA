import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class MeasuredStateHumanoid(mros.Message):
    __slots__ = ['header','imuData','jointsState','force']
    _slot_types = ['std_msgs/Header','controller_msgs/IMUData','controller_msgs/JointsStateHumanoid','int16[4]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MeasuredStateHumanoid, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.imuData is None:
                self.imuData = mros.controller_msgs.msg.IMUData()
            if self.jointsState is None:
                self.jointsState = mros.controller_msgs.msg.JointsStateHumanoid()
            if self.force is None:
                self.force = [0 for x in range(0, 4)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.imuData = mros.controller_msgs.msg.IMUData()
            self.jointsState = mros.controller_msgs.msg.JointsStateHumanoid()
            self.force = [0 for x in range(0, 4)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.imuData.serialize(buff)
            offset += self.jointsState.serialize(buff)
            buff.write(struct.pack(f'<{4}h', *self.force))
            offset += 4 * 2
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.imuData.deserialize(buff[offset:])
            offset += self.jointsState.deserialize(buff[offset:])
            self.force = np.frombuffer(buff[offset:offset + 4 * 2], dtype=np.int16)
            offset += 4 * 2
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.imuData.serializedLength()
        length += self.jointsState.serializedLength()
        length += 4 * 2
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"imuData":'
        string_echo += self.imuData.echo()
        string_echo += ','
        string_echo += '"jointsState":'
        string_echo += self.jointsState.echo()
        string_echo += ','
        string_echo += '"force":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.force[i]
            else:
                string_echo += '%s,' % self.force[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/MeasuredStateHumanoid"

    def getMD5(self):
        return "0f10d78fe4d5bf603712eab9384324c4"

    def getDef(self):
        return "std_msgs/Header header\ncontroller_msgs/IMUData imuData\ncontroller_msgs/JointsStateHumanoid jointsState\nint16[4] force\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: controller_msgs/IMUData\nstd_msgs/Header header\nuint64 imustamp\nuint32 status\nfloat64[3] euler\nfloat64[4] quat\nfloat64[3] acc\nfloat64[3] gyro\n================================================================================\nMSG: controller_msgs/JointsStateHumanoid\nstd_msgs/Header header\nfloat32[18] qpos\nfloat32[18] qvel\nfloat32[18] qacc\nfloat32[18] tau\n"

_struct_I = struct.Struct('<I')

