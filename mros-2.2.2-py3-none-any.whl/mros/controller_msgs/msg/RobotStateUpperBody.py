import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotStateUpperBody(mros.Message):
    __slots__ = ['header','qState','qdState','currentState','dc_voltage']
    _slot_types = ['std_msgs/Header','float32[8]','float32[8]','float32[8]','float32[8]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotStateUpperBody, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qState is None:
                self.qState = [0. for x in range(0, 8)]
            if self.qdState is None:
                self.qdState = [0. for x in range(0, 8)]
            if self.currentState is None:
                self.currentState = [0. for x in range(0, 8)]
            if self.dc_voltage is None:
                self.dc_voltage = [0. for x in range(0, 8)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qState = [0. for x in range(0, 8)]
            self.qdState = [0. for x in range(0, 8)]
            self.currentState = [0. for x in range(0, 8)]
            self.dc_voltage = [0. for x in range(0, 8)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{8}f', *self.qState))
            offset += 8 * 4
            buff.write(struct.pack(f'<{8}f', *self.qdState))
            offset += 8 * 4
            buff.write(struct.pack(f'<{8}f', *self.currentState))
            offset += 8 * 4
            buff.write(struct.pack(f'<{8}f', *self.dc_voltage))
            offset += 8 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.qState = np.frombuffer(buff[offset:offset + 8 * 4], dtype=np.float32)
            offset += 8 * 4
            self.qdState = np.frombuffer(buff[offset:offset + 8 * 4], dtype=np.float32)
            offset += 8 * 4
            self.currentState = np.frombuffer(buff[offset:offset + 8 * 4], dtype=np.float32)
            offset += 8 * 4
            self.dc_voltage = np.frombuffer(buff[offset:offset + 8 * 4], dtype=np.float32)
            offset += 8 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8 * 4
        length += 8 * 4
        length += 8 * 4
        length += 8 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qState":['
        for i in range(0, 8):
            if i == (8 - 1): 
                string_echo += '%s' % self.qState[i]
            else:
                string_echo += '%s,' % self.qState[i]
        string_echo += '],'
        string_echo += '"qdState":['
        for i in range(0, 8):
            if i == (8 - 1): 
                string_echo += '%s' % self.qdState[i]
            else:
                string_echo += '%s,' % self.qdState[i]
        string_echo += '],'
        string_echo += '"currentState":['
        for i in range(0, 8):
            if i == (8 - 1): 
                string_echo += '%s' % self.currentState[i]
            else:
                string_echo += '%s,' % self.currentState[i]
        string_echo += '],'
        string_echo += '"dc_voltage":['
        for i in range(0, 8):
            if i == (8 - 1): 
                string_echo += '%s' % self.dc_voltage[i]
            else:
                string_echo += '%s,' % self.dc_voltage[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotStateUpperBody"

    def getMD5(self):
        return "09d5d587c9bfbc25348db624b90ed784"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[8] qState\nfloat32[8] qdState\nfloat32[8] currentState\nfloat32[8] dc_voltage\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

