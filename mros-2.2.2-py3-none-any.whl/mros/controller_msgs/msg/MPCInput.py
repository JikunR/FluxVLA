import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class MPCInput(mros.Message):
    __slots__ = ['header','updated','first_run','iter','x0','xd','fd','cp_current','cp_next','contact_table','contact_horizon','payload_mass','payload_pos']
    _slot_types = ['std_msgs/Header','bool','bool','int32','float64[]','float64[]','float64[]','std_msgs/Float64Array[]','std_msgs/Float64Array[]','std_msgs/Int32Array[]','std_msgs/Int32Array[]','float64','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MPCInput, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.updated is None:
                self.updated = False
            if self.first_run is None:
                self.first_run = False
            if self.iter is None:
                self.iter = 0
            if self.x0 is None:
                self.x0 = []
            if self.xd is None:
                self.xd = []
            if self.fd is None:
                self.fd = []
            if self.cp_current is None:
                self.cp_current = []
            if self.cp_next is None:
                self.cp_next = []
            if self.contact_table is None:
                self.contact_table = []
            if self.contact_horizon is None:
                self.contact_horizon = []
            if self.payload_mass is None:
                self.payload_mass = 0.
            if self.payload_pos is None:
                self.payload_pos = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.updated = False
            self.first_run = False
            self.iter = 0
            self.x0 = []
            self.xd = []
            self.fd = []
            self.cp_current = []
            self.cp_next = []
            self.contact_table = []
            self.contact_horizon = []
            self.payload_mass = 0.
            self.payload_pos = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_updated = struct.Struct("<B")
            buff.write(struct_updated.pack(self.updated))
            offset += 1
            struct_first_run = struct.Struct("<B")
            buff.write(struct_first_run.pack(self.first_run))
            offset += 1
            struct_iter = struct.Struct("<i")
            buff.write(struct_iter.pack(self.iter))
            offset += 4
            x0_length = len(self.x0)
            buff.write(struct.pack('<I', x0_length))
            buff.write(struct.pack(f'<{x0_length}d', *self.x0))
            offset += 4 + x0_length * 8
            xd_length = len(self.xd)
            buff.write(struct.pack('<I', xd_length))
            buff.write(struct.pack(f'<{xd_length}d', *self.xd))
            offset += 4 + xd_length * 8
            fd_length = len(self.fd)
            buff.write(struct.pack('<I', fd_length))
            buff.write(struct.pack(f'<{fd_length}d', *self.fd))
            offset += 4 + fd_length * 8
            cp_current_length = len(self.cp_current)
            buff.write(struct.pack('<I', cp_current_length))
            offset += 4
            for i in range(0, cp_current_length):
                offset += self.cp_current[i].serialize(buff)
            cp_next_length = len(self.cp_next)
            buff.write(struct.pack('<I', cp_next_length))
            offset += 4
            for i in range(0, cp_next_length):
                offset += self.cp_next[i].serialize(buff)
            contact_table_length = len(self.contact_table)
            buff.write(struct.pack('<I', contact_table_length))
            offset += 4
            for i in range(0, contact_table_length):
                offset += self.contact_table[i].serialize(buff)
            contact_horizon_length = len(self.contact_horizon)
            buff.write(struct.pack('<I', contact_horizon_length))
            offset += 4
            for i in range(0, contact_horizon_length):
                offset += self.contact_horizon[i].serialize(buff)
            struct_payload_mass = struct.Struct("<d")
            buff.write(struct_payload_mass.pack(self.payload_mass))
            offset += 8
            payload_pos_length = len(self.payload_pos)
            buff.write(struct.pack('<I', payload_pos_length))
            buff.write(struct.pack(f'<{payload_pos_length}d', *self.payload_pos))
            offset += 4 + payload_pos_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_updated = struct.Struct("<B")
            (self.updated,) = struct_updated.unpack(buff[offset:(offset + 1)])
            self.updated = bool(self.updated)
            offset += 1
            struct_first_run = struct.Struct("<B")
            (self.first_run,) = struct_first_run.unpack(buff[offset:(offset + 1)])
            self.first_run = bool(self.first_run)
            offset += 1
            struct_iter = struct.Struct("<i")
            (self.iter,) = struct_iter.unpack(buff[offset:(offset + 4)])
            offset += 4
            (x0_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.x0 = np.frombuffer(buff[offset:offset + x0_length * 8], dtype=np.float64)
            offset += x0_length * 8
            (xd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.xd = np.frombuffer(buff[offset:offset + xd_length * 8], dtype=np.float64)
            offset += xd_length * 8
            (fd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.fd = np.frombuffer(buff[offset:offset + fd_length * 8], dtype=np.float64)
            offset += fd_length * 8
            (cp_current_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.cp_current) != cp_current_length:
                self.cp_current = [mros.std_msgs.msg.Float64Array() for _ in range(cp_current_length)]
            for i in range(0, cp_current_length):
                offset += self.cp_current[i].deserialize(buff[offset:])
            (cp_next_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.cp_next) != cp_next_length:
                self.cp_next = [mros.std_msgs.msg.Float64Array() for _ in range(cp_next_length)]
            for i in range(0, cp_next_length):
                offset += self.cp_next[i].deserialize(buff[offset:])
            (contact_table_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.contact_table) != contact_table_length:
                self.contact_table = [mros.std_msgs.msg.Int32Array() for _ in range(contact_table_length)]
            for i in range(0, contact_table_length):
                offset += self.contact_table[i].deserialize(buff[offset:])
            (contact_horizon_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.contact_horizon) != contact_horizon_length:
                self.contact_horizon = [mros.std_msgs.msg.Int32Array() for _ in range(contact_horizon_length)]
            for i in range(0, contact_horizon_length):
                offset += self.contact_horizon[i].deserialize(buff[offset:])
            struct_payload_mass = struct.Struct("<d")
            (self.payload_mass,) = struct_payload_mass.unpack(buff[offset:(offset + 8)])
            offset += 8
            (payload_pos_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.payload_pos = np.frombuffer(buff[offset:offset + payload_pos_length * 8], dtype=np.float64)
            offset += payload_pos_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 1
        length += 4
        length += 4
        length += len(self.x0) * 8
        length += 4
        length += len(self.xd) * 8
        length += 4
        length += len(self.fd) * 8
        length += 4
        for i in range(0, cp_current_length):
            length += self.cp_current[i].serializedLength()
        length += 4
        for i in range(0, cp_next_length):
            length += self.cp_next[i].serializedLength()
        length += 4
        for i in range(0, contact_table_length):
            length += self.contact_table[i].serializedLength()
        length += 4
        for i in range(0, contact_horizon_length):
            length += self.contact_horizon[i].serializedLength()
        length += 8
        length += 4
        length += len(self.payload_pos) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"updated":%s' % self.updated
        string_echo += ','
        string_echo += '"first_run":%s' % self.first_run
        string_echo += ','
        string_echo += '"iter":%s' % self.iter
        string_echo += ','
        string_echo += '"x0":['
        x0_length = len(self.x0)
        for i in range(0, x0_length):
            if i == (x0_length - 1): 
                string_echo += '%s' % self.x0[i]
            else:
                string_echo += '%s,' % self.x0[i]
        string_echo += '],'
        string_echo += '"xd":['
        xd_length = len(self.xd)
        for i in range(0, xd_length):
            if i == (xd_length - 1): 
                string_echo += '%s' % self.xd[i]
            else:
                string_echo += '%s,' % self.xd[i]
        string_echo += '],'
        string_echo += '"fd":['
        fd_length = len(self.fd)
        for i in range(0, fd_length):
            if i == (fd_length - 1): 
                string_echo += '%s' % self.fd[i]
            else:
                string_echo += '%s,' % self.fd[i]
        string_echo += '],'
        string_echo += '"cp_current":['
        cp_current_length = len(self.cp_current)
        for i in range(0, cp_current_length):
            if i == (cp_current_length - 1): 
                string_echo += '{cp_current%s":' % i
                string_echo += self.cp_current[i].echo()
                string_echo += ''
            else:
                string_echo += '{cp_current%s":' % i
                string_echo += self.cp_current[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"cp_next":['
        cp_next_length = len(self.cp_next)
        for i in range(0, cp_next_length):
            if i == (cp_next_length - 1): 
                string_echo += '{cp_next%s":' % i
                string_echo += self.cp_next[i].echo()
                string_echo += ''
            else:
                string_echo += '{cp_next%s":' % i
                string_echo += self.cp_next[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"contact_table":['
        contact_table_length = len(self.contact_table)
        for i in range(0, contact_table_length):
            if i == (contact_table_length - 1): 
                string_echo += '{contact_table%s":' % i
                string_echo += self.contact_table[i].echo()
                string_echo += ''
            else:
                string_echo += '{contact_table%s":' % i
                string_echo += self.contact_table[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"contact_horizon":['
        contact_horizon_length = len(self.contact_horizon)
        for i in range(0, contact_horizon_length):
            if i == (contact_horizon_length - 1): 
                string_echo += '{contact_horizon%s":' % i
                string_echo += self.contact_horizon[i].echo()
                string_echo += ''
            else:
                string_echo += '{contact_horizon%s":' % i
                string_echo += self.contact_horizon[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"payload_mass":%s' % self.payload_mass
        string_echo += ','
        string_echo += '"payload_pos":['
        payload_pos_length = len(self.payload_pos)
        for i in range(0, payload_pos_length):
            if i == (payload_pos_length - 1): 
                string_echo += '%s' % self.payload_pos[i]
            else:
                string_echo += '%s,' % self.payload_pos[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/MPCInput"

    def getMD5(self):
        return "a6c471d40c57591791dce4bc6be26154"

    def getDef(self):
        return "std_msgs/Header header\nbool updated\nbool first_run\nint32 iter\nfloat64[] x0\nfloat64[] xd\nfloat64[] fd\nstd_msgs/Float64Array[] cp_current\nstd_msgs/Float64Array[] cp_next\nstd_msgs/Int32Array[] contact_table\nstd_msgs/Int32Array[] contact_horizon\nfloat64 payload_mass\nfloat64[] payload_pos\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: std_msgs/Float64Array\nstd_msgs/Header header\nfloat64[] data\n================================================================================\nMSG: std_msgs/Int32Array\nstd_msgs/Header header\nint32[] data\n"

_struct_I = struct.Struct('<I')

