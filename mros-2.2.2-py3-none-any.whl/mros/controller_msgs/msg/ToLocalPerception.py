import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class ToLocalPerception(mros.Message):
    __slots__ = ['header','wRb','contact_indicator','pf','motion_type','time_stamp']
    _slot_types = ['std_msgs/Header','float64[9]','int16[4]','mros.geometry_msgs.msg.Point[4]','int8','int64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ToLocalPerception, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.wRb is None:
                self.wRb = [0. for x in range(0, 9)]
            if self.contact_indicator is None:
                self.contact_indicator = [0 for x in range(0, 4)]
            if self.pf is None:
                self.pf = [mros.geometry_msgs.msg.Point() for x in range(0, 4)]
            if self.motion_type is None:
                self.motion_type = 0
            if self.time_stamp is None:
                self.time_stamp = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.wRb = [0. for x in range(0, 9)]
            self.contact_indicator = [0 for x in range(0, 4)]
            self.pf = [mros.geometry_msgs.msg.Point() for x in range(0, 4)]
            self.motion_type = 0
            self.time_stamp = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{9}d', *self.wRb))
            offset += 9 * 8
            buff.write(struct.pack(f'<{4}h', *self.contact_indicator))
            offset += 4 * 2
            for i in range(0, 4):
                offset += self.pf[i].serialize(buff)
            struct_motion_type = struct.Struct("<b")
            buff.write(struct_motion_type.pack(self.motion_type))
            offset += 1
            struct_time_stamp = struct.Struct("<q")
            buff.write(struct_time_stamp.pack(self.time_stamp))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.wRb = np.frombuffer(buff[offset:offset + 9 * 8], dtype=np.float64)
            offset += 9 * 8
            self.contact_indicator = np.frombuffer(buff[offset:offset + 4 * 2], dtype=np.int16)
            offset += 4 * 2
            for i in range(0, 4):
                offset += self.pf[i].deserialize(buff[offset:])
            struct_motion_type = struct.Struct("<b")
            (self.motion_type,) = struct_motion_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_time_stamp = struct.Struct("<q")
            (self.time_stamp,) = struct_time_stamp.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 9 * 8
        length += 4 * 2
        for i in range(0, 4):
            length += self.pf[i].serializedLength()
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"wRb":['
        for i in range(0, 9):
            if i == (9 - 1): 
                string_echo += '%s' % self.wRb[i]
            else:
                string_echo += '%s,' % self.wRb[i]
        string_echo += '],'
        string_echo += '"contact_indicator":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.contact_indicator[i]
            else:
                string_echo += '%s,' % self.contact_indicator[i]
        string_echo += '],'
        string_echo += '"pf":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '{pf%s":' % i
                string_echo += self.pf[i].echo()
                string_echo += ''
            else:
                string_echo += '{pf%s":' % i
                string_echo += self.pf[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"motion_type":%s' % self.motion_type
        string_echo += ','
        string_echo += '"time_stamp":%s' % self.time_stamp
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/ToLocalPerception"

    def getMD5(self):
        return "2695895c00758d88293902ec92c05d27"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[9] wRb\nint16[4] contact_indicator\ngeometry_msgs/Point[4] pf\nint8 motion_type\nint64 time_stamp\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

