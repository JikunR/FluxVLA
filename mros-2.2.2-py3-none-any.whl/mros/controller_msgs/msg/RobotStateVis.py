import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotStateVis(mros.Message):
    __slots__ = ['header','base_pos','base_quat','base_vel','base_omega','joint_pos','nj','contact_phase']
    _slot_types = ['std_msgs/Header','float32[3]','float32[4]','float32[3]','float32[3]','float32[]','uint32','float64[2]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotStateVis, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.base_pos is None:
                self.base_pos = [0. for x in range(0, 3)]
            if self.base_quat is None:
                self.base_quat = [0. for x in range(0, 4)]
            if self.base_vel is None:
                self.base_vel = [0. for x in range(0, 3)]
            if self.base_omega is None:
                self.base_omega = [0. for x in range(0, 3)]
            if self.joint_pos is None:
                self.joint_pos = []
            if self.nj is None:
                self.nj = 0
            if self.contact_phase is None:
                self.contact_phase = [0. for x in range(0, 2)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.base_pos = [0. for x in range(0, 3)]
            self.base_quat = [0. for x in range(0, 4)]
            self.base_vel = [0. for x in range(0, 3)]
            self.base_omega = [0. for x in range(0, 3)]
            self.joint_pos = []
            self.nj = 0
            self.contact_phase = [0. for x in range(0, 2)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{3}f', *self.base_pos))
            offset += 3 * 4
            buff.write(struct.pack(f'<{4}f', *self.base_quat))
            offset += 4 * 4
            buff.write(struct.pack(f'<{3}f', *self.base_vel))
            offset += 3 * 4
            buff.write(struct.pack(f'<{3}f', *self.base_omega))
            offset += 3 * 4
            joint_pos_length = len(self.joint_pos)
            buff.write(struct.pack('<I', joint_pos_length))
            buff.write(struct.pack(f'<{joint_pos_length}f', *self.joint_pos))
            offset += 4 + joint_pos_length * 4
            buff.write(_struct_I.pack(self.nj))
            offset += 4
            buff.write(struct.pack(f'<{2}d', *self.contact_phase))
            offset += 2 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.base_pos = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            self.base_quat = np.frombuffer(buff[offset:offset + 4 * 4], dtype=np.float32)
            offset += 4 * 4
            self.base_vel = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            self.base_omega = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            (joint_pos_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.joint_pos = np.frombuffer(buff[offset:offset + joint_pos_length * 4], dtype=np.float32)
            offset += joint_pos_length * 4
            (self.nj,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.contact_phase = np.frombuffer(buff[offset:offset + 2 * 8], dtype=np.float64)
            offset += 2 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 3 * 4
        length += 4 * 4
        length += 3 * 4
        length += 3 * 4
        length += 4
        length += len(self.joint_pos) * 4
        length += 4
        length += 2 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"base_pos":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.base_pos[i]
            else:
                string_echo += '%s,' % self.base_pos[i]
        string_echo += '],'
        string_echo += '"base_quat":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.base_quat[i]
            else:
                string_echo += '%s,' % self.base_quat[i]
        string_echo += '],'
        string_echo += '"base_vel":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.base_vel[i]
            else:
                string_echo += '%s,' % self.base_vel[i]
        string_echo += '],'
        string_echo += '"base_omega":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.base_omega[i]
            else:
                string_echo += '%s,' % self.base_omega[i]
        string_echo += '],'
        string_echo += '"joint_pos":['
        joint_pos_length = len(self.joint_pos)
        for i in range(0, joint_pos_length):
            if i == (joint_pos_length - 1): 
                string_echo += '%s' % self.joint_pos[i]
            else:
                string_echo += '%s,' % self.joint_pos[i]
        string_echo += '],'
        string_echo += '"nj":%s' % self.nj
        string_echo += ','
        string_echo += '"contact_phase":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.contact_phase[i]
            else:
                string_echo += '%s,' % self.contact_phase[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotStateVis"

    def getMD5(self):
        return "47e20195e0d4c3d0a953852d4d78eb49"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[3] base_pos\nfloat32[4] base_quat\nfloat32[3] base_vel\nfloat32[3] base_omega\nfloat32[] joint_pos\nuint32 nj\nfloat64[2] contact_phase\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

