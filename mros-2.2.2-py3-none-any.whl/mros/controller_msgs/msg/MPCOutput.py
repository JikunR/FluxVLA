import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class MPCOutput(mros.Message):
    __slots__ = ['header','updated','iter','desired_contact_force','discrete_optimized_trajectory','xdot']
    _slot_types = ['std_msgs/Header','bool','int32','float64[]','float64[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MPCOutput, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.updated is None:
                self.updated = False
            if self.iter is None:
                self.iter = 0
            if self.desired_contact_force is None:
                self.desired_contact_force = []
            if self.discrete_optimized_trajectory is None:
                self.discrete_optimized_trajectory = []
            if self.xdot is None:
                self.xdot = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.updated = False
            self.iter = 0
            self.desired_contact_force = []
            self.discrete_optimized_trajectory = []
            self.xdot = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_updated = struct.Struct("<B")
            buff.write(struct_updated.pack(self.updated))
            offset += 1
            struct_iter = struct.Struct("<i")
            buff.write(struct_iter.pack(self.iter))
            offset += 4
            desired_contact_force_length = len(self.desired_contact_force)
            buff.write(struct.pack('<I', desired_contact_force_length))
            buff.write(struct.pack(f'<{desired_contact_force_length}d', *self.desired_contact_force))
            offset += 4 + desired_contact_force_length * 8
            discrete_optimized_trajectory_length = len(self.discrete_optimized_trajectory)
            buff.write(struct.pack('<I', discrete_optimized_trajectory_length))
            buff.write(struct.pack(f'<{discrete_optimized_trajectory_length}d', *self.discrete_optimized_trajectory))
            offset += 4 + discrete_optimized_trajectory_length * 8
            xdot_length = len(self.xdot)
            buff.write(struct.pack('<I', xdot_length))
            buff.write(struct.pack(f'<{xdot_length}d', *self.xdot))
            offset += 4 + xdot_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_updated = struct.Struct("<B")
            (self.updated,) = struct_updated.unpack(buff[offset:(offset + 1)])
            self.updated = bool(self.updated)
            offset += 1
            struct_iter = struct.Struct("<i")
            (self.iter,) = struct_iter.unpack(buff[offset:(offset + 4)])
            offset += 4
            (desired_contact_force_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.desired_contact_force = np.frombuffer(buff[offset:offset + desired_contact_force_length * 8], dtype=np.float64)
            offset += desired_contact_force_length * 8
            (discrete_optimized_trajectory_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.discrete_optimized_trajectory = np.frombuffer(buff[offset:offset + discrete_optimized_trajectory_length * 8], dtype=np.float64)
            offset += discrete_optimized_trajectory_length * 8
            (xdot_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.xdot = np.frombuffer(buff[offset:offset + xdot_length * 8], dtype=np.float64)
            offset += xdot_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 4
        length += 4
        length += len(self.desired_contact_force) * 8
        length += 4
        length += len(self.discrete_optimized_trajectory) * 8
        length += 4
        length += len(self.xdot) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"updated":%s' % self.updated
        string_echo += ','
        string_echo += '"iter":%s' % self.iter
        string_echo += ','
        string_echo += '"desired_contact_force":['
        desired_contact_force_length = len(self.desired_contact_force)
        for i in range(0, desired_contact_force_length):
            if i == (desired_contact_force_length - 1): 
                string_echo += '%s' % self.desired_contact_force[i]
            else:
                string_echo += '%s,' % self.desired_contact_force[i]
        string_echo += '],'
        string_echo += '"discrete_optimized_trajectory":['
        discrete_optimized_trajectory_length = len(self.discrete_optimized_trajectory)
        for i in range(0, discrete_optimized_trajectory_length):
            if i == (discrete_optimized_trajectory_length - 1): 
                string_echo += '%s' % self.discrete_optimized_trajectory[i]
            else:
                string_echo += '%s,' % self.discrete_optimized_trajectory[i]
        string_echo += '],'
        string_echo += '"xdot":['
        xdot_length = len(self.xdot)
        for i in range(0, xdot_length):
            if i == (xdot_length - 1): 
                string_echo += '%s' % self.xdot[i]
            else:
                string_echo += '%s,' % self.xdot[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/MPCOutput"

    def getMD5(self):
        return "fcb90c087c37dc305ce8df4f60c0fe94"

    def getDef(self):
        return "std_msgs/Header header\nbool updated\nint32 iter\nfloat64[] desired_contact_force\nfloat64[] discrete_optimized_trajectory\nfloat64[] xdot\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

