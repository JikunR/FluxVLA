import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotWrenchUpperBody(mros.Message):
    __slots__ = ['header','leftArm','rightArm']
    _slot_types = ['std_msgs/Header','float32[6]','float32[6]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotWrenchUpperBody, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.leftArm is None:
                self.leftArm = [0. for x in range(0, 6)]
            if self.rightArm is None:
                self.rightArm = [0. for x in range(0, 6)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.leftArm = [0. for x in range(0, 6)]
            self.rightArm = [0. for x in range(0, 6)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{6}f', *self.leftArm))
            offset += 6 * 4
            buff.write(struct.pack(f'<{6}f', *self.rightArm))
            offset += 6 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.leftArm = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.rightArm = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 6 * 4
        length += 6 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"leftArm":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.leftArm[i]
            else:
                string_echo += '%s,' % self.leftArm[i]
        string_echo += '],'
        string_echo += '"rightArm":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.rightArm[i]
            else:
                string_echo += '%s,' % self.rightArm[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotWrenchUpperBody"

    def getMD5(self):
        return "90bac017ed40aab4455a139178425582"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[6] leftArm\nfloat32[6] rightArm\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

