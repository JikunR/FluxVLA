import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RCASCmdStampedWL(mros.Message):
    __slots__ = ['header','vx','vy','w','roll','pitch','yaw','height','gait']
    _slot_types = ['std_msgs/Header','float64','float64','float64','float64','float64','float64','float64','int8']

    GAIT_STAND =  1
    GAIT_TROT_WALK =  2
    GAIT_STAND_TROT =  3

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RCASCmdStampedWL, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.vx is None:
                self.vx = 0.
            if self.vy is None:
                self.vy = 0.
            if self.w is None:
                self.w = 0.
            if self.roll is None:
                self.roll = 0.
            if self.pitch is None:
                self.pitch = 0.
            if self.yaw is None:
                self.yaw = 0.
            if self.height is None:
                self.height = 0.
            if self.gait is None:
                self.gait = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.vx = 0.
            self.vy = 0.
            self.w = 0.
            self.roll = 0.
            self.pitch = 0.
            self.yaw = 0.
            self.height = 0.
            self.gait = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_vx = struct.Struct("<d")
            buff.write(struct_vx.pack(self.vx))
            offset += 8
            struct_vy = struct.Struct("<d")
            buff.write(struct_vy.pack(self.vy))
            offset += 8
            struct_w = struct.Struct("<d")
            buff.write(struct_w.pack(self.w))
            offset += 8
            struct_roll = struct.Struct("<d")
            buff.write(struct_roll.pack(self.roll))
            offset += 8
            struct_pitch = struct.Struct("<d")
            buff.write(struct_pitch.pack(self.pitch))
            offset += 8
            struct_yaw = struct.Struct("<d")
            buff.write(struct_yaw.pack(self.yaw))
            offset += 8
            struct_height = struct.Struct("<d")
            buff.write(struct_height.pack(self.height))
            offset += 8
            struct_gait = struct.Struct("<b")
            buff.write(struct_gait.pack(self.gait))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_vx = struct.Struct("<d")
            (self.vx,) = struct_vx.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_vy = struct.Struct("<d")
            (self.vy,) = struct_vy.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_w = struct.Struct("<d")
            (self.w,) = struct_w.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_roll = struct.Struct("<d")
            (self.roll,) = struct_roll.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_pitch = struct.Struct("<d")
            (self.pitch,) = struct_pitch.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_yaw = struct.Struct("<d")
            (self.yaw,) = struct_yaw.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_height = struct.Struct("<d")
            (self.height,) = struct_height.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_gait = struct.Struct("<b")
            (self.gait,) = struct_gait.unpack(buff[offset:(offset + 1)])
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"vx":%s' % self.vx
        string_echo += ','
        string_echo += '"vy":%s' % self.vy
        string_echo += ','
        string_echo += '"w":%s' % self.w
        string_echo += ','
        string_echo += '"roll":%s' % self.roll
        string_echo += ','
        string_echo += '"pitch":%s' % self.pitch
        string_echo += ','
        string_echo += '"yaw":%s' % self.yaw
        string_echo += ','
        string_echo += '"height":%s' % self.height
        string_echo += ','
        string_echo += '"gait":%s' % self.gait
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RCASCmdStampedWL"

    def getMD5(self):
        return "0197db14404650210fcc1b048026a46d"

    def getDef(self):
        return "std_msgs/Header header\nfloat64 vx\nfloat64 vy\nfloat64 w\nfloat64 roll\nfloat64 pitch\nfloat64 yaw\nfloat64 height\nint8 GAIT_STAND = 1\nint8 GAIT_TROT_WALK = 2\nint8 GAIT_STAND_TROT = 3\nint8 gait\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

