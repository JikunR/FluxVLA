import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotStateTeleoperation(mros.Message):
    __slots__ = ['header','qState','qdState','currentState']
    _slot_types = ['std_msgs/Header','float64[16]','float64[16]','float64[16]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotStateTeleoperation, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qState is None:
                self.qState = [0. for x in range(0, 16)]
            if self.qdState is None:
                self.qdState = [0. for x in range(0, 16)]
            if self.currentState is None:
                self.currentState = [0. for x in range(0, 16)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qState = [0. for x in range(0, 16)]
            self.qdState = [0. for x in range(0, 16)]
            self.currentState = [0. for x in range(0, 16)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{16}d', *self.qState))
            offset += 16 * 8
            buff.write(struct.pack(f'<{16}d', *self.qdState))
            offset += 16 * 8
            buff.write(struct.pack(f'<{16}d', *self.currentState))
            offset += 16 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.qState = np.frombuffer(buff[offset:offset + 16 * 8], dtype=np.float64)
            offset += 16 * 8
            self.qdState = np.frombuffer(buff[offset:offset + 16 * 8], dtype=np.float64)
            offset += 16 * 8
            self.currentState = np.frombuffer(buff[offset:offset + 16 * 8], dtype=np.float64)
            offset += 16 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 16 * 8
        length += 16 * 8
        length += 16 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qState":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.qState[i]
            else:
                string_echo += '%s,' % self.qState[i]
        string_echo += '],'
        string_echo += '"qdState":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.qdState[i]
            else:
                string_echo += '%s,' % self.qdState[i]
        string_echo += '],'
        string_echo += '"currentState":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.currentState[i]
            else:
                string_echo += '%s,' % self.currentState[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotStateTeleoperation"

    def getMD5(self):
        return "b7f3e3b140c30e6edfa1e98ac6d2787f"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[16] qState\nfloat64[16] qdState\nfloat64[16] currentState\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

