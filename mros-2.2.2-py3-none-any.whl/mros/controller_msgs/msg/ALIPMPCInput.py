import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class ALIPMPCInput(mros.Message):
    __slots__ = ['header','updated','first_run','iter','body_height_ref','CoM_offset_World','position_ref_world','velocity_ref_world','position_state_world','velocity_state_world','contact_table','footPos','bothFootPos']
    _slot_types = ['std_msgs/Header','bool','bool','int32','float64','float64[3]','float64[6]','float64[6]','float64[6]','float64[6]','std_msgs/Int32Array[]','std_msgs/Float64Array[]','std_msgs/Float64Array[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ALIPMPCInput, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.updated is None:
                self.updated = False
            if self.first_run is None:
                self.first_run = False
            if self.iter is None:
                self.iter = 0
            if self.body_height_ref is None:
                self.body_height_ref = 0.
            if self.CoM_offset_World is None:
                self.CoM_offset_World = [0. for x in range(0, 3)]
            if self.position_ref_world is None:
                self.position_ref_world = [0. for x in range(0, 6)]
            if self.velocity_ref_world is None:
                self.velocity_ref_world = [0. for x in range(0, 6)]
            if self.position_state_world is None:
                self.position_state_world = [0. for x in range(0, 6)]
            if self.velocity_state_world is None:
                self.velocity_state_world = [0. for x in range(0, 6)]
            if self.contact_table is None:
                self.contact_table = []
            if self.footPos is None:
                self.footPos = []
            if self.bothFootPos is None:
                self.bothFootPos = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.updated = False
            self.first_run = False
            self.iter = 0
            self.body_height_ref = 0.
            self.CoM_offset_World = [0. for x in range(0, 3)]
            self.position_ref_world = [0. for x in range(0, 6)]
            self.velocity_ref_world = [0. for x in range(0, 6)]
            self.position_state_world = [0. for x in range(0, 6)]
            self.velocity_state_world = [0. for x in range(0, 6)]
            self.contact_table = []
            self.footPos = []
            self.bothFootPos = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_updated = struct.Struct("<B")
            buff.write(struct_updated.pack(self.updated))
            offset += 1
            struct_first_run = struct.Struct("<B")
            buff.write(struct_first_run.pack(self.first_run))
            offset += 1
            struct_iter = struct.Struct("<i")
            buff.write(struct_iter.pack(self.iter))
            offset += 4
            struct_body_height_ref = struct.Struct("<d")
            buff.write(struct_body_height_ref.pack(self.body_height_ref))
            offset += 8
            buff.write(struct.pack(f'<{3}d', *self.CoM_offset_World))
            offset += 3 * 8
            buff.write(struct.pack(f'<{6}d', *self.position_ref_world))
            offset += 6 * 8
            buff.write(struct.pack(f'<{6}d', *self.velocity_ref_world))
            offset += 6 * 8
            buff.write(struct.pack(f'<{6}d', *self.position_state_world))
            offset += 6 * 8
            buff.write(struct.pack(f'<{6}d', *self.velocity_state_world))
            offset += 6 * 8
            contact_table_length = len(self.contact_table)
            buff.write(struct.pack('<I', contact_table_length))
            offset += 4
            for i in range(0, contact_table_length):
                offset += self.contact_table[i].serialize(buff)
            footPos_length = len(self.footPos)
            buff.write(struct.pack('<I', footPos_length))
            offset += 4
            for i in range(0, footPos_length):
                offset += self.footPos[i].serialize(buff)
            bothFootPos_length = len(self.bothFootPos)
            buff.write(struct.pack('<I', bothFootPos_length))
            offset += 4
            for i in range(0, bothFootPos_length):
                offset += self.bothFootPos[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_updated = struct.Struct("<B")
            (self.updated,) = struct_updated.unpack(buff[offset:(offset + 1)])
            self.updated = bool(self.updated)
            offset += 1
            struct_first_run = struct.Struct("<B")
            (self.first_run,) = struct_first_run.unpack(buff[offset:(offset + 1)])
            self.first_run = bool(self.first_run)
            offset += 1
            struct_iter = struct.Struct("<i")
            (self.iter,) = struct_iter.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_body_height_ref = struct.Struct("<d")
            (self.body_height_ref,) = struct_body_height_ref.unpack(buff[offset:(offset + 8)])
            offset += 8
            self.CoM_offset_World = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.position_ref_world = np.frombuffer(buff[offset:offset + 6 * 8], dtype=np.float64)
            offset += 6 * 8
            self.velocity_ref_world = np.frombuffer(buff[offset:offset + 6 * 8], dtype=np.float64)
            offset += 6 * 8
            self.position_state_world = np.frombuffer(buff[offset:offset + 6 * 8], dtype=np.float64)
            offset += 6 * 8
            self.velocity_state_world = np.frombuffer(buff[offset:offset + 6 * 8], dtype=np.float64)
            offset += 6 * 8
            (contact_table_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.contact_table) != contact_table_length:
                self.contact_table = [mros.std_msgs.msg.Int32Array() for _ in range(contact_table_length)]
            for i in range(0, contact_table_length):
                offset += self.contact_table[i].deserialize(buff[offset:])
            (footPos_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.footPos) != footPos_length:
                self.footPos = [mros.std_msgs.msg.Float64Array() for _ in range(footPos_length)]
            for i in range(0, footPos_length):
                offset += self.footPos[i].deserialize(buff[offset:])
            (bothFootPos_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.bothFootPos) != bothFootPos_length:
                self.bothFootPos = [mros.std_msgs.msg.Float64Array() for _ in range(bothFootPos_length)]
            for i in range(0, bothFootPos_length):
                offset += self.bothFootPos[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 1
        length += 4
        length += 8
        length += 3 * 8
        length += 6 * 8
        length += 6 * 8
        length += 6 * 8
        length += 6 * 8
        length += 4
        for i in range(0, contact_table_length):
            length += self.contact_table[i].serializedLength()
        length += 4
        for i in range(0, footPos_length):
            length += self.footPos[i].serializedLength()
        length += 4
        for i in range(0, bothFootPos_length):
            length += self.bothFootPos[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"updated":%s' % self.updated
        string_echo += ','
        string_echo += '"first_run":%s' % self.first_run
        string_echo += ','
        string_echo += '"iter":%s' % self.iter
        string_echo += ','
        string_echo += '"body_height_ref":%s' % self.body_height_ref
        string_echo += ','
        string_echo += '"CoM_offset_World":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.CoM_offset_World[i]
            else:
                string_echo += '%s,' % self.CoM_offset_World[i]
        string_echo += '],'
        string_echo += '"position_ref_world":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.position_ref_world[i]
            else:
                string_echo += '%s,' % self.position_ref_world[i]
        string_echo += '],'
        string_echo += '"velocity_ref_world":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.velocity_ref_world[i]
            else:
                string_echo += '%s,' % self.velocity_ref_world[i]
        string_echo += '],'
        string_echo += '"position_state_world":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.position_state_world[i]
            else:
                string_echo += '%s,' % self.position_state_world[i]
        string_echo += '],'
        string_echo += '"velocity_state_world":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.velocity_state_world[i]
            else:
                string_echo += '%s,' % self.velocity_state_world[i]
        string_echo += '],'
        string_echo += '"contact_table":['
        contact_table_length = len(self.contact_table)
        for i in range(0, contact_table_length):
            if i == (contact_table_length - 1): 
                string_echo += '{contact_table%s":' % i
                string_echo += self.contact_table[i].echo()
                string_echo += ''
            else:
                string_echo += '{contact_table%s":' % i
                string_echo += self.contact_table[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"footPos":['
        footPos_length = len(self.footPos)
        for i in range(0, footPos_length):
            if i == (footPos_length - 1): 
                string_echo += '{footPos%s":' % i
                string_echo += self.footPos[i].echo()
                string_echo += ''
            else:
                string_echo += '{footPos%s":' % i
                string_echo += self.footPos[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"bothFootPos":['
        bothFootPos_length = len(self.bothFootPos)
        for i in range(0, bothFootPos_length):
            if i == (bothFootPos_length - 1): 
                string_echo += '{bothFootPos%s":' % i
                string_echo += self.bothFootPos[i].echo()
                string_echo += ''
            else:
                string_echo += '{bothFootPos%s":' % i
                string_echo += self.bothFootPos[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/ALIPMPCInput"

    def getMD5(self):
        return "8086cd5ac1a593111703fcb9359ca9ef"

    def getDef(self):
        return "std_msgs/Header header\nbool updated\nbool first_run\nint32 iter\nfloat64 body_height_ref\nfloat64[3] CoM_offset_World\nfloat64[6] position_ref_world\nfloat64[6] velocity_ref_world\nfloat64[6] position_state_world\nfloat64[6] velocity_state_world\nstd_msgs/Int32Array[] contact_table\nstd_msgs/Float64Array[] footPos\nstd_msgs/Float64Array[] bothFootPos\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: std_msgs/Int32Array\nstd_msgs/Header header\nint32[] data\n================================================================================\nMSG: std_msgs/Float64Array\nstd_msgs/Header header\nfloat64[] data\n"

_struct_I = struct.Struct('<I')

