import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotCmds(mros.Message):
    __slots__ = ['header','qCmd','qdCmd','kpCmd','kdCmd','currentCmd','mode']
    _slot_types = ['std_msgs/Header','float32[]','float32[]','float32[]','float32[]','float32[]','uint8[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotCmds, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qCmd is None:
                self.qCmd = []
            if self.qdCmd is None:
                self.qdCmd = []
            if self.kpCmd is None:
                self.kpCmd = []
            if self.kdCmd is None:
                self.kdCmd = []
            if self.currentCmd is None:
                self.currentCmd = []
            if self.mode is None:
                self.mode = ''
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qCmd = []
            self.qdCmd = []
            self.kpCmd = []
            self.kdCmd = []
            self.currentCmd = []
            self.mode = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            qCmd_length = len(self.qCmd)
            buff.write(struct.pack('<I', qCmd_length))
            buff.write(struct.pack(f'<{qCmd_length}f', *self.qCmd))
            offset += 4 + qCmd_length * 4
            qdCmd_length = len(self.qdCmd)
            buff.write(struct.pack('<I', qdCmd_length))
            buff.write(struct.pack(f'<{qdCmd_length}f', *self.qdCmd))
            offset += 4 + qdCmd_length * 4
            kpCmd_length = len(self.kpCmd)
            buff.write(struct.pack('<I', kpCmd_length))
            buff.write(struct.pack(f'<{kpCmd_length}f', *self.kpCmd))
            offset += 4 + kpCmd_length * 4
            kdCmd_length = len(self.kdCmd)
            buff.write(struct.pack('<I', kdCmd_length))
            buff.write(struct.pack(f'<{kdCmd_length}f', *self.kdCmd))
            offset += 4 + kdCmd_length * 4
            currentCmd_length = len(self.currentCmd)
            buff.write(struct.pack('<I', currentCmd_length))
            buff.write(struct.pack(f'<{currentCmd_length}f', *self.currentCmd))
            offset += 4 + currentCmd_length * 4
            mode_length = len(self.mode)
            buff.write(struct.pack('<I', mode_length))
            buff.write(struct.pack(f'<{mode_length}B', *self.mode))
            offset += 4 + mode_length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (qCmd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qCmd = np.frombuffer(buff[offset:offset + qCmd_length * 4], dtype=np.float32)
            offset += qCmd_length * 4
            (qdCmd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qdCmd = np.frombuffer(buff[offset:offset + qdCmd_length * 4], dtype=np.float32)
            offset += qdCmd_length * 4
            (kpCmd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.kpCmd = np.frombuffer(buff[offset:offset + kpCmd_length * 4], dtype=np.float32)
            offset += kpCmd_length * 4
            (kdCmd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.kdCmd = np.frombuffer(buff[offset:offset + kdCmd_length * 4], dtype=np.float32)
            offset += kdCmd_length * 4
            (currentCmd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.currentCmd = np.frombuffer(buff[offset:offset + currentCmd_length * 4], dtype=np.float32)
            offset += currentCmd_length * 4
            (mode_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.mode = np.frombuffer(buff[offset:offset + mode_length], dtype=np.uint8)
            offset += mode_length
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.qCmd) * 4
        length += 4
        length += len(self.qdCmd) * 4
        length += 4
        length += len(self.kpCmd) * 4
        length += 4
        length += len(self.kdCmd) * 4
        length += 4
        length += len(self.currentCmd) * 4
        length += 4
        length += len(self.mode)
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qCmd":['
        qCmd_length = len(self.qCmd)
        for i in range(0, qCmd_length):
            if i == (qCmd_length - 1): 
                string_echo += '%s' % self.qCmd[i]
            else:
                string_echo += '%s,' % self.qCmd[i]
        string_echo += '],'
        string_echo += '"qdCmd":['
        qdCmd_length = len(self.qdCmd)
        for i in range(0, qdCmd_length):
            if i == (qdCmd_length - 1): 
                string_echo += '%s' % self.qdCmd[i]
            else:
                string_echo += '%s,' % self.qdCmd[i]
        string_echo += '],'
        string_echo += '"kpCmd":['
        kpCmd_length = len(self.kpCmd)
        for i in range(0, kpCmd_length):
            if i == (kpCmd_length - 1): 
                string_echo += '%s' % self.kpCmd[i]
            else:
                string_echo += '%s,' % self.kpCmd[i]
        string_echo += '],'
        string_echo += '"kdCmd":['
        kdCmd_length = len(self.kdCmd)
        for i in range(0, kdCmd_length):
            if i == (kdCmd_length - 1): 
                string_echo += '%s' % self.kdCmd[i]
            else:
                string_echo += '%s,' % self.kdCmd[i]
        string_echo += '],'
        string_echo += '"currentCmd":['
        currentCmd_length = len(self.currentCmd)
        for i in range(0, currentCmd_length):
            if i == (currentCmd_length - 1): 
                string_echo += '%s' % self.currentCmd[i]
            else:
                string_echo += '%s,' % self.currentCmd[i]
        string_echo += '],'
        string_echo += '"mode":['
        mode_length = len(self.mode)
        for i in range(0, mode_length):
            if i == (mode_length - 1): 
                string_echo += '%s' % self.mode[i]
            else:
                string_echo += '%s,' % self.mode[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotCmds"

    def getMD5(self):
        return "585795f6d10d80fb27e1f8f9bf1ada3b"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[] qCmd\nfloat32[] qdCmd\nfloat32[] kpCmd\nfloat32[] kdCmd\nfloat32[] currentCmd\nuint8[] mode\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

