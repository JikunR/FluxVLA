import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class HandTaskData(mros.Message):
    __slots__ = ['header','pose','twist','accel','gripper']
    _slot_types = ['std_msgs/Header','geometry_msgs/Pose[]','geometry_msgs/Twist[]','geometry_msgs/Accel[]','float32[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HandTaskData, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.pose is None:
                self.pose = []
            if self.twist is None:
                self.twist = []
            if self.accel is None:
                self.accel = []
            if self.gripper is None:
                self.gripper = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.pose = []
            self.twist = []
            self.accel = []
            self.gripper = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            pose_length = len(self.pose)
            buff.write(struct.pack('<I', pose_length))
            offset += 4
            for i in range(0, pose_length):
                offset += self.pose[i].serialize(buff)
            twist_length = len(self.twist)
            buff.write(struct.pack('<I', twist_length))
            offset += 4
            for i in range(0, twist_length):
                offset += self.twist[i].serialize(buff)
            accel_length = len(self.accel)
            buff.write(struct.pack('<I', accel_length))
            offset += 4
            for i in range(0, accel_length):
                offset += self.accel[i].serialize(buff)
            gripper_length = len(self.gripper)
            buff.write(struct.pack('<I', gripper_length))
            buff.write(struct.pack(f'<{gripper_length}f', *self.gripper))
            offset += 4 + gripper_length * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (pose_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.pose) != pose_length:
                self.pose = [mros.geometry_msgs.msg.Pose() for _ in range(pose_length)]
            for i in range(0, pose_length):
                offset += self.pose[i].deserialize(buff[offset:])
            (twist_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.twist) != twist_length:
                self.twist = [mros.geometry_msgs.msg.Twist() for _ in range(twist_length)]
            for i in range(0, twist_length):
                offset += self.twist[i].deserialize(buff[offset:])
            (accel_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.accel) != accel_length:
                self.accel = [mros.geometry_msgs.msg.Accel() for _ in range(accel_length)]
            for i in range(0, accel_length):
                offset += self.accel[i].deserialize(buff[offset:])
            (gripper_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.gripper = np.frombuffer(buff[offset:offset + gripper_length * 4], dtype=np.float32)
            offset += gripper_length * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, pose_length):
            length += self.pose[i].serializedLength()
        length += 4
        for i in range(0, twist_length):
            length += self.twist[i].serializedLength()
        length += 4
        for i in range(0, accel_length):
            length += self.accel[i].serializedLength()
        length += 4
        length += len(self.gripper) * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"pose":['
        pose_length = len(self.pose)
        for i in range(0, pose_length):
            if i == (pose_length - 1): 
                string_echo += '{pose%s":' % i
                string_echo += self.pose[i].echo()
                string_echo += ''
            else:
                string_echo += '{pose%s":' % i
                string_echo += self.pose[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"twist":['
        twist_length = len(self.twist)
        for i in range(0, twist_length):
            if i == (twist_length - 1): 
                string_echo += '{twist%s":' % i
                string_echo += self.twist[i].echo()
                string_echo += ''
            else:
                string_echo += '{twist%s":' % i
                string_echo += self.twist[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"accel":['
        accel_length = len(self.accel)
        for i in range(0, accel_length):
            if i == (accel_length - 1): 
                string_echo += '{accel%s":' % i
                string_echo += self.accel[i].echo()
                string_echo += ''
            else:
                string_echo += '{accel%s":' % i
                string_echo += self.accel[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"gripper":['
        gripper_length = len(self.gripper)
        for i in range(0, gripper_length):
            if i == (gripper_length - 1): 
                string_echo += '%s' % self.gripper[i]
            else:
                string_echo += '%s,' % self.gripper[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/HandTaskData"

    def getMD5(self):
        return "94e52494bddc361e7957bd614e77d0a9"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Pose[] pose\ngeometry_msgs/Twist[] twist\ngeometry_msgs/Accel[] accel\nfloat32[] gripper\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Twist\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Accel\ngeometry_msgs/Vector3 linear\ngeometry_msgs/Vector3 angular\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

