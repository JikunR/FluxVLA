import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class StateVis(mros.Message):
    __slots__ = ['header','qpos','vbody','contactPhaseDes']
    _slot_types = ['std_msgs/Header','float64[19]','float64[3]','float64[4]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StateVis, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qpos is None:
                self.qpos = [0. for x in range(0, 19)]
            if self.vbody is None:
                self.vbody = [0. for x in range(0, 3)]
            if self.contactPhaseDes is None:
                self.contactPhaseDes = [0. for x in range(0, 4)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qpos = [0. for x in range(0, 19)]
            self.vbody = [0. for x in range(0, 3)]
            self.contactPhaseDes = [0. for x in range(0, 4)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{19}d', *self.qpos))
            offset += 19 * 8
            buff.write(struct.pack(f'<{3}d', *self.vbody))
            offset += 3 * 8
            buff.write(struct.pack(f'<{4}d', *self.contactPhaseDes))
            offset += 4 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.qpos = np.frombuffer(buff[offset:offset + 19 * 8], dtype=np.float64)
            offset += 19 * 8
            self.vbody = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.contactPhaseDes = np.frombuffer(buff[offset:offset + 4 * 8], dtype=np.float64)
            offset += 4 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 19 * 8
        length += 3 * 8
        length += 4 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qpos":['
        for i in range(0, 19):
            if i == (19 - 1): 
                string_echo += '%s' % self.qpos[i]
            else:
                string_echo += '%s,' % self.qpos[i]
        string_echo += '],'
        string_echo += '"vbody":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.vbody[i]
            else:
                string_echo += '%s,' % self.vbody[i]
        string_echo += '],'
        string_echo += '"contactPhaseDes":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.contactPhaseDes[i]
            else:
                string_echo += '%s,' % self.contactPhaseDes[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/StateVis"

    def getMD5(self):
        return "1c7a4ba104a5ac4ad9d58300b0220f2e"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[19] qpos\nfloat64[3] vbody\nfloat64[4] contactPhaseDes\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

