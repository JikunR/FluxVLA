import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class ContactState(mros.Message):
    __slots__ = ['header','name','state']
    _slot_types = ['std_msgs/Header','string[]','bool[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ContactState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.name is None:
                self.name = []
            if self.state is None:
                self.state = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.name = []
            self.state = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            name_length = len(self.name)
            buff.write(struct.pack('<I', name_length))
            offset += 4
            for i in range(0, name_length):
                _x = self.name[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            state_length = len(self.state)
            buff.write(struct.pack('<I', state_length))
            buff.write(struct.pack(f'<{state_length}B', *self.state))
            offset += 4 + state_length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (name_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.name) != name_length:
                self.name = ['' for _ in range(name_length)]
            for i in range(0, name_length):
                (length_namei,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.name[i] = buff[offset:(offset + length_namei)].decode('utf-8')
                else:
                    self.name[i] = buff[offset:(offset + length_namei)]
                offset += length_namei
            (state_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.state = np.frombuffer(buff[offset:offset + state_length], dtype=np.uint8)
            offset += state_length
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, name_length):
            namei_x = self.name[i]
            namei_length = len(namei_x)
            if python3 or type(namei_x) == unicode:
                namei_x = namei_x.encode('utf-8')
                namei_length = len(namei_x)
            length += 4
            length += namei_length
        length += 4
        length += len(self.state)
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"name":['
        name_length = len(self.name)
        for i in range(0, name_length):
            if i == (name_length - 1): 
                string_echo += '"name[i]":"%s"' % self.name[i]
                string_echo += ''
            else:
                string_echo += '"name[i]":"%s"' % self.name[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"state":['
        state_length = len(self.state)
        for i in range(0, state_length):
            if i == (state_length - 1): 
                string_echo += '%s' % self.state[i]
            else:
                string_echo += '%s,' % self.state[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/ContactState"

    def getMD5(self):
        return "678afd95d51d5a66befdfa88bb0ec5d9"

    def getDef(self):
        return "std_msgs/Header header\nstring[] name\nbool[] state\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

