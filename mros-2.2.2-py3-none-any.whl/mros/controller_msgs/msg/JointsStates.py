import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class JointsStates(mros.Message):
    __slots__ = ['header','qpos','qvel','qacc','tau']
    _slot_types = ['std_msgs/Header','float32[]','float32[]','float32[]','float32[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointsStates, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qpos is None:
                self.qpos = []
            if self.qvel is None:
                self.qvel = []
            if self.qacc is None:
                self.qacc = []
            if self.tau is None:
                self.tau = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qpos = []
            self.qvel = []
            self.qacc = []
            self.tau = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            qpos_length = len(self.qpos)
            buff.write(struct.pack('<I', qpos_length))
            buff.write(struct.pack(f'<{qpos_length}f', *self.qpos))
            offset += 4 + qpos_length * 4
            qvel_length = len(self.qvel)
            buff.write(struct.pack('<I', qvel_length))
            buff.write(struct.pack(f'<{qvel_length}f', *self.qvel))
            offset += 4 + qvel_length * 4
            qacc_length = len(self.qacc)
            buff.write(struct.pack('<I', qacc_length))
            buff.write(struct.pack(f'<{qacc_length}f', *self.qacc))
            offset += 4 + qacc_length * 4
            tau_length = len(self.tau)
            buff.write(struct.pack('<I', tau_length))
            buff.write(struct.pack(f'<{tau_length}f', *self.tau))
            offset += 4 + tau_length * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (qpos_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qpos = np.frombuffer(buff[offset:offset + qpos_length * 4], dtype=np.float32)
            offset += qpos_length * 4
            (qvel_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qvel = np.frombuffer(buff[offset:offset + qvel_length * 4], dtype=np.float32)
            offset += qvel_length * 4
            (qacc_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qacc = np.frombuffer(buff[offset:offset + qacc_length * 4], dtype=np.float32)
            offset += qacc_length * 4
            (tau_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.tau = np.frombuffer(buff[offset:offset + tau_length * 4], dtype=np.float32)
            offset += tau_length * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.qpos) * 4
        length += 4
        length += len(self.qvel) * 4
        length += 4
        length += len(self.qacc) * 4
        length += 4
        length += len(self.tau) * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qpos":['
        qpos_length = len(self.qpos)
        for i in range(0, qpos_length):
            if i == (qpos_length - 1): 
                string_echo += '%s' % self.qpos[i]
            else:
                string_echo += '%s,' % self.qpos[i]
        string_echo += '],'
        string_echo += '"qvel":['
        qvel_length = len(self.qvel)
        for i in range(0, qvel_length):
            if i == (qvel_length - 1): 
                string_echo += '%s' % self.qvel[i]
            else:
                string_echo += '%s,' % self.qvel[i]
        string_echo += '],'
        string_echo += '"qacc":['
        qacc_length = len(self.qacc)
        for i in range(0, qacc_length):
            if i == (qacc_length - 1): 
                string_echo += '%s' % self.qacc[i]
            else:
                string_echo += '%s,' % self.qacc[i]
        string_echo += '],'
        string_echo += '"tau":['
        tau_length = len(self.tau)
        for i in range(0, tau_length):
            if i == (tau_length - 1): 
                string_echo += '%s' % self.tau[i]
            else:
                string_echo += '%s,' % self.tau[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/JointsStates"

    def getMD5(self):
        return "515ad804d87cdd4d908e73b0ae72731e"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[] qpos\nfloat32[] qvel\nfloat32[] qacc\nfloat32[] tau\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

