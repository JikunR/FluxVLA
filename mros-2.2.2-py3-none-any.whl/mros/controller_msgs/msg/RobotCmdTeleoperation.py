import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotCmdTeleoperation(mros.Message):
    __slots__ = ['header','qCmd','qdCmd','kpCmd','kdCmd','currentCmd','mode']
    _slot_types = ['std_msgs/Header','float32[16]','float32[16]','float32[16]','float32[16]','float32[16]','uint8[16]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotCmdTeleoperation, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qCmd is None:
                self.qCmd = [0. for x in range(0, 16)]
            if self.qdCmd is None:
                self.qdCmd = [0. for x in range(0, 16)]
            if self.kpCmd is None:
                self.kpCmd = [0. for x in range(0, 16)]
            if self.kdCmd is None:
                self.kdCmd = [0. for x in range(0, 16)]
            if self.currentCmd is None:
                self.currentCmd = [0. for x in range(0, 16)]
            if self.mode is None:
                self.mode = chr(0)*16
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qCmd = [0. for x in range(0, 16)]
            self.qdCmd = [0. for x in range(0, 16)]
            self.kpCmd = [0. for x in range(0, 16)]
            self.kdCmd = [0. for x in range(0, 16)]
            self.currentCmd = [0. for x in range(0, 16)]
            self.mode = chr(0)*16

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{16}f', *self.qCmd))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.qdCmd))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.kpCmd))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.kdCmd))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}f', *self.currentCmd))
            offset += 16 * 4
            buff.write(struct.pack(f'<{16}B', *self.mode))
            offset += 16
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.qCmd = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.qdCmd = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.kpCmd = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.kdCmd = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.currentCmd = np.frombuffer(buff[offset:offset + 16 * 4], dtype=np.float32)
            offset += 16 * 4
            self.mode = np.frombuffer(buff[offset:offset + 16], dtype=np.uint8)
            offset += 16
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 16 * 4
        length += 16 * 4
        length += 16 * 4
        length += 16 * 4
        length += 16 * 4
        length += 16
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qCmd":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.qCmd[i]
            else:
                string_echo += '%s,' % self.qCmd[i]
        string_echo += '],'
        string_echo += '"qdCmd":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.qdCmd[i]
            else:
                string_echo += '%s,' % self.qdCmd[i]
        string_echo += '],'
        string_echo += '"kpCmd":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.kpCmd[i]
            else:
                string_echo += '%s,' % self.kpCmd[i]
        string_echo += '],'
        string_echo += '"kdCmd":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.kdCmd[i]
            else:
                string_echo += '%s,' % self.kdCmd[i]
        string_echo += '],'
        string_echo += '"currentCmd":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.currentCmd[i]
            else:
                string_echo += '%s,' % self.currentCmd[i]
        string_echo += '],'
        string_echo += '"mode":['
        for i in range(0, 16):
            if i == (16 - 1): 
                string_echo += '%s' % self.mode[i]
            else:
                string_echo += '%s,' % self.mode[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotCmdTeleoperation"

    def getMD5(self):
        return "363bd33f3d9aa9cb2cc4eb51a38b2fe0"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[16] qCmd\nfloat32[16] qdCmd\nfloat32[16] kpCmd\nfloat32[16] kdCmd\nfloat32[16] currentCmd\nuint8[16] mode\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

