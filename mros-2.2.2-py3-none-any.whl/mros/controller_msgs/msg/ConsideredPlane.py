import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class ConsideredPlane(mros.Message):
    __slots__ = ['header','num','id']
    _slot_types = ['std_msgs/Header','int16','int16[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ConsideredPlane, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.num is None:
                self.num = 0
            if self.id is None:
                self.id = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.num = 0
            self.id = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_num = struct.Struct("<h")
            buff.write(struct_num.pack(self.num))
            offset += 2
            id_length = len(self.id)
            buff.write(struct.pack('<I', id_length))
            buff.write(struct.pack(f'<{id_length}h', *self.id))
            offset += 4 + id_length * 2
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_num = struct.Struct("<h")
            (self.num,) = struct_num.unpack(buff[offset:(offset + 2)])
            offset += 2
            (id_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.id = np.frombuffer(buff[offset:offset + id_length * 2], dtype=np.int16)
            offset += id_length * 2
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 2
        length += 4
        length += len(self.id) * 2
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"num":%s' % self.num
        string_echo += ','
        string_echo += '"id":['
        id_length = len(self.id)
        for i in range(0, id_length):
            if i == (id_length - 1): 
                string_echo += '%s' % self.id[i]
            else:
                string_echo += '%s,' % self.id[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/ConsideredPlane"

    def getMD5(self):
        return "84688d28af46cca26c2aba261169f64c"

    def getDef(self):
        return "std_msgs/Header header\nint16 num\nint16[] id\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

