import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class VelocityCmd(mros.Message):
    __slots__ = ['header','type','v','w']
    _slot_types = ['std_msgs/Header','int8','float32','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(VelocityCmd, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.type is None:
                self.type = 0
            if self.v is None:
                self.v = 0.
            if self.w is None:
                self.w = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.type = 0
            self.v = 0.
            self.w = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_type = struct.Struct("<b")
            buff.write(struct_type.pack(self.type))
            offset += 1
            struct_v = struct.Struct("<f")
            buff.write(struct_v.pack(self.v))
            offset += 4
            struct_w = struct.Struct("<f")
            buff.write(struct_w.pack(self.w))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_type = struct.Struct("<b")
            (self.type,) = struct_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_v = struct.Struct("<f")
            (self.v,) = struct_v.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_w = struct.Struct("<f")
            (self.w,) = struct_w.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"type":%s' % self.type
        string_echo += ','
        string_echo += '"v":%s' % self.v
        string_echo += ','
        string_echo += '"w":%s' % self.w
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/VelocityCmd"

    def getMD5(self):
        return "e54619c0029a0ef0f6fb89cbc6cf9298"

    def getDef(self):
        return "std_msgs/Header header\nint8 type\nfloat32 v\nfloat32 w\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

