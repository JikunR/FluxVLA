import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class JointsCmds(mros.Message):
    __slots__ = ['header','Kp','Kd','qpos_des','qvel_des','tau_ff']
    _slot_types = ['std_msgs/Header','float64[]','float64[]','float64[]','float64[]','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointsCmds, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.Kp is None:
                self.Kp = []
            if self.Kd is None:
                self.Kd = []
            if self.qpos_des is None:
                self.qpos_des = []
            if self.qvel_des is None:
                self.qvel_des = []
            if self.tau_ff is None:
                self.tau_ff = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.Kp = []
            self.Kd = []
            self.qpos_des = []
            self.qvel_des = []
            self.tau_ff = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            Kp_length = len(self.Kp)
            buff.write(struct.pack('<I', Kp_length))
            buff.write(struct.pack(f'<{Kp_length}d', *self.Kp))
            offset += 4 + Kp_length * 8
            Kd_length = len(self.Kd)
            buff.write(struct.pack('<I', Kd_length))
            buff.write(struct.pack(f'<{Kd_length}d', *self.Kd))
            offset += 4 + Kd_length * 8
            qpos_des_length = len(self.qpos_des)
            buff.write(struct.pack('<I', qpos_des_length))
            buff.write(struct.pack(f'<{qpos_des_length}d', *self.qpos_des))
            offset += 4 + qpos_des_length * 8
            qvel_des_length = len(self.qvel_des)
            buff.write(struct.pack('<I', qvel_des_length))
            buff.write(struct.pack(f'<{qvel_des_length}d', *self.qvel_des))
            offset += 4 + qvel_des_length * 8
            tau_ff_length = len(self.tau_ff)
            buff.write(struct.pack('<I', tau_ff_length))
            buff.write(struct.pack(f'<{tau_ff_length}d', *self.tau_ff))
            offset += 4 + tau_ff_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (Kp_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.Kp = np.frombuffer(buff[offset:offset + Kp_length * 8], dtype=np.float64)
            offset += Kp_length * 8
            (Kd_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.Kd = np.frombuffer(buff[offset:offset + Kd_length * 8], dtype=np.float64)
            offset += Kd_length * 8
            (qpos_des_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qpos_des = np.frombuffer(buff[offset:offset + qpos_des_length * 8], dtype=np.float64)
            offset += qpos_des_length * 8
            (qvel_des_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.qvel_des = np.frombuffer(buff[offset:offset + qvel_des_length * 8], dtype=np.float64)
            offset += qvel_des_length * 8
            (tau_ff_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.tau_ff = np.frombuffer(buff[offset:offset + tau_ff_length * 8], dtype=np.float64)
            offset += tau_ff_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.Kp) * 8
        length += 4
        length += len(self.Kd) * 8
        length += 4
        length += len(self.qpos_des) * 8
        length += 4
        length += len(self.qvel_des) * 8
        length += 4
        length += len(self.tau_ff) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"Kp":['
        Kp_length = len(self.Kp)
        for i in range(0, Kp_length):
            if i == (Kp_length - 1): 
                string_echo += '%s' % self.Kp[i]
            else:
                string_echo += '%s,' % self.Kp[i]
        string_echo += '],'
        string_echo += '"Kd":['
        Kd_length = len(self.Kd)
        for i in range(0, Kd_length):
            if i == (Kd_length - 1): 
                string_echo += '%s' % self.Kd[i]
            else:
                string_echo += '%s,' % self.Kd[i]
        string_echo += '],'
        string_echo += '"qpos_des":['
        qpos_des_length = len(self.qpos_des)
        for i in range(0, qpos_des_length):
            if i == (qpos_des_length - 1): 
                string_echo += '%s' % self.qpos_des[i]
            else:
                string_echo += '%s,' % self.qpos_des[i]
        string_echo += '],'
        string_echo += '"qvel_des":['
        qvel_des_length = len(self.qvel_des)
        for i in range(0, qvel_des_length):
            if i == (qvel_des_length - 1): 
                string_echo += '%s' % self.qvel_des[i]
            else:
                string_echo += '%s,' % self.qvel_des[i]
        string_echo += '],'
        string_echo += '"tau_ff":['
        tau_ff_length = len(self.tau_ff)
        for i in range(0, tau_ff_length):
            if i == (tau_ff_length - 1): 
                string_echo += '%s' % self.tau_ff[i]
            else:
                string_echo += '%s,' % self.tau_ff[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/JointsCmds"

    def getMD5(self):
        return "983c368dff7c8f920057cd25b8dc09c7"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[] Kp\nfloat64[] Kd\nfloat64[] qpos_des\nfloat64[] qvel_des\nfloat64[] tau_ff\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

