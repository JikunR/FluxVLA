import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class EstimatedDataPointFoot(mros.Message):
    __slots__ = ['header','posBase','rpyBase','vWorldBase','omegaWorldBase','posFoot','contactState']
    _slot_types = ['std_msgs/Header','float32[3]','float32[3]','float32[3]','float32[3]','float32[6]','int16[2]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(EstimatedDataPointFoot, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.posBase is None:
                self.posBase = [0. for x in range(0, 3)]
            if self.rpyBase is None:
                self.rpyBase = [0. for x in range(0, 3)]
            if self.vWorldBase is None:
                self.vWorldBase = [0. for x in range(0, 3)]
            if self.omegaWorldBase is None:
                self.omegaWorldBase = [0. for x in range(0, 3)]
            if self.posFoot is None:
                self.posFoot = [0. for x in range(0, 6)]
            if self.contactState is None:
                self.contactState = [0 for x in range(0, 2)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.posBase = [0. for x in range(0, 3)]
            self.rpyBase = [0. for x in range(0, 3)]
            self.vWorldBase = [0. for x in range(0, 3)]
            self.omegaWorldBase = [0. for x in range(0, 3)]
            self.posFoot = [0. for x in range(0, 6)]
            self.contactState = [0 for x in range(0, 2)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{3}f', *self.posBase))
            offset += 3 * 4
            buff.write(struct.pack(f'<{3}f', *self.rpyBase))
            offset += 3 * 4
            buff.write(struct.pack(f'<{3}f', *self.vWorldBase))
            offset += 3 * 4
            buff.write(struct.pack(f'<{3}f', *self.omegaWorldBase))
            offset += 3 * 4
            buff.write(struct.pack(f'<{6}f', *self.posFoot))
            offset += 6 * 4
            buff.write(struct.pack(f'<{2}h', *self.contactState))
            offset += 2 * 2
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.posBase = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            self.rpyBase = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            self.vWorldBase = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            self.omegaWorldBase = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
            self.posFoot = np.frombuffer(buff[offset:offset + 6 * 4], dtype=np.float32)
            offset += 6 * 4
            self.contactState = np.frombuffer(buff[offset:offset + 2 * 2], dtype=np.int16)
            offset += 2 * 2
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 3 * 4
        length += 3 * 4
        length += 3 * 4
        length += 3 * 4
        length += 6 * 4
        length += 2 * 2
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"posBase":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.posBase[i]
            else:
                string_echo += '%s,' % self.posBase[i]
        string_echo += '],'
        string_echo += '"rpyBase":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.rpyBase[i]
            else:
                string_echo += '%s,' % self.rpyBase[i]
        string_echo += '],'
        string_echo += '"vWorldBase":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.vWorldBase[i]
            else:
                string_echo += '%s,' % self.vWorldBase[i]
        string_echo += '],'
        string_echo += '"omegaWorldBase":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.omegaWorldBase[i]
            else:
                string_echo += '%s,' % self.omegaWorldBase[i]
        string_echo += '],'
        string_echo += '"posFoot":['
        for i in range(0, 6):
            if i == (6 - 1): 
                string_echo += '%s' % self.posFoot[i]
            else:
                string_echo += '%s,' % self.posFoot[i]
        string_echo += '],'
        string_echo += '"contactState":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.contactState[i]
            else:
                string_echo += '%s,' % self.contactState[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/EstimatedDataPointFoot"

    def getMD5(self):
        return "d33b32b3e287fd54d2fab041a13ca6d1"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[3] posBase\nfloat32[3] rpyBase\nfloat32[3] vWorldBase\nfloat32[3] omegaWorldBase\nfloat32[6] posFoot\nint16[2] contactState\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

