import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class StairClimbState(mros.Message):
    __slots__ = ['header','finish_climb']
    _slot_types = ['std_msgs/Header','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StairClimbState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.finish_climb is None:
                self.finish_climb = False
        else:
            self.header = mros.std_msgs.msg.Header()
            self.finish_climb = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_finish_climb = struct.Struct("<B")
            buff.write(struct_finish_climb.pack(self.finish_climb))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_finish_climb = struct.Struct("<B")
            (self.finish_climb,) = struct_finish_climb.unpack(buff[offset:(offset + 1)])
            self.finish_climb = bool(self.finish_climb)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"finish_climb":%s' % self.finish_climb
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/StairClimbState"

    def getMD5(self):
        return "02efc04110bd80baf7b54945202ae661"

    def getDef(self):
        return "std_msgs/Header header\nbool finish_climb\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

