import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class SwingTrackingData(mros.Message):
    __slots__ = ['Header','pos_des','vel_des','pos_cur','vel_cur']
    _slot_types = ['std_msgs/Header','float32[12]','float32[12]','float32[12]','float32[12]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SwingTrackingData, self).__init__(*args, **kwds)
            if self.Header is None:
                self.Header = mros.std_msgs.msg.Header()
            if self.pos_des is None:
                self.pos_des = [0. for x in range(0, 12)]
            if self.vel_des is None:
                self.vel_des = [0. for x in range(0, 12)]
            if self.pos_cur is None:
                self.pos_cur = [0. for x in range(0, 12)]
            if self.vel_cur is None:
                self.vel_cur = [0. for x in range(0, 12)]
        else:
            self.Header = mros.std_msgs.msg.Header()
            self.pos_des = [0. for x in range(0, 12)]
            self.vel_des = [0. for x in range(0, 12)]
            self.pos_cur = [0. for x in range(0, 12)]
            self.vel_cur = [0. for x in range(0, 12)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.Header.seq, self.Header.stamp.sec, self.Header.stamp.nsec))
            offset += 4 * 3
            _x = self.Header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{12}f', *self.pos_des))
            offset += 12 * 4
            buff.write(struct.pack(f'<{12}f', *self.vel_des))
            offset += 12 * 4
            buff.write(struct.pack(f'<{12}f', *self.pos_cur))
            offset += 12 * 4
            buff.write(struct.pack(f'<{12}f', *self.vel_cur))
            offset += 12 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.Header.seq, self.Header.stamp.sec, self.Header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.Header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.Header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.pos_des = np.frombuffer(buff[offset:offset + 12 * 4], dtype=np.float32)
            offset += 12 * 4
            self.vel_des = np.frombuffer(buff[offset:offset + 12 * 4], dtype=np.float32)
            offset += 12 * 4
            self.pos_cur = np.frombuffer(buff[offset:offset + 12 * 4], dtype=np.float32)
            offset += 12 * 4
            self.vel_cur = np.frombuffer(buff[offset:offset + 12 * 4], dtype=np.float32)
            offset += 12 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.Header.serializedLength()
        length += 12 * 4
        length += 12 * 4
        length += 12 * 4
        length += 12 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"Header":'
        string_echo += self.Header.echo()
        string_echo += ','
        string_echo += '"pos_des":['
        for i in range(0, 12):
            if i == (12 - 1): 
                string_echo += '%s' % self.pos_des[i]
            else:
                string_echo += '%s,' % self.pos_des[i]
        string_echo += '],'
        string_echo += '"vel_des":['
        for i in range(0, 12):
            if i == (12 - 1): 
                string_echo += '%s' % self.vel_des[i]
            else:
                string_echo += '%s,' % self.vel_des[i]
        string_echo += '],'
        string_echo += '"pos_cur":['
        for i in range(0, 12):
            if i == (12 - 1): 
                string_echo += '%s' % self.pos_cur[i]
            else:
                string_echo += '%s,' % self.pos_cur[i]
        string_echo += '],'
        string_echo += '"vel_cur":['
        for i in range(0, 12):
            if i == (12 - 1): 
                string_echo += '%s' % self.vel_cur[i]
            else:
                string_echo += '%s,' % self.vel_cur[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/SwingTrackingData"

    def getMD5(self):
        return "82efb3c464e9dbcc6accd6ed17795f13"

    def getDef(self):
        return "std_msgs/Header Header\nfloat32[12] pos_des\nfloat32[12] vel_des\nfloat32[12] pos_cur\nfloat32[12] vel_cur\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

