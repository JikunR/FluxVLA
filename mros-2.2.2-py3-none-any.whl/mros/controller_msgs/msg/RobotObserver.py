import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotObserver(mros.Message):
    __slots__ = ['header','obs']
    _slot_types = ['std_msgs/Header','float32[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotObserver, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.obs is None:
                self.obs = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.obs = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            obs_length = len(self.obs)
            buff.write(struct.pack('<I', obs_length))
            buff.write(struct.pack(f'<{obs_length}f', *self.obs))
            offset += 4 + obs_length * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (obs_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.obs = np.frombuffer(buff[offset:offset + obs_length * 4], dtype=np.float32)
            offset += obs_length * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.obs) * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"obs":['
        obs_length = len(self.obs)
        for i in range(0, obs_length):
            if i == (obs_length - 1): 
                string_echo += '%s' % self.obs[i]
            else:
                string_echo += '%s,' % self.obs[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotObserver"

    def getMD5(self):
        return "153db915b9daf909708dc9162b9e5056"

    def getDef(self):
        return "std_msgs/Header header\nfloat32[] obs\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

