import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class ALIPMPCOutput(mros.Message):
    __slots__ = ['header','updated','iter','optimized_trajectory']
    _slot_types = ['std_msgs/Header','bool','int32','float64[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ALIPMPCOutput, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.updated is None:
                self.updated = False
            if self.iter is None:
                self.iter = 0
            if self.optimized_trajectory is None:
                self.optimized_trajectory = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.updated = False
            self.iter = 0
            self.optimized_trajectory = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_updated = struct.Struct("<B")
            buff.write(struct_updated.pack(self.updated))
            offset += 1
            struct_iter = struct.Struct("<i")
            buff.write(struct_iter.pack(self.iter))
            offset += 4
            optimized_trajectory_length = len(self.optimized_trajectory)
            buff.write(struct.pack('<I', optimized_trajectory_length))
            buff.write(struct.pack(f'<{optimized_trajectory_length}d', *self.optimized_trajectory))
            offset += 4 + optimized_trajectory_length * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_updated = struct.Struct("<B")
            (self.updated,) = struct_updated.unpack(buff[offset:(offset + 1)])
            self.updated = bool(self.updated)
            offset += 1
            struct_iter = struct.Struct("<i")
            (self.iter,) = struct_iter.unpack(buff[offset:(offset + 4)])
            offset += 4
            (optimized_trajectory_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.optimized_trajectory = np.frombuffer(buff[offset:offset + optimized_trajectory_length * 8], dtype=np.float64)
            offset += optimized_trajectory_length * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 4
        length += 4
        length += len(self.optimized_trajectory) * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"updated":%s' % self.updated
        string_echo += ','
        string_echo += '"iter":%s' % self.iter
        string_echo += ','
        string_echo += '"optimized_trajectory":['
        optimized_trajectory_length = len(self.optimized_trajectory)
        for i in range(0, optimized_trajectory_length):
            if i == (optimized_trajectory_length - 1): 
                string_echo += '%s' % self.optimized_trajectory[i]
            else:
                string_echo += '%s,' % self.optimized_trajectory[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/ALIPMPCOutput"

    def getMD5(self):
        return "b4cb2ca472aa5f8d23fa3d9f724920e7"

    def getDef(self):
        return "std_msgs/Header header\nbool updated\nint32 iter\nfloat64[] optimized_trajectory\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

