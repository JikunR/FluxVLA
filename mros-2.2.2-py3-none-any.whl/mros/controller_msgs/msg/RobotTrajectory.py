import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg

class RobotTrajectory(mros.Message):
    __slots__ = ['horizon','CoMtraj_Integral','CoMtraj_LIPM','CoMtraj_SRGB']
    _slot_types = ['int8','float64[60]','float64[60]','float64[60]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotTrajectory, self).__init__(*args, **kwds)
            if self.horizon is None:
                self.horizon = 0
            if self.CoMtraj_Integral is None:
                self.CoMtraj_Integral = [0. for x in range(0, 60)]
            if self.CoMtraj_LIPM is None:
                self.CoMtraj_LIPM = [0. for x in range(0, 60)]
            if self.CoMtraj_SRGB is None:
                self.CoMtraj_SRGB = [0. for x in range(0, 60)]
        else:
            self.horizon = 0
            self.CoMtraj_Integral = [0. for x in range(0, 60)]
            self.CoMtraj_LIPM = [0. for x in range(0, 60)]
            self.CoMtraj_SRGB = [0. for x in range(0, 60)]

    def serialize(self, buff):
        offset = 0
        try:
            struct_horizon = struct.Struct("<b")
            buff.write(struct_horizon.pack(self.horizon))
            offset += 1
            buff.write(struct.pack(f'<{60}d', *self.CoMtraj_Integral))
            offset += 60 * 8
            buff.write(struct.pack(f'<{60}d', *self.CoMtraj_LIPM))
            offset += 60 * 8
            buff.write(struct.pack(f'<{60}d', *self.CoMtraj_SRGB))
            offset += 60 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_horizon = struct.Struct("<b")
            (self.horizon,) = struct_horizon.unpack(buff[offset:(offset + 1)])
            offset += 1
            self.CoMtraj_Integral = np.frombuffer(buff[offset:offset + 60 * 8], dtype=np.float64)
            offset += 60 * 8
            self.CoMtraj_LIPM = np.frombuffer(buff[offset:offset + 60 * 8], dtype=np.float64)
            offset += 60 * 8
            self.CoMtraj_SRGB = np.frombuffer(buff[offset:offset + 60 * 8], dtype=np.float64)
            offset += 60 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 60 * 8
        length += 60 * 8
        length += 60 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"horizon":%s' % self.horizon
        string_echo += ','
        string_echo += '"CoMtraj_Integral":['
        for i in range(0, 60):
            if i == (60 - 1): 
                string_echo += '%s' % self.CoMtraj_Integral[i]
            else:
                string_echo += '%s,' % self.CoMtraj_Integral[i]
        string_echo += '],'
        string_echo += '"CoMtraj_LIPM":['
        for i in range(0, 60):
            if i == (60 - 1): 
                string_echo += '%s' % self.CoMtraj_LIPM[i]
            else:
                string_echo += '%s,' % self.CoMtraj_LIPM[i]
        string_echo += '],'
        string_echo += '"CoMtraj_SRGB":['
        for i in range(0, 60):
            if i == (60 - 1): 
                string_echo += '%s' % self.CoMtraj_SRGB[i]
            else:
                string_echo += '%s,' % self.CoMtraj_SRGB[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotTrajectory"

    def getMD5(self):
        return "c9542892bb15e426f48149320bea4a2e"

    def getDef(self):
        return "int8 horizon\nfloat64[60] CoMtraj_Integral\nfloat64[60] CoMtraj_LIPM\nfloat64[60] CoMtraj_SRGB\n"

_struct_I = struct.Struct('<I')

