import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class RobotStateHumanoid(mros.Message):
    __slots__ = ['header','qState','qdState','currentState','dc_voltage']
    _slot_types = ['std_msgs/Header','float64[18]','float64[18]','float64[18]','float64[18]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(RobotStateHumanoid, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.qState is None:
                self.qState = [0. for x in range(0, 18)]
            if self.qdState is None:
                self.qdState = [0. for x in range(0, 18)]
            if self.currentState is None:
                self.currentState = [0. for x in range(0, 18)]
            if self.dc_voltage is None:
                self.dc_voltage = [0. for x in range(0, 18)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.qState = [0. for x in range(0, 18)]
            self.qdState = [0. for x in range(0, 18)]
            self.currentState = [0. for x in range(0, 18)]
            self.dc_voltage = [0. for x in range(0, 18)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{18}d', *self.qState))
            offset += 18 * 8
            buff.write(struct.pack(f'<{18}d', *self.qdState))
            offset += 18 * 8
            buff.write(struct.pack(f'<{18}d', *self.currentState))
            offset += 18 * 8
            buff.write(struct.pack(f'<{18}d', *self.dc_voltage))
            offset += 18 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.qState = np.frombuffer(buff[offset:offset + 18 * 8], dtype=np.float64)
            offset += 18 * 8
            self.qdState = np.frombuffer(buff[offset:offset + 18 * 8], dtype=np.float64)
            offset += 18 * 8
            self.currentState = np.frombuffer(buff[offset:offset + 18 * 8], dtype=np.float64)
            offset += 18 * 8
            self.dc_voltage = np.frombuffer(buff[offset:offset + 18 * 8], dtype=np.float64)
            offset += 18 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 18 * 8
        length += 18 * 8
        length += 18 * 8
        length += 18 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"qState":['
        for i in range(0, 18):
            if i == (18 - 1): 
                string_echo += '%s' % self.qState[i]
            else:
                string_echo += '%s,' % self.qState[i]
        string_echo += '],'
        string_echo += '"qdState":['
        for i in range(0, 18):
            if i == (18 - 1): 
                string_echo += '%s' % self.qdState[i]
            else:
                string_echo += '%s,' % self.qdState[i]
        string_echo += '],'
        string_echo += '"currentState":['
        for i in range(0, 18):
            if i == (18 - 1): 
                string_echo += '%s' % self.currentState[i]
            else:
                string_echo += '%s,' % self.currentState[i]
        string_echo += '],'
        string_echo += '"dc_voltage":['
        for i in range(0, 18):
            if i == (18 - 1): 
                string_echo += '%s' % self.dc_voltage[i]
            else:
                string_echo += '%s,' % self.dc_voltage[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/RobotStateHumanoid"

    def getMD5(self):
        return "a415e263ef53b976e3d13524cd590516"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[18] qState\nfloat64[18] qdState\nfloat64[18] currentState\nfloat64[18] dc_voltage\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

