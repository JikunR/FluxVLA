import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class MeasuredStates(mros.Message):
    __slots__ = ['header','imuData','jointsStates','force']
    _slot_types = ['std_msgs/Header','controller_msgs/IMUData','controller_msgs/JointsStates','int16[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MeasuredStates, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.imuData is None:
                self.imuData = mros.controller_msgs.msg.IMUData()
            if self.jointsStates is None:
                self.jointsStates = mros.controller_msgs.msg.JointsStates()
            if self.force is None:
                self.force = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.imuData = mros.controller_msgs.msg.IMUData()
            self.jointsStates = mros.controller_msgs.msg.JointsStates()
            self.force = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.imuData.serialize(buff)
            offset += self.jointsStates.serialize(buff)
            force_length = len(self.force)
            buff.write(struct.pack('<I', force_length))
            buff.write(struct.pack(f'<{force_length}h', *self.force))
            offset += 4 + force_length * 2
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.imuData.deserialize(buff[offset:])
            offset += self.jointsStates.deserialize(buff[offset:])
            (force_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.force = np.frombuffer(buff[offset:offset + force_length * 2], dtype=np.int16)
            offset += force_length * 2
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.imuData.serializedLength()
        length += self.jointsStates.serializedLength()
        length += 4
        length += len(self.force) * 2
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"imuData":'
        string_echo += self.imuData.echo()
        string_echo += ','
        string_echo += '"jointsStates":'
        string_echo += self.jointsStates.echo()
        string_echo += ','
        string_echo += '"force":['
        force_length = len(self.force)
        for i in range(0, force_length):
            if i == (force_length - 1): 
                string_echo += '%s' % self.force[i]
            else:
                string_echo += '%s,' % self.force[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/MeasuredStates"

    def getMD5(self):
        return "ebd354011cff5d7f7ac65c158cd0ac89"

    def getDef(self):
        return "std_msgs/Header header\ncontroller_msgs/IMUData imuData\ncontroller_msgs/JointsStates jointsStates\nint16[] force\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: controller_msgs/IMUData\nstd_msgs/Header header\nuint64 imustamp\nuint32 status\nfloat64[3] euler\nfloat64[4] quat\nfloat64[3] acc\nfloat64[3] gyro\n================================================================================\nMSG: controller_msgs/JointsStates\nstd_msgs/Header header\nfloat32[] qpos\nfloat32[] qvel\nfloat32[] qacc\nfloat32[] tau\n"

_struct_I = struct.Struct('<I')

