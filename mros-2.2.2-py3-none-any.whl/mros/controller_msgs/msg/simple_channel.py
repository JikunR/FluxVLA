import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class simple_channel(mros.Message):
    __slots__ = ['header','name','value']
    _slot_types = ['std_msgs/Header','string','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(simple_channel, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.name is None:
                self.name = ''
            if self.value is None:
                self.value = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.name = ''
            self.value = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_value = struct.Struct("<d")
            buff.write(struct_value.pack(self.value))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            struct_value = struct.Struct("<d")
            (self.value,) = struct_value.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"value":%s' % self.value
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/simple_channel"

    def getMD5(self):
        return "fe323ce539f11d9d1cdf8f16a89897f3"

    def getDef(self):
        return "std_msgs/Header header\nstring name\nfloat64 value\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

