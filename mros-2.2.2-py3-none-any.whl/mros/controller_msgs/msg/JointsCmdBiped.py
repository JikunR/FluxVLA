import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class JointsCmdBiped(mros.Message):
    __slots__ = ['header','Kp','Kd','qpos_des','qvel_des','tau_ff']
    _slot_types = ['std_msgs/Header','float64[10]','float64[10]','float64[10]','float64[10]','float64[10]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(JointsCmdBiped, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.Kp is None:
                self.Kp = [0. for x in range(0, 10)]
            if self.Kd is None:
                self.Kd = [0. for x in range(0, 10)]
            if self.qpos_des is None:
                self.qpos_des = [0. for x in range(0, 10)]
            if self.qvel_des is None:
                self.qvel_des = [0. for x in range(0, 10)]
            if self.tau_ff is None:
                self.tau_ff = [0. for x in range(0, 10)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.Kp = [0. for x in range(0, 10)]
            self.Kd = [0. for x in range(0, 10)]
            self.qpos_des = [0. for x in range(0, 10)]
            self.qvel_des = [0. for x in range(0, 10)]
            self.tau_ff = [0. for x in range(0, 10)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{10}d', *self.Kp))
            offset += 10 * 8
            buff.write(struct.pack(f'<{10}d', *self.Kd))
            offset += 10 * 8
            buff.write(struct.pack(f'<{10}d', *self.qpos_des))
            offset += 10 * 8
            buff.write(struct.pack(f'<{10}d', *self.qvel_des))
            offset += 10 * 8
            buff.write(struct.pack(f'<{10}d', *self.tau_ff))
            offset += 10 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.Kp = np.frombuffer(buff[offset:offset + 10 * 8], dtype=np.float64)
            offset += 10 * 8
            self.Kd = np.frombuffer(buff[offset:offset + 10 * 8], dtype=np.float64)
            offset += 10 * 8
            self.qpos_des = np.frombuffer(buff[offset:offset + 10 * 8], dtype=np.float64)
            offset += 10 * 8
            self.qvel_des = np.frombuffer(buff[offset:offset + 10 * 8], dtype=np.float64)
            offset += 10 * 8
            self.tau_ff = np.frombuffer(buff[offset:offset + 10 * 8], dtype=np.float64)
            offset += 10 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 10 * 8
        length += 10 * 8
        length += 10 * 8
        length += 10 * 8
        length += 10 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"Kp":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.Kp[i]
            else:
                string_echo += '%s,' % self.Kp[i]
        string_echo += '],'
        string_echo += '"Kd":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.Kd[i]
            else:
                string_echo += '%s,' % self.Kd[i]
        string_echo += '],'
        string_echo += '"qpos_des":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.qpos_des[i]
            else:
                string_echo += '%s,' % self.qpos_des[i]
        string_echo += '],'
        string_echo += '"qvel_des":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.qvel_des[i]
            else:
                string_echo += '%s,' % self.qvel_des[i]
        string_echo += '],'
        string_echo += '"tau_ff":['
        for i in range(0, 10):
            if i == (10 - 1): 
                string_echo += '%s' % self.tau_ff[i]
            else:
                string_echo += '%s,' % self.tau_ff[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/JointsCmdBiped"

    def getMD5(self):
        return "271fd07ffacfe8d46730317396ff0cb2"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[10] Kp\nfloat64[10] Kd\nfloat64[10] qpos_des\nfloat64[10] qvel_des\nfloat64[10] tau_ff\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

