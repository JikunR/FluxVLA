import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class HalfPlane(mros.Message):
    __slots__ = ['header','succeed','Bs','Vertexs','height_diff']
    _slot_types = ['std_msgs/Header','bool','geometry_msgs/Point','mros.geometry_msgs.msg.Point[2]','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HalfPlane, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.succeed is None:
                self.succeed = False
            if self.Bs is None:
                self.Bs = mros.geometry_msgs.msg.Point()
            if self.Vertexs is None:
                self.Vertexs = [mros.geometry_msgs.msg.Point() for x in range(0, 2)]
            if self.height_diff is None:
                self.height_diff = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.succeed = False
            self.Bs = mros.geometry_msgs.msg.Point()
            self.Vertexs = [mros.geometry_msgs.msg.Point() for x in range(0, 2)]
            self.height_diff = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_succeed = struct.Struct("<B")
            buff.write(struct_succeed.pack(self.succeed))
            offset += 1
            offset += self.Bs.serialize(buff)
            for i in range(0, 2):
                offset += self.Vertexs[i].serialize(buff)
            struct_height_diff = struct.Struct("<d")
            buff.write(struct_height_diff.pack(self.height_diff))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_succeed = struct.Struct("<B")
            (self.succeed,) = struct_succeed.unpack(buff[offset:(offset + 1)])
            self.succeed = bool(self.succeed)
            offset += 1
            offset += self.Bs.deserialize(buff[offset:])
            for i in range(0, 2):
                offset += self.Vertexs[i].deserialize(buff[offset:])
            struct_height_diff = struct.Struct("<d")
            (self.height_diff,) = struct_height_diff.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += self.Bs.serializedLength()
        for i in range(0, 2):
            length += self.Vertexs[i].serializedLength()
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"succeed":%s' % self.succeed
        string_echo += ','
        string_echo += '"Bs":'
        string_echo += self.Bs.echo()
        string_echo += ','
        string_echo += '"Vertexs":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '{Vertexs%s":' % i
                string_echo += self.Vertexs[i].echo()
                string_echo += ''
            else:
                string_echo += '{Vertexs%s":' % i
                string_echo += self.Vertexs[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"height_diff":%s' % self.height_diff
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/HalfPlane"

    def getMD5(self):
        return "4b05acbf1c46a7dfbb248dd56de8fb1d"

    def getDef(self):
        return "std_msgs/Header header\nbool succeed\ngeometry_msgs/Point Bs\ngeometry_msgs/Point[2] Vertexs\nfloat64 height_diff\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

