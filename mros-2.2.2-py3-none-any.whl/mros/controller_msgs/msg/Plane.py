import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class Plane(mros.Message):
    __slots__ = ['header','A','bound_num','Bs','Vertexs','center','area']
    _slot_types = ['std_msgs/Header','float64[3]','int16','mros.geometry_msgs.msg.Point[8]','mros.geometry_msgs.msg.Point[8]','float64[3]','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Plane, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.A is None:
                self.A = [0. for x in range(0, 3)]
            if self.bound_num is None:
                self.bound_num = 0
            if self.Bs is None:
                self.Bs = [mros.geometry_msgs.msg.Point() for x in range(0, 8)]
            if self.Vertexs is None:
                self.Vertexs = [mros.geometry_msgs.msg.Point() for x in range(0, 8)]
            if self.center is None:
                self.center = [0. for x in range(0, 3)]
            if self.area is None:
                self.area = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.A = [0. for x in range(0, 3)]
            self.bound_num = 0
            self.Bs = [mros.geometry_msgs.msg.Point() for x in range(0, 8)]
            self.Vertexs = [mros.geometry_msgs.msg.Point() for x in range(0, 8)]
            self.center = [0. for x in range(0, 3)]
            self.area = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{3}d', *self.A))
            offset += 3 * 8
            struct_bound_num = struct.Struct("<h")
            buff.write(struct_bound_num.pack(self.bound_num))
            offset += 2
            for i in range(0, 8):
                offset += self.Bs[i].serialize(buff)
            for i in range(0, 8):
                offset += self.Vertexs[i].serialize(buff)
            buff.write(struct.pack(f'<{3}d', *self.center))
            offset += 3 * 8
            struct_area = struct.Struct("<d")
            buff.write(struct_area.pack(self.area))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.A = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            struct_bound_num = struct.Struct("<h")
            (self.bound_num,) = struct_bound_num.unpack(buff[offset:(offset + 2)])
            offset += 2
            for i in range(0, 8):
                offset += self.Bs[i].deserialize(buff[offset:])
            for i in range(0, 8):
                offset += self.Vertexs[i].deserialize(buff[offset:])
            self.center = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            struct_area = struct.Struct("<d")
            (self.area,) = struct_area.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 3 * 8
        length += 2
        for i in range(0, 8):
            length += self.Bs[i].serializedLength()
        for i in range(0, 8):
            length += self.Vertexs[i].serializedLength()
        length += 3 * 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"A":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.A[i]
            else:
                string_echo += '%s,' % self.A[i]
        string_echo += '],'
        string_echo += '"bound_num":%s' % self.bound_num
        string_echo += ','
        string_echo += '"Bs":['
        for i in range(0, 8):
            if i == (8 - 1): 
                string_echo += '{Bs%s":' % i
                string_echo += self.Bs[i].echo()
                string_echo += ''
            else:
                string_echo += '{Bs%s":' % i
                string_echo += self.Bs[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"Vertexs":['
        for i in range(0, 8):
            if i == (8 - 1): 
                string_echo += '{Vertexs%s":' % i
                string_echo += self.Vertexs[i].echo()
                string_echo += ''
            else:
                string_echo += '{Vertexs%s":' % i
                string_echo += self.Vertexs[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"center":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.center[i]
            else:
                string_echo += '%s,' % self.center[i]
        string_echo += '],'
        string_echo += '"area":%s' % self.area
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/Plane"

    def getMD5(self):
        return "ebd5694fa79a5e167383d05ac14f390c"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[3] A\nint16 bound_num\ngeometry_msgs/Point[8] Bs\ngeometry_msgs/Point[8] Vertexs\nfloat64[3] center\nfloat64 area\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

