import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class IMUData(mros.Message):
    __slots__ = ['header','imustamp','status','euler','quat','acc','gyro']
    _slot_types = ['std_msgs/Header','uint64','uint32','float64[3]','float64[4]','float64[3]','float64[3]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(IMUData, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.imustamp is None:
                self.imustamp = 0
            if self.status is None:
                self.status = 0
            if self.euler is None:
                self.euler = [0. for x in range(0, 3)]
            if self.quat is None:
                self.quat = [0. for x in range(0, 4)]
            if self.acc is None:
                self.acc = [0. for x in range(0, 3)]
            if self.gyro is None:
                self.gyro = [0. for x in range(0, 3)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.imustamp = 0
            self.status = 0
            self.euler = [0. for x in range(0, 3)]
            self.quat = [0. for x in range(0, 4)]
            self.acc = [0. for x in range(0, 3)]
            self.gyro = [0. for x in range(0, 3)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_imustamp = struct.Struct("<Q")
            buff.write(struct_imustamp.pack(self.imustamp))
            offset += 8
            buff.write(_struct_I.pack(self.status))
            offset += 4
            buff.write(struct.pack(f'<{3}d', *self.euler))
            offset += 3 * 8
            buff.write(struct.pack(f'<{4}d', *self.quat))
            offset += 4 * 8
            buff.write(struct.pack(f'<{3}d', *self.acc))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.gyro))
            offset += 3 * 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_imustamp = struct.Struct("<Q")
            (self.imustamp,) = struct_imustamp.unpack(buff[offset:(offset + 8)])
            offset += 8
            (self.status,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.euler = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.quat = np.frombuffer(buff[offset:offset + 4 * 8], dtype=np.float64)
            offset += 4 * 8
            self.acc = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.gyro = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 4
        length += 3 * 8
        length += 4 * 8
        length += 3 * 8
        length += 3 * 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"imustamp":%s' % self.imustamp
        string_echo += ','
        string_echo += '"status":%s' % self.status
        string_echo += ','
        string_echo += '"euler":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.euler[i]
            else:
                string_echo += '%s,' % self.euler[i]
        string_echo += '],'
        string_echo += '"quat":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.quat[i]
            else:
                string_echo += '%s,' % self.quat[i]
        string_echo += '],'
        string_echo += '"acc":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.acc[i]
            else:
                string_echo += '%s,' % self.acc[i]
        string_echo += '],'
        string_echo += '"gyro":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.gyro[i]
            else:
                string_echo += '%s,' % self.gyro[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/IMUData"

    def getMD5(self):
        return "4713fbd787897a0c91a2a31aa6a873c6"

    def getDef(self):
        return "std_msgs/Header header\nuint64 imustamp\nuint32 status\nfloat64[3] euler\nfloat64[4] quat\nfloat64[3] acc\nfloat64[3] gyro\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

