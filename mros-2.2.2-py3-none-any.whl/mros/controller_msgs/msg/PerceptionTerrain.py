import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg
import mros.std_msgs.msg

class PerceptionTerrain(mros.Message):
    __slots__ = ['header','pos','quat','stair_depth','stair_height','lateral_factor','yaw_error','plane_num','build_stairs','stair_origin','iter_plane','reach_post_stair','planes']
    _slot_types = ['std_msgs/Header','float64[3]','float64[4]','float64','float64','int16','float64','int16','bool','float64[3]','int64','bool','mros.controller_msgs.msg.Plane[30]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PerceptionTerrain, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.pos is None:
                self.pos = [0. for x in range(0, 3)]
            if self.quat is None:
                self.quat = [0. for x in range(0, 4)]
            if self.stair_depth is None:
                self.stair_depth = 0.
            if self.stair_height is None:
                self.stair_height = 0.
            if self.lateral_factor is None:
                self.lateral_factor = 0
            if self.yaw_error is None:
                self.yaw_error = 0.
            if self.plane_num is None:
                self.plane_num = 0
            if self.build_stairs is None:
                self.build_stairs = False
            if self.stair_origin is None:
                self.stair_origin = [0. for x in range(0, 3)]
            if self.iter_plane is None:
                self.iter_plane = 0
            if self.reach_post_stair is None:
                self.reach_post_stair = False
            if self.planes is None:
                self.planes = [mros.controller_msgs.msg.Plane() for x in range(0, 30)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.pos = [0. for x in range(0, 3)]
            self.quat = [0. for x in range(0, 4)]
            self.stair_depth = 0.
            self.stair_height = 0.
            self.lateral_factor = 0
            self.yaw_error = 0.
            self.plane_num = 0
            self.build_stairs = False
            self.stair_origin = [0. for x in range(0, 3)]
            self.iter_plane = 0
            self.reach_post_stair = False
            self.planes = [mros.controller_msgs.msg.Plane() for x in range(0, 30)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{3}d', *self.pos))
            offset += 3 * 8
            buff.write(struct.pack(f'<{4}d', *self.quat))
            offset += 4 * 8
            struct_stair_depth = struct.Struct("<d")
            buff.write(struct_stair_depth.pack(self.stair_depth))
            offset += 8
            struct_stair_height = struct.Struct("<d")
            buff.write(struct_stair_height.pack(self.stair_height))
            offset += 8
            struct_lateral_factor = struct.Struct("<h")
            buff.write(struct_lateral_factor.pack(self.lateral_factor))
            offset += 2
            struct_yaw_error = struct.Struct("<d")
            buff.write(struct_yaw_error.pack(self.yaw_error))
            offset += 8
            struct_plane_num = struct.Struct("<h")
            buff.write(struct_plane_num.pack(self.plane_num))
            offset += 2
            struct_build_stairs = struct.Struct("<B")
            buff.write(struct_build_stairs.pack(self.build_stairs))
            offset += 1
            buff.write(struct.pack(f'<{3}d', *self.stair_origin))
            offset += 3 * 8
            struct_iter_plane = struct.Struct("<q")
            buff.write(struct_iter_plane.pack(self.iter_plane))
            offset += 8
            struct_reach_post_stair = struct.Struct("<B")
            buff.write(struct_reach_post_stair.pack(self.reach_post_stair))
            offset += 1
            for i in range(0, 30):
                offset += self.planes[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.pos = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.quat = np.frombuffer(buff[offset:offset + 4 * 8], dtype=np.float64)
            offset += 4 * 8
            struct_stair_depth = struct.Struct("<d")
            (self.stair_depth,) = struct_stair_depth.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_stair_height = struct.Struct("<d")
            (self.stair_height,) = struct_stair_height.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_lateral_factor = struct.Struct("<h")
            (self.lateral_factor,) = struct_lateral_factor.unpack(buff[offset:(offset + 2)])
            offset += 2
            struct_yaw_error = struct.Struct("<d")
            (self.yaw_error,) = struct_yaw_error.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_plane_num = struct.Struct("<h")
            (self.plane_num,) = struct_plane_num.unpack(buff[offset:(offset + 2)])
            offset += 2
            struct_build_stairs = struct.Struct("<B")
            (self.build_stairs,) = struct_build_stairs.unpack(buff[offset:(offset + 1)])
            self.build_stairs = bool(self.build_stairs)
            offset += 1
            self.stair_origin = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            struct_iter_plane = struct.Struct("<q")
            (self.iter_plane,) = struct_iter_plane.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_reach_post_stair = struct.Struct("<B")
            (self.reach_post_stair,) = struct_reach_post_stair.unpack(buff[offset:(offset + 1)])
            self.reach_post_stair = bool(self.reach_post_stair)
            offset += 1
            for i in range(0, 30):
                offset += self.planes[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 3 * 8
        length += 4 * 8
        length += 8
        length += 8
        length += 2
        length += 8
        length += 2
        length += 1
        length += 3 * 8
        length += 8
        length += 1
        for i in range(0, 30):
            length += self.planes[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"pos":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.pos[i]
            else:
                string_echo += '%s,' % self.pos[i]
        string_echo += '],'
        string_echo += '"quat":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.quat[i]
            else:
                string_echo += '%s,' % self.quat[i]
        string_echo += '],'
        string_echo += '"stair_depth":%s' % self.stair_depth
        string_echo += ','
        string_echo += '"stair_height":%s' % self.stair_height
        string_echo += ','
        string_echo += '"lateral_factor":%s' % self.lateral_factor
        string_echo += ','
        string_echo += '"yaw_error":%s' % self.yaw_error
        string_echo += ','
        string_echo += '"plane_num":%s' % self.plane_num
        string_echo += ','
        string_echo += '"build_stairs":%s' % self.build_stairs
        string_echo += ','
        string_echo += '"stair_origin":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.stair_origin[i]
            else:
                string_echo += '%s,' % self.stair_origin[i]
        string_echo += '],'
        string_echo += '"iter_plane":%s' % self.iter_plane
        string_echo += ','
        string_echo += '"reach_post_stair":%s' % self.reach_post_stair
        string_echo += ','
        string_echo += '"planes":['
        for i in range(0, 30):
            if i == (30 - 1): 
                string_echo += '{planes%s":' % i
                string_echo += self.planes[i].echo()
                string_echo += ''
            else:
                string_echo += '{planes%s":' % i
                string_echo += self.planes[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/PerceptionTerrain"

    def getMD5(self):
        return "83e5fa257af87084d5d9b3bc17517b07"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[3] pos\nfloat64[4] quat\nfloat64 stair_depth\nfloat64 stair_height\nint16 lateral_factor\nfloat64 yaw_error\nint16 plane_num\nbool build_stairs\nfloat64[3] stair_origin\nint64 iter_plane\nbool reach_post_stair\ncontroller_msgs/Plane[30] planes\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: controller_msgs/Plane\nstd_msgs/Header header\nfloat64[3] A\nint16 bound_num\ngeometry_msgs/Point[8] Bs\ngeometry_msgs/Point[8] Vertexs\nfloat64[3] center\nfloat64 area\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

