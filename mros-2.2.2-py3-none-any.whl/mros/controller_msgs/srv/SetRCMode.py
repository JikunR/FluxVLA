import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.controller_msgs.msg

class SetRCModeRequest(mros.Message):
    __slots__ = ['__id__','current_mode','change_to_mode']
    _slot_types = ['uint32','int8','int8']

    IDLE_MODE =  0  
    NAVI_MODE =  1  
    USER_MODE =  2  
    MANUAL_MODE =  3  

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetRCModeRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.current_mode is None:
                self.current_mode = 0
            if self.change_to_mode is None:
                self.change_to_mode = 0
        else:
            self.__id__ = 0
            self.current_mode = 0
            self.change_to_mode = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_current_mode = struct.Struct("<b")
            buff.write(struct_current_mode.pack(self.current_mode))
            offset += 1
            struct_change_to_mode = struct.Struct("<b")
            buff.write(struct_change_to_mode.pack(self.change_to_mode))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_current_mode = struct.Struct("<b")
            (self.current_mode,) = struct_current_mode.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_change_to_mode = struct.Struct("<b")
            (self.change_to_mode,) = struct_change_to_mode.unpack(buff[offset:(offset + 1)])
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"current_mode":%s' % self.current_mode
        string_echo += ','
        string_echo += '"change_to_mode":%s' % self.change_to_mode
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/SetRCMode"

    def getMD5(self):
        return "a3db3b488d101674bd33cc2f63a13cb9"
    def getDef(self):
        return "int8 IDLE_MODE    = 0\nint8 NAVI_MODE    = 1\nint8 USER_MODE    = 2\nint8 MANUAL_MODE  = 3\nint8 current_mode\nint8 change_to_mode\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetRCModeResponse(mros.Message):
    __slots__ = ['__id__','error','success']
    _slot_types = ['uint32','string','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetRCModeResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.error is None:
                self.error = ''
            if self.success is None:
                self.success = False
        else:
            self.__id__ = 0
            self.error = ''
            self.success = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.error
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_error,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.error = buff[offset:(offset + length_error)].decode('utf-8')
            else:
                self.error = buff[offset:(offset + length_error)]
            offset += length_error
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        error_x = self.error
        error_length = len(error_x)
        if python3 or type(error_x) == unicode:
            error_x = error_x.encode('utf-8')
            error_length = len(error_x)
        length += 4
        length += error_length
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"error":"%s"' % self.error
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "controller_msgs/SetRCMode"

    def getMD5(self):
        return "a3db3b488d101674bd33cc2f63a13cb9"
    def getDef(self):
        return "string error\nbool success\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetRCMode(object):
    Request = SetRCModeRequest
    Response = SetRCModeResponse

    __slots__ = ['request','response']
    _slot_types = ['SetRCModeRequest','SetRCModeResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetRCMode, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

