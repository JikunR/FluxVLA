import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ipcamera_msgs.msg

class CameraCtrl(mros.Message):
    __slots__ = ['cmd']
    _slot_types = ['int32']

    IPC_CMD_UP =  0
    IPC_CMD_DOWN =  1
    IPC_CMD_LEFT =  2
    IPC_CMD_RIGHT =  3
    IPC_CMD_ZOOM_UP_START =  4
    IPC_CMD_ZOOM_UP_STOP =  6
    IPC_CMD_ZOOM_DOWN_START =  7
    IPC_CMD_ZOOM_DOWN_STOP =  8
    IPC_CMD_SET_LOCK_MODE =  9
    IPC_CMD_SET_FOLLOW_MODE =  10

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CameraCtrl, self).__init__(*args, **kwds)
            if self.cmd is None:
                self.cmd = 0
        else:
            self.cmd = 0

    def serialize(self, buff):
        offset = 0
        try:
            struct_cmd = struct.Struct("<i")
            buff.write(struct_cmd.pack(self.cmd))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_cmd = struct.Struct("<i")
            (self.cmd,) = struct_cmd.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"cmd":%s' % self.cmd
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ipcamera_msgs/CameraCtrl"

    def getMD5(self):
        return "41cfee5ccb3e668affc169faf932fb42"

    def getDef(self):
        return "int32 IPC_CMD_UP = 0\nint32 IPC_CMD_DOWN = 1\nint32 IPC_CMD_LEFT = 2\nint32 IPC_CMD_RIGHT = 3\nint32 IPC_CMD_ZOOM_UP_START = 4\nint32 IPC_CMD_ZOOM_UP_STOP = 6\nint32 IPC_CMD_ZOOM_DOWN_START = 7\nint32 IPC_CMD_ZOOM_DOWN_STOP = 8\nint32 IPC_CMD_SET_LOCK_MODE = 9\nint32 IPC_CMD_SET_FOLLOW_MODE = 10\nint32 cmd\n"

_struct_I = struct.Struct('<I')

