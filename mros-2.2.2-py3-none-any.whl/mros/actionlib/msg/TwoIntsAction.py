import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TwoIntsAction(mros.Message):
    __slots__ = ['action_goal','action_result','action_feedback']
    _slot_types = ['actionlib/TwoIntsActionGoal','actionlib/TwoIntsActionResult','actionlib/TwoIntsActionFeedback']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TwoIntsAction, self).__init__(*args, **kwds)
            if self.action_goal is None:
                self.action_goal = mros.actionlib.msg.TwoIntsActionGoal()
            if self.action_result is None:
                self.action_result = mros.actionlib.msg.TwoIntsActionResult()
            if self.action_feedback is None:
                self.action_feedback = mros.actionlib.msg.TwoIntsActionFeedback()
        else:
            self.action_goal = mros.actionlib.msg.TwoIntsActionGoal()
            self.action_result = mros.actionlib.msg.TwoIntsActionResult()
            self.action_feedback = mros.actionlib.msg.TwoIntsActionFeedback()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.serialize(buff)
            offset += self.action_result.serialize(buff)
            offset += self.action_feedback.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.deserialize(buff[offset:])
            offset += self.action_result.deserialize(buff[offset:])
            offset += self.action_feedback.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.action_goal.serializedLength()
        length += self.action_result.serializedLength()
        length += self.action_feedback.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"action_goal":'
        string_echo += self.action_goal.echo()
        string_echo += ','
        string_echo += '"action_result":'
        string_echo += self.action_result.echo()
        string_echo += ','
        string_echo += '"action_feedback":'
        string_echo += self.action_feedback.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TwoIntsAction"

    def getMD5(self):
        return "6d1aa538c4bd6183a2dfb7fcac41ee50"

    def getDef(self):
        return "actionlib/TwoIntsActionGoal action_goal\nactionlib/TwoIntsActionResult action_result\nactionlib/TwoIntsActionFeedback action_feedback\n================================================================================\nMSG: actionlib/TwoIntsActionGoal\nstd_msgs/Header header\nactionlib_msgs/GoalID goal_id\nactionlib/TwoIntsGoal goal\n================================================================================\nMSG: actionlib/TwoIntsActionResult\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nactionlib/TwoIntsResult result\n================================================================================\nMSG: actionlib/TwoIntsActionFeedback\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nactionlib/TwoIntsFeedback feedback\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: actionlib/TwoIntsGoal\nint64 a\nint64 b\n================================================================================\nMSG: actionlib_msgs/GoalStatus\nactionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: actionlib/TwoIntsResult\nint64 sum\n================================================================================\nMSG: actionlib/TwoIntsFeedback\n"

_struct_I = struct.Struct('<I')

