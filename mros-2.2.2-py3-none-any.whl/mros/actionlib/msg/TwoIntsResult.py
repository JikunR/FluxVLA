import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TwoIntsResult(mros.Message):
    __slots__ = ['sum']
    _slot_types = ['int64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TwoIntsResult, self).__init__(*args, **kwds)
            if self.sum is None:
                self.sum = 0
        else:
            self.sum = 0

    def serialize(self, buff):
        offset = 0
        try:
            struct_sum = struct.Struct("<q")
            buff.write(struct_sum.pack(self.sum))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_sum = struct.Struct("<q")
            (self.sum,) = struct_sum.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"sum":%s' % self.sum
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TwoIntsResult"

    def getMD5(self):
        return "b88405221c77b1878a3cbbfff53428d7"

    def getDef(self):
        return "int64 sum\n"

_struct_I = struct.Struct('<I')

