import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TestGoal(mros.Message):
    __slots__ = ['goal']
    _slot_types = ['int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestGoal, self).__init__(*args, **kwds)
            if self.goal is None:
                self.goal = 0
        else:
            self.goal = 0

    def serialize(self, buff):
        offset = 0
        try:
            struct_goal = struct.Struct("<i")
            buff.write(struct_goal.pack(self.goal))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_goal = struct.Struct("<i")
            (self.goal,) = struct_goal.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"goal":%s' % self.goal
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestGoal"

    def getMD5(self):
        return "18df0149936b7aa95588e3862476ebde"

    def getDef(self):
        return "int32 goal\n"

_struct_I = struct.Struct('<I')

