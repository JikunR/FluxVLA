import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TestRequestGoal(mros.Message):
    __slots__ = ['terminate_status','ignore_cancel','result_text','the_result','is_simple_client','delay_accept','delay_terminate','pause_status']
    _slot_types = ['int32','bool','string','int32','bool','Duration','Duration','Duration']

    TERMINATE_SUCCESS =  0
    TERMINATE_ABORTED =  1
    TERMINATE_REJECTED =  2
    TERMINATE_LOSE =  3
    TERMINATE_DROP =  4
    TERMINATE_EXCEPTION =  5

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestRequestGoal, self).__init__(*args, **kwds)
            if self.terminate_status is None:
                self.terminate_status = 0
            if self.ignore_cancel is None:
                self.ignore_cancel = False
            if self.result_text is None:
                self.result_text = ''
            if self.the_result is None:
                self.the_result = 0
            if self.is_simple_client is None:
                self.is_simple_client = False
            if self.delay_accept is None:
                self.delay_accept = mros.Duration()
            if self.delay_terminate is None:
                self.delay_terminate = mros.Duration()
            if self.pause_status is None:
                self.pause_status = mros.Duration()
        else:
            self.terminate_status = 0
            self.ignore_cancel = False
            self.result_text = ''
            self.the_result = 0
            self.is_simple_client = False
            self.delay_accept = mros.Duration()
            self.delay_terminate = mros.Duration()
            self.pause_status = mros.Duration()

    def serialize(self, buff):
        offset = 0
        try:
            struct_terminate_status = struct.Struct("<i")
            buff.write(struct_terminate_status.pack(self.terminate_status))
            offset += 4
            struct_ignore_cancel = struct.Struct("<B")
            buff.write(struct_ignore_cancel.pack(self.ignore_cancel))
            offset += 1
            _x = self.result_text
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_the_result = struct.Struct("<i")
            buff.write(struct_the_result.pack(self.the_result))
            offset += 4
            struct_is_simple_client = struct.Struct("<B")
            buff.write(struct_is_simple_client.pack(self.is_simple_client))
            offset += 1
            buff.write(_struct_I.pack(self.delay_accept.sec))
            offset += 4
            buff.write(_struct_I.pack(self.delay_accept.nsec))
            offset += 4
            buff.write(_struct_I.pack(self.delay_terminate.sec))
            offset += 4
            buff.write(_struct_I.pack(self.delay_terminate.nsec))
            offset += 4
            buff.write(_struct_I.pack(self.pause_status.sec))
            offset += 4
            buff.write(_struct_I.pack(self.pause_status.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_terminate_status = struct.Struct("<i")
            (self.terminate_status,) = struct_terminate_status.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_ignore_cancel = struct.Struct("<B")
            (self.ignore_cancel,) = struct_ignore_cancel.unpack(buff[offset:(offset + 1)])
            self.ignore_cancel = bool(self.ignore_cancel)
            offset += 1
            (length_result_text,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.result_text = buff[offset:(offset + length_result_text)].decode('utf-8')
            else:
                self.result_text = buff[offset:(offset + length_result_text)]
            offset += length_result_text
            struct_the_result = struct.Struct("<i")
            (self.the_result,) = struct_the_result.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_is_simple_client = struct.Struct("<B")
            (self.is_simple_client,) = struct_is_simple_client.unpack(buff[offset:(offset + 1)])
            self.is_simple_client = bool(self.is_simple_client)
            offset += 1
            (self.delay_accept.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.delay_accept.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.delay_terminate.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.delay_terminate.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.pause_status.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.pause_status.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        result_text_x = self.result_text
        result_text_length = len(result_text_x)
        if python3 or type(result_text_x) == unicode:
            result_text_x = result_text_x.encode('utf-8')
            result_text_length = len(result_text_x)
        length += 4
        length += result_text_length
        length += 4
        length += 1
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"terminate_status":%s' % self.terminate_status
        string_echo += ','
        string_echo += '"ignore_cancel":%s' % self.ignore_cancel
        string_echo += ','
        string_echo += '"result_text":"%s"' % self.result_text
        string_echo += ','
        string_echo += '"the_result":%s' % self.the_result
        string_echo += ','
        string_echo += '"is_simple_client":%s' % self.is_simple_client
        string_echo += ','
        string_echo += '"delay_accept.sec":%s,' % self.delay_accept.sec
        string_echo += '"delay_accept.nsec":%s' % self.delay_accept.nsec
        string_echo += ','
        string_echo += '"delay_terminate.sec":%s,' % self.delay_terminate.sec
        string_echo += '"delay_terminate.nsec":%s' % self.delay_terminate.nsec
        string_echo += ','
        string_echo += '"pause_status.sec":%s,' % self.pause_status.sec
        string_echo += '"pause_status.nsec":%s' % self.pause_status.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestRequestGoal"

    def getMD5(self):
        return "db5d00ba98302d6c6dd3737e9a03ceea"

    def getDef(self):
        return "int32 TERMINATE_SUCCESS = 0\nint32 TERMINATE_ABORTED = 1\nint32 TERMINATE_REJECTED = 2\nint32 TERMINATE_LOSE = 3\nint32 TERMINATE_DROP = 4\nint32 TERMINATE_EXCEPTION = 5\nint32 terminate_status\nbool ignore_cancel\nstring result_text\nint32 the_result\nbool is_simple_client\nduration delay_accept\nduration delay_terminate\nduration pause_status\n"

_struct_I = struct.Struct('<I')

