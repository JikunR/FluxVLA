import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TestFeedback(mros.Message):
    __slots__ = ['feedback']
    _slot_types = ['int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestFeedback, self).__init__(*args, **kwds)
            if self.feedback is None:
                self.feedback = 0
        else:
            self.feedback = 0

    def serialize(self, buff):
        offset = 0
        try:
            struct_feedback = struct.Struct("<i")
            buff.write(struct_feedback.pack(self.feedback))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_feedback = struct.Struct("<i")
            (self.feedback,) = struct_feedback.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"feedback":%s' % self.feedback
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestFeedback"

    def getMD5(self):
        return "49ceb5b32ea3af22073ede4a0328249e"

    def getDef(self):
        return "int32 feedback\n"

_struct_I = struct.Struct('<I')

