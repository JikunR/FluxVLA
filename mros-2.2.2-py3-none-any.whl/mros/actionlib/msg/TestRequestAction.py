import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TestRequestAction(mros.Message):
    __slots__ = ['action_goal','action_result','action_feedback']
    _slot_types = ['actionlib/TestRequestActionGoal','actionlib/TestRequestActionResult','actionlib/TestRequestActionFeedback']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestRequestAction, self).__init__(*args, **kwds)
            if self.action_goal is None:
                self.action_goal = mros.actionlib.msg.TestRequestActionGoal()
            if self.action_result is None:
                self.action_result = mros.actionlib.msg.TestRequestActionResult()
            if self.action_feedback is None:
                self.action_feedback = mros.actionlib.msg.TestRequestActionFeedback()
        else:
            self.action_goal = mros.actionlib.msg.TestRequestActionGoal()
            self.action_result = mros.actionlib.msg.TestRequestActionResult()
            self.action_feedback = mros.actionlib.msg.TestRequestActionFeedback()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.serialize(buff)
            offset += self.action_result.serialize(buff)
            offset += self.action_feedback.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.deserialize(buff[offset:])
            offset += self.action_result.deserialize(buff[offset:])
            offset += self.action_feedback.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.action_goal.serializedLength()
        length += self.action_result.serializedLength()
        length += self.action_feedback.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"action_goal":'
        string_echo += self.action_goal.echo()
        string_echo += ','
        string_echo += '"action_result":'
        string_echo += self.action_result.echo()
        string_echo += ','
        string_echo += '"action_feedback":'
        string_echo += self.action_feedback.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestRequestAction"

    def getMD5(self):
        return "dc44b1f4045dbf0d1db54423b3b86b30"

    def getDef(self):
        return "actionlib/TestRequestActionGoal action_goal\nactionlib/TestRequestActionResult action_result\nactionlib/TestRequestActionFeedback action_feedback\n================================================================================\nMSG: actionlib/TestRequestActionGoal\nstd_msgs/Header header\nactionlib_msgs/GoalID goal_id\nactionlib/TestRequestGoal goal\n================================================================================\nMSG: actionlib/TestRequestActionResult\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nactionlib/TestRequestResult result\n================================================================================\nMSG: actionlib/TestRequestActionFeedback\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nactionlib/TestRequestFeedback feedback\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: actionlib/TestRequestGoal\nint32 TERMINATE_SUCCESS = 0\nint32 TERMINATE_ABORTED = 1\nint32 TERMINATE_REJECTED = 2\nint32 TERMINATE_LOSE = 3\nint32 TERMINATE_DROP = 4\nint32 TERMINATE_EXCEPTION = 5\nint32 terminate_status\nbool ignore_cancel\nstring result_text\nint32 the_result\nbool is_simple_client\nduration delay_accept\nduration delay_terminate\nduration pause_status\n================================================================================\nMSG: actionlib_msgs/GoalStatus\nactionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: actionlib/TestRequestResult\nint32 the_result\nbool is_simple_server\n================================================================================\nMSG: actionlib/TestRequestFeedback\n"

_struct_I = struct.Struct('<I')

