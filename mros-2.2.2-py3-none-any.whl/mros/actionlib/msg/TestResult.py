import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TestResult(mros.Message):
    __slots__ = ['result']
    _slot_types = ['int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestResult, self).__init__(*args, **kwds)
            if self.result is None:
                self.result = 0
        else:
            self.result = 0

    def serialize(self, buff):
        offset = 0
        try:
            struct_result = struct.Struct("<i")
            buff.write(struct_result.pack(self.result))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_result = struct.Struct("<i")
            (self.result,) = struct_result.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"result":%s' % self.result
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestResult"

    def getMD5(self):
        return "034a8e20d6a306665e3a5b340fab3f09"

    def getDef(self):
        return "int32 result\n"

_struct_I = struct.Struct('<I')

