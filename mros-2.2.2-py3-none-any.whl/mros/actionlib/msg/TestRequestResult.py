import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TestRequestResult(mros.Message):
    __slots__ = ['the_result','is_simple_server']
    _slot_types = ['int32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestRequestResult, self).__init__(*args, **kwds)
            if self.the_result is None:
                self.the_result = 0
            if self.is_simple_server is None:
                self.is_simple_server = False
        else:
            self.the_result = 0
            self.is_simple_server = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_the_result = struct.Struct("<i")
            buff.write(struct_the_result.pack(self.the_result))
            offset += 4
            struct_is_simple_server = struct.Struct("<B")
            buff.write(struct_is_simple_server.pack(self.is_simple_server))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_the_result = struct.Struct("<i")
            (self.the_result,) = struct_the_result.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_is_simple_server = struct.Struct("<B")
            (self.is_simple_server,) = struct_is_simple_server.unpack(buff[offset:(offset + 1)])
            self.is_simple_server = bool(self.is_simple_server)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"the_result":%s' % self.the_result
        string_echo += ','
        string_echo += '"is_simple_server":%s' % self.is_simple_server
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestRequestResult"

    def getMD5(self):
        return "61c2364524499c7c5017e2f3fce7ba06"

    def getDef(self):
        return "int32 the_result\nbool is_simple_server\n"

_struct_I = struct.Struct('<I')

