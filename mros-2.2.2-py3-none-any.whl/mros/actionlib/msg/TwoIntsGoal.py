import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TwoIntsGoal(mros.Message):
    __slots__ = ['a','b']
    _slot_types = ['int64','int64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TwoIntsGoal, self).__init__(*args, **kwds)
            if self.a is None:
                self.a = 0
            if self.b is None:
                self.b = 0
        else:
            self.a = 0
            self.b = 0

    def serialize(self, buff):
        offset = 0
        try:
            struct_a = struct.Struct("<q")
            buff.write(struct_a.pack(self.a))
            offset += 8
            struct_b = struct.Struct("<q")
            buff.write(struct_b.pack(self.b))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_a = struct.Struct("<q")
            (self.a,) = struct_a.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_b = struct.Struct("<q")
            (self.b,) = struct_b.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"a":%s' % self.a
        string_echo += ','
        string_echo += '"b":%s' % self.b
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TwoIntsGoal"

    def getMD5(self):
        return "36d09b846be0b371c5f190354dd3153e"

    def getDef(self):
        return "int64 a\nint64 b\n"

_struct_I = struct.Struct('<I')

