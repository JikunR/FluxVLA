import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TestAction(mros.Message):
    __slots__ = ['action_goal','action_result','action_feedback']
    _slot_types = ['actionlib/TestActionGoal','actionlib/TestActionResult','actionlib/TestActionFeedback']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestAction, self).__init__(*args, **kwds)
            if self.action_goal is None:
                self.action_goal = mros.actionlib.msg.TestActionGoal()
            if self.action_result is None:
                self.action_result = mros.actionlib.msg.TestActionResult()
            if self.action_feedback is None:
                self.action_feedback = mros.actionlib.msg.TestActionFeedback()
        else:
            self.action_goal = mros.actionlib.msg.TestActionGoal()
            self.action_result = mros.actionlib.msg.TestActionResult()
            self.action_feedback = mros.actionlib.msg.TestActionFeedback()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.serialize(buff)
            offset += self.action_result.serialize(buff)
            offset += self.action_feedback.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.action_goal.deserialize(buff[offset:])
            offset += self.action_result.deserialize(buff[offset:])
            offset += self.action_feedback.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.action_goal.serializedLength()
        length += self.action_result.serializedLength()
        length += self.action_feedback.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"action_goal":'
        string_echo += self.action_goal.echo()
        string_echo += ','
        string_echo += '"action_result":'
        string_echo += self.action_result.echo()
        string_echo += ','
        string_echo += '"action_feedback":'
        string_echo += self.action_feedback.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestAction"

    def getMD5(self):
        return "991e87a72802262dfbe5d1b3cf6efc9a"

    def getDef(self):
        return "actionlib/TestActionGoal action_goal\nactionlib/TestActionResult action_result\nactionlib/TestActionFeedback action_feedback\n================================================================================\nMSG: actionlib/TestActionGoal\nstd_msgs/Header header\nactionlib_msgs/GoalID goal_id\nactionlib/TestGoal goal\n================================================================================\nMSG: actionlib/TestActionResult\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nactionlib/TestResult result\n================================================================================\nMSG: actionlib/TestActionFeedback\nstd_msgs/Header header\nactionlib_msgs/GoalStatus status\nactionlib/TestFeedback feedback\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: actionlib/TestGoal\nint32 goal\n================================================================================\nMSG: actionlib_msgs/GoalStatus\nactionlib_msgs/GoalID goal_id\nuint8 status\nuint8 PENDING         = 0\nuint8 ACTIVE          = 1\nuint8 PREEMPTED       = 2\nuint8 SUCCEEDED       = 3\nuint8 ABORTED         = 4\nuint8 REJECTED        = 5\nuint8 PREEMPTING      = 6\nuint8 RECALLING       = 7\nuint8 RECALLED        = 8\nuint8 LOST            = 9\nstring text\n================================================================================\nMSG: actionlib/TestResult\nint32 result\n================================================================================\nMSG: actionlib/TestFeedback\nint32 feedback\n"

_struct_I = struct.Struct('<I')

