import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg

class TwoIntsFeedback(mros.Message):
    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TwoIntsFeedback, self).__init__(*args, **kwds)

    def serialize(self, buff):
        offset = 0
        return offset

    def deserialize(self, buff):
        offset = 0
        return offset

    def serializedLength(self):
        length = 0
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TwoIntsFeedback"

    def getMD5(self):
        return "d41d8cd98f00b204e9800998ecf8427e"

    def getDef(self):
        return ""

_struct_I = struct.Struct('<I')

