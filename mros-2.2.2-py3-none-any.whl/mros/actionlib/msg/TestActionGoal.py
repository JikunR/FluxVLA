import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.actionlib.msg
import mros.std_msgs.msg
import mros.actionlib_msgs.msg

class TestActionGoal(mros.Message):
    __slots__ = ['header','goal_id','goal']
    _slot_types = ['std_msgs/Header','actionlib_msgs/GoalID','actionlib/TestGoal']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TestActionGoal, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.goal_id is None:
                self.goal_id = mros.actionlib_msgs.msg.GoalID()
            if self.goal is None:
                self.goal = mros.actionlib.msg.TestGoal()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.goal_id = mros.actionlib_msgs.msg.GoalID()
            self.goal = mros.actionlib.msg.TestGoal()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.goal_id.serialize(buff)
            offset += self.goal.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.goal_id.deserialize(buff[offset:])
            offset += self.goal.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.goal_id.serializedLength()
        length += self.goal.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"goal_id":'
        string_echo += self.goal_id.echo()
        string_echo += ','
        string_echo += '"goal":'
        string_echo += self.goal.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "actionlib/TestActionGoal"

    def getMD5(self):
        return "348369c5b403676156094e8c159720bf"

    def getDef(self):
        return "std_msgs/Header header\nactionlib_msgs/GoalID goal_id\nactionlib/TestGoal goal\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: actionlib_msgs/GoalID\ntime stamp\nstring id\n================================================================================\nMSG: actionlib/TestGoal\nint32 goal\n"

_struct_I = struct.Struct('<I')

