import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.convex_plane_decomposition_msgs.msg

class Polygon2d(mros.Message):
    __slots__ = ['points']
    _slot_types = ['convex_plane_decomposition_msgs/Point2d[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Polygon2d, self).__init__(*args, **kwds)
            if self.points is None:
                self.points = []
        else:
            self.points = []

    def serialize(self, buff):
        offset = 0
        try:
            points_length = len(self.points)
            buff.write(struct.pack('<I', points_length))
            offset += 4
            for i in range(0, points_length):
                offset += self.points[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (points_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.points) != points_length:
                self.points = [mros.convex_plane_decomposition_msgs.msg.Point2d() for _ in range(points_length)]
            for i in range(0, points_length):
                offset += self.points[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, points_length):
            length += self.points[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"points":['
        points_length = len(self.points)
        for i in range(0, points_length):
            if i == (points_length - 1): 
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ''
            else:
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "convex_plane_decomposition_msgs/Polygon2d"

    def getMD5(self):
        return "0083ddac30f807eeef29c66ffedb79c7"

    def getDef(self):
        return "convex_plane_decomposition_msgs/Point2d[] points\n================================================================================\nMSG: convex_plane_decomposition_msgs/Point2d\nfloat32 x\nfloat32 y\n"

_struct_I = struct.Struct('<I')

