import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.convex_plane_decomposition_msgs.msg

class Point2d(mros.Message):
    __slots__ = ['x','y']
    _slot_types = ['float32','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Point2d, self).__init__(*args, **kwds)
            if self.x is None:
                self.x = 0.
            if self.y is None:
                self.y = 0.
        else:
            self.x = 0.
            self.y = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_x = struct.Struct("<f")
            buff.write(struct_x.pack(self.x))
            offset += 4
            struct_y = struct.Struct("<f")
            buff.write(struct_y.pack(self.y))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_x = struct.Struct("<f")
            (self.x,) = struct_x.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_y = struct.Struct("<f")
            (self.y,) = struct_y.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"x":%s' % self.x
        string_echo += ','
        string_echo += '"y":%s' % self.y
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "convex_plane_decomposition_msgs/Point2d"

    def getMD5(self):
        return "ff8d7d66dd3e4b731ef14a45d38888b6"

    def getDef(self):
        return "float32 x\nfloat32 y\n"

_struct_I = struct.Struct('<I')

