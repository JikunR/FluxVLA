import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.convex_plane_decomposition_msgs.msg
import mros.geometry_msgs.msg

class PlanarRegion(mros.Message):
    __slots__ = ['plane_parameters','bbox2d','boundary','insets']
    _slot_types = ['geometry_msgs/Pose','convex_plane_decomposition_msgs/BoundingBox2d','convex_plane_decomposition_msgs/PolygonWithHoles2d','convex_plane_decomposition_msgs/PolygonWithHoles2d[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlanarRegion, self).__init__(*args, **kwds)
            if self.plane_parameters is None:
                self.plane_parameters = mros.geometry_msgs.msg.Pose()
            if self.bbox2d is None:
                self.bbox2d = mros.convex_plane_decomposition_msgs.msg.BoundingBox2d()
            if self.boundary is None:
                self.boundary = mros.convex_plane_decomposition_msgs.msg.PolygonWithHoles2d()
            if self.insets is None:
                self.insets = []
        else:
            self.plane_parameters = mros.geometry_msgs.msg.Pose()
            self.bbox2d = mros.convex_plane_decomposition_msgs.msg.BoundingBox2d()
            self.boundary = mros.convex_plane_decomposition_msgs.msg.PolygonWithHoles2d()
            self.insets = []

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.plane_parameters.serialize(buff)
            offset += self.bbox2d.serialize(buff)
            offset += self.boundary.serialize(buff)
            insets_length = len(self.insets)
            buff.write(struct.pack('<I', insets_length))
            offset += 4
            for i in range(0, insets_length):
                offset += self.insets[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.plane_parameters.deserialize(buff[offset:])
            offset += self.bbox2d.deserialize(buff[offset:])
            offset += self.boundary.deserialize(buff[offset:])
            (insets_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.insets) != insets_length:
                self.insets = [mros.convex_plane_decomposition_msgs.msg.PolygonWithHoles2d() for _ in range(insets_length)]
            for i in range(0, insets_length):
                offset += self.insets[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.plane_parameters.serializedLength()
        length += self.bbox2d.serializedLength()
        length += self.boundary.serializedLength()
        length += 4
        for i in range(0, insets_length):
            length += self.insets[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"plane_parameters":'
        string_echo += self.plane_parameters.echo()
        string_echo += ','
        string_echo += '"bbox2d":'
        string_echo += self.bbox2d.echo()
        string_echo += ','
        string_echo += '"boundary":'
        string_echo += self.boundary.echo()
        string_echo += ','
        string_echo += '"insets":['
        insets_length = len(self.insets)
        for i in range(0, insets_length):
            if i == (insets_length - 1): 
                string_echo += '{insets%s":' % i
                string_echo += self.insets[i].echo()
                string_echo += ''
            else:
                string_echo += '{insets%s":' % i
                string_echo += self.insets[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "convex_plane_decomposition_msgs/PlanarRegion"

    def getMD5(self):
        return "8cff8c52c8273f12e2fd17b9d4a3d417"

    def getDef(self):
        return "geometry_msgs/Pose plane_parameters\nconvex_plane_decomposition_msgs/BoundingBox2d bbox2d\nconvex_plane_decomposition_msgs/PolygonWithHoles2d boundary\nconvex_plane_decomposition_msgs/PolygonWithHoles2d[] insets\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: convex_plane_decomposition_msgs/BoundingBox2d\nfloat32 min_x\nfloat32 min_y\nfloat32 max_x\nfloat32 max_y\n================================================================================\nMSG: convex_plane_decomposition_msgs/PolygonWithHoles2d\nconvex_plane_decomposition_msgs/Polygon2d outer_boundary\nconvex_plane_decomposition_msgs/Polygon2d[] holes\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: convex_plane_decomposition_msgs/Polygon2d\nconvex_plane_decomposition_msgs/Point2d[] points\n================================================================================\nMSG: convex_plane_decomposition_msgs/Point2d\nfloat32 x\nfloat32 y\n"

_struct_I = struct.Struct('<I')

