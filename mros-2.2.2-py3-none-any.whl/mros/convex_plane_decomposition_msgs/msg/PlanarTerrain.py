import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.convex_plane_decomposition_msgs.msg
import mros.grid_map_msgs.msg

class PlanarTerrain(mros.Message):
    __slots__ = ['planarRegions','gridmap']
    _slot_types = ['convex_plane_decomposition_msgs/PlanarRegion[]','grid_map_msgs/GridMap']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PlanarTerrain, self).__init__(*args, **kwds)
            if self.planarRegions is None:
                self.planarRegions = []
            if self.gridmap is None:
                self.gridmap = mros.grid_map_msgs.msg.GridMap()
        else:
            self.planarRegions = []
            self.gridmap = mros.grid_map_msgs.msg.GridMap()

    def serialize(self, buff):
        offset = 0
        try:
            planarRegions_length = len(self.planarRegions)
            buff.write(struct.pack('<I', planarRegions_length))
            offset += 4
            for i in range(0, planarRegions_length):
                offset += self.planarRegions[i].serialize(buff)
            offset += self.gridmap.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (planarRegions_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.planarRegions) != planarRegions_length:
                self.planarRegions = [mros.convex_plane_decomposition_msgs.msg.PlanarRegion() for _ in range(planarRegions_length)]
            for i in range(0, planarRegions_length):
                offset += self.planarRegions[i].deserialize(buff[offset:])
            offset += self.gridmap.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        for i in range(0, planarRegions_length):
            length += self.planarRegions[i].serializedLength()
        length += self.gridmap.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"planarRegions":['
        planarRegions_length = len(self.planarRegions)
        for i in range(0, planarRegions_length):
            if i == (planarRegions_length - 1): 
                string_echo += '{planarRegions%s":' % i
                string_echo += self.planarRegions[i].echo()
                string_echo += ''
            else:
                string_echo += '{planarRegions%s":' % i
                string_echo += self.planarRegions[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"gridmap":'
        string_echo += self.gridmap.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "convex_plane_decomposition_msgs/PlanarTerrain"

    def getMD5(self):
        return "081e702fce247ef5685dd96b39e3dfd4"

    def getDef(self):
        return "convex_plane_decomposition_msgs/PlanarRegion[] planarRegions\ngrid_map_msgs/GridMap gridmap\n================================================================================\nMSG: convex_plane_decomposition_msgs/PlanarRegion\ngeometry_msgs/Pose plane_parameters\nconvex_plane_decomposition_msgs/BoundingBox2d bbox2d\nconvex_plane_decomposition_msgs/PolygonWithHoles2d boundary\nconvex_plane_decomposition_msgs/PolygonWithHoles2d[] insets\n================================================================================\nMSG: grid_map_msgs/GridMap\ngrid_map_msgs/GridMapInfo info\nstring[] layers\nstring[] basic_layers\nstd_msgs/Float32MultiArray[] data\nuint16 outer_start_index\nuint16 inner_start_index\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: convex_plane_decomposition_msgs/BoundingBox2d\nfloat32 min_x\nfloat32 min_y\nfloat32 max_x\nfloat32 max_y\n================================================================================\nMSG: convex_plane_decomposition_msgs/PolygonWithHoles2d\nconvex_plane_decomposition_msgs/Polygon2d outer_boundary\nconvex_plane_decomposition_msgs/Polygon2d[] holes\n================================================================================\nMSG: grid_map_msgs/GridMapInfo\nstd_msgs/Header header\nfloat64 resolution\nfloat64 length_x\nfloat64 length_y\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Float32MultiArray\nstd_msgs/MultiArrayLayout layout\nfloat32[] data\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: convex_plane_decomposition_msgs/Polygon2d\nconvex_plane_decomposition_msgs/Point2d[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: std_msgs/MultiArrayLayout\nstd_msgs/MultiArrayDimension[] dim\nuint32 data_offset\n================================================================================\nMSG: convex_plane_decomposition_msgs/Point2d\nfloat32 x\nfloat32 y\n================================================================================\nMSG: std_msgs/MultiArrayDimension\nstring label\nuint32 size\nuint32 stride\n"

_struct_I = struct.Struct('<I')

