import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.convex_plane_decomposition_msgs.msg

class BoundingBox2d(mros.Message):
    __slots__ = ['min_x','min_y','max_x','max_y']
    _slot_types = ['float32','float32','float32','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(BoundingBox2d, self).__init__(*args, **kwds)
            if self.min_x is None:
                self.min_x = 0.
            if self.min_y is None:
                self.min_y = 0.
            if self.max_x is None:
                self.max_x = 0.
            if self.max_y is None:
                self.max_y = 0.
        else:
            self.min_x = 0.
            self.min_y = 0.
            self.max_x = 0.
            self.max_y = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_min_x = struct.Struct("<f")
            buff.write(struct_min_x.pack(self.min_x))
            offset += 4
            struct_min_y = struct.Struct("<f")
            buff.write(struct_min_y.pack(self.min_y))
            offset += 4
            struct_max_x = struct.Struct("<f")
            buff.write(struct_max_x.pack(self.max_x))
            offset += 4
            struct_max_y = struct.Struct("<f")
            buff.write(struct_max_y.pack(self.max_y))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_min_x = struct.Struct("<f")
            (self.min_x,) = struct_min_x.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_min_y = struct.Struct("<f")
            (self.min_y,) = struct_min_y.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_max_x = struct.Struct("<f")
            (self.max_x,) = struct_max_x.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_max_y = struct.Struct("<f")
            (self.max_y,) = struct_max_y.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"min_x":%s' % self.min_x
        string_echo += ','
        string_echo += '"min_y":%s' % self.min_y
        string_echo += ','
        string_echo += '"max_x":%s' % self.max_x
        string_echo += ','
        string_echo += '"max_y":%s' % self.max_y
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "convex_plane_decomposition_msgs/BoundingBox2d"

    def getMD5(self):
        return "882c57bd03c558cc1c0ff70ad4c5ef0e"

    def getDef(self):
        return "float32 min_x\nfloat32 min_y\nfloat32 max_x\nfloat32 max_y\n"

_struct_I = struct.Struct('<I')

