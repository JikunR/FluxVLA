import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.convex_plane_decomposition_msgs.msg

class PolygonWithHoles2d(mros.Message):
    __slots__ = ['outer_boundary','holes']
    _slot_types = ['convex_plane_decomposition_msgs/Polygon2d','convex_plane_decomposition_msgs/Polygon2d[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(PolygonWithHoles2d, self).__init__(*args, **kwds)
            if self.outer_boundary is None:
                self.outer_boundary = mros.convex_plane_decomposition_msgs.msg.Polygon2d()
            if self.holes is None:
                self.holes = []
        else:
            self.outer_boundary = mros.convex_plane_decomposition_msgs.msg.Polygon2d()
            self.holes = []

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.outer_boundary.serialize(buff)
            holes_length = len(self.holes)
            buff.write(struct.pack('<I', holes_length))
            offset += 4
            for i in range(0, holes_length):
                offset += self.holes[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.outer_boundary.deserialize(buff[offset:])
            (holes_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.holes) != holes_length:
                self.holes = [mros.convex_plane_decomposition_msgs.msg.Polygon2d() for _ in range(holes_length)]
            for i in range(0, holes_length):
                offset += self.holes[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.outer_boundary.serializedLength()
        length += 4
        for i in range(0, holes_length):
            length += self.holes[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"outer_boundary":'
        string_echo += self.outer_boundary.echo()
        string_echo += ','
        string_echo += '"holes":['
        holes_length = len(self.holes)
        for i in range(0, holes_length):
            if i == (holes_length - 1): 
                string_echo += '{holes%s":' % i
                string_echo += self.holes[i].echo()
                string_echo += ''
            else:
                string_echo += '{holes%s":' % i
                string_echo += self.holes[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "convex_plane_decomposition_msgs/PolygonWithHoles2d"

    def getMD5(self):
        return "62e09666eefc245f9ca3347875cb36cc"

    def getDef(self):
        return "convex_plane_decomposition_msgs/Polygon2d outer_boundary\nconvex_plane_decomposition_msgs/Polygon2d[] holes\n================================================================================\nMSG: convex_plane_decomposition_msgs/Polygon2d\nconvex_plane_decomposition_msgs/Point2d[] points\n================================================================================\nMSG: convex_plane_decomposition_msgs/Point2d\nfloat32 x\nfloat32 y\n"

_struct_I = struct.Struct('<I')

