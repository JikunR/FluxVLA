import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.kindr_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class VectorAtPosition(mros.Message):
    __slots__ = ['header','type','name','vector','position','position_frame_id']
    _slot_types = ['std_msgs/Header','uint8','string','geometry_msgs/Vector3','geometry_msgs/Point','string']

    TYPE_TYPELESS = 0
    TYPE_JERK = 6
    TYPE_ACCELERATION = 7
    TYPE_VELOCITY = 8
    TYPE_POSITION = 9
    TYPE_FORCE = 10
    TYPE_MOMEMTUM = 11
    TYPE_ANGULAR_JERK = 12
    TYPE_ANGULAR_ACCELERATION = 13
    TYPE_ANGULAR_VELOCITY = 14
    TYPE_TORQUE = 16
    TYPE_ANGULAR_MOMEMTUM = 17

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(VectorAtPosition, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.type is None:
                self.type = 0
            if self.name is None:
                self.name = ''
            if self.vector is None:
                self.vector = mros.geometry_msgs.msg.Vector3()
            if self.position is None:
                self.position = mros.geometry_msgs.msg.Point()
            if self.position_frame_id is None:
                self.position_frame_id = ''
        else:
            self.header = mros.std_msgs.msg.Header()
            self.type = 0
            self.name = ''
            self.vector = mros.geometry_msgs.msg.Vector3()
            self.position = mros.geometry_msgs.msg.Point()
            self.position_frame_id = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_type = struct.Struct("<B")
            buff.write(struct_type.pack(self.type))
            offset += 1
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.vector.serialize(buff)
            offset += self.position.serialize(buff)
            _x = self.position_frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_type = struct.Struct("<B")
            (self.type,) = struct_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            offset += self.vector.deserialize(buff[offset:])
            offset += self.position.deserialize(buff[offset:])
            (length_position_frame_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.position_frame_id = buff[offset:(offset + length_position_frame_id)].decode('utf-8')
            else:
                self.position_frame_id = buff[offset:(offset + length_position_frame_id)]
            offset += length_position_frame_id
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        length += self.vector.serializedLength()
        length += self.position.serializedLength()
        position_frame_id_x = self.position_frame_id
        position_frame_id_length = len(position_frame_id_x)
        if python3 or type(position_frame_id_x) == unicode:
            position_frame_id_x = position_frame_id_x.encode('utf-8')
            position_frame_id_length = len(position_frame_id_x)
        length += 4
        length += position_frame_id_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"type":%s' % self.type
        string_echo += ','
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"vector":'
        string_echo += self.vector.echo()
        string_echo += ','
        string_echo += '"position":'
        string_echo += self.position.echo()
        string_echo += ','
        string_echo += '"position_frame_id":"%s"' % self.position_frame_id
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "kindr_msgs/VectorAtPosition"

    def getMD5(self):
        return "fcf32a1df9f6d53ef1926f20ce6b66e0"

    def getDef(self):
        return "uint8 TYPE_TYPELESS=0\nuint8 TYPE_JERK=6\nuint8 TYPE_ACCELERATION=7\nuint8 TYPE_VELOCITY=8\nuint8 TYPE_POSITION=9\nuint8 TYPE_FORCE=10\nuint8 TYPE_MOMEMTUM=11\nuint8 TYPE_ANGULAR_JERK=12\nuint8 TYPE_ANGULAR_ACCELERATION=13\nuint8 TYPE_ANGULAR_VELOCITY=14\nuint8 TYPE_TORQUE=16\nuint8 TYPE_ANGULAR_MOMEMTUM=17\nstd_msgs/Header header\nuint8 type\nstring name\ngeometry_msgs/Vector3 vector\ngeometry_msgs/Point position\nstring position_frame_id\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Vector3\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n"

_struct_I = struct.Struct('<I')

