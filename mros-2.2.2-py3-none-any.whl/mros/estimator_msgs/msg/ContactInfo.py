import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.estimator_msgs.msg
import mros.std_msgs.msg

class ContactInfo(mros.Message):
    __slots__ = ['header','external_force','MomentumObserver_external_force','contact_flag','MomentumObserver_contact_flag']
    _slot_types = ['std_msgs/Header','float64[4]','float64[4]','bool[4]','bool[4]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ContactInfo, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.external_force is None:
                self.external_force = [0. for x in range(0, 4)]
            if self.MomentumObserver_external_force is None:
                self.MomentumObserver_external_force = [0. for x in range(0, 4)]
            if self.contact_flag is None:
                self.contact_flag = [False for x in range(0, 4)]
            if self.MomentumObserver_contact_flag is None:
                self.MomentumObserver_contact_flag = [False for x in range(0, 4)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.external_force = [0. for x in range(0, 4)]
            self.MomentumObserver_external_force = [0. for x in range(0, 4)]
            self.contact_flag = [False for x in range(0, 4)]
            self.MomentumObserver_contact_flag = [False for x in range(0, 4)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{4}d', *self.external_force))
            offset += 4 * 8
            buff.write(struct.pack(f'<{4}d', *self.MomentumObserver_external_force))
            offset += 4 * 8
            buff.write(struct.pack(f'<{4}B', *self.contact_flag))
            offset += 4
            buff.write(struct.pack(f'<{4}B', *self.MomentumObserver_contact_flag))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.external_force = np.frombuffer(buff[offset:offset + 4 * 8], dtype=np.float64)
            offset += 4 * 8
            self.MomentumObserver_external_force = np.frombuffer(buff[offset:offset + 4 * 8], dtype=np.float64)
            offset += 4 * 8
            self.contact_flag = np.frombuffer(buff[offset:offset + 4], dtype=np.uint8)
            offset += 4
            self.MomentumObserver_contact_flag = np.frombuffer(buff[offset:offset + 4], dtype=np.uint8)
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4 * 8
        length += 4 * 8
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"external_force":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.external_force[i]
            else:
                string_echo += '%s,' % self.external_force[i]
        string_echo += '],'
        string_echo += '"MomentumObserver_external_force":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.MomentumObserver_external_force[i]
            else:
                string_echo += '%s,' % self.MomentumObserver_external_force[i]
        string_echo += '],'
        string_echo += '"contact_flag":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.contact_flag[i]
            else:
                string_echo += '%s,' % self.contact_flag[i]
        string_echo += '],'
        string_echo += '"MomentumObserver_contact_flag":['
        for i in range(0, 4):
            if i == (4 - 1): 
                string_echo += '%s' % self.MomentumObserver_contact_flag[i]
            else:
                string_echo += '%s,' % self.MomentumObserver_contact_flag[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "estimator_msgs/ContactInfo"

    def getMD5(self):
        return "68d007d9e8e771e2653e4fd3c18e66c4"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[4] external_force\nfloat64[4] MomentumObserver_external_force\nbool[4] contact_flag\nbool[4] MomentumObserver_contact_flag\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

