import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.estimator_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class EstimatorState(mros.Message):
    __slots__ = ['header','orientation','euler','xeuler','vel','pos','gb','ab','gyr','acc','mag','roll_acc','pitch_acc','yaw_mag','yaw_mag_raw','yaw_mag_offset','mag_test_ratio','mag_norm','mag_test_flag','mcu_time_stamp']
    _slot_types = ['std_msgs/Header','geometry_msgs/Quaternion','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64','float64','float64','float64','float64','float64','float64','uint8','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(EstimatorState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.orientation is None:
                self.orientation = mros.geometry_msgs.msg.Quaternion()
            if self.euler is None:
                self.euler = [0. for x in range(0, 3)]
            if self.xeuler is None:
                self.xeuler = [0. for x in range(0, 3)]
            if self.vel is None:
                self.vel = [0. for x in range(0, 3)]
            if self.pos is None:
                self.pos = [0. for x in range(0, 3)]
            if self.gb is None:
                self.gb = [0. for x in range(0, 3)]
            if self.ab is None:
                self.ab = [0. for x in range(0, 3)]
            if self.gyr is None:
                self.gyr = [0. for x in range(0, 3)]
            if self.acc is None:
                self.acc = [0. for x in range(0, 3)]
            if self.mag is None:
                self.mag = [0. for x in range(0, 3)]
            if self.roll_acc is None:
                self.roll_acc = 0.
            if self.pitch_acc is None:
                self.pitch_acc = 0.
            if self.yaw_mag is None:
                self.yaw_mag = 0.
            if self.yaw_mag_raw is None:
                self.yaw_mag_raw = 0.
            if self.yaw_mag_offset is None:
                self.yaw_mag_offset = 0.
            if self.mag_test_ratio is None:
                self.mag_test_ratio = 0.
            if self.mag_norm is None:
                self.mag_norm = 0.
            if self.mag_test_flag is None:
                self.mag_test_flag = 0
            if self.mcu_time_stamp is None:
                self.mcu_time_stamp = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.orientation = mros.geometry_msgs.msg.Quaternion()
            self.euler = [0. for x in range(0, 3)]
            self.xeuler = [0. for x in range(0, 3)]
            self.vel = [0. for x in range(0, 3)]
            self.pos = [0. for x in range(0, 3)]
            self.gb = [0. for x in range(0, 3)]
            self.ab = [0. for x in range(0, 3)]
            self.gyr = [0. for x in range(0, 3)]
            self.acc = [0. for x in range(0, 3)]
            self.mag = [0. for x in range(0, 3)]
            self.roll_acc = 0.
            self.pitch_acc = 0.
            self.yaw_mag = 0.
            self.yaw_mag_raw = 0.
            self.yaw_mag_offset = 0.
            self.mag_test_ratio = 0.
            self.mag_norm = 0.
            self.mag_test_flag = 0
            self.mcu_time_stamp = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.orientation.serialize(buff)
            buff.write(struct.pack(f'<{3}d', *self.euler))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.xeuler))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.vel))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.pos))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.gb))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.ab))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.gyr))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.acc))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.mag))
            offset += 3 * 8
            struct_roll_acc = struct.Struct("<d")
            buff.write(struct_roll_acc.pack(self.roll_acc))
            offset += 8
            struct_pitch_acc = struct.Struct("<d")
            buff.write(struct_pitch_acc.pack(self.pitch_acc))
            offset += 8
            struct_yaw_mag = struct.Struct("<d")
            buff.write(struct_yaw_mag.pack(self.yaw_mag))
            offset += 8
            struct_yaw_mag_raw = struct.Struct("<d")
            buff.write(struct_yaw_mag_raw.pack(self.yaw_mag_raw))
            offset += 8
            struct_yaw_mag_offset = struct.Struct("<d")
            buff.write(struct_yaw_mag_offset.pack(self.yaw_mag_offset))
            offset += 8
            struct_mag_test_ratio = struct.Struct("<d")
            buff.write(struct_mag_test_ratio.pack(self.mag_test_ratio))
            offset += 8
            struct_mag_norm = struct.Struct("<d")
            buff.write(struct_mag_norm.pack(self.mag_norm))
            offset += 8
            struct_mag_test_flag = struct.Struct("<B")
            buff.write(struct_mag_test_flag.pack(self.mag_test_flag))
            offset += 1
            struct_mcu_time_stamp = struct.Struct("<d")
            buff.write(struct_mcu_time_stamp.pack(self.mcu_time_stamp))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.orientation.deserialize(buff[offset:])
            self.euler = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.xeuler = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.vel = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.pos = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.gb = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.ab = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.gyr = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.acc = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.mag = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            struct_roll_acc = struct.Struct("<d")
            (self.roll_acc,) = struct_roll_acc.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_pitch_acc = struct.Struct("<d")
            (self.pitch_acc,) = struct_pitch_acc.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_yaw_mag = struct.Struct("<d")
            (self.yaw_mag,) = struct_yaw_mag.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_yaw_mag_raw = struct.Struct("<d")
            (self.yaw_mag_raw,) = struct_yaw_mag_raw.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_yaw_mag_offset = struct.Struct("<d")
            (self.yaw_mag_offset,) = struct_yaw_mag_offset.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_mag_test_ratio = struct.Struct("<d")
            (self.mag_test_ratio,) = struct_mag_test_ratio.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_mag_norm = struct.Struct("<d")
            (self.mag_norm,) = struct_mag_norm.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_mag_test_flag = struct.Struct("<B")
            (self.mag_test_flag,) = struct_mag_test_flag.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_mcu_time_stamp = struct.Struct("<d")
            (self.mcu_time_stamp,) = struct_mcu_time_stamp.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.orientation.serializedLength()
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"orientation":'
        string_echo += self.orientation.echo()
        string_echo += ','
        string_echo += '"euler":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.euler[i]
            else:
                string_echo += '%s,' % self.euler[i]
        string_echo += '],'
        string_echo += '"xeuler":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.xeuler[i]
            else:
                string_echo += '%s,' % self.xeuler[i]
        string_echo += '],'
        string_echo += '"vel":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.vel[i]
            else:
                string_echo += '%s,' % self.vel[i]
        string_echo += '],'
        string_echo += '"pos":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.pos[i]
            else:
                string_echo += '%s,' % self.pos[i]
        string_echo += '],'
        string_echo += '"gb":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.gb[i]
            else:
                string_echo += '%s,' % self.gb[i]
        string_echo += '],'
        string_echo += '"ab":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.ab[i]
            else:
                string_echo += '%s,' % self.ab[i]
        string_echo += '],'
        string_echo += '"gyr":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.gyr[i]
            else:
                string_echo += '%s,' % self.gyr[i]
        string_echo += '],'
        string_echo += '"acc":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.acc[i]
            else:
                string_echo += '%s,' % self.acc[i]
        string_echo += '],'
        string_echo += '"mag":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.mag[i]
            else:
                string_echo += '%s,' % self.mag[i]
        string_echo += '],'
        string_echo += '"roll_acc":%s' % self.roll_acc
        string_echo += ','
        string_echo += '"pitch_acc":%s' % self.pitch_acc
        string_echo += ','
        string_echo += '"yaw_mag":%s' % self.yaw_mag
        string_echo += ','
        string_echo += '"yaw_mag_raw":%s' % self.yaw_mag_raw
        string_echo += ','
        string_echo += '"yaw_mag_offset":%s' % self.yaw_mag_offset
        string_echo += ','
        string_echo += '"mag_test_ratio":%s' % self.mag_test_ratio
        string_echo += ','
        string_echo += '"mag_norm":%s' % self.mag_norm
        string_echo += ','
        string_echo += '"mag_test_flag":%s' % self.mag_test_flag
        string_echo += ','
        string_echo += '"mcu_time_stamp":%s' % self.mcu_time_stamp
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "estimator_msgs/EstimatorState"

    def getMD5(self):
        return "029054a9ed0ea103549e2804373ac300"

    def getDef(self):
        return "std_msgs/Header header\ngeometry_msgs/Quaternion orientation\nfloat64[3] euler\nfloat64[3] xeuler\nfloat64[3] vel\nfloat64[3] pos\nfloat64[3] gb\nfloat64[3] ab\nfloat64[3] gyr\nfloat64[3] acc\nfloat64[3] mag\nfloat64 roll_acc\nfloat64 pitch_acc\nfloat64 yaw_mag\nfloat64 yaw_mag_raw\nfloat64 yaw_mag_offset\nfloat64 mag_test_ratio\nfloat64 mag_norm\nuint8 mag_test_flag\nfloat64 mcu_time_stamp\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

