import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.estimator_msgs.msg
import mros.std_msgs.msg

class EstimatorStatus(mros.Message):
    __slots__ = ['header','gyr_mag_filt','gyr_vibration_metric','acc_mag_filt','acc_vibration_metric','mag_norm','mag_disturb_metric','mag_disturb_ref','mag_disturb_ref_new','in_reset','in_hign_motion','in_mag_disturb']
    _slot_types = ['std_msgs/Header','float64','float64','float64','float64','float64','float64[2]','float64[2]','float64[2]','uint8','uint8','uint8']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(EstimatorStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.gyr_mag_filt is None:
                self.gyr_mag_filt = 0.
            if self.gyr_vibration_metric is None:
                self.gyr_vibration_metric = 0.
            if self.acc_mag_filt is None:
                self.acc_mag_filt = 0.
            if self.acc_vibration_metric is None:
                self.acc_vibration_metric = 0.
            if self.mag_norm is None:
                self.mag_norm = 0.
            if self.mag_disturb_metric is None:
                self.mag_disturb_metric = [0. for x in range(0, 2)]
            if self.mag_disturb_ref is None:
                self.mag_disturb_ref = [0. for x in range(0, 2)]
            if self.mag_disturb_ref_new is None:
                self.mag_disturb_ref_new = [0. for x in range(0, 2)]
            if self.in_reset is None:
                self.in_reset = 0
            if self.in_hign_motion is None:
                self.in_hign_motion = 0
            if self.in_mag_disturb is None:
                self.in_mag_disturb = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.gyr_mag_filt = 0.
            self.gyr_vibration_metric = 0.
            self.acc_mag_filt = 0.
            self.acc_vibration_metric = 0.
            self.mag_norm = 0.
            self.mag_disturb_metric = [0. for x in range(0, 2)]
            self.mag_disturb_ref = [0. for x in range(0, 2)]
            self.mag_disturb_ref_new = [0. for x in range(0, 2)]
            self.in_reset = 0
            self.in_hign_motion = 0
            self.in_mag_disturb = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_gyr_mag_filt = struct.Struct("<d")
            buff.write(struct_gyr_mag_filt.pack(self.gyr_mag_filt))
            offset += 8
            struct_gyr_vibration_metric = struct.Struct("<d")
            buff.write(struct_gyr_vibration_metric.pack(self.gyr_vibration_metric))
            offset += 8
            struct_acc_mag_filt = struct.Struct("<d")
            buff.write(struct_acc_mag_filt.pack(self.acc_mag_filt))
            offset += 8
            struct_acc_vibration_metric = struct.Struct("<d")
            buff.write(struct_acc_vibration_metric.pack(self.acc_vibration_metric))
            offset += 8
            struct_mag_norm = struct.Struct("<d")
            buff.write(struct_mag_norm.pack(self.mag_norm))
            offset += 8
            buff.write(struct.pack(f'<{2}d', *self.mag_disturb_metric))
            offset += 2 * 8
            buff.write(struct.pack(f'<{2}d', *self.mag_disturb_ref))
            offset += 2 * 8
            buff.write(struct.pack(f'<{2}d', *self.mag_disturb_ref_new))
            offset += 2 * 8
            struct_in_reset = struct.Struct("<B")
            buff.write(struct_in_reset.pack(self.in_reset))
            offset += 1
            struct_in_hign_motion = struct.Struct("<B")
            buff.write(struct_in_hign_motion.pack(self.in_hign_motion))
            offset += 1
            struct_in_mag_disturb = struct.Struct("<B")
            buff.write(struct_in_mag_disturb.pack(self.in_mag_disturb))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_gyr_mag_filt = struct.Struct("<d")
            (self.gyr_mag_filt,) = struct_gyr_mag_filt.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_gyr_vibration_metric = struct.Struct("<d")
            (self.gyr_vibration_metric,) = struct_gyr_vibration_metric.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_acc_mag_filt = struct.Struct("<d")
            (self.acc_mag_filt,) = struct_acc_mag_filt.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_acc_vibration_metric = struct.Struct("<d")
            (self.acc_vibration_metric,) = struct_acc_vibration_metric.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_mag_norm = struct.Struct("<d")
            (self.mag_norm,) = struct_mag_norm.unpack(buff[offset:(offset + 8)])
            offset += 8
            self.mag_disturb_metric = np.frombuffer(buff[offset:offset + 2 * 8], dtype=np.float64)
            offset += 2 * 8
            self.mag_disturb_ref = np.frombuffer(buff[offset:offset + 2 * 8], dtype=np.float64)
            offset += 2 * 8
            self.mag_disturb_ref_new = np.frombuffer(buff[offset:offset + 2 * 8], dtype=np.float64)
            offset += 2 * 8
            struct_in_reset = struct.Struct("<B")
            (self.in_reset,) = struct_in_reset.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_in_hign_motion = struct.Struct("<B")
            (self.in_hign_motion,) = struct_in_hign_motion.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_in_mag_disturb = struct.Struct("<B")
            (self.in_mag_disturb,) = struct_in_mag_disturb.unpack(buff[offset:(offset + 1)])
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 8
        length += 8
        length += 8
        length += 8
        length += 2 * 8
        length += 2 * 8
        length += 2 * 8
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"gyr_mag_filt":%s' % self.gyr_mag_filt
        string_echo += ','
        string_echo += '"gyr_vibration_metric":%s' % self.gyr_vibration_metric
        string_echo += ','
        string_echo += '"acc_mag_filt":%s' % self.acc_mag_filt
        string_echo += ','
        string_echo += '"acc_vibration_metric":%s' % self.acc_vibration_metric
        string_echo += ','
        string_echo += '"mag_norm":%s' % self.mag_norm
        string_echo += ','
        string_echo += '"mag_disturb_metric":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.mag_disturb_metric[i]
            else:
                string_echo += '%s,' % self.mag_disturb_metric[i]
        string_echo += '],'
        string_echo += '"mag_disturb_ref":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.mag_disturb_ref[i]
            else:
                string_echo += '%s,' % self.mag_disturb_ref[i]
        string_echo += '],'
        string_echo += '"mag_disturb_ref_new":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.mag_disturb_ref_new[i]
            else:
                string_echo += '%s,' % self.mag_disturb_ref_new[i]
        string_echo += '],'
        string_echo += '"in_reset":%s' % self.in_reset
        string_echo += ','
        string_echo += '"in_hign_motion":%s' % self.in_hign_motion
        string_echo += ','
        string_echo += '"in_mag_disturb":%s' % self.in_mag_disturb
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "estimator_msgs/EstimatorStatus"

    def getMD5(self):
        return "5b82b5cc8221d99e7a400871a883855c"

    def getDef(self):
        return "std_msgs/Header header\nfloat64 gyr_mag_filt\nfloat64 gyr_vibration_metric\nfloat64 acc_mag_filt\nfloat64 acc_vibration_metric\nfloat64 mag_norm\nfloat64[2] mag_disturb_metric\nfloat64[2] mag_disturb_ref\nfloat64[2] mag_disturb_ref_new\nuint8 in_reset\nuint8 in_hign_motion\nuint8 in_mag_disturb\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

