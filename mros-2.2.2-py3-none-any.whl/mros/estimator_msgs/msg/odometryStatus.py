import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.estimator_msgs.msg
import mros.std_msgs.msg

class odometryStatus(mros.Message):
    __slots__ = ['header','position','velocity','left_leg_position','right_leg_position','d_position','d_velocity','d_left_leg_position','d_right_leg_position','knee_ground_angle','knee_ground_angle_vel','left_obs_position','right_obs_position','left_obs_vel','right_obs_vel','wheel_frame_roll','wheel_frame_yaw']
    _slot_types = ['std_msgs/Header','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[3]','float64[2]','float64[2]','float64[3]','float64[3]','float64[3]','float64[3]','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(odometryStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.position is None:
                self.position = [0. for x in range(0, 3)]
            if self.velocity is None:
                self.velocity = [0. for x in range(0, 3)]
            if self.left_leg_position is None:
                self.left_leg_position = [0. for x in range(0, 3)]
            if self.right_leg_position is None:
                self.right_leg_position = [0. for x in range(0, 3)]
            if self.d_position is None:
                self.d_position = [0. for x in range(0, 3)]
            if self.d_velocity is None:
                self.d_velocity = [0. for x in range(0, 3)]
            if self.d_left_leg_position is None:
                self.d_left_leg_position = [0. for x in range(0, 3)]
            if self.d_right_leg_position is None:
                self.d_right_leg_position = [0. for x in range(0, 3)]
            if self.knee_ground_angle is None:
                self.knee_ground_angle = [0. for x in range(0, 2)]
            if self.knee_ground_angle_vel is None:
                self.knee_ground_angle_vel = [0. for x in range(0, 2)]
            if self.left_obs_position is None:
                self.left_obs_position = [0. for x in range(0, 3)]
            if self.right_obs_position is None:
                self.right_obs_position = [0. for x in range(0, 3)]
            if self.left_obs_vel is None:
                self.left_obs_vel = [0. for x in range(0, 3)]
            if self.right_obs_vel is None:
                self.right_obs_vel = [0. for x in range(0, 3)]
            if self.wheel_frame_roll is None:
                self.wheel_frame_roll = 0.
            if self.wheel_frame_yaw is None:
                self.wheel_frame_yaw = 0.
        else:
            self.header = mros.std_msgs.msg.Header()
            self.position = [0. for x in range(0, 3)]
            self.velocity = [0. for x in range(0, 3)]
            self.left_leg_position = [0. for x in range(0, 3)]
            self.right_leg_position = [0. for x in range(0, 3)]
            self.d_position = [0. for x in range(0, 3)]
            self.d_velocity = [0. for x in range(0, 3)]
            self.d_left_leg_position = [0. for x in range(0, 3)]
            self.d_right_leg_position = [0. for x in range(0, 3)]
            self.knee_ground_angle = [0. for x in range(0, 2)]
            self.knee_ground_angle_vel = [0. for x in range(0, 2)]
            self.left_obs_position = [0. for x in range(0, 3)]
            self.right_obs_position = [0. for x in range(0, 3)]
            self.left_obs_vel = [0. for x in range(0, 3)]
            self.right_obs_vel = [0. for x in range(0, 3)]
            self.wheel_frame_roll = 0.
            self.wheel_frame_yaw = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            buff.write(struct.pack(f'<{3}d', *self.position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.velocity))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.left_leg_position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.right_leg_position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.d_position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.d_velocity))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.d_left_leg_position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.d_right_leg_position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{2}d', *self.knee_ground_angle))
            offset += 2 * 8
            buff.write(struct.pack(f'<{2}d', *self.knee_ground_angle_vel))
            offset += 2 * 8
            buff.write(struct.pack(f'<{3}d', *self.left_obs_position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.right_obs_position))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.left_obs_vel))
            offset += 3 * 8
            buff.write(struct.pack(f'<{3}d', *self.right_obs_vel))
            offset += 3 * 8
            struct_wheel_frame_roll = struct.Struct("<d")
            buff.write(struct_wheel_frame_roll.pack(self.wheel_frame_roll))
            offset += 8
            struct_wheel_frame_yaw = struct.Struct("<d")
            buff.write(struct_wheel_frame_yaw.pack(self.wheel_frame_yaw))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            self.position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.velocity = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.left_leg_position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.right_leg_position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.d_position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.d_velocity = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.d_left_leg_position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.d_right_leg_position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.knee_ground_angle = np.frombuffer(buff[offset:offset + 2 * 8], dtype=np.float64)
            offset += 2 * 8
            self.knee_ground_angle_vel = np.frombuffer(buff[offset:offset + 2 * 8], dtype=np.float64)
            offset += 2 * 8
            self.left_obs_position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.right_obs_position = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.left_obs_vel = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            self.right_obs_vel = np.frombuffer(buff[offset:offset + 3 * 8], dtype=np.float64)
            offset += 3 * 8
            struct_wheel_frame_roll = struct.Struct("<d")
            (self.wheel_frame_roll,) = struct_wheel_frame_roll.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_wheel_frame_yaw = struct.Struct("<d")
            (self.wheel_frame_yaw,) = struct_wheel_frame_yaw.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 2 * 8
        length += 2 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 3 * 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.position[i]
            else:
                string_echo += '%s,' % self.position[i]
        string_echo += '],'
        string_echo += '"velocity":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.velocity[i]
            else:
                string_echo += '%s,' % self.velocity[i]
        string_echo += '],'
        string_echo += '"left_leg_position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.left_leg_position[i]
            else:
                string_echo += '%s,' % self.left_leg_position[i]
        string_echo += '],'
        string_echo += '"right_leg_position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.right_leg_position[i]
            else:
                string_echo += '%s,' % self.right_leg_position[i]
        string_echo += '],'
        string_echo += '"d_position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.d_position[i]
            else:
                string_echo += '%s,' % self.d_position[i]
        string_echo += '],'
        string_echo += '"d_velocity":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.d_velocity[i]
            else:
                string_echo += '%s,' % self.d_velocity[i]
        string_echo += '],'
        string_echo += '"d_left_leg_position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.d_left_leg_position[i]
            else:
                string_echo += '%s,' % self.d_left_leg_position[i]
        string_echo += '],'
        string_echo += '"d_right_leg_position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.d_right_leg_position[i]
            else:
                string_echo += '%s,' % self.d_right_leg_position[i]
        string_echo += '],'
        string_echo += '"knee_ground_angle":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.knee_ground_angle[i]
            else:
                string_echo += '%s,' % self.knee_ground_angle[i]
        string_echo += '],'
        string_echo += '"knee_ground_angle_vel":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.knee_ground_angle_vel[i]
            else:
                string_echo += '%s,' % self.knee_ground_angle_vel[i]
        string_echo += '],'
        string_echo += '"left_obs_position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.left_obs_position[i]
            else:
                string_echo += '%s,' % self.left_obs_position[i]
        string_echo += '],'
        string_echo += '"right_obs_position":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.right_obs_position[i]
            else:
                string_echo += '%s,' % self.right_obs_position[i]
        string_echo += '],'
        string_echo += '"left_obs_vel":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.left_obs_vel[i]
            else:
                string_echo += '%s,' % self.left_obs_vel[i]
        string_echo += '],'
        string_echo += '"right_obs_vel":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.right_obs_vel[i]
            else:
                string_echo += '%s,' % self.right_obs_vel[i]
        string_echo += '],'
        string_echo += '"wheel_frame_roll":%s' % self.wheel_frame_roll
        string_echo += ','
        string_echo += '"wheel_frame_yaw":%s' % self.wheel_frame_yaw
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "estimator_msgs/odometryStatus"

    def getMD5(self):
        return "0a49a3efbff9e36de21e9e126c83a4ad"

    def getDef(self):
        return "std_msgs/Header header\nfloat64[3] position\nfloat64[3] velocity\nfloat64[3] left_leg_position\nfloat64[3] right_leg_position\nfloat64[3] d_position\nfloat64[3] d_velocity\nfloat64[3] d_left_leg_position\nfloat64[3] d_right_leg_position\nfloat64[2] knee_ground_angle\nfloat64[2] knee_ground_angle_vel\nfloat64[3] left_obs_position\nfloat64[3] right_obs_position\nfloat64[3] left_obs_vel\nfloat64[3] right_obs_vel\nfloat64 wheel_frame_roll\nfloat64 wheel_frame_yaw\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

