import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.diagnostic_msgs.msg
import mros.std_msgs.msg

class DiagnosticValue(mros.Message):
    __slots__ = ['header','level','name','code','message']
    _slot_types = ['std_msgs/Header','int32','string','int32','string']

    OK = 0
    WARN = 1
    ERROR = 2

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DiagnosticValue, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.level is None:
                self.level = 0
            if self.name is None:
                self.name = ''
            if self.code is None:
                self.code = 0
            if self.message is None:
                self.message = ''
        else:
            self.header = mros.std_msgs.msg.Header()
            self.level = 0
            self.name = ''
            self.code = 0
            self.message = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_level = struct.Struct("<i")
            buff.write(struct_level.pack(self.level))
            offset += 4
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_code = struct.Struct("<i")
            buff.write(struct_code.pack(self.code))
            offset += 4
            _x = self.message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_level = struct.Struct("<i")
            (self.level,) = struct_level.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            struct_code = struct.Struct("<i")
            (self.code,) = struct_code.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.message = buff[offset:(offset + length_message)].decode('utf-8')
            else:
                self.message = buff[offset:(offset + length_message)]
            offset += length_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        length += 4
        message_x = self.message
        message_length = len(message_x)
        if python3 or type(message_x) == unicode:
            message_x = message_x.encode('utf-8')
            message_length = len(message_x)
        length += 4
        length += message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"level":%s' % self.level
        string_echo += ','
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"code":%s' % self.code
        string_echo += ','
        string_echo += '"message":"%s"' % self.message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "diagnostic_msgs/DiagnosticValue"

    def getMD5(self):
        return "879d5c821998ca0ab6e3520e8c63e5fc"

    def getDef(self):
        return "std_msgs/Header header\nint32 OK=0\nint32 WARN=1\nint32 ERROR=2\nint32 level\nstring name\nint32 code\nstring message\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

