import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.diagnostic_msgs.msg

class KeyValue(mros.Message):
    __slots__ = ['key','value']
    _slot_types = ['string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(KeyValue, self).__init__(*args, **kwds)
            if self.key is None:
                self.key = ''
            if self.value is None:
                self.value = ''
        else:
            self.key = ''
            self.value = ''

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.key
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.value
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_key,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.key = buff[offset:(offset + length_key)].decode('utf-8')
            else:
                self.key = buff[offset:(offset + length_key)]
            offset += length_key
            (length_value,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.value = buff[offset:(offset + length_value)].decode('utf-8')
            else:
                self.value = buff[offset:(offset + length_value)]
            offset += length_value
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        key_x = self.key
        key_length = len(key_x)
        if python3 or type(key_x) == unicode:
            key_x = key_x.encode('utf-8')
            key_length = len(key_x)
        length += 4
        length += key_length
        value_x = self.value
        value_length = len(value_x)
        if python3 or type(value_x) == unicode:
            value_x = value_x.encode('utf-8')
            value_length = len(value_x)
        length += 4
        length += value_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"key":"%s"' % self.key
        string_echo += ','
        string_echo += '"value":"%s"' % self.value
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "diagnostic_msgs/KeyValue"

    def getMD5(self):
        return "cf57fdc6617a881a88c16e768132149c"

    def getDef(self):
        return "string key\nstring value\n"

_struct_I = struct.Struct('<I')

