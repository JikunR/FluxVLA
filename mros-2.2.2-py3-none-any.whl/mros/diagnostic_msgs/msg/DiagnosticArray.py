import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.diagnostic_msgs.msg
import mros.std_msgs.msg

class DiagnosticArray(mros.Message):
    __slots__ = ['header','status']
    _slot_types = ['std_msgs/Header','diagnostic_msgs/DiagnosticStatus[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DiagnosticArray, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.status is None:
                self.status = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.status = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            status_length = len(self.status)
            buff.write(struct.pack('<I', status_length))
            offset += 4
            for i in range(0, status_length):
                offset += self.status[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (status_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.status) != status_length:
                self.status = [mros.diagnostic_msgs.msg.DiagnosticStatus() for _ in range(status_length)]
            for i in range(0, status_length):
                offset += self.status[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, status_length):
            length += self.status[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"status":['
        status_length = len(self.status)
        for i in range(0, status_length):
            if i == (status_length - 1): 
                string_echo += '{status%s":' % i
                string_echo += self.status[i].echo()
                string_echo += ''
            else:
                string_echo += '{status%s":' % i
                string_echo += self.status[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "diagnostic_msgs/DiagnosticArray"

    def getMD5(self):
        return "60810da900de1dd6ddd437c3503511da"

    def getDef(self):
        return "std_msgs/Header header\ndiagnostic_msgs/DiagnosticStatus[] status\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: diagnostic_msgs/DiagnosticStatus\nbyte OK=0\nbyte WARN=1\nbyte ERROR=2\nbyte STALE=3\nbyte level\nstring name\nstring message\nstring hardware_id\ndiagnostic_msgs/KeyValue[] values\n================================================================================\nMSG: diagnostic_msgs/KeyValue\nstring key\nstring value\n"

_struct_I = struct.Struct('<I')

