import sys
from functools import partial
import mros

if sys.version > '3':
    long = int

try:
    from cStringIO import StringIO  # Python 2.x
except ImportError:
    from io import BytesIO as StringIO  # Python 3.x


class Subscriber(object):
    __slots__ = ['native', 'topic_name', 'msg_class', 'msg_orig',
                 'message_type', 'md5sum', 'msg_def', 'user_callback', 'partial_callback']

    def __init__(self, topic_name: str, msg_class, callback=None, queue_size: int = -1, latch: bool = False, reliable: bool = False):
        try:
            self.native = mros.SubscriberNative()
            self.topic_name = topic_name
            self.msg_class = msg_class
            self.msg_orig = self.msg_class()
            self.message_type = self.msg_orig.getType()
            self.md5sum = self.msg_orig.getMD5()
            self.msg_def = self.msg_orig.getDef()
            self.user_callback = callback
            self.partial_callback = partial(self.callback)

            if self.user_callback != None:
                self.native.subscribe(self.topic_name, self.message_type, self.md5sum,
                                      self.msg_def, self.partial_callback, queue_size, latch, reliable)
            else:
                self.native.subscribe(self.topic_name, self.message_type,
                                      self.md5sum, self.msg_def, None, queue_size, latch, reliable)
        except Exception as e:
            print(str(e))

    def callback(self, buff, callerid):
        msg = self.msg_class()
        msg.callerid = callerid
        msg.deserialize(buff)
        self.user_callback(msg)

    def readMsgRT(self):
        native_bytes, callerid = self.native.realtimeBuffer()
        if native_bytes != None and callerid != None:
            msg = self.msg_class()
            msg.callerid = callerid
            msg.deserialize(native_bytes)
            return msg
        else:
            return None

    def getMsgType(self):
        return self.message_type

    def getMsgMD5(self):
        return self.md5sum

    def getMsgDef(self):
        return self.msg_def

    def setEnabled(self, enabled: bool):
        return self.native.setEnabled(enabled)

    def getEnabled(self):
        return self.native.getEnabled()

    def negotiated(self):
        return self.native.negotiated()
