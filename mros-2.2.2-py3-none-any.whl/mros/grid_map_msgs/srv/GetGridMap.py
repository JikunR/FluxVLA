import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.grid_map_msgs.msg

class GetGridMapRequest(mros.Message):
    __slots__ = ['__id__','frame_id','position_x','position_y','length_x','length_y','layers']
    _slot_types = ['uint32','string','float64','float64','float64','float64','string[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetGridMapRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.frame_id is None:
                self.frame_id = ''
            if self.position_x is None:
                self.position_x = 0.
            if self.position_y is None:
                self.position_y = 0.
            if self.length_x is None:
                self.length_x = 0.
            if self.length_y is None:
                self.length_y = 0.
            if self.layers is None:
                self.layers = []
        else:
            self.__id__ = 0
            self.frame_id = ''
            self.position_x = 0.
            self.position_y = 0.
            self.length_x = 0.
            self.length_y = 0.
            self.layers = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_position_x = struct.Struct("<d")
            buff.write(struct_position_x.pack(self.position_x))
            offset += 8
            struct_position_y = struct.Struct("<d")
            buff.write(struct_position_y.pack(self.position_y))
            offset += 8
            struct_length_x = struct.Struct("<d")
            buff.write(struct_length_x.pack(self.length_x))
            offset += 8
            struct_length_y = struct.Struct("<d")
            buff.write(struct_length_y.pack(self.length_y))
            offset += 8
            layers_length = len(self.layers)
            buff.write(struct.pack('<I', layers_length))
            offset += 4
            for i in range(0, layers_length):
                _x = self.layers[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_frame_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_position_x = struct.Struct("<d")
            (self.position_x,) = struct_position_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_position_y = struct.Struct("<d")
            (self.position_y,) = struct_position_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_length_x = struct.Struct("<d")
            (self.length_x,) = struct_length_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_length_y = struct.Struct("<d")
            (self.length_y,) = struct_length_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            (layers_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.layers) != layers_length:
                self.layers = ['' for _ in range(layers_length)]
            for i in range(0, layers_length):
                (length_layersi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.layers[i] = buff[offset:(offset + length_layersi)].decode('utf-8')
                else:
                    self.layers[i] = buff[offset:(offset + length_layersi)]
                offset += length_layersi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        frame_id_x = self.frame_id
        frame_id_length = len(frame_id_x)
        if python3 or type(frame_id_x) == unicode:
            frame_id_x = frame_id_x.encode('utf-8')
            frame_id_length = len(frame_id_x)
        length += 4
        length += frame_id_length
        length += 8
        length += 8
        length += 8
        length += 8
        length += 4
        for i in range(0, layers_length):
            layersi_x = self.layers[i]
            layersi_length = len(layersi_x)
            if python3 or type(layersi_x) == unicode:
                layersi_x = layersi_x.encode('utf-8')
                layersi_length = len(layersi_x)
            length += 4
            length += layersi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"frame_id":"%s"' % self.frame_id
        string_echo += ','
        string_echo += '"position_x":%s' % self.position_x
        string_echo += ','
        string_echo += '"position_y":%s' % self.position_y
        string_echo += ','
        string_echo += '"length_x":%s' % self.length_x
        string_echo += ','
        string_echo += '"length_y":%s' % self.length_y
        string_echo += ','
        string_echo += '"layers":['
        layers_length = len(self.layers)
        for i in range(0, layers_length):
            if i == (layers_length - 1): 
                string_echo += '"layers[i]":"%s"' % self.layers[i]
                string_echo += ''
            else:
                string_echo += '"layers[i]":"%s"' % self.layers[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/GetGridMap"

    def getMD5(self):
        return "802c2cbc7b10fada2d44db75ddb8c738"
    def getDef(self):
        return "string frame_id\nfloat64 position_x\nfloat64 position_y\nfloat64 length_x\nfloat64 length_y\nstring[] layers\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetGridMapResponse(mros.Message):
    __slots__ = ['__id__','map']
    _slot_types = ['uint32','grid_map_msgs/GridMap']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetGridMapResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.map is None:
                self.map = mros.grid_map_msgs.msg.GridMap()
        else:
            self.__id__ = 0
            self.map = mros.grid_map_msgs.msg.GridMap()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.map.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.map.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.map.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"map":'
        string_echo += self.map.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/GetGridMap"

    def getMD5(self):
        return "802c2cbc7b10fada2d44db75ddb8c738"
    def getDef(self):
        return "grid_map_msgs/GridMap map\n================================================================================\nMSG: grid_map_msgs/GridMap\ngrid_map_msgs/GridMapInfo info\nstring[] layers\nstring[] basic_layers\nstd_msgs/Float32MultiArray[] data\nuint16 outer_start_index\nuint16 inner_start_index\n================================================================================\nMSG: grid_map_msgs/GridMapInfo\nstd_msgs/Header header\nfloat64 resolution\nfloat64 length_x\nfloat64 length_y\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Float32MultiArray\nstd_msgs/MultiArrayLayout layout\nfloat32[] data\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: std_msgs/MultiArrayLayout\nstd_msgs/MultiArrayDimension[] dim\nuint32 data_offset\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: std_msgs/MultiArrayDimension\nstring label\nuint32 size\nuint32 stride\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetGridMap(object):
    Request = GetGridMapRequest
    Response = GetGridMapResponse

    __slots__ = ['request','response']
    _slot_types = ['GetGridMapRequest','GetGridMapResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetGridMap, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

