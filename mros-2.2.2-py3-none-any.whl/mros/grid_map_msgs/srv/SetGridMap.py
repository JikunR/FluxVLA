import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.grid_map_msgs.msg

class SetGridMapRequest(mros.Message):
    __slots__ = ['__id__','map']
    _slot_types = ['uint32','grid_map_msgs/GridMap']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetGridMapRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.map is None:
                self.map = mros.grid_map_msgs.msg.GridMap()
        else:
            self.__id__ = 0
            self.map = mros.grid_map_msgs.msg.GridMap()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.map.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.map.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.map.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"map":'
        string_echo += self.map.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/SetGridMap"

    def getMD5(self):
        return "4f8e24cfd42bc1470fe765b7516ff7e5"
    def getDef(self):
        return "grid_map_msgs/GridMap map\n================================================================================\nMSG: grid_map_msgs/GridMap\ngrid_map_msgs/GridMapInfo info\nstring[] layers\nstring[] basic_layers\nstd_msgs/Float32MultiArray[] data\nuint16 outer_start_index\nuint16 inner_start_index\n================================================================================\nMSG: grid_map_msgs/GridMapInfo\nstd_msgs/Header header\nfloat64 resolution\nfloat64 length_x\nfloat64 length_y\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Float32MultiArray\nstd_msgs/MultiArrayLayout layout\nfloat32[] data\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: std_msgs/MultiArrayLayout\nstd_msgs/MultiArrayDimension[] dim\nuint32 data_offset\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: std_msgs/MultiArrayDimension\nstring label\nuint32 size\nuint32 stride\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetGridMapResponse(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetGridMapResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/SetGridMap"

    def getMD5(self):
        return "4f8e24cfd42bc1470fe765b7516ff7e5"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetGridMap(object):
    Request = SetGridMapRequest
    Response = SetGridMapResponse

    __slots__ = ['request','response']
    _slot_types = ['SetGridMapRequest','SetGridMapResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetGridMap, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

