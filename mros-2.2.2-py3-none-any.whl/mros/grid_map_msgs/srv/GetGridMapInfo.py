import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.grid_map_msgs.msg

class GetGridMapInfoRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetGridMapInfoRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/GetGridMapInfo"

    def getMD5(self):
        return "a0be1719725f7fd7b490db4d64321ff2"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetGridMapInfoResponse(mros.Message):
    __slots__ = ['__id__','info']
    _slot_types = ['uint32','grid_map_msgs/GridMapInfo']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetGridMapInfoResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.info is None:
                self.info = mros.grid_map_msgs.msg.GridMapInfo()
        else:
            self.__id__ = 0
            self.info = mros.grid_map_msgs.msg.GridMapInfo()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.info.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.info.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.info.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"info":'
        string_echo += self.info.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/GetGridMapInfo"

    def getMD5(self):
        return "a0be1719725f7fd7b490db4d64321ff2"
    def getDef(self):
        return "grid_map_msgs/GridMapInfo info\n================================================================================\nMSG: grid_map_msgs/GridMapInfo\nstd_msgs/Header header\nfloat64 resolution\nfloat64 length_x\nfloat64 length_y\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetGridMapInfo(object):
    Request = GetGridMapInfoRequest
    Response = GetGridMapInfoResponse

    __slots__ = ['request','response']
    _slot_types = ['GetGridMapInfoRequest','GetGridMapInfoResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetGridMapInfo, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

