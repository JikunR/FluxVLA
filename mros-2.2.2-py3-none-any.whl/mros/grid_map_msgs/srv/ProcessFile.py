import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.grid_map_msgs.msg

class ProcessFileRequest(mros.Message):
    __slots__ = ['__id__','file_path','topic_name']
    _slot_types = ['uint32','string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ProcessFileRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.file_path is None:
                self.file_path = ''
            if self.topic_name is None:
                self.topic_name = ''
        else:
            self.__id__ = 0
            self.file_path = ''
            self.topic_name = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.file_path
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.topic_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_file_path,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.file_path = buff[offset:(offset + length_file_path)].decode('utf-8')
            else:
                self.file_path = buff[offset:(offset + length_file_path)]
            offset += length_file_path
            (length_topic_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.topic_name = buff[offset:(offset + length_topic_name)].decode('utf-8')
            else:
                self.topic_name = buff[offset:(offset + length_topic_name)]
            offset += length_topic_name
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        file_path_x = self.file_path
        file_path_length = len(file_path_x)
        if python3 or type(file_path_x) == unicode:
            file_path_x = file_path_x.encode('utf-8')
            file_path_length = len(file_path_x)
        length += 4
        length += file_path_length
        topic_name_x = self.topic_name
        topic_name_length = len(topic_name_x)
        if python3 or type(topic_name_x) == unicode:
            topic_name_x = topic_name_x.encode('utf-8')
            topic_name_length = len(topic_name_x)
        length += 4
        length += topic_name_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"file_path":"%s"' % self.file_path
        string_echo += ','
        string_echo += '"topic_name":"%s"' % self.topic_name
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/ProcessFile"

    def getMD5(self):
        return "03f389710f49a6dd2a8b447bb2850cd6"
    def getDef(self):
        return "string file_path\nstring topic_name\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ProcessFileResponse(mros.Message):
    __slots__ = ['__id__','success']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ProcessFileResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.success is None:
                self.success = False
        else:
            self.__id__ = 0
            self.success = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/ProcessFile"

    def getMD5(self):
        return "03f389710f49a6dd2a8b447bb2850cd6"
    def getDef(self):
        return "bool success\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ProcessFile(object):
    Request = ProcessFileRequest
    Response = ProcessFileResponse

    __slots__ = ['request','response']
    _slot_types = ['ProcessFileRequest','ProcessFileResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ProcessFile, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

