import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.grid_map_msgs.msg
import mros.std_msgs.msg
import mros.geometry_msgs.msg

class GridMapInfo(mros.Message):
    __slots__ = ['header','resolution','length_x','length_y','pose']
    _slot_types = ['std_msgs/Header','float64','float64','float64','geometry_msgs/Pose']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GridMapInfo, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.resolution is None:
                self.resolution = 0.
            if self.length_x is None:
                self.length_x = 0.
            if self.length_y is None:
                self.length_y = 0.
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.resolution = 0.
            self.length_x = 0.
            self.length_y = 0.
            self.pose = mros.geometry_msgs.msg.Pose()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_resolution = struct.Struct("<d")
            buff.write(struct_resolution.pack(self.resolution))
            offset += 8
            struct_length_x = struct.Struct("<d")
            buff.write(struct_length_x.pack(self.length_x))
            offset += 8
            struct_length_y = struct.Struct("<d")
            buff.write(struct_length_y.pack(self.length_y))
            offset += 8
            offset += self.pose.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_resolution = struct.Struct("<d")
            (self.resolution,) = struct_resolution.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_length_x = struct.Struct("<d")
            (self.length_x,) = struct_length_x.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_length_y = struct.Struct("<d")
            (self.length_y,) = struct_length_y.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.pose.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 8
        length += 8
        length += self.pose.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"resolution":%s' % self.resolution
        string_echo += ','
        string_echo += '"length_x":%s' % self.length_x
        string_echo += ','
        string_echo += '"length_y":%s' % self.length_y
        string_echo += ','
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/GridMapInfo"

    def getMD5(self):
        return "43ee5430e1c253682111cb6bedac0ef9"

    def getDef(self):
        return "std_msgs/Header header\nfloat64 resolution\nfloat64 length_x\nfloat64 length_y\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

