import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.grid_map_msgs.msg
import mros.std_msgs.msg

class GridMap(mros.Message):
    __slots__ = ['info','layers','basic_layers','data','outer_start_index','inner_start_index']
    _slot_types = ['grid_map_msgs/GridMapInfo','string[]','string[]','std_msgs/Float32MultiArray[]','uint16','uint16']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GridMap, self).__init__(*args, **kwds)
            if self.info is None:
                self.info = mros.grid_map_msgs.msg.GridMapInfo()
            if self.layers is None:
                self.layers = []
            if self.basic_layers is None:
                self.basic_layers = []
            if self.data is None:
                self.data = []
            if self.outer_start_index is None:
                self.outer_start_index = 0
            if self.inner_start_index is None:
                self.inner_start_index = 0
        else:
            self.info = mros.grid_map_msgs.msg.GridMapInfo()
            self.layers = []
            self.basic_layers = []
            self.data = []
            self.outer_start_index = 0
            self.inner_start_index = 0

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.info.serialize(buff)
            layers_length = len(self.layers)
            buff.write(struct.pack('<I', layers_length))
            offset += 4
            for i in range(0, layers_length):
                _x = self.layers[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            basic_layers_length = len(self.basic_layers)
            buff.write(struct.pack('<I', basic_layers_length))
            offset += 4
            for i in range(0, basic_layers_length):
                _x = self.basic_layers[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            data_length = len(self.data)
            buff.write(struct.pack('<I', data_length))
            offset += 4
            for i in range(0, data_length):
                offset += self.data[i].serialize(buff)
            struct_outer_start_index = struct.Struct("<H")
            buff.write(struct_outer_start_index.pack(self.outer_start_index))
            offset += 2
            struct_inner_start_index = struct.Struct("<H")
            buff.write(struct_inner_start_index.pack(self.inner_start_index))
            offset += 2
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.info.deserialize(buff[offset:])
            (layers_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.layers) != layers_length:
                self.layers = ['' for _ in range(layers_length)]
            for i in range(0, layers_length):
                (length_layersi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.layers[i] = buff[offset:(offset + length_layersi)].decode('utf-8')
                else:
                    self.layers[i] = buff[offset:(offset + length_layersi)]
                offset += length_layersi
            (basic_layers_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.basic_layers) != basic_layers_length:
                self.basic_layers = ['' for _ in range(basic_layers_length)]
            for i in range(0, basic_layers_length):
                (length_basic_layersi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.basic_layers[i] = buff[offset:(offset + length_basic_layersi)].decode('utf-8')
                else:
                    self.basic_layers[i] = buff[offset:(offset + length_basic_layersi)]
                offset += length_basic_layersi
            (data_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.data) != data_length:
                self.data = [mros.std_msgs.msg.Float32MultiArray() for _ in range(data_length)]
            for i in range(0, data_length):
                offset += self.data[i].deserialize(buff[offset:])
            struct_outer_start_index = struct.Struct("<H")
            (self.outer_start_index,) = struct_outer_start_index.unpack(buff[offset:(offset + 2)])
            offset += 2
            struct_inner_start_index = struct.Struct("<H")
            (self.inner_start_index,) = struct_inner_start_index.unpack(buff[offset:(offset + 2)])
            offset += 2
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.info.serializedLength()
        length += 4
        for i in range(0, layers_length):
            layersi_x = self.layers[i]
            layersi_length = len(layersi_x)
            if python3 or type(layersi_x) == unicode:
                layersi_x = layersi_x.encode('utf-8')
                layersi_length = len(layersi_x)
            length += 4
            length += layersi_length
        length += 4
        for i in range(0, basic_layers_length):
            basic_layersi_x = self.basic_layers[i]
            basic_layersi_length = len(basic_layersi_x)
            if python3 or type(basic_layersi_x) == unicode:
                basic_layersi_x = basic_layersi_x.encode('utf-8')
                basic_layersi_length = len(basic_layersi_x)
            length += 4
            length += basic_layersi_length
        length += 4
        for i in range(0, data_length):
            length += self.data[i].serializedLength()
        length += 2
        length += 2
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"info":'
        string_echo += self.info.echo()
        string_echo += ','
        string_echo += '"layers":['
        layers_length = len(self.layers)
        for i in range(0, layers_length):
            if i == (layers_length - 1): 
                string_echo += '"layers[i]":"%s"' % self.layers[i]
                string_echo += ''
            else:
                string_echo += '"layers[i]":"%s"' % self.layers[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"basic_layers":['
        basic_layers_length = len(self.basic_layers)
        for i in range(0, basic_layers_length):
            if i == (basic_layers_length - 1): 
                string_echo += '"basic_layers[i]":"%s"' % self.basic_layers[i]
                string_echo += ''
            else:
                string_echo += '"basic_layers[i]":"%s"' % self.basic_layers[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"data":['
        data_length = len(self.data)
        for i in range(0, data_length):
            if i == (data_length - 1): 
                string_echo += '{data%s":' % i
                string_echo += self.data[i].echo()
                string_echo += ''
            else:
                string_echo += '{data%s":' % i
                string_echo += self.data[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"outer_start_index":%s' % self.outer_start_index
        string_echo += ','
        string_echo += '"inner_start_index":%s' % self.inner_start_index
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "grid_map_msgs/GridMap"

    def getMD5(self):
        return "95681e052b1f73bf87b7eb984382b401"

    def getDef(self):
        return "grid_map_msgs/GridMapInfo info\nstring[] layers\nstring[] basic_layers\nstd_msgs/Float32MultiArray[] data\nuint16 outer_start_index\nuint16 inner_start_index\n================================================================================\nMSG: grid_map_msgs/GridMapInfo\nstd_msgs/Header header\nfloat64 resolution\nfloat64 length_x\nfloat64 length_y\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Float32MultiArray\nstd_msgs/MultiArrayLayout layout\nfloat32[] data\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: std_msgs/MultiArrayLayout\nstd_msgs/MultiArrayDimension[] dim\nuint32 data_offset\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n================================================================================\nMSG: std_msgs/MultiArrayDimension\nstring label\nuint32 size\nuint32 stride\n"

_struct_I = struct.Struct('<I')

