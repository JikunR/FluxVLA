import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.hmc_msg.msg

class WalkState(mros.Message):
    __slots__ = ['stand']
    _slot_types = ['bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(WalkState, self).__init__(*args, **kwds)
            if self.stand is None:
                self.stand = False
        else:
            self.stand = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_stand = struct.Struct("<B")
            buff.write(struct_stand.pack(self.stand))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_stand = struct.Struct("<B")
            (self.stand,) = struct_stand.unpack(buff[offset:(offset + 1)])
            self.stand = bool(self.stand)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"stand":%s' % self.stand
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "hmc_msg/WalkState"

    def getMD5(self):
        return "532bde67c529a42872f1401c59af6da7"

    def getDef(self):
        return "bool stand\n"

_struct_I = struct.Struct('<I')

