import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.hmc_msg.msg

class WalkAvailable(mros.Message):
    __slots__ = ['available','offset']
    _slot_types = ['bool','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(WalkAvailable, self).__init__(*args, **kwds)
            if self.available is None:
                self.available = False
            if self.offset is None:
                self.offset = 0.
        else:
            self.available = False
            self.offset = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_available = struct.Struct("<B")
            buff.write(struct_available.pack(self.available))
            offset += 1
            struct_offset = struct.Struct("<d")
            buff.write(struct_offset.pack(self.offset))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_available = struct.Struct("<B")
            (self.available,) = struct_available.unpack(buff[offset:(offset + 1)])
            self.available = bool(self.available)
            offset += 1
            struct_offset = struct.Struct("<d")
            (self.offset,) = struct_offset.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"available":%s' % self.available
        string_echo += ','
        string_echo += '"offset":%s' % self.offset
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "hmc_msg/WalkAvailable"

    def getMD5(self):
        return "81a20b067e5eb7246df01379e37e2327"

    def getDef(self):
        return "bool available\nfloat64 offset\n"

_struct_I = struct.Struct('<I')

