import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.hmc_msg.msg

class LBStand(mros.Message):
    __slots__ = ['base_height','waist_roll','waist_pitch','waist_yaw']
    _slot_types = ['float64','float64','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(LBStand, self).__init__(*args, **kwds)
            if self.base_height is None:
                self.base_height = 0.
            if self.waist_roll is None:
                self.waist_roll = 0.
            if self.waist_pitch is None:
                self.waist_pitch = 0.
            if self.waist_yaw is None:
                self.waist_yaw = 0.
        else:
            self.base_height = 0.
            self.waist_roll = 0.
            self.waist_pitch = 0.
            self.waist_yaw = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_base_height = struct.Struct("<d")
            buff.write(struct_base_height.pack(self.base_height))
            offset += 8
            struct_waist_roll = struct.Struct("<d")
            buff.write(struct_waist_roll.pack(self.waist_roll))
            offset += 8
            struct_waist_pitch = struct.Struct("<d")
            buff.write(struct_waist_pitch.pack(self.waist_pitch))
            offset += 8
            struct_waist_yaw = struct.Struct("<d")
            buff.write(struct_waist_yaw.pack(self.waist_yaw))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_base_height = struct.Struct("<d")
            (self.base_height,) = struct_base_height.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_waist_roll = struct.Struct("<d")
            (self.waist_roll,) = struct_waist_roll.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_waist_pitch = struct.Struct("<d")
            (self.waist_pitch,) = struct_waist_pitch.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_waist_yaw = struct.Struct("<d")
            (self.waist_yaw,) = struct_waist_yaw.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 8
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"base_height":%s' % self.base_height
        string_echo += ','
        string_echo += '"waist_roll":%s' % self.waist_roll
        string_echo += ','
        string_echo += '"waist_pitch":%s' % self.waist_pitch
        string_echo += ','
        string_echo += '"waist_yaw":%s' % self.waist_yaw
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "hmc_msg/LBStand"

    def getMD5(self):
        return "30306d40504821d5b163385605accecd"

    def getDef(self):
        return "float64 base_height\nfloat64 waist_roll\nfloat64 waist_pitch\nfloat64 waist_yaw\n"

_struct_I = struct.Struct('<I')

