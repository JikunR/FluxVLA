import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.hmc_msg.msg

class ContactGroundState(mros.Message):
    __slots__ = ['stand','leg_torque']
    _slot_types = ['bool','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ContactGroundState, self).__init__(*args, **kwds)
            if self.stand is None:
                self.stand = False
            if self.leg_torque is None:
                self.leg_torque = 0.
        else:
            self.stand = False
            self.leg_torque = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_stand = struct.Struct("<B")
            buff.write(struct_stand.pack(self.stand))
            offset += 1
            struct_leg_torque = struct.Struct("<d")
            buff.write(struct_leg_torque.pack(self.leg_torque))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_stand = struct.Struct("<B")
            (self.stand,) = struct_stand.unpack(buff[offset:(offset + 1)])
            self.stand = bool(self.stand)
            offset += 1
            struct_leg_torque = struct.Struct("<d")
            (self.leg_torque,) = struct_leg_torque.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"stand":%s' % self.stand
        string_echo += ','
        string_echo += '"leg_torque":%s' % self.leg_torque
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "hmc_msg/ContactGroundState"

    def getMD5(self):
        return "91217c20f6d59d289227e1ce7f6075f9"

    def getDef(self):
        return "bool stand\nfloat64 leg_torque\n"

_struct_I = struct.Struct('<I')

