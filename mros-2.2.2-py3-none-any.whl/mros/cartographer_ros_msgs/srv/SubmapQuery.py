import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class SubmapQueryRequest(mros.Message):
    __slots__ = ['__id__','trajectory_id','submap_index']
    _slot_types = ['uint32','int32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SubmapQueryRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.trajectory_id is None:
                self.trajectory_id = 0
            if self.submap_index is None:
                self.submap_index = 0
        else:
            self.__id__ = 0
            self.trajectory_id = 0
            self.submap_index = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_trajectory_id = struct.Struct("<i")
            buff.write(struct_trajectory_id.pack(self.trajectory_id))
            offset += 4
            struct_submap_index = struct.Struct("<i")
            buff.write(struct_submap_index.pack(self.submap_index))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_trajectory_id = struct.Struct("<i")
            (self.trajectory_id,) = struct_trajectory_id.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_submap_index = struct.Struct("<i")
            (self.submap_index,) = struct_submap_index.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"trajectory_id":%s' % self.trajectory_id
        string_echo += ','
        string_echo += '"submap_index":%s' % self.submap_index
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/SubmapQuery"

    def getMD5(self):
        return "d39f26c172921775c4ad99dbf7cb0792"
    def getDef(self):
        return "int32 trajectory_id\nint32 submap_index\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SubmapQueryResponse(mros.Message):
    __slots__ = ['__id__','status','submap_version','textures']
    _slot_types = ['uint32','cartographer_ros_msgs/StatusResponse','int32','cartographer_ros_msgs/SubmapTexture[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SubmapQueryResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            if self.submap_version is None:
                self.submap_version = 0
            if self.textures is None:
                self.textures = []
        else:
            self.__id__ = 0
            self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            self.submap_version = 0
            self.textures = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.status.serialize(buff)
            struct_submap_version = struct.Struct("<i")
            buff.write(struct_submap_version.pack(self.submap_version))
            offset += 4
            textures_length = len(self.textures)
            buff.write(struct.pack('<I', textures_length))
            offset += 4
            for i in range(0, textures_length):
                offset += self.textures[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.status.deserialize(buff[offset:])
            struct_submap_version = struct.Struct("<i")
            (self.submap_version,) = struct_submap_version.unpack(buff[offset:(offset + 4)])
            offset += 4
            (textures_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.textures) != textures_length:
                self.textures = [mros.cartographer_ros_msgs.msg.SubmapTexture() for _ in range(textures_length)]
            for i in range(0, textures_length):
                offset += self.textures[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.status.serializedLength()
        length += 4
        length += 4
        for i in range(0, textures_length):
            length += self.textures[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ','
        string_echo += '"submap_version":%s' % self.submap_version
        string_echo += ','
        string_echo += '"textures":['
        textures_length = len(self.textures)
        for i in range(0, textures_length):
            if i == (textures_length - 1): 
                string_echo += '{textures%s":' % i
                string_echo += self.textures[i].echo()
                string_echo += ''
            else:
                string_echo += '{textures%s":' % i
                string_echo += self.textures[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/SubmapQuery"

    def getMD5(self):
        return "d39f26c172921775c4ad99dbf7cb0792"
    def getDef(self):
        return "cartographer_ros_msgs/StatusResponse status\nint32 submap_version\ncartographer_ros_msgs/SubmapTexture[] textures\n================================================================================\nMSG: cartographer_ros_msgs/StatusResponse\nuint8 code\nstring message\n================================================================================\nMSG: cartographer_ros_msgs/SubmapTexture\nuint8[] cells\nint32 width\nint32 height\nfloat64 resolution\ngeometry_msgs/Pose slice_pose\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SubmapQuery(object):
    Request = SubmapQueryRequest
    Response = SubmapQueryResponse

    __slots__ = ['request','response']
    _slot_types = ['SubmapQueryRequest','SubmapQueryResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SubmapQuery, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

