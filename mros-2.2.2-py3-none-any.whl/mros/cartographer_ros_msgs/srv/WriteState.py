import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class WriteStateRequest(mros.Message):
    __slots__ = ['__id__','filename','include_unfinished_submaps']
    _slot_types = ['uint32','string','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(WriteStateRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.filename is None:
                self.filename = ''
            if self.include_unfinished_submaps is None:
                self.include_unfinished_submaps = False
        else:
            self.__id__ = 0
            self.filename = ''
            self.include_unfinished_submaps = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.filename
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_include_unfinished_submaps = struct.Struct("<B")
            buff.write(struct_include_unfinished_submaps.pack(self.include_unfinished_submaps))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_filename,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.filename = buff[offset:(offset + length_filename)].decode('utf-8')
            else:
                self.filename = buff[offset:(offset + length_filename)]
            offset += length_filename
            struct_include_unfinished_submaps = struct.Struct("<B")
            (self.include_unfinished_submaps,) = struct_include_unfinished_submaps.unpack(buff[offset:(offset + 1)])
            self.include_unfinished_submaps = bool(self.include_unfinished_submaps)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        filename_x = self.filename
        filename_length = len(filename_x)
        if python3 or type(filename_x) == unicode:
            filename_x = filename_x.encode('utf-8')
            filename_length = len(filename_x)
        length += 4
        length += filename_length
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"filename":"%s"' % self.filename
        string_echo += ','
        string_echo += '"include_unfinished_submaps":%s' % self.include_unfinished_submaps
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/WriteState"

    def getMD5(self):
        return "96db93844e1eb87ed5b1526b3e48e3bb"
    def getDef(self):
        return "string filename\nbool include_unfinished_submaps\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class WriteStateResponse(mros.Message):
    __slots__ = ['__id__','status']
    _slot_types = ['uint32','cartographer_ros_msgs/StatusResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(WriteStateResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
        else:
            self.__id__ = 0
            self.status = mros.cartographer_ros_msgs.msg.StatusResponse()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.status.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.status.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.status.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/WriteState"

    def getMD5(self):
        return "96db93844e1eb87ed5b1526b3e48e3bb"
    def getDef(self):
        return "cartographer_ros_msgs/StatusResponse status\n================================================================================\nMSG: cartographer_ros_msgs/StatusResponse\nuint8 code\nstring message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class WriteState(object):
    Request = WriteStateRequest
    Response = WriteStateResponse

    __slots__ = ['request','response']
    _slot_types = ['WriteStateRequest','WriteStateResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(WriteState, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

