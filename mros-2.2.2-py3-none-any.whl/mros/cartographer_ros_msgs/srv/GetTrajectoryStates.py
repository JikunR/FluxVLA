import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class GetTrajectoryStatesRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetTrajectoryStatesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/GetTrajectoryStates"

    def getMD5(self):
        return "b9e3b373f17df088ee6dcd817b79dff0"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetTrajectoryStatesResponse(mros.Message):
    __slots__ = ['__id__','status','trajectory_states']
    _slot_types = ['uint32','cartographer_ros_msgs/StatusResponse','cartographer_ros_msgs/TrajectoryStates']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetTrajectoryStatesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            if self.trajectory_states is None:
                self.trajectory_states = mros.cartographer_ros_msgs.msg.TrajectoryStates()
        else:
            self.__id__ = 0
            self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            self.trajectory_states = mros.cartographer_ros_msgs.msg.TrajectoryStates()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.status.serialize(buff)
            offset += self.trajectory_states.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.status.deserialize(buff[offset:])
            offset += self.trajectory_states.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.status.serializedLength()
        length += self.trajectory_states.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ','
        string_echo += '"trajectory_states":'
        string_echo += self.trajectory_states.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/GetTrajectoryStates"

    def getMD5(self):
        return "b9e3b373f17df088ee6dcd817b79dff0"
    def getDef(self):
        return "cartographer_ros_msgs/StatusResponse status\ncartographer_ros_msgs/TrajectoryStates trajectory_states\n================================================================================\nMSG: cartographer_ros_msgs/StatusResponse\nuint8 code\nstring message\n================================================================================\nMSG: cartographer_ros_msgs/TrajectoryStates\nuint8 ACTIVE = 0\nuint8 FINISHED = 1\nuint8 FROZEN = 2\nuint8 DELETED = 3\nstd_msgs/Header header\nint32[] trajectory_id\nuint8[] trajectory_state\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetTrajectoryStates(object):
    Request = GetTrajectoryStatesRequest
    Response = GetTrajectoryStatesResponse

    __slots__ = ['request','response']
    _slot_types = ['GetTrajectoryStatesRequest','GetTrajectoryStatesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetTrajectoryStates, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

