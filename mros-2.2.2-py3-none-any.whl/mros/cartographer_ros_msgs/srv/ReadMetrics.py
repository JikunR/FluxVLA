import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class ReadMetricsRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ReadMetricsRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/ReadMetrics"

    def getMD5(self):
        return "a1fe8d7dcf3708e96e015774b1df470e"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ReadMetricsResponse(mros.Message):
    __slots__ = ['__id__','status','metric_families','timestamp']
    _slot_types = ['uint32','cartographer_ros_msgs/StatusResponse','cartographer_ros_msgs/MetricFamily[]','Time']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ReadMetricsResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            if self.metric_families is None:
                self.metric_families = []
            if self.timestamp is None:
                self.timestamp = mros.Time()
        else:
            self.__id__ = 0
            self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            self.metric_families = []
            self.timestamp = mros.Time()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.status.serialize(buff)
            metric_families_length = len(self.metric_families)
            buff.write(struct.pack('<I', metric_families_length))
            offset += 4
            for i in range(0, metric_families_length):
                offset += self.metric_families[i].serialize(buff)
            buff.write(_struct_I.pack(self.timestamp.sec))
            offset += 4
            buff.write(_struct_I.pack(self.timestamp.nsec))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.status.deserialize(buff[offset:])
            (metric_families_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.metric_families) != metric_families_length:
                self.metric_families = [mros.cartographer_ros_msgs.msg.MetricFamily() for _ in range(metric_families_length)]
            for i in range(0, metric_families_length):
                offset += self.metric_families[i].deserialize(buff[offset:])
            (self.timestamp.sec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.timestamp.nsec,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.status.serializedLength()
        length += 4
        for i in range(0, metric_families_length):
            length += self.metric_families[i].serializedLength()
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ','
        string_echo += '"metric_families":['
        metric_families_length = len(self.metric_families)
        for i in range(0, metric_families_length):
            if i == (metric_families_length - 1): 
                string_echo += '{metric_families%s":' % i
                string_echo += self.metric_families[i].echo()
                string_echo += ''
            else:
                string_echo += '{metric_families%s":' % i
                string_echo += self.metric_families[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"timestamp.sec":%s,' % self.timestamp.sec
        string_echo += '"timestamp.nsec":%s' % self.timestamp.nsec
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/ReadMetrics"

    def getMD5(self):
        return "a1fe8d7dcf3708e96e015774b1df470e"
    def getDef(self):
        return "cartographer_ros_msgs/StatusResponse status\ncartographer_ros_msgs/MetricFamily[] metric_families\ntime timestamp\n================================================================================\nMSG: cartographer_ros_msgs/StatusResponse\nuint8 code\nstring message\n================================================================================\nMSG: cartographer_ros_msgs/MetricFamily\nstring name\nstring description\ncartographer_ros_msgs/Metric[] metrics\n================================================================================\nMSG: cartographer_ros_msgs/Metric\nuint8 TYPE_COUNTER=0\nuint8 TYPE_GAUGE=1\nuint8 TYPE_HISTOGRAM=2\nuint8 type\ncartographer_ros_msgs/MetricLabel[] labels\nfloat64 value\ncartographer_ros_msgs/HistogramBucket[] counts_by_bucket\n================================================================================\nMSG: cartographer_ros_msgs/MetricLabel\nstring key\nstring value\n================================================================================\nMSG: cartographer_ros_msgs/HistogramBucket\nfloat64 bucket_boundary\nfloat64 count\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ReadMetrics(object):
    Request = ReadMetricsRequest
    Response = ReadMetricsResponse

    __slots__ = ['request','response']
    _slot_types = ['ReadMetricsRequest','ReadMetricsResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ReadMetrics, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

