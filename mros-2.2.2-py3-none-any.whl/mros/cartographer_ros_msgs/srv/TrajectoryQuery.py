import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.cartographer_ros_msgs.msg

class TrajectoryQueryRequest(mros.Message):
    __slots__ = ['__id__','trajectory_id']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TrajectoryQueryRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.trajectory_id is None:
                self.trajectory_id = 0
        else:
            self.__id__ = 0
            self.trajectory_id = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_trajectory_id = struct.Struct("<i")
            buff.write(struct_trajectory_id.pack(self.trajectory_id))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_trajectory_id = struct.Struct("<i")
            (self.trajectory_id,) = struct_trajectory_id.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"trajectory_id":%s' % self.trajectory_id
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/TrajectoryQuery"

    def getMD5(self):
        return "a2f9ca51998db8f538b44b11375e5916"
    def getDef(self):
        return "int32 trajectory_id\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class TrajectoryQueryResponse(mros.Message):
    __slots__ = ['__id__','status','trajectory']
    _slot_types = ['uint32','cartographer_ros_msgs/StatusResponse','geometry_msgs/PoseStamped[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TrajectoryQueryResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            if self.trajectory is None:
                self.trajectory = []
        else:
            self.__id__ = 0
            self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            self.trajectory = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.status.serialize(buff)
            trajectory_length = len(self.trajectory)
            buff.write(struct.pack('<I', trajectory_length))
            offset += 4
            for i in range(0, trajectory_length):
                offset += self.trajectory[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.status.deserialize(buff[offset:])
            (trajectory_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.trajectory) != trajectory_length:
                self.trajectory = [mros.geometry_msgs.msg.PoseStamped() for _ in range(trajectory_length)]
            for i in range(0, trajectory_length):
                offset += self.trajectory[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.status.serializedLength()
        length += 4
        for i in range(0, trajectory_length):
            length += self.trajectory[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ','
        string_echo += '"trajectory":['
        trajectory_length = len(self.trajectory)
        for i in range(0, trajectory_length):
            if i == (trajectory_length - 1): 
                string_echo += '{trajectory%s":' % i
                string_echo += self.trajectory[i].echo()
                string_echo += ''
            else:
                string_echo += '{trajectory%s":' % i
                string_echo += self.trajectory[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/TrajectoryQuery"

    def getMD5(self):
        return "a2f9ca51998db8f538b44b11375e5916"
    def getDef(self):
        return "cartographer_ros_msgs/StatusResponse status\ngeometry_msgs/PoseStamped[] trajectory\n================================================================================\nMSG: cartographer_ros_msgs/StatusResponse\nuint8 code\nstring message\n================================================================================\nMSG: geometry_msgs/PoseStamped\nstd_msgs/Header header\ngeometry_msgs/Pose pose\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class TrajectoryQuery(object):
    Request = TrajectoryQueryRequest
    Response = TrajectoryQueryResponse

    __slots__ = ['request','response']
    _slot_types = ['TrajectoryQueryRequest','TrajectoryQueryResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TrajectoryQuery, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

