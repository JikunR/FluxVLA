import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.geometry_msgs.msg
import mros.cartographer_ros_msgs.msg

class StartTrajectoryRequest(mros.Message):
    __slots__ = ['__id__','configuration_directory','configuration_basename','use_initial_pose','initial_pose','relative_to_trajectory_id']
    _slot_types = ['uint32','string','string','bool','geometry_msgs/Pose','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StartTrajectoryRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.configuration_directory is None:
                self.configuration_directory = ''
            if self.configuration_basename is None:
                self.configuration_basename = ''
            if self.use_initial_pose is None:
                self.use_initial_pose = False
            if self.initial_pose is None:
                self.initial_pose = mros.geometry_msgs.msg.Pose()
            if self.relative_to_trajectory_id is None:
                self.relative_to_trajectory_id = 0
        else:
            self.__id__ = 0
            self.configuration_directory = ''
            self.configuration_basename = ''
            self.use_initial_pose = False
            self.initial_pose = mros.geometry_msgs.msg.Pose()
            self.relative_to_trajectory_id = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.configuration_directory
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.configuration_basename
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_use_initial_pose = struct.Struct("<B")
            buff.write(struct_use_initial_pose.pack(self.use_initial_pose))
            offset += 1
            offset += self.initial_pose.serialize(buff)
            struct_relative_to_trajectory_id = struct.Struct("<i")
            buff.write(struct_relative_to_trajectory_id.pack(self.relative_to_trajectory_id))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_configuration_directory,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.configuration_directory = buff[offset:(offset + length_configuration_directory)].decode('utf-8')
            else:
                self.configuration_directory = buff[offset:(offset + length_configuration_directory)]
            offset += length_configuration_directory
            (length_configuration_basename,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.configuration_basename = buff[offset:(offset + length_configuration_basename)].decode('utf-8')
            else:
                self.configuration_basename = buff[offset:(offset + length_configuration_basename)]
            offset += length_configuration_basename
            struct_use_initial_pose = struct.Struct("<B")
            (self.use_initial_pose,) = struct_use_initial_pose.unpack(buff[offset:(offset + 1)])
            self.use_initial_pose = bool(self.use_initial_pose)
            offset += 1
            offset += self.initial_pose.deserialize(buff[offset:])
            struct_relative_to_trajectory_id = struct.Struct("<i")
            (self.relative_to_trajectory_id,) = struct_relative_to_trajectory_id.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        configuration_directory_x = self.configuration_directory
        configuration_directory_length = len(configuration_directory_x)
        if python3 or type(configuration_directory_x) == unicode:
            configuration_directory_x = configuration_directory_x.encode('utf-8')
            configuration_directory_length = len(configuration_directory_x)
        length += 4
        length += configuration_directory_length
        configuration_basename_x = self.configuration_basename
        configuration_basename_length = len(configuration_basename_x)
        if python3 or type(configuration_basename_x) == unicode:
            configuration_basename_x = configuration_basename_x.encode('utf-8')
            configuration_basename_length = len(configuration_basename_x)
        length += 4
        length += configuration_basename_length
        length += 1
        length += self.initial_pose.serializedLength()
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"configuration_directory":"%s"' % self.configuration_directory
        string_echo += ','
        string_echo += '"configuration_basename":"%s"' % self.configuration_basename
        string_echo += ','
        string_echo += '"use_initial_pose":%s' % self.use_initial_pose
        string_echo += ','
        string_echo += '"initial_pose":'
        string_echo += self.initial_pose.echo()
        string_echo += ','
        string_echo += '"relative_to_trajectory_id":%s' % self.relative_to_trajectory_id
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/StartTrajectory"

    def getMD5(self):
        return "dcc000df748d283ba7bf678a47ffa491"
    def getDef(self):
        return "string configuration_directory\nstring configuration_basename\nbool use_initial_pose\ngeometry_msgs/Pose initial_pose\nint32 relative_to_trajectory_id\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class StartTrajectoryResponse(mros.Message):
    __slots__ = ['__id__','status','trajectory_id']
    _slot_types = ['uint32','cartographer_ros_msgs/StatusResponse','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StartTrajectoryResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            if self.trajectory_id is None:
                self.trajectory_id = 0
        else:
            self.__id__ = 0
            self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
            self.trajectory_id = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.status.serialize(buff)
            struct_trajectory_id = struct.Struct("<i")
            buff.write(struct_trajectory_id.pack(self.trajectory_id))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.status.deserialize(buff[offset:])
            struct_trajectory_id = struct.Struct("<i")
            (self.trajectory_id,) = struct_trajectory_id.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.status.serializedLength()
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ','
        string_echo += '"trajectory_id":%s' % self.trajectory_id
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/StartTrajectory"

    def getMD5(self):
        return "dcc000df748d283ba7bf678a47ffa491"
    def getDef(self):
        return "cartographer_ros_msgs/StatusResponse status\nint32 trajectory_id\n================================================================================\nMSG: cartographer_ros_msgs/StatusResponse\nuint8 code\nstring message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class StartTrajectory(object):
    Request = StartTrajectoryRequest
    Response = StartTrajectoryResponse

    __slots__ = ['request','response']
    _slot_types = ['StartTrajectoryRequest','StartTrajectoryResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StartTrajectory, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

