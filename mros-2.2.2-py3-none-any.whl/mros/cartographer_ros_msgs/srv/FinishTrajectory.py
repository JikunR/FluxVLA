import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class FinishTrajectoryRequest(mros.Message):
    __slots__ = ['__id__','trajectory_id']
    _slot_types = ['uint32','int32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(FinishTrajectoryRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.trajectory_id is None:
                self.trajectory_id = 0
        else:
            self.__id__ = 0
            self.trajectory_id = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_trajectory_id = struct.Struct("<i")
            buff.write(struct_trajectory_id.pack(self.trajectory_id))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_trajectory_id = struct.Struct("<i")
            (self.trajectory_id,) = struct_trajectory_id.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"trajectory_id":%s' % self.trajectory_id
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/FinishTrajectory"

    def getMD5(self):
        return "0feba73841cb434875547ca2a563a021"
    def getDef(self):
        return "int32 trajectory_id\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class FinishTrajectoryResponse(mros.Message):
    __slots__ = ['__id__','status']
    _slot_types = ['uint32','cartographer_ros_msgs/StatusResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(FinishTrajectoryResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.status is None:
                self.status = mros.cartographer_ros_msgs.msg.StatusResponse()
        else:
            self.__id__ = 0
            self.status = mros.cartographer_ros_msgs.msg.StatusResponse()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.status.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.status.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.status.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/FinishTrajectory"

    def getMD5(self):
        return "0feba73841cb434875547ca2a563a021"
    def getDef(self):
        return "cartographer_ros_msgs/StatusResponse status\n================================================================================\nMSG: cartographer_ros_msgs/StatusResponse\nuint8 code\nstring message\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class FinishTrajectory(object):
    Request = FinishTrajectoryRequest
    Response = FinishTrajectoryResponse

    __slots__ = ['request','response']
    _slot_types = ['FinishTrajectoryRequest','FinishTrajectoryResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(FinishTrajectory, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

