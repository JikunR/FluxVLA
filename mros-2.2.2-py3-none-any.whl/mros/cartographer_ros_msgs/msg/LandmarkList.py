import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg
import mros.std_msgs.msg

class LandmarkList(mros.Message):
    __slots__ = ['header','landmarks']
    _slot_types = ['std_msgs/Header','cartographer_ros_msgs/LandmarkEntry[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(LandmarkList, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.landmarks is None:
                self.landmarks = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.landmarks = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            landmarks_length = len(self.landmarks)
            buff.write(struct.pack('<I', landmarks_length))
            offset += 4
            for i in range(0, landmarks_length):
                offset += self.landmarks[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (landmarks_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.landmarks) != landmarks_length:
                self.landmarks = [mros.cartographer_ros_msgs.msg.LandmarkEntry() for _ in range(landmarks_length)]
            for i in range(0, landmarks_length):
                offset += self.landmarks[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, landmarks_length):
            length += self.landmarks[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"landmarks":['
        landmarks_length = len(self.landmarks)
        for i in range(0, landmarks_length):
            if i == (landmarks_length - 1): 
                string_echo += '{landmarks%s":' % i
                string_echo += self.landmarks[i].echo()
                string_echo += ''
            else:
                string_echo += '{landmarks%s":' % i
                string_echo += self.landmarks[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/LandmarkList"

    def getMD5(self):
        return "322e3fb6b49d8fcd97544b4896b0ae66"

    def getDef(self):
        return "std_msgs/Header header\ncartographer_ros_msgs/LandmarkEntry[] landmarks\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: cartographer_ros_msgs/LandmarkEntry\nstring id\ngeometry_msgs/Pose tracking_from_landmark_transform\nfloat64 translation_weight\nfloat64 rotation_weight\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

