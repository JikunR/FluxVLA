import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class StatusResponse(mros.Message):
    __slots__ = ['code','message']
    _slot_types = ['uint8','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StatusResponse, self).__init__(*args, **kwds)
            if self.code is None:
                self.code = 0
            if self.message is None:
                self.message = ''
        else:
            self.code = 0
            self.message = ''

    def serialize(self, buff):
        offset = 0
        try:
            struct_code = struct.Struct("<B")
            buff.write(struct_code.pack(self.code))
            offset += 1
            _x = self.message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_code = struct.Struct("<B")
            (self.code,) = struct_code.unpack(buff[offset:(offset + 1)])
            offset += 1
            (length_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.message = buff[offset:(offset + length_message)].decode('utf-8')
            else:
                self.message = buff[offset:(offset + length_message)]
            offset += length_message
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        message_x = self.message
        message_length = len(message_x)
        if python3 or type(message_x) == unicode:
            message_x = message_x.encode('utf-8')
            message_length = len(message_x)
        length += 4
        length += message_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"code":%s' % self.code
        string_echo += ','
        string_echo += '"message":"%s"' % self.message
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/StatusResponse"

    def getMD5(self):
        return "f45eaca0a8effd52a8b18d39434a6627"

    def getDef(self):
        return "uint8 code\nstring message\n"

_struct_I = struct.Struct('<I')

