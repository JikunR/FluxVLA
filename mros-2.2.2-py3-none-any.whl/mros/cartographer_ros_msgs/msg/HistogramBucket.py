import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class HistogramBucket(mros.Message):
    __slots__ = ['bucket_boundary','count']
    _slot_types = ['float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HistogramBucket, self).__init__(*args, **kwds)
            if self.bucket_boundary is None:
                self.bucket_boundary = 0.
            if self.count is None:
                self.count = 0.
        else:
            self.bucket_boundary = 0.
            self.count = 0.

    def serialize(self, buff):
        offset = 0
        try:
            struct_bucket_boundary = struct.Struct("<d")
            buff.write(struct_bucket_boundary.pack(self.bucket_boundary))
            offset += 8
            struct_count = struct.Struct("<d")
            buff.write(struct_count.pack(self.count))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_bucket_boundary = struct.Struct("<d")
            (self.bucket_boundary,) = struct_bucket_boundary.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_count = struct.Struct("<d")
            (self.count,) = struct_count.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"bucket_boundary":%s' % self.bucket_boundary
        string_echo += ','
        string_echo += '"count":%s' % self.count
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/HistogramBucket"

    def getMD5(self):
        return "b579df35b32758cf09f65ae223aea0ad"

    def getDef(self):
        return "float64 bucket_boundary\nfloat64 count\n"

_struct_I = struct.Struct('<I')

