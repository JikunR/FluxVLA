import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class StatusCode(mros.Message):
    OK = 0
    CANCELLED = 1
    UNKNOWN = 2
    INVALID_ARGUMENT = 3
    DEADLINE_EXCEEDED = 4
    NOT_FOUND = 5
    ALREADY_EXISTS = 6
    PERMISSION_DENIED = 7
    RESOURCE_EXHAUSTED = 8
    FAILED_PRECONDITION = 9
    ABORTED = 10
    OUT_OF_RANGE = 11
    UNIMPLEMENTED = 12
    INTERNAL = 13
    UNAVAILABLE = 14
    DATA_LOSS = 15

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StatusCode, self).__init__(*args, **kwds)

    def serialize(self, buff):
        offset = 0
        return offset

    def deserialize(self, buff):
        offset = 0
        return offset

    def serializedLength(self):
        length = 0
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/StatusCode"

    def getMD5(self):
        return "90c460dc6da71af1a19af6615a8dc9a4"

    def getDef(self):
        return "uint8 OK=0\nuint8 CANCELLED=1\nuint8 UNKNOWN=2\nuint8 INVALID_ARGUMENT=3\nuint8 DEADLINE_EXCEEDED=4\nuint8 NOT_FOUND=5\nuint8 ALREADY_EXISTS=6\nuint8 PERMISSION_DENIED=7\nuint8 RESOURCE_EXHAUSTED=8\nuint8 FAILED_PRECONDITION=9\nuint8 ABORTED=10\nuint8 OUT_OF_RANGE=11\nuint8 UNIMPLEMENTED=12\nuint8 INTERNAL=13\nuint8 UNAVAILABLE=14\nuint8 DATA_LOSS=15\n"

_struct_I = struct.Struct('<I')

