import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class MetricFamily(mros.Message):
    __slots__ = ['name','description','metrics']
    _slot_types = ['string','string','cartographer_ros_msgs/Metric[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MetricFamily, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.description is None:
                self.description = ''
            if self.metrics is None:
                self.metrics = []
        else:
            self.name = ''
            self.description = ''
            self.metrics = []

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.description
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            metrics_length = len(self.metrics)
            buff.write(struct.pack('<I', metrics_length))
            offset += 4
            for i in range(0, metrics_length):
                offset += self.metrics[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (length_description,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.description = buff[offset:(offset + length_description)].decode('utf-8')
            else:
                self.description = buff[offset:(offset + length_description)]
            offset += length_description
            (metrics_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.metrics) != metrics_length:
                self.metrics = [mros.cartographer_ros_msgs.msg.Metric() for _ in range(metrics_length)]
            for i in range(0, metrics_length):
                offset += self.metrics[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        description_x = self.description
        description_length = len(description_x)
        if python3 or type(description_x) == unicode:
            description_x = description_x.encode('utf-8')
            description_length = len(description_x)
        length += 4
        length += description_length
        length += 4
        for i in range(0, metrics_length):
            length += self.metrics[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"description":"%s"' % self.description
        string_echo += ','
        string_echo += '"metrics":['
        metrics_length = len(self.metrics)
        for i in range(0, metrics_length):
            if i == (metrics_length - 1): 
                string_echo += '{metrics%s":' % i
                string_echo += self.metrics[i].echo()
                string_echo += ''
            else:
                string_echo += '{metrics%s":' % i
                string_echo += self.metrics[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/MetricFamily"

    def getMD5(self):
        return "583a11b161bb4a70f5df274715bcaf10"

    def getDef(self):
        return "string name\nstring description\ncartographer_ros_msgs/Metric[] metrics\n================================================================================\nMSG: cartographer_ros_msgs/Metric\nuint8 TYPE_COUNTER=0\nuint8 TYPE_GAUGE=1\nuint8 TYPE_HISTOGRAM=2\nuint8 type\ncartographer_ros_msgs/MetricLabel[] labels\nfloat64 value\ncartographer_ros_msgs/HistogramBucket[] counts_by_bucket\n================================================================================\nMSG: cartographer_ros_msgs/MetricLabel\nstring key\nstring value\n================================================================================\nMSG: cartographer_ros_msgs/HistogramBucket\nfloat64 bucket_boundary\nfloat64 count\n"

_struct_I = struct.Struct('<I')

