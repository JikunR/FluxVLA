import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg
import mros.geometry_msgs.msg

class SubmapEntry(mros.Message):
    __slots__ = ['trajectory_id','submap_index','submap_version','pose','is_frozen']
    _slot_types = ['int32','int32','int32','geometry_msgs/Pose','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SubmapEntry, self).__init__(*args, **kwds)
            if self.trajectory_id is None:
                self.trajectory_id = 0
            if self.submap_index is None:
                self.submap_index = 0
            if self.submap_version is None:
                self.submap_version = 0
            if self.pose is None:
                self.pose = mros.geometry_msgs.msg.Pose()
            if self.is_frozen is None:
                self.is_frozen = False
        else:
            self.trajectory_id = 0
            self.submap_index = 0
            self.submap_version = 0
            self.pose = mros.geometry_msgs.msg.Pose()
            self.is_frozen = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_trajectory_id = struct.Struct("<i")
            buff.write(struct_trajectory_id.pack(self.trajectory_id))
            offset += 4
            struct_submap_index = struct.Struct("<i")
            buff.write(struct_submap_index.pack(self.submap_index))
            offset += 4
            struct_submap_version = struct.Struct("<i")
            buff.write(struct_submap_version.pack(self.submap_version))
            offset += 4
            offset += self.pose.serialize(buff)
            struct_is_frozen = struct.Struct("<B")
            buff.write(struct_is_frozen.pack(self.is_frozen))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_trajectory_id = struct.Struct("<i")
            (self.trajectory_id,) = struct_trajectory_id.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_submap_index = struct.Struct("<i")
            (self.submap_index,) = struct_submap_index.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_submap_version = struct.Struct("<i")
            (self.submap_version,) = struct_submap_version.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.pose.deserialize(buff[offset:])
            struct_is_frozen = struct.Struct("<B")
            (self.is_frozen,) = struct_is_frozen.unpack(buff[offset:(offset + 1)])
            self.is_frozen = bool(self.is_frozen)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        length += 4
        length += self.pose.serializedLength()
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"trajectory_id":%s' % self.trajectory_id
        string_echo += ','
        string_echo += '"submap_index":%s' % self.submap_index
        string_echo += ','
        string_echo += '"submap_version":%s' % self.submap_version
        string_echo += ','
        string_echo += '"pose":'
        string_echo += self.pose.echo()
        string_echo += ','
        string_echo += '"is_frozen":%s' % self.is_frozen
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/SubmapEntry"

    def getMD5(self):
        return "0b064ac06b4af2be11388441508c9572"

    def getDef(self):
        return "int32 trajectory_id\nint32 submap_index\nint32 submap_version\ngeometry_msgs/Pose pose\nbool is_frozen\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

