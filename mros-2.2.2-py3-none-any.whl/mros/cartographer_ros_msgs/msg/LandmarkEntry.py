import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg
import mros.geometry_msgs.msg

class LandmarkEntry(mros.Message):
    __slots__ = ['id','tracking_from_landmark_transform','translation_weight','rotation_weight']
    _slot_types = ['string','geometry_msgs/Pose','float64','float64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(LandmarkEntry, self).__init__(*args, **kwds)
            if self.id is None:
                self.id = ''
            if self.tracking_from_landmark_transform is None:
                self.tracking_from_landmark_transform = mros.geometry_msgs.msg.Pose()
            if self.translation_weight is None:
                self.translation_weight = 0.
            if self.rotation_weight is None:
                self.rotation_weight = 0.
        else:
            self.id = ''
            self.tracking_from_landmark_transform = mros.geometry_msgs.msg.Pose()
            self.translation_weight = 0.
            self.rotation_weight = 0.

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            offset += self.tracking_from_landmark_transform.serialize(buff)
            struct_translation_weight = struct.Struct("<d")
            buff.write(struct_translation_weight.pack(self.translation_weight))
            offset += 8
            struct_rotation_weight = struct.Struct("<d")
            buff.write(struct_rotation_weight.pack(self.rotation_weight))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.id = buff[offset:(offset + length_id)].decode('utf-8')
            else:
                self.id = buff[offset:(offset + length_id)]
            offset += length_id
            offset += self.tracking_from_landmark_transform.deserialize(buff[offset:])
            struct_translation_weight = struct.Struct("<d")
            (self.translation_weight,) = struct_translation_weight.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_rotation_weight = struct.Struct("<d")
            (self.rotation_weight,) = struct_rotation_weight.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        id_x = self.id
        id_length = len(id_x)
        if python3 or type(id_x) == unicode:
            id_x = id_x.encode('utf-8')
            id_length = len(id_x)
        length += 4
        length += id_length
        length += self.tracking_from_landmark_transform.serializedLength()
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"id":"%s"' % self.id
        string_echo += ','
        string_echo += '"tracking_from_landmark_transform":'
        string_echo += self.tracking_from_landmark_transform.echo()
        string_echo += ','
        string_echo += '"translation_weight":%s' % self.translation_weight
        string_echo += ','
        string_echo += '"rotation_weight":%s' % self.rotation_weight
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/LandmarkEntry"

    def getMD5(self):
        return "133f8dd7259f83a87eb4d78b301c0b70"

    def getDef(self):
        return "string id\ngeometry_msgs/Pose tracking_from_landmark_transform\nfloat64 translation_weight\nfloat64 rotation_weight\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

