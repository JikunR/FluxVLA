import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg
import mros.std_msgs.msg

class TrajectoryStates(mros.Message):
    __slots__ = ['header','trajectory_id','trajectory_state']
    _slot_types = ['std_msgs/Header','int32[]','uint8[]']

    ACTIVE =  0
    FINISHED =  1
    FROZEN =  2
    DELETED =  3

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(TrajectoryStates, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.trajectory_id is None:
                self.trajectory_id = []
            if self.trajectory_state is None:
                self.trajectory_state = ''
        else:
            self.header = mros.std_msgs.msg.Header()
            self.trajectory_id = []
            self.trajectory_state = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            trajectory_id_length = len(self.trajectory_id)
            buff.write(struct.pack('<I', trajectory_id_length))
            buff.write(struct.pack(f'<{trajectory_id_length}i', *self.trajectory_id))
            offset += 4 + trajectory_id_length * 4
            trajectory_state_length = len(self.trajectory_state)
            buff.write(struct.pack('<I', trajectory_state_length))
            buff.write(struct.pack(f'<{trajectory_state_length}B', *self.trajectory_state))
            offset += 4 + trajectory_state_length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (trajectory_id_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.trajectory_id = np.frombuffer(buff[offset:offset + trajectory_id_length * 4], dtype=np.int32)
            offset += trajectory_id_length * 4
            (trajectory_state_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.trajectory_state = np.frombuffer(buff[offset:offset + trajectory_state_length], dtype=np.uint8)
            offset += trajectory_state_length
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += len(self.trajectory_id) * 4
        length += 4
        length += len(self.trajectory_state)
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"trajectory_id":['
        trajectory_id_length = len(self.trajectory_id)
        for i in range(0, trajectory_id_length):
            if i == (trajectory_id_length - 1): 
                string_echo += '%s' % self.trajectory_id[i]
            else:
                string_echo += '%s,' % self.trajectory_id[i]
        string_echo += '],'
        string_echo += '"trajectory_state":['
        trajectory_state_length = len(self.trajectory_state)
        for i in range(0, trajectory_state_length):
            if i == (trajectory_state_length - 1): 
                string_echo += '%s' % self.trajectory_state[i]
            else:
                string_echo += '%s,' % self.trajectory_state[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/TrajectoryStates"

    def getMD5(self):
        return "85efdd795e95b57a59cb785ecb152345"

    def getDef(self):
        return "uint8 ACTIVE = 0\nuint8 FINISHED = 1\nuint8 FROZEN = 2\nuint8 DELETED = 3\nstd_msgs/Header header\nint32[] trajectory_id\nuint8[] trajectory_state\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

