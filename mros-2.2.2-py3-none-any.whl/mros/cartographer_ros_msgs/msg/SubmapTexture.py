import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg
import mros.geometry_msgs.msg

class SubmapTexture(mros.Message):
    __slots__ = ['cells','width','height','resolution','slice_pose']
    _slot_types = ['uint8[]','int32','int32','float64','geometry_msgs/Pose']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SubmapTexture, self).__init__(*args, **kwds)
            if self.cells is None:
                self.cells = ''
            if self.width is None:
                self.width = 0
            if self.height is None:
                self.height = 0
            if self.resolution is None:
                self.resolution = 0.
            if self.slice_pose is None:
                self.slice_pose = mros.geometry_msgs.msg.Pose()
        else:
            self.cells = ''
            self.width = 0
            self.height = 0
            self.resolution = 0.
            self.slice_pose = mros.geometry_msgs.msg.Pose()

    def serialize(self, buff):
        offset = 0
        try:
            cells_length = len(self.cells)
            buff.write(struct.pack('<I', cells_length))
            buff.write(struct.pack(f'<{cells_length}B', *self.cells))
            offset += 4 + cells_length
            struct_width = struct.Struct("<i")
            buff.write(struct_width.pack(self.width))
            offset += 4
            struct_height = struct.Struct("<i")
            buff.write(struct_height.pack(self.height))
            offset += 4
            struct_resolution = struct.Struct("<d")
            buff.write(struct_resolution.pack(self.resolution))
            offset += 8
            offset += self.slice_pose.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (cells_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.cells = np.frombuffer(buff[offset:offset + cells_length], dtype=np.uint8)
            offset += cells_length
            struct_width = struct.Struct("<i")
            (self.width,) = struct_width.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_height = struct.Struct("<i")
            (self.height,) = struct_height.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_resolution = struct.Struct("<d")
            (self.resolution,) = struct_resolution.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.slice_pose.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += len(self.cells)
        length += 4
        length += 4
        length += 8
        length += self.slice_pose.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"cells":['
        cells_length = len(self.cells)
        for i in range(0, cells_length):
            if i == (cells_length - 1): 
                string_echo += '%s' % self.cells[i]
            else:
                string_echo += '%s,' % self.cells[i]
        string_echo += '],'
        string_echo += '"width":%s' % self.width
        string_echo += ','
        string_echo += '"height":%s' % self.height
        string_echo += ','
        string_echo += '"resolution":%s' % self.resolution
        string_echo += ','
        string_echo += '"slice_pose":'
        string_echo += self.slice_pose.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/SubmapTexture"

    def getMD5(self):
        return "26187fc048d2d8e578b6c781f3b53158"

    def getDef(self):
        return "uint8[] cells\nint32 width\nint32 height\nfloat64 resolution\ngeometry_msgs/Pose slice_pose\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

