import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class Metric(mros.Message):
    __slots__ = ['type','labels','value','counts_by_bucket']
    _slot_types = ['uint8','cartographer_ros_msgs/MetricLabel[]','float64','cartographer_ros_msgs/HistogramBucket[]']

    TYPE_COUNTER = 0
    TYPE_GAUGE = 1
    TYPE_HISTOGRAM = 2

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Metric, self).__init__(*args, **kwds)
            if self.type is None:
                self.type = 0
            if self.labels is None:
                self.labels = []
            if self.value is None:
                self.value = 0.
            if self.counts_by_bucket is None:
                self.counts_by_bucket = []
        else:
            self.type = 0
            self.labels = []
            self.value = 0.
            self.counts_by_bucket = []

    def serialize(self, buff):
        offset = 0
        try:
            struct_type = struct.Struct("<B")
            buff.write(struct_type.pack(self.type))
            offset += 1
            labels_length = len(self.labels)
            buff.write(struct.pack('<I', labels_length))
            offset += 4
            for i in range(0, labels_length):
                offset += self.labels[i].serialize(buff)
            struct_value = struct.Struct("<d")
            buff.write(struct_value.pack(self.value))
            offset += 8
            counts_by_bucket_length = len(self.counts_by_bucket)
            buff.write(struct.pack('<I', counts_by_bucket_length))
            offset += 4
            for i in range(0, counts_by_bucket_length):
                offset += self.counts_by_bucket[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_type = struct.Struct("<B")
            (self.type,) = struct_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            (labels_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.labels) != labels_length:
                self.labels = [mros.cartographer_ros_msgs.msg.MetricLabel() for _ in range(labels_length)]
            for i in range(0, labels_length):
                offset += self.labels[i].deserialize(buff[offset:])
            struct_value = struct.Struct("<d")
            (self.value,) = struct_value.unpack(buff[offset:(offset + 8)])
            offset += 8
            (counts_by_bucket_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.counts_by_bucket) != counts_by_bucket_length:
                self.counts_by_bucket = [mros.cartographer_ros_msgs.msg.HistogramBucket() for _ in range(counts_by_bucket_length)]
            for i in range(0, counts_by_bucket_length):
                offset += self.counts_by_bucket[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 4
        for i in range(0, labels_length):
            length += self.labels[i].serializedLength()
        length += 8
        length += 4
        for i in range(0, counts_by_bucket_length):
            length += self.counts_by_bucket[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"type":%s' % self.type
        string_echo += ','
        string_echo += '"labels":['
        labels_length = len(self.labels)
        for i in range(0, labels_length):
            if i == (labels_length - 1): 
                string_echo += '{labels%s":' % i
                string_echo += self.labels[i].echo()
                string_echo += ''
            else:
                string_echo += '{labels%s":' % i
                string_echo += self.labels[i].echo()
                string_echo += ','
        string_echo += '],'
        string_echo += '"value":%s' % self.value
        string_echo += ','
        string_echo += '"counts_by_bucket":['
        counts_by_bucket_length = len(self.counts_by_bucket)
        for i in range(0, counts_by_bucket_length):
            if i == (counts_by_bucket_length - 1): 
                string_echo += '{counts_by_bucket%s":' % i
                string_echo += self.counts_by_bucket[i].echo()
                string_echo += ''
            else:
                string_echo += '{counts_by_bucket%s":' % i
                string_echo += self.counts_by_bucket[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/Metric"

    def getMD5(self):
        return "94a6ea1c6ef245b483a220f6769c8e36"

    def getDef(self):
        return "uint8 TYPE_COUNTER=0\nuint8 TYPE_GAUGE=1\nuint8 TYPE_HISTOGRAM=2\nuint8 type\ncartographer_ros_msgs/MetricLabel[] labels\nfloat64 value\ncartographer_ros_msgs/HistogramBucket[] counts_by_bucket\n================================================================================\nMSG: cartographer_ros_msgs/MetricLabel\nstring key\nstring value\n================================================================================\nMSG: cartographer_ros_msgs/HistogramBucket\nfloat64 bucket_boundary\nfloat64 count\n"

_struct_I = struct.Struct('<I')

