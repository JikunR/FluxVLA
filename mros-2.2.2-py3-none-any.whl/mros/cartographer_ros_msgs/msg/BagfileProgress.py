import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg

class BagfileProgress(mros.Message):
    __slots__ = ['current_bagfile_name','current_bagfile_id','total_bagfiles','total_messages','processed_messages','total_seconds','processed_seconds']
    _slot_types = ['string','uint32','uint32','uint32','uint32','float32','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(BagfileProgress, self).__init__(*args, **kwds)
            if self.current_bagfile_name is None:
                self.current_bagfile_name = ''
            if self.current_bagfile_id is None:
                self.current_bagfile_id = 0
            if self.total_bagfiles is None:
                self.total_bagfiles = 0
            if self.total_messages is None:
                self.total_messages = 0
            if self.processed_messages is None:
                self.processed_messages = 0
            if self.total_seconds is None:
                self.total_seconds = 0.
            if self.processed_seconds is None:
                self.processed_seconds = 0.
        else:
            self.current_bagfile_name = ''
            self.current_bagfile_id = 0
            self.total_bagfiles = 0
            self.total_messages = 0
            self.processed_messages = 0
            self.total_seconds = 0.
            self.processed_seconds = 0.

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.current_bagfile_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(_struct_I.pack(self.current_bagfile_id))
            offset += 4
            buff.write(_struct_I.pack(self.total_bagfiles))
            offset += 4
            buff.write(_struct_I.pack(self.total_messages))
            offset += 4
            buff.write(_struct_I.pack(self.processed_messages))
            offset += 4
            struct_total_seconds = struct.Struct("<f")
            buff.write(struct_total_seconds.pack(self.total_seconds))
            offset += 4
            struct_processed_seconds = struct.Struct("<f")
            buff.write(struct_processed_seconds.pack(self.processed_seconds))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_current_bagfile_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.current_bagfile_name = buff[offset:(offset + length_current_bagfile_name)].decode('utf-8')
            else:
                self.current_bagfile_name = buff[offset:(offset + length_current_bagfile_name)]
            offset += length_current_bagfile_name
            (self.current_bagfile_id,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.total_bagfiles,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.total_messages,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (self.processed_messages,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_total_seconds = struct.Struct("<f")
            (self.total_seconds,) = struct_total_seconds.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_processed_seconds = struct.Struct("<f")
            (self.processed_seconds,) = struct_processed_seconds.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        current_bagfile_name_x = self.current_bagfile_name
        current_bagfile_name_length = len(current_bagfile_name_x)
        if python3 or type(current_bagfile_name_x) == unicode:
            current_bagfile_name_x = current_bagfile_name_x.encode('utf-8')
            current_bagfile_name_length = len(current_bagfile_name_x)
        length += 4
        length += current_bagfile_name_length
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"current_bagfile_name":"%s"' % self.current_bagfile_name
        string_echo += ','
        string_echo += '"current_bagfile_id":%s' % self.current_bagfile_id
        string_echo += ','
        string_echo += '"total_bagfiles":%s' % self.total_bagfiles
        string_echo += ','
        string_echo += '"total_messages":%s' % self.total_messages
        string_echo += ','
        string_echo += '"processed_messages":%s' % self.processed_messages
        string_echo += ','
        string_echo += '"total_seconds":%s' % self.total_seconds
        string_echo += ','
        string_echo += '"processed_seconds":%s' % self.processed_seconds
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/BagfileProgress"

    def getMD5(self):
        return "2a36f93b13e2b297d45098a38cb00510"

    def getDef(self):
        return "string current_bagfile_name\nuint32 current_bagfile_id\nuint32 total_bagfiles\nuint32 total_messages\nuint32 processed_messages\nfloat32 total_seconds\nfloat32 processed_seconds\n"

_struct_I = struct.Struct('<I')

