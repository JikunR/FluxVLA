import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.cartographer_ros_msgs.msg
import mros.std_msgs.msg

class SubmapList(mros.Message):
    __slots__ = ['header','submap']
    _slot_types = ['std_msgs/Header','cartographer_ros_msgs/SubmapEntry[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SubmapList, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.submap is None:
                self.submap = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.submap = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            submap_length = len(self.submap)
            buff.write(struct.pack('<I', submap_length))
            offset += 4
            for i in range(0, submap_length):
                offset += self.submap[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (submap_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.submap) != submap_length:
                self.submap = [mros.cartographer_ros_msgs.msg.SubmapEntry() for _ in range(submap_length)]
            for i in range(0, submap_length):
                offset += self.submap[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, submap_length):
            length += self.submap[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"submap":['
        submap_length = len(self.submap)
        for i in range(0, submap_length):
            if i == (submap_length - 1): 
                string_echo += '{submap%s":' % i
                string_echo += self.submap[i].echo()
                string_echo += ''
            else:
                string_echo += '{submap%s":' % i
                string_echo += self.submap[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "cartographer_ros_msgs/SubmapList"

    def getMD5(self):
        return "73b1e412208f0787050395996f6143db"

    def getDef(self):
        return "std_msgs/Header header\ncartographer_ros_msgs/SubmapEntry[] submap\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: cartographer_ros_msgs/SubmapEntry\nint32 trajectory_id\nint32 submap_index\nint32 submap_version\ngeometry_msgs/Pose pose\nbool is_frozen\n================================================================================\nMSG: geometry_msgs/Pose\ngeometry_msgs/Point position\ngeometry_msgs/Quaternion orientation\n================================================================================\nMSG: geometry_msgs/Point\nfloat64 x\nfloat64 y\nfloat64 z\n================================================================================\nMSG: geometry_msgs/Quaternion\nfloat64 x\nfloat64 y\nfloat64 z\nfloat64 w\n"

_struct_I = struct.Struct('<I')

