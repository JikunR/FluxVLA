import math
import struct
import sys


class Message(object):
    __slots__ = ['callerid']
    _slot_types = ['string']

    def __init__(self, *args, **kwds):
        self.callerid = ''
        if args and kwds:
              raise TypeError('Message constructor may only use args OR keywords, not both')
        if args:
            if len(args) != len(self.__slots__):
                raise TypeError('Invalid number of arguments, args should be %s' % str(self.__slots__) + ' args are' + str(args))
            for i, k in enumerate(self.__slots__):
                setattr(self, k, args[i])
        else:
            for k, v in kwds.items():
                if k not in self.__slots__:
                    raise AttributeError('%s is not an attribute of %s' % (k, self.__class__.__name__))
            for k in self.__slots__:
                if k in kwds:
                    setattr(self, k, kwds[k])
                else:
                    setattr(self, k, None)
        self.callerid = ''

    def __getstate__(self):
        return [getattr(self, x) for x in self.__slots__]

    def __setstate__(self, state):
        for x, val in zip(self.__slots__, state):
            setattr(self, x, val)
    
    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        for f in self.__slots__:
            try:
                v1 = getattr(self, f)
                v2 = getattr(other, f)
                if type(v1) in (list, tuple) and type(v2) in (list, tuple):
                    if tuple(v1) != tuple(v2):
                        return False
                elif not v1 == v2:
                    return False
            except AttributeError:
                return False
        return True

    def __ne__(self, other):
        return not self == other

    def serialize(self, buff):
        pass

    def deserialize(self, buff):
        pass

    def serializedLength(self):
        pass

    def echo(self):
        pass

    def getType(self):
        pass

    def getMD5(self):
        pass

    def getDef(self):
        pass
