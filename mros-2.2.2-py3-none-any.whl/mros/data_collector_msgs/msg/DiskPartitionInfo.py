import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.data_collector_msgs.msg

class DiskPartitionInfo(mros.Message):
    __slots__ = ['device','mount_point','removable','total_bytes','available_bytes']
    _slot_types = ['string','string','bool','uint64','uint64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DiskPartitionInfo, self).__init__(*args, **kwds)
            if self.device is None:
                self.device = ''
            if self.mount_point is None:
                self.mount_point = ''
            if self.removable is None:
                self.removable = False
            if self.total_bytes is None:
                self.total_bytes = 0
            if self.available_bytes is None:
                self.available_bytes = 0
        else:
            self.device = ''
            self.mount_point = ''
            self.removable = False
            self.total_bytes = 0
            self.available_bytes = 0

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.device
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.mount_point
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_removable = struct.Struct("<B")
            buff.write(struct_removable.pack(self.removable))
            offset += 1
            struct_total_bytes = struct.Struct("<Q")
            buff.write(struct_total_bytes.pack(self.total_bytes))
            offset += 8
            struct_available_bytes = struct.Struct("<Q")
            buff.write(struct_available_bytes.pack(self.available_bytes))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_device,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.device = buff[offset:(offset + length_device)].decode('utf-8')
            else:
                self.device = buff[offset:(offset + length_device)]
            offset += length_device
            (length_mount_point,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.mount_point = buff[offset:(offset + length_mount_point)].decode('utf-8')
            else:
                self.mount_point = buff[offset:(offset + length_mount_point)]
            offset += length_mount_point
            struct_removable = struct.Struct("<B")
            (self.removable,) = struct_removable.unpack(buff[offset:(offset + 1)])
            self.removable = bool(self.removable)
            offset += 1
            struct_total_bytes = struct.Struct("<Q")
            (self.total_bytes,) = struct_total_bytes.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_available_bytes = struct.Struct("<Q")
            (self.available_bytes,) = struct_available_bytes.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        device_x = self.device
        device_length = len(device_x)
        if python3 or type(device_x) == unicode:
            device_x = device_x.encode('utf-8')
            device_length = len(device_x)
        length += 4
        length += device_length
        mount_point_x = self.mount_point
        mount_point_length = len(mount_point_x)
        if python3 or type(mount_point_x) == unicode:
            mount_point_x = mount_point_x.encode('utf-8')
            mount_point_length = len(mount_point_x)
        length += 4
        length += mount_point_length
        length += 1
        length += 8
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"device":"%s"' % self.device
        string_echo += ','
        string_echo += '"mount_point":"%s"' % self.mount_point
        string_echo += ','
        string_echo += '"removable":%s' % self.removable
        string_echo += ','
        string_echo += '"total_bytes":%s' % self.total_bytes
        string_echo += ','
        string_echo += '"available_bytes":%s' % self.available_bytes
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "data_collector_msgs/DiskPartitionInfo"

    def getMD5(self):
        return "07bbe4a55105148199538a8c307e3f0c"

    def getDef(self):
        return "string device\nstring mount_point\nbool removable\nuint64 total_bytes\nuint64 available_bytes\n"

_struct_I = struct.Struct('<I')

