import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.data_collector_msgs.msg

class CameraInfo(mros.Message):
    __slots__ = ['name','serial_no']
    _slot_types = ['string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CameraInfo, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.serial_no is None:
                self.serial_no = ''
        else:
            self.name = ''
            self.serial_no = ''

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.serial_no
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (length_serial_no,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.serial_no = buff[offset:(offset + length_serial_no)].decode('utf-8')
            else:
                self.serial_no = buff[offset:(offset + length_serial_no)]
            offset += length_serial_no
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        serial_no_x = self.serial_no
        serial_no_length = len(serial_no_x)
        if python3 or type(serial_no_x) == unicode:
            serial_no_x = serial_no_x.encode('utf-8')
            serial_no_length = len(serial_no_x)
        length += 4
        length += serial_no_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"serial_no":"%s"' % self.serial_no
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "data_collector_msgs/CameraInfo"

    def getMD5(self):
        return "1986041f803fa4de411d8e0f8fdd6c40"

    def getDef(self):
        return "string name\nstring serial_no\n"

_struct_I = struct.Struct('<I')

