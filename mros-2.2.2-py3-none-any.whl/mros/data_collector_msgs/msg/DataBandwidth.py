import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.data_collector_msgs.msg
import mros.std_msgs.msg

class DataBandwidth(mros.Message):
    __slots__ = ['header','frame_rate','bandwidth','storage_total_bytes','storage_available_bytes','hdf5_file_name','hdf5_file_size']
    _slot_types = ['std_msgs/Header','float64','uint64','uint64','uint64','string','uint64']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(DataBandwidth, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.frame_rate is None:
                self.frame_rate = 0.
            if self.bandwidth is None:
                self.bandwidth = 0
            if self.storage_total_bytes is None:
                self.storage_total_bytes = 0
            if self.storage_available_bytes is None:
                self.storage_available_bytes = 0
            if self.hdf5_file_name is None:
                self.hdf5_file_name = ''
            if self.hdf5_file_size is None:
                self.hdf5_file_size = 0
        else:
            self.header = mros.std_msgs.msg.Header()
            self.frame_rate = 0.
            self.bandwidth = 0
            self.storage_total_bytes = 0
            self.storage_available_bytes = 0
            self.hdf5_file_name = ''
            self.hdf5_file_size = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_frame_rate = struct.Struct("<d")
            buff.write(struct_frame_rate.pack(self.frame_rate))
            offset += 8
            struct_bandwidth = struct.Struct("<Q")
            buff.write(struct_bandwidth.pack(self.bandwidth))
            offset += 8
            struct_storage_total_bytes = struct.Struct("<Q")
            buff.write(struct_storage_total_bytes.pack(self.storage_total_bytes))
            offset += 8
            struct_storage_available_bytes = struct.Struct("<Q")
            buff.write(struct_storage_available_bytes.pack(self.storage_available_bytes))
            offset += 8
            _x = self.hdf5_file_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_hdf5_file_size = struct.Struct("<Q")
            buff.write(struct_hdf5_file_size.pack(self.hdf5_file_size))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_frame_rate = struct.Struct("<d")
            (self.frame_rate,) = struct_frame_rate.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_bandwidth = struct.Struct("<Q")
            (self.bandwidth,) = struct_bandwidth.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_storage_total_bytes = struct.Struct("<Q")
            (self.storage_total_bytes,) = struct_storage_total_bytes.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_storage_available_bytes = struct.Struct("<Q")
            (self.storage_available_bytes,) = struct_storage_available_bytes.unpack(buff[offset:(offset + 8)])
            offset += 8
            (length_hdf5_file_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.hdf5_file_name = buff[offset:(offset + length_hdf5_file_name)].decode('utf-8')
            else:
                self.hdf5_file_name = buff[offset:(offset + length_hdf5_file_name)]
            offset += length_hdf5_file_name
            struct_hdf5_file_size = struct.Struct("<Q")
            (self.hdf5_file_size,) = struct_hdf5_file_size.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 8
        length += 8
        length += 8
        hdf5_file_name_x = self.hdf5_file_name
        hdf5_file_name_length = len(hdf5_file_name_x)
        if python3 or type(hdf5_file_name_x) == unicode:
            hdf5_file_name_x = hdf5_file_name_x.encode('utf-8')
            hdf5_file_name_length = len(hdf5_file_name_x)
        length += 4
        length += hdf5_file_name_length
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"frame_rate":%s' % self.frame_rate
        string_echo += ','
        string_echo += '"bandwidth":%s' % self.bandwidth
        string_echo += ','
        string_echo += '"storage_total_bytes":%s' % self.storage_total_bytes
        string_echo += ','
        string_echo += '"storage_available_bytes":%s' % self.storage_available_bytes
        string_echo += ','
        string_echo += '"hdf5_file_name":"%s"' % self.hdf5_file_name
        string_echo += ','
        string_echo += '"hdf5_file_size":%s' % self.hdf5_file_size
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "data_collector_msgs/DataBandwidth"

    def getMD5(self):
        return "f9e12acce48e1aebdc6f457762ec7086"

    def getDef(self):
        return "std_msgs/Header header\nfloat64 frame_rate\nuint64 bandwidth\nuint64 storage_total_bytes\nuint64 storage_available_bytes\nstring hdf5_file_name\nuint64 hdf5_file_size\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

