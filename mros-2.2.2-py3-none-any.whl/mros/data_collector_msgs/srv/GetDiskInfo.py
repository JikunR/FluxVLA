import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.data_collector_msgs.msg

class GetDiskInfoRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetDiskInfoRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "data_collector_msgs/GetDiskInfo"

    def getMD5(self):
        return "588c998d63d9fd23d99ec4f0b50345e0"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetDiskInfoResponse(mros.Message):
    __slots__ = ['__id__','info']
    _slot_types = ['uint32','data_collector_msgs/DiskPartitionInfo[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetDiskInfoResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.info is None:
                self.info = []
        else:
            self.__id__ = 0
            self.info = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            info_length = len(self.info)
            buff.write(struct.pack('<I', info_length))
            offset += 4
            for i in range(0, info_length):
                offset += self.info[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (info_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.info) != info_length:
                self.info = [mros.data_collector_msgs.msg.DiskPartitionInfo() for _ in range(info_length)]
            for i in range(0, info_length):
                offset += self.info[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, info_length):
            length += self.info[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"info":['
        info_length = len(self.info)
        for i in range(0, info_length):
            if i == (info_length - 1): 
                string_echo += '{info%s":' % i
                string_echo += self.info[i].echo()
                string_echo += ''
            else:
                string_echo += '{info%s":' % i
                string_echo += self.info[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "data_collector_msgs/GetDiskInfo"

    def getMD5(self):
        return "588c998d63d9fd23d99ec4f0b50345e0"
    def getDef(self):
        return "data_collector_msgs/DiskPartitionInfo[] info\n================================================================================\nMSG: data_collector_msgs/DiskPartitionInfo\nstring device\nstring mount_point\nbool removable\nuint64 total_bytes\nuint64 available_bytes\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class GetDiskInfo(object):
    Request = GetDiskInfoRequest
    Response = GetDiskInfoResponse

    __slots__ = ['request','response']
    _slot_types = ['GetDiskInfoRequest','GetDiskInfoResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(GetDiskInfo, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

