import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.data_collector_msgs.msg

class StartCollectorRequest(mros.Message):
    __slots__ = ['__id__','storage_directory','task_identifier','frame_rate','resolution','camera_parameters']
    _slot_types = ['uint32','string','string','int32','int32','data_collector_msgs/CameraInfo[]']

    RESOLUTION_480P =  0  
    RESOLUTION_720P =  1  
    RESOLUTION_360P =  2  

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StartCollectorRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.storage_directory is None:
                self.storage_directory = ''
            if self.task_identifier is None:
                self.task_identifier = ''
            if self.frame_rate is None:
                self.frame_rate = 0
            if self.resolution is None:
                self.resolution = 0
            if self.camera_parameters is None:
                self.camera_parameters = []
        else:
            self.__id__ = 0
            self.storage_directory = ''
            self.task_identifier = ''
            self.frame_rate = 0
            self.resolution = 0
            self.camera_parameters = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.storage_directory
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.task_identifier
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_frame_rate = struct.Struct("<i")
            buff.write(struct_frame_rate.pack(self.frame_rate))
            offset += 4
            struct_resolution = struct.Struct("<i")
            buff.write(struct_resolution.pack(self.resolution))
            offset += 4
            camera_parameters_length = len(self.camera_parameters)
            buff.write(struct.pack('<I', camera_parameters_length))
            offset += 4
            for i in range(0, camera_parameters_length):
                offset += self.camera_parameters[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_storage_directory,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.storage_directory = buff[offset:(offset + length_storage_directory)].decode('utf-8')
            else:
                self.storage_directory = buff[offset:(offset + length_storage_directory)]
            offset += length_storage_directory
            (length_task_identifier,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.task_identifier = buff[offset:(offset + length_task_identifier)].decode('utf-8')
            else:
                self.task_identifier = buff[offset:(offset + length_task_identifier)]
            offset += length_task_identifier
            struct_frame_rate = struct.Struct("<i")
            (self.frame_rate,) = struct_frame_rate.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_resolution = struct.Struct("<i")
            (self.resolution,) = struct_resolution.unpack(buff[offset:(offset + 4)])
            offset += 4
            (camera_parameters_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.camera_parameters) != camera_parameters_length:
                self.camera_parameters = [mros.data_collector_msgs.msg.CameraInfo() for _ in range(camera_parameters_length)]
            for i in range(0, camera_parameters_length):
                offset += self.camera_parameters[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        storage_directory_x = self.storage_directory
        storage_directory_length = len(storage_directory_x)
        if python3 or type(storage_directory_x) == unicode:
            storage_directory_x = storage_directory_x.encode('utf-8')
            storage_directory_length = len(storage_directory_x)
        length += 4
        length += storage_directory_length
        task_identifier_x = self.task_identifier
        task_identifier_length = len(task_identifier_x)
        if python3 or type(task_identifier_x) == unicode:
            task_identifier_x = task_identifier_x.encode('utf-8')
            task_identifier_length = len(task_identifier_x)
        length += 4
        length += task_identifier_length
        length += 4
        length += 4
        length += 4
        for i in range(0, camera_parameters_length):
            length += self.camera_parameters[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"storage_directory":"%s"' % self.storage_directory
        string_echo += ','
        string_echo += '"task_identifier":"%s"' % self.task_identifier
        string_echo += ','
        string_echo += '"frame_rate":%s' % self.frame_rate
        string_echo += ','
        string_echo += '"resolution":%s' % self.resolution
        string_echo += ','
        string_echo += '"camera_parameters":['
        camera_parameters_length = len(self.camera_parameters)
        for i in range(0, camera_parameters_length):
            if i == (camera_parameters_length - 1): 
                string_echo += '{camera_parameters%s":' % i
                string_echo += self.camera_parameters[i].echo()
                string_echo += ''
            else:
                string_echo += '{camera_parameters%s":' % i
                string_echo += self.camera_parameters[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "data_collector_msgs/StartCollector"

    def getMD5(self):
        return "7f309f9fab89f330f0a0efdd89c5499b"
    def getDef(self):
        return "string storage_directory\nstring task_identifier\nint32 frame_rate\nint32 RESOLUTION_480P = 0\nint32 RESOLUTION_720P = 1\nint32 RESOLUTION_360P = 2\nint32 resolution\ndata_collector_msgs/CameraInfo[] camera_parameters\n================================================================================\nMSG: data_collector_msgs/CameraInfo\nstring name\nstring serial_no\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class StartCollectorResponse(mros.Message):
    __slots__ = ['__id__','message','success']
    _slot_types = ['uint32','string','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StartCollectorResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.message is None:
                self.message = ''
            if self.success is None:
                self.success = False
        else:
            self.__id__ = 0
            self.message = ''
            self.success = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.message
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            struct_success = struct.Struct("<B")
            buff.write(struct_success.pack(self.success))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_message,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.message = buff[offset:(offset + length_message)].decode('utf-8')
            else:
                self.message = buff[offset:(offset + length_message)]
            offset += length_message
            struct_success = struct.Struct("<B")
            (self.success,) = struct_success.unpack(buff[offset:(offset + 1)])
            self.success = bool(self.success)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        message_x = self.message
        message_length = len(message_x)
        if python3 or type(message_x) == unicode:
            message_x = message_x.encode('utf-8')
            message_length = len(message_x)
        length += 4
        length += message_length
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"message":"%s"' % self.message
        string_echo += ','
        string_echo += '"success":%s' % self.success
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "data_collector_msgs/StartCollector"

    def getMD5(self):
        return "7f309f9fab89f330f0a0efdd89c5499b"
    def getDef(self):
        return "string message\nbool success\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class StartCollector(object):
    Request = StartCollectorRequest
    Response = StartCollectorResponse

    __slots__ = ['request','response']
    _slot_types = ['StartCollectorRequest','StartCollectorResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(StartCollector, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

