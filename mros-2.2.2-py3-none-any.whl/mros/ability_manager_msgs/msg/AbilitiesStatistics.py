import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ability_manager_msgs.msg
import mros.std_msgs.msg

class AbilitiesStatistics(mros.Message):
    __slots__ = ['header','ability']
    _slot_types = ['std_msgs/Header','ability_manager_msgs/AbilityStatistics[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AbilitiesStatistics, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.ability is None:
                self.ability = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.ability = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            ability_length = len(self.ability)
            buff.write(struct.pack('<I', ability_length))
            offset += 4
            for i in range(0, ability_length):
                offset += self.ability[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (ability_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.ability) != ability_length:
                self.ability = [mros.ability_manager_msgs.msg.AbilityStatistics() for _ in range(ability_length)]
            for i in range(0, ability_length):
                offset += self.ability[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, ability_length):
            length += self.ability[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"ability":['
        ability_length = len(self.ability)
        for i in range(0, ability_length):
            if i == (ability_length - 1): 
                string_echo += '{ability%s":' % i
                string_echo += self.ability[i].echo()
                string_echo += ''
            else:
                string_echo += '{ability%s":' % i
                string_echo += self.ability[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/AbilitiesStatistics"

    def getMD5(self):
        return "7010f910293134cd0bdb59605544a7d3"

    def getDef(self):
        return "std_msgs/Header header\nability_manager_msgs/AbilityStatistics[] ability\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: ability_manager_msgs/AbilityStatistics\nstring name\nstring type\ntime timestamp\nbool running\nduration max_time\nduration mean_time\nduration variance_time\nint32 num_control_loop_overruns\ntime time_last_control_loop_overrun\n"

_struct_I = struct.Struct('<I')

