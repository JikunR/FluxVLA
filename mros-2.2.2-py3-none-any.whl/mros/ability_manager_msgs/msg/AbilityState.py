import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ability_manager_msgs.msg

class AbilityState(mros.Message):
    __slots__ = ['name','state','type']
    _slot_types = ['string','string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AbilityState, self).__init__(*args, **kwds)
            if self.name is None:
                self.name = ''
            if self.state is None:
                self.state = ''
            if self.type is None:
                self.type = ''
        else:
            self.name = ''
            self.state = ''
            self.type = ''

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.state
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.type
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
            (length_state,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.state = buff[offset:(offset + length_state)].decode('utf-8')
            else:
                self.state = buff[offset:(offset + length_state)]
            offset += length_state
            (length_type,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.type = buff[offset:(offset + length_type)].decode('utf-8')
            else:
                self.type = buff[offset:(offset + length_type)]
            offset += length_type
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        state_x = self.state
        state_length = len(state_x)
        if python3 or type(state_x) == unicode:
            state_x = state_x.encode('utf-8')
            state_length = len(state_x)
        length += 4
        length += state_length
        type_x = self.type
        type_length = len(type_x)
        if python3 or type(type_x) == unicode:
            type_x = type_x.encode('utf-8')
            type_length = len(type_x)
        length += 4
        length += type_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"name":"%s"' % self.name
        string_echo += ','
        string_echo += '"state":"%s"' % self.state
        string_echo += ','
        string_echo += '"type":"%s"' % self.type
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/AbilityState"

    def getMD5(self):
        return "dd040d834affcfafe41e0dab0ae71780"

    def getDef(self):
        return "string name\nstring state\nstring type\n"

_struct_I = struct.Struct('<I')

