import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ability_manager_msgs.msg

class ListAbilitiesRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListAbilitiesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/ListAbilities"

    def getMD5(self):
        return "98127dad21ea14f1da003f7a2f18c2f2"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ListAbilitiesResponse(mros.Message):
    __slots__ = ['__id__','ability']
    _slot_types = ['uint32','ability_manager_msgs/AbilityState[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListAbilitiesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.ability is None:
                self.ability = []
        else:
            self.__id__ = 0
            self.ability = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            ability_length = len(self.ability)
            buff.write(struct.pack('<I', ability_length))
            offset += 4
            for i in range(0, ability_length):
                offset += self.ability[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (ability_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.ability) != ability_length:
                self.ability = [mros.ability_manager_msgs.msg.AbilityState() for _ in range(ability_length)]
            for i in range(0, ability_length):
                offset += self.ability[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, ability_length):
            length += self.ability[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"ability":['
        ability_length = len(self.ability)
        for i in range(0, ability_length):
            if i == (ability_length - 1): 
                string_echo += '{ability%s":' % i
                string_echo += self.ability[i].echo()
                string_echo += ''
            else:
                string_echo += '{ability%s":' % i
                string_echo += self.ability[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/ListAbilities"

    def getMD5(self):
        return "98127dad21ea14f1da003f7a2f18c2f2"
    def getDef(self):
        return "ability_manager_msgs/AbilityState[] ability\n================================================================================\nMSG: ability_manager_msgs/AbilityState\nstring name\nstring state\nstring type\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ListAbilities(object):
    Request = ListAbilitiesRequest
    Response = ListAbilitiesResponse

    __slots__ = ['request','response']
    _slot_types = ['ListAbilitiesRequest','ListAbilitiesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListAbilities, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

