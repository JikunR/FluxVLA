import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ability_manager_msgs.msg

class ReloadAbilityLibrariesRequest(mros.Message):
    __slots__ = ['__id__','force_kill']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ReloadAbilityLibrariesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.force_kill is None:
                self.force_kill = False
        else:
            self.__id__ = 0
            self.force_kill = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_force_kill = struct.Struct("<B")
            buff.write(struct_force_kill.pack(self.force_kill))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_force_kill = struct.Struct("<B")
            (self.force_kill,) = struct_force_kill.unpack(buff[offset:(offset + 1)])
            self.force_kill = bool(self.force_kill)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"force_kill":%s' % self.force_kill
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/ReloadAbilityLibraries"

    def getMD5(self):
        return "40e8c411fd1797d2e2c486018f846040"
    def getDef(self):
        return "bool force_kill\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ReloadAbilityLibrariesResponse(mros.Message):
    __slots__ = ['__id__','ok']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ReloadAbilityLibrariesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.ok is None:
                self.ok = False
        else:
            self.__id__ = 0
            self.ok = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_ok = struct.Struct("<B")
            buff.write(struct_ok.pack(self.ok))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_ok = struct.Struct("<B")
            (self.ok,) = struct_ok.unpack(buff[offset:(offset + 1)])
            self.ok = bool(self.ok)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"ok":%s' % self.ok
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/ReloadAbilityLibraries"

    def getMD5(self):
        return "40e8c411fd1797d2e2c486018f846040"
    def getDef(self):
        return "bool ok\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ReloadAbilityLibraries(object):
    Request = ReloadAbilityLibrariesRequest
    Response = ReloadAbilityLibrariesResponse

    __slots__ = ['request','response']
    _slot_types = ['ReloadAbilityLibrariesRequest','ReloadAbilityLibrariesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ReloadAbilityLibraries, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

