import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ability_manager_msgs.msg

class UnloadAbilityRequest(mros.Message):
    __slots__ = ['__id__','name']
    _slot_types = ['uint32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(UnloadAbilityRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.name is None:
                self.name = ''
        else:
            self.__id__ = 0
            self.name = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            _x = self.name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.name = buff[offset:(offset + length_name)].decode('utf-8')
            else:
                self.name = buff[offset:(offset + length_name)]
            offset += length_name
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        name_x = self.name
        name_length = len(name_x)
        if python3 or type(name_x) == unicode:
            name_x = name_x.encode('utf-8')
            name_length = len(name_x)
        length += 4
        length += name_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"name":"%s"' % self.name
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/UnloadAbility"

    def getMD5(self):
        return "647e5c54b8d6468952d8d31f1efe96c0"
    def getDef(self):
        return "string name\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class UnloadAbilityResponse(mros.Message):
    __slots__ = ['__id__','ok']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(UnloadAbilityResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.ok is None:
                self.ok = False
        else:
            self.__id__ = 0
            self.ok = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_ok = struct.Struct("<B")
            buff.write(struct_ok.pack(self.ok))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_ok = struct.Struct("<B")
            (self.ok,) = struct_ok.unpack(buff[offset:(offset + 1)])
            self.ok = bool(self.ok)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"ok":%s' % self.ok
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/UnloadAbility"

    def getMD5(self):
        return "647e5c54b8d6468952d8d31f1efe96c0"
    def getDef(self):
        return "bool ok\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class UnloadAbility(object):
    Request = UnloadAbilityRequest
    Response = UnloadAbilityResponse

    __slots__ = ['request','response']
    _slot_types = ['UnloadAbilityRequest','UnloadAbilityResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(UnloadAbility, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

