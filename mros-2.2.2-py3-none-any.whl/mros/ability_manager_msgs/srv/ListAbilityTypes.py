import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ability_manager_msgs.msg

class ListAbilityTypesRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListAbilityTypesRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/ListAbilityTypes"

    def getMD5(self):
        return "c1d4cd11aefa9f97ba4aeb5b33987f4e"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ListAbilityTypesResponse(mros.Message):
    __slots__ = ['__id__','types','base_classes']
    _slot_types = ['uint32','string[]','string[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListAbilityTypesResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.types is None:
                self.types = []
            if self.base_classes is None:
                self.base_classes = []
        else:
            self.__id__ = 0
            self.types = []
            self.base_classes = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            types_length = len(self.types)
            buff.write(struct.pack('<I', types_length))
            offset += 4
            for i in range(0, types_length):
                _x = self.types[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            base_classes_length = len(self.base_classes)
            buff.write(struct.pack('<I', base_classes_length))
            offset += 4
            for i in range(0, base_classes_length):
                _x = self.base_classes[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (types_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.types) != types_length:
                self.types = ['' for _ in range(types_length)]
            for i in range(0, types_length):
                (length_typesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.types[i] = buff[offset:(offset + length_typesi)].decode('utf-8')
                else:
                    self.types[i] = buff[offset:(offset + length_typesi)]
                offset += length_typesi
            (base_classes_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.base_classes) != base_classes_length:
                self.base_classes = ['' for _ in range(base_classes_length)]
            for i in range(0, base_classes_length):
                (length_base_classesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.base_classes[i] = buff[offset:(offset + length_base_classesi)].decode('utf-8')
                else:
                    self.base_classes[i] = buff[offset:(offset + length_base_classesi)]
                offset += length_base_classesi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, types_length):
            typesi_x = self.types[i]
            typesi_length = len(typesi_x)
            if python3 or type(typesi_x) == unicode:
                typesi_x = typesi_x.encode('utf-8')
                typesi_length = len(typesi_x)
            length += 4
            length += typesi_length
        length += 4
        for i in range(0, base_classes_length):
            base_classesi_x = self.base_classes[i]
            base_classesi_length = len(base_classesi_x)
            if python3 or type(base_classesi_x) == unicode:
                base_classesi_x = base_classesi_x.encode('utf-8')
                base_classesi_length = len(base_classesi_x)
            length += 4
            length += base_classesi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"types":['
        types_length = len(self.types)
        for i in range(0, types_length):
            if i == (types_length - 1): 
                string_echo += '"types[i]":"%s"' % self.types[i]
                string_echo += ''
            else:
                string_echo += '"types[i]":"%s"' % self.types[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"base_classes":['
        base_classes_length = len(self.base_classes)
        for i in range(0, base_classes_length):
            if i == (base_classes_length - 1): 
                string_echo += '"base_classes[i]":"%s"' % self.base_classes[i]
                string_echo += ''
            else:
                string_echo += '"base_classes[i]":"%s"' % self.base_classes[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/ListAbilityTypes"

    def getMD5(self):
        return "c1d4cd11aefa9f97ba4aeb5b33987f4e"
    def getDef(self):
        return "string[] types\nstring[] base_classes\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class ListAbilityTypes(object):
    Request = ListAbilityTypesRequest
    Response = ListAbilityTypesResponse

    __slots__ = ['request','response']
    _slot_types = ['ListAbilityTypesRequest','ListAbilityTypesResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(ListAbilityTypes, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

