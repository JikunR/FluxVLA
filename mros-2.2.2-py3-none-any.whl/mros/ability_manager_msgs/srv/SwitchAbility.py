import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.ability_manager_msgs.msg

class SwitchAbilityRequest(mros.Message):
    __slots__ = ['__id__','start_abilities','stop_abilities','strictness','start_asap','timeout']
    _slot_types = ['uint32','string[]','string[]','int32','bool','float64']

    BEST_EFFORT = 1
    STRICT = 2

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SwitchAbilityRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.start_abilities is None:
                self.start_abilities = []
            if self.stop_abilities is None:
                self.stop_abilities = []
            if self.strictness is None:
                self.strictness = 0
            if self.start_asap is None:
                self.start_asap = False
            if self.timeout is None:
                self.timeout = 0.
        else:
            self.__id__ = 0
            self.start_abilities = []
            self.stop_abilities = []
            self.strictness = 0
            self.start_asap = False
            self.timeout = 0.

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            start_abilities_length = len(self.start_abilities)
            buff.write(struct.pack('<I', start_abilities_length))
            offset += 4
            for i in range(0, start_abilities_length):
                _x = self.start_abilities[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            stop_abilities_length = len(self.stop_abilities)
            buff.write(struct.pack('<I', stop_abilities_length))
            offset += 4
            for i in range(0, stop_abilities_length):
                _x = self.stop_abilities[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            struct_strictness = struct.Struct("<i")
            buff.write(struct_strictness.pack(self.strictness))
            offset += 4
            struct_start_asap = struct.Struct("<B")
            buff.write(struct_start_asap.pack(self.start_asap))
            offset += 1
            struct_timeout = struct.Struct("<d")
            buff.write(struct_timeout.pack(self.timeout))
            offset += 8
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            (start_abilities_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.start_abilities) != start_abilities_length:
                self.start_abilities = ['' for _ in range(start_abilities_length)]
            for i in range(0, start_abilities_length):
                (length_start_abilitiesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.start_abilities[i] = buff[offset:(offset + length_start_abilitiesi)].decode('utf-8')
                else:
                    self.start_abilities[i] = buff[offset:(offset + length_start_abilitiesi)]
                offset += length_start_abilitiesi
            (stop_abilities_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.stop_abilities) != stop_abilities_length:
                self.stop_abilities = ['' for _ in range(stop_abilities_length)]
            for i in range(0, stop_abilities_length):
                (length_stop_abilitiesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.stop_abilities[i] = buff[offset:(offset + length_stop_abilitiesi)].decode('utf-8')
                else:
                    self.stop_abilities[i] = buff[offset:(offset + length_stop_abilitiesi)]
                offset += length_stop_abilitiesi
            struct_strictness = struct.Struct("<i")
            (self.strictness,) = struct_strictness.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_start_asap = struct.Struct("<B")
            (self.start_asap,) = struct_start_asap.unpack(buff[offset:(offset + 1)])
            self.start_asap = bool(self.start_asap)
            offset += 1
            struct_timeout = struct.Struct("<d")
            (self.timeout,) = struct_timeout.unpack(buff[offset:(offset + 8)])
            offset += 8
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        for i in range(0, start_abilities_length):
            start_abilitiesi_x = self.start_abilities[i]
            start_abilitiesi_length = len(start_abilitiesi_x)
            if python3 or type(start_abilitiesi_x) == unicode:
                start_abilitiesi_x = start_abilitiesi_x.encode('utf-8')
                start_abilitiesi_length = len(start_abilitiesi_x)
            length += 4
            length += start_abilitiesi_length
        length += 4
        for i in range(0, stop_abilities_length):
            stop_abilitiesi_x = self.stop_abilities[i]
            stop_abilitiesi_length = len(stop_abilitiesi_x)
            if python3 or type(stop_abilitiesi_x) == unicode:
                stop_abilitiesi_x = stop_abilitiesi_x.encode('utf-8')
                stop_abilitiesi_length = len(stop_abilitiesi_x)
            length += 4
            length += stop_abilitiesi_length
        length += 4
        length += 1
        length += 8
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"start_abilities":['
        start_abilities_length = len(self.start_abilities)
        for i in range(0, start_abilities_length):
            if i == (start_abilities_length - 1): 
                string_echo += '"start_abilities[i]":"%s"' % self.start_abilities[i]
                string_echo += ''
            else:
                string_echo += '"start_abilities[i]":"%s"' % self.start_abilities[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"stop_abilities":['
        stop_abilities_length = len(self.stop_abilities)
        for i in range(0, stop_abilities_length):
            if i == (stop_abilities_length - 1): 
                string_echo += '"stop_abilities[i]":"%s"' % self.stop_abilities[i]
                string_echo += ''
            else:
                string_echo += '"stop_abilities[i]":"%s"' % self.stop_abilities[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"strictness":%s' % self.strictness
        string_echo += ','
        string_echo += '"start_asap":%s' % self.start_asap
        string_echo += ','
        string_echo += '"timeout":%s' % self.timeout
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/SwitchAbility"

    def getMD5(self):
        return "6eb6f190410064e7b47025a4d3dba1c8"
    def getDef(self):
        return "string[] start_abilities\nstring[] stop_abilities\nint32 strictness\nint32 BEST_EFFORT=1\nint32 STRICT=2\nbool start_asap\nfloat64 timeout\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SwitchAbilityResponse(mros.Message):
    __slots__ = ['__id__','ok']
    _slot_types = ['uint32','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SwitchAbilityResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.ok is None:
                self.ok = False
        else:
            self.__id__ = 0
            self.ok = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_ok = struct.Struct("<B")
            buff.write(struct_ok.pack(self.ok))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_ok = struct.Struct("<B")
            (self.ok,) = struct_ok.unpack(buff[offset:(offset + 1)])
            self.ok = bool(self.ok)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"ok":%s' % self.ok
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "ability_manager_msgs/SwitchAbility"

    def getMD5(self):
        return "6eb6f190410064e7b47025a4d3dba1c8"
    def getDef(self):
        return "bool ok\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SwitchAbility(object):
    Request = SwitchAbilityRequest
    Response = SwitchAbilityResponse

    __slots__ = ['request','response']
    _slot_types = ['SwitchAbilityRequest','SwitchAbilityResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SwitchAbility, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

