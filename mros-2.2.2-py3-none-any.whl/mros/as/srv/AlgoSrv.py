import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.as.msg

class AlgoSrvRequest(mros.Message):
    __slots__ = ['__id__','srv_type','srv_cmd','data','str_data']
    _slot_types = ['uint32','uint8','uint8','uint8[]','string']

    SRV_MTN =  1 
    SRV_DCK =  2 
    SRV_RBT =  3 
    SRV_EXP =  4 
    SRV_PER =  5 
    SRV_MAX =  6
    DCK_SWH =  1
    DCK_FIN =  2
    DCK_MAX =  3
    RBT_BOOT =  1
    RBT_SHUTDOWN =  2
    RBT_CTRL_SWH =  3 
    RBT_CTRL_CFM =  4 
    RBT_MTR_PW_OFF =  5
    RBT_ANY =  6
    RBT_TIMEOUT =  7
    RBT_LOSE_SIG =  8
    RBT_LOW_BATTERY =  9
    RBT_MAX =  10
    EXP_MTR_ERR =  1
    EXP_CMR_ERR =  2
    EXP_MAX =  3
    CTL_RMT =  1 
    CTL_USR =  2 
    CTL_ATO =  3 
    CTL_MAX =  4

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AlgoSrvRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.srv_type is None:
                self.srv_type = 0
            if self.srv_cmd is None:
                self.srv_cmd = 0
            if self.data is None:
                self.data = ''
            if self.str_data is None:
                self.str_data = ''
        else:
            self.__id__ = 0
            self.srv_type = 0
            self.srv_cmd = 0
            self.data = ''
            self.str_data = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_srv_type = struct.Struct("<B")
            buff.write(struct_srv_type.pack(self.srv_type))
            offset += 1
            struct_srv_cmd = struct.Struct("<B")
            buff.write(struct_srv_cmd.pack(self.srv_cmd))
            offset += 1
            data_length = len(self.data)
            buff.write(struct.pack('<I', data_length))
            buff.write(struct.pack(f'<{data_length}B', *self.data))
            offset += 4 + data_length
            _x = self.str_data
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_srv_type = struct.Struct("<B")
            (self.srv_type,) = struct_srv_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_srv_cmd = struct.Struct("<B")
            (self.srv_cmd,) = struct_srv_cmd.unpack(buff[offset:(offset + 1)])
            offset += 1
            (data_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.data = np.frombuffer(buff[offset:offset + data_length], dtype=np.uint8)
            offset += data_length
            (length_str_data,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.str_data = buff[offset:(offset + length_str_data)].decode('utf-8')
            else:
                self.str_data = buff[offset:(offset + length_str_data)]
            offset += length_str_data
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 1
        length += 1
        length += 4
        length += len(self.data)
        str_data_x = self.str_data
        str_data_length = len(str_data_x)
        if python3 or type(str_data_x) == unicode:
            str_data_x = str_data_x.encode('utf-8')
            str_data_length = len(str_data_x)
        length += 4
        length += str_data_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"srv_type":%s' % self.srv_type
        string_echo += ','
        string_echo += '"srv_cmd":%s' % self.srv_cmd
        string_echo += ','
        string_echo += '"data":['
        data_length = len(self.data)
        for i in range(0, data_length):
            if i == (data_length - 1): 
                string_echo += '%s' % self.data[i]
            else:
                string_echo += '%s,' % self.data[i]
        string_echo += '],'
        string_echo += '"str_data":"%s"' % self.str_data
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "as/AlgoSrv"

    def getMD5(self):
        return "6e44271af9c9cc43542062b5ff084d83"
    def getDef(self):
        return "uint8 SRV_MTN = 1\nuint8 SRV_DCK = 2\nuint8 SRV_RBT = 3\nuint8 SRV_EXP = 4\nuint8 SRV_PER = 5\nuint8 SRV_MAX = 6\nuint8 DCK_SWH = 1\nuint8 DCK_FIN = 2\nuint8 DCK_MAX = 3\nuint8 RBT_BOOT       = 1\nuint8 RBT_SHUTDOWN   = 2\nuint8 RBT_CTRL_SWH   = 3\nuint8 RBT_CTRL_CFM   = 4\nuint8 RBT_MTR_PW_OFF = 5\nuint8 RBT_ANY        = 6\nuint8 RBT_TIMEOUT    = 7\nuint8 RBT_LOSE_SIG   = 8\nuint8 RBT_LOW_BATTERY= 9\nuint8 RBT_MAX        = 10\nuint8 EXP_MTR_ERR = 1\nuint8 EXP_CMR_ERR = 2\nuint8 EXP_MAX     = 3\nuint8 CTL_RMT = 1\nuint8 CTL_USR = 2\nuint8 CTL_ATO = 3\nuint8 CTL_MAX = 4\nuint8 srv_type\nuint8 srv_cmd\nuint8[] data\nstring str_data\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class AlgoSrvResponse(mros.Message):
    __slots__ = ['__id__','result','msg']
    _slot_types = ['uint32','int32','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AlgoSrvResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.result is None:
                self.result = 0
            if self.msg is None:
                self.msg = ''
        else:
            self.__id__ = 0
            self.result = 0
            self.msg = ''

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_result = struct.Struct("<i")
            buff.write(struct_result.pack(self.result))
            offset += 4
            _x = self.msg
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_result = struct.Struct("<i")
            (self.result,) = struct_result.unpack(buff[offset:(offset + 4)])
            offset += 4
            (length_msg,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.msg = buff[offset:(offset + length_msg)].decode('utf-8')
            else:
                self.msg = buff[offset:(offset + length_msg)]
            offset += length_msg
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 4
        msg_x = self.msg
        msg_length = len(msg_x)
        if python3 or type(msg_x) == unicode:
            msg_x = msg_x.encode('utf-8')
            msg_length = len(msg_x)
        length += 4
        length += msg_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"result":%s' % self.result
        string_echo += ','
        string_echo += '"msg":"%s"' % self.msg
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "as/AlgoSrv"

    def getMD5(self):
        return "6e44271af9c9cc43542062b5ff084d83"
    def getDef(self):
        return "int32 result\nstring msg\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class AlgoSrv(object):
    Request = AlgoSrvRequest
    Response = AlgoSrvResponse

    __slots__ = ['request','response']
    _slot_types = ['AlgoSrvRequest','AlgoSrvResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(AlgoSrv, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

