import sys
import time
import struct
import mros
import mros.mros_msgs.msg.Log
import mros.diagnostic_msgs.msg.DiagnosticValue

python3 = True if sys.hexversion > 0x03000000 else False

if sys.version > '3':
    long = int
try:
    from cStringIO import StringIO  # Python 2.x
except ImportError:
    from io import BytesIO as StringIO  # Python 3.x


class NodeHandle(object):
    global_nh = None

    __slots__ = ['node_name', 'native']

    def __init__(self):
        try:
            self.node_name = ''
            self.native = mros.NodeHandleNative()
        except Exception as e:
            print(str(e))

    def init(self, node_name: str):
        self.node_name = node_name
        return self.native.init(self.node_name)

    def log(self, level, msg):
        return self.native.log(level, msg)

    def logonce(self, level, msg):
        return self.native.logonce(level, msg)

    def diag(self, diag: mros.diagnostic_msgs.msg.DiagnosticValue):
        return self.native.diag(diag.name, diag.code, diag.level, diag.message)

    def timeNow(self):
        return self.native.timeNow()

    def timeNowNsec(self):
        return self.native.timeNowNsec()

    def timeMonotonic(self):
        return self.native.timeMonotonic()

    def timeMonotonicNsec(self):
        return self.native.timeMonotonicNsec()

    def timeWall(self):
        return self.native.timeWall()

    def timeWallNsec(self):
        return self.native.timeWallNsec()

    def sleep(self, sec):
        return self.native.sleep(sec)

    def wallSleep(self, sec):
        return self.native.wallSleep(sec)

    def ok(self):
        return self.native.ok()

    def shutdown(self):
        return self.native.shutdown()

    def getPublishedTopics(self):
        return self.native.getPublishedTopics()

    def getSubscribedTopics(self):
        return self.native.getSubscribedTopics()

    def getServiceList(self):
        return self.native.getServiceList()

#####################################################################
# Global functions


MROS_CALLERID_SIZE = 32


def getCallerid(buff: StringIO):
    callerid = ''
    offset = 0
    try:
        _struct_I = struct.Struct('<I')
        (length_data,) = _struct_I.unpack(buff[0:(offset + 4)])
        offset += 4
        if python3:
            callerid = buff[offset:(offset + length_data)].decode('utf-8')
        else:
            callerid = buff[offset:(offset + length_data)]
    except struct.error as ex:
        print('Unable to getCallerid messages: %s' % str(ex))
    return callerid


def init(node_name: str):
    NodeHandle.global_nh = NodeHandle()
    return NodeHandle.global_nh.init(node_name)


def ok():
    if not NodeHandle.global_nh:
        return False
    return NodeHandle.global_nh.ok()


def logDebug(msg: str):
    return NodeHandle.global_nh.log(mros.mros_msgs.msg.Log.DEBUG, msg)


def logInfo(msg: str):
    return NodeHandle.global_nh.log(mros.mros_msgs.msg.Log.INFO, msg)


def logWarn(msg: str):
    return NodeHandle.global_nh.log(mros.mros_msgs.msg.Log.WARN, msg)


def logError(msg: str):
    return NodeHandle.global_nh.log(mros.mros_msgs.msg.Log.ERROR, msg)


def logFatal(msg: str):
    return NodeHandle.global_nh.log(mros.mros_msgs.msg.Log.FATAL, msg)


def logDebugOnce(msg: str):
    return NodeHandle.global_nh.logonce(mros.mros_msgs.msg.Log.DEBUG, msg)


def logInfoOnce(msg: str):
    return NodeHandle.global_nh.logonce(mros.mros_msgs.msg.Log.INFO, msg)


def logWarnOnce(msg: str):
    return NodeHandle.global_nh.logonce(mros.mros_msgs.msg.Log.WARN, msg)


def logErrorOnce(msg: str):
    return NodeHandle.global_nh.logonce(mros.mros_msgs.msg.Log.ERROR, msg)


def logFatalOnce(msg: str):
    return NodeHandle.global_nh.logonce(mros.mros_msgs.msg.Log.FATAL, msg)

def diag(diag: mros.diagnostic_msgs.msg.DiagnosticValue):
    return NodeHandle.global_nh.diag(diag)

def getPublishedTopics():
    return NodeHandle.global_nh.getPublishedTopics()

def getSubscribedTopics():
    return NodeHandle.global_nh.getSubscribedTopics()

def getServiceList():
    return NodeHandle.global_nh.getServiceList()

def timeNow():
    return NodeHandle.global_nh.timeNow()

def timeNowNsec():
    return NodeHandle.global_nh.timeNowNsec()

def timeMonotonic():
    return NodeHandle.global_nh.timeMonotonic()

def timeMonotonicNsec():
    return NodeHandle.global_nh.timeMonotonicNsec()

def timeWall():
    return NodeHandle.global_nh.timeWall()

def timeWallNsec():
    return NodeHandle.global_nh.timeWallNsec()

def sleep(sec: float):
    return NodeHandle.global_nh.sleep(sec)

def wallSleep(sec: float):
    return NodeHandle.global_nh.wallSleep(sec)

def advertise(topic_name: str, msg_class, intra_process: bool = False, queue_size: int = 50):
    return mros.Publisher(topic_name, msg_class, intra_process, queue_size)

def subscribe(topic_name: str, msg_class, callback=None, queue_size: int = -1, latch: bool = False, reliable: bool = False):
    return mros.Subscriber(topic_name, msg_class, callback, queue_size, latch, reliable)

def advertiseService(topic_name: str, user_callback, data_req_class, data_resp_class):
    return mros.ServiceServer(topic_name, user_callback, data_req_class, data_resp_class)

def serviceClient(topic_name: str, data_req_class, data_resp_class):
    return mros.ServiceClient(topic_name, data_req_class, data_resp_class)

def shutdown():
    return NodeHandle.global_nh.shutdown()

def spin():
    while mros.ok():
        time.sleep(1)
