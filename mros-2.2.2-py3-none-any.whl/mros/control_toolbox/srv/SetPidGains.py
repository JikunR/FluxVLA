import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.control_toolbox.msg

class SetPidGainsRequest(mros.Message):
    __slots__ = ['__id__','p','i','d','i_clamp','antiwindup']
    _slot_types = ['uint32','float64','float64','float64','float64','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetPidGainsRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.p is None:
                self.p = 0.
            if self.i is None:
                self.i = 0.
            if self.d is None:
                self.d = 0.
            if self.i_clamp is None:
                self.i_clamp = 0.
            if self.antiwindup is None:
                self.antiwindup = False
        else:
            self.__id__ = 0
            self.p = 0.
            self.i = 0.
            self.d = 0.
            self.i_clamp = 0.
            self.antiwindup = False

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            struct_p = struct.Struct("<d")
            buff.write(struct_p.pack(self.p))
            offset += 8
            struct_i = struct.Struct("<d")
            buff.write(struct_i.pack(self.i))
            offset += 8
            struct_d = struct.Struct("<d")
            buff.write(struct_d.pack(self.d))
            offset += 8
            struct_i_clamp = struct.Struct("<d")
            buff.write(struct_i_clamp.pack(self.i_clamp))
            offset += 8
            struct_antiwindup = struct.Struct("<B")
            buff.write(struct_antiwindup.pack(self.antiwindup))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_p = struct.Struct("<d")
            (self.p,) = struct_p.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i = struct.Struct("<d")
            (self.i,) = struct_i.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_d = struct.Struct("<d")
            (self.d,) = struct_d.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_i_clamp = struct.Struct("<d")
            (self.i_clamp,) = struct_i_clamp.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_antiwindup = struct.Struct("<B")
            (self.antiwindup,) = struct_antiwindup.unpack(buff[offset:(offset + 1)])
            self.antiwindup = bool(self.antiwindup)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 8
        length += 8
        length += 8
        length += 8
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"p":%s' % self.p
        string_echo += ','
        string_echo += '"i":%s' % self.i
        string_echo += ','
        string_echo += '"d":%s' % self.d
        string_echo += ','
        string_echo += '"i_clamp":%s' % self.i_clamp
        string_echo += ','
        string_echo += '"antiwindup":%s' % self.antiwindup
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_toolbox/SetPidGains"

    def getMD5(self):
        return "4a43159879643e60937bf2893b633607"
    def getDef(self):
        return "float64 p\nfloat64 i\nfloat64 d\nfloat64 i_clamp\nbool antiwindup\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetPidGainsResponse(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetPidGainsResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "control_toolbox/SetPidGains"

    def getMD5(self):
        return "4a43159879643e60937bf2893b633607"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class SetPidGains(object):
    Request = SetPidGainsRequest
    Response = SetPidGainsResponse

    __slots__ = ['request','response']
    _slot_types = ['SetPidGainsRequest','SetPidGainsResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(SetPidGains, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

