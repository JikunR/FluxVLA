import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.livox_ros_driver2.msg
import mros.std_msgs.msg

class CustomMsg(mros.Message):
    __slots__ = ['header','timebase','point_num','lidar_id','rsvd','points']
    _slot_types = ['std_msgs/Header','uint64','uint32','uint8','uint8[3]','livox_ros_driver2/CustomPoint[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(CustomMsg, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.timebase is None:
                self.timebase = 0
            if self.point_num is None:
                self.point_num = 0
            if self.lidar_id is None:
                self.lidar_id = 0
            if self.rsvd is None:
                self.rsvd = chr(0)*3
            if self.points is None:
                self.points = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.timebase = 0
            self.point_num = 0
            self.lidar_id = 0
            self.rsvd = chr(0)*3
            self.points = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_timebase = struct.Struct("<Q")
            buff.write(struct_timebase.pack(self.timebase))
            offset += 8
            buff.write(_struct_I.pack(self.point_num))
            offset += 4
            struct_lidar_id = struct.Struct("<B")
            buff.write(struct_lidar_id.pack(self.lidar_id))
            offset += 1
            buff.write(struct.pack(f'<{3}B', *self.rsvd))
            offset += 3
            points_length = len(self.points)
            buff.write(struct.pack('<I', points_length))
            offset += 4
            for i in range(0, points_length):
                offset += self.points[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_timebase = struct.Struct("<Q")
            (self.timebase,) = struct_timebase.unpack(buff[offset:(offset + 8)])
            offset += 8
            (self.point_num,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_lidar_id = struct.Struct("<B")
            (self.lidar_id,) = struct_lidar_id.unpack(buff[offset:(offset + 1)])
            offset += 1
            self.rsvd = np.frombuffer(buff[offset:offset + 3], dtype=np.uint8)
            offset += 3
            (points_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.points) != points_length:
                self.points = [mros.livox_ros_driver2.msg.CustomPoint() for _ in range(points_length)]
            for i in range(0, points_length):
                offset += self.points[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 4
        length += 1
        length += 3
        length += 4
        for i in range(0, points_length):
            length += self.points[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"timebase":%s' % self.timebase
        string_echo += ','
        string_echo += '"point_num":%s' % self.point_num
        string_echo += ','
        string_echo += '"lidar_id":%s' % self.lidar_id
        string_echo += ','
        string_echo += '"rsvd":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.rsvd[i]
            else:
                string_echo += '%s,' % self.rsvd[i]
        string_echo += '],'
        string_echo += '"points":['
        points_length = len(self.points)
        for i in range(0, points_length):
            if i == (points_length - 1): 
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ''
            else:
                string_echo += '{points%s":' % i
                string_echo += self.points[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "livox_ros_driver2/CustomMsg"

    def getMD5(self):
        return "e4d6829bdfe657cb6c21a746c86b21a6"

    def getDef(self):
        return "std_msgs/Header header\nuint64 timebase\nuint32 point_num\nuint8 lidar_id\nuint8[3] rsvd\nlivox_ros_driver2/CustomPoint[] points\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: livox_ros_driver2/CustomPoint\nuint32 offset_time\nfloat32 x\nfloat32 y\nfloat32 z\nuint8 reflectivity\nuint8 tag\nuint8 line\n"

_struct_I = struct.Struct('<I')

