import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterStatusGx5StatusFlags(mros.Message):
    __slots__ = ['init_no_attitude','init_no_position_velocity','run_imu_unavailable','run_gps_unavailable','run_matrix_singularity','run_position_covariance_warning','run_velocity_covariance_warning','run_attitude_covariance_warning','run_nan_in_solution_warning','run_gyro_bias_est_high_warning','run_accel_bias_est_high_warning','run_gyro_scale_factor_est_high_warning','run_accel_scale_factor_est_high_warning','run_mag_bias_est_high_warning','run_ant_offset_correction_est_high_warning','run_mag_hard_iron_est_high_warning','run_mag_soft_iron_est_high_warning']
    _slot_types = ['bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterStatusGx5StatusFlags, self).__init__(*args, **kwds)
            if self.init_no_attitude is None:
                self.init_no_attitude = False
            if self.init_no_position_velocity is None:
                self.init_no_position_velocity = False
            if self.run_imu_unavailable is None:
                self.run_imu_unavailable = False
            if self.run_gps_unavailable is None:
                self.run_gps_unavailable = False
            if self.run_matrix_singularity is None:
                self.run_matrix_singularity = False
            if self.run_position_covariance_warning is None:
                self.run_position_covariance_warning = False
            if self.run_velocity_covariance_warning is None:
                self.run_velocity_covariance_warning = False
            if self.run_attitude_covariance_warning is None:
                self.run_attitude_covariance_warning = False
            if self.run_nan_in_solution_warning is None:
                self.run_nan_in_solution_warning = False
            if self.run_gyro_bias_est_high_warning is None:
                self.run_gyro_bias_est_high_warning = False
            if self.run_accel_bias_est_high_warning is None:
                self.run_accel_bias_est_high_warning = False
            if self.run_gyro_scale_factor_est_high_warning is None:
                self.run_gyro_scale_factor_est_high_warning = False
            if self.run_accel_scale_factor_est_high_warning is None:
                self.run_accel_scale_factor_est_high_warning = False
            if self.run_mag_bias_est_high_warning is None:
                self.run_mag_bias_est_high_warning = False
            if self.run_ant_offset_correction_est_high_warning is None:
                self.run_ant_offset_correction_est_high_warning = False
            if self.run_mag_hard_iron_est_high_warning is None:
                self.run_mag_hard_iron_est_high_warning = False
            if self.run_mag_soft_iron_est_high_warning is None:
                self.run_mag_soft_iron_est_high_warning = False
        else:
            self.init_no_attitude = False
            self.init_no_position_velocity = False
            self.run_imu_unavailable = False
            self.run_gps_unavailable = False
            self.run_matrix_singularity = False
            self.run_position_covariance_warning = False
            self.run_velocity_covariance_warning = False
            self.run_attitude_covariance_warning = False
            self.run_nan_in_solution_warning = False
            self.run_gyro_bias_est_high_warning = False
            self.run_accel_bias_est_high_warning = False
            self.run_gyro_scale_factor_est_high_warning = False
            self.run_accel_scale_factor_est_high_warning = False
            self.run_mag_bias_est_high_warning = False
            self.run_ant_offset_correction_est_high_warning = False
            self.run_mag_hard_iron_est_high_warning = False
            self.run_mag_soft_iron_est_high_warning = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_init_no_attitude = struct.Struct("<B")
            buff.write(struct_init_no_attitude.pack(self.init_no_attitude))
            offset += 1
            struct_init_no_position_velocity = struct.Struct("<B")
            buff.write(struct_init_no_position_velocity.pack(self.init_no_position_velocity))
            offset += 1
            struct_run_imu_unavailable = struct.Struct("<B")
            buff.write(struct_run_imu_unavailable.pack(self.run_imu_unavailable))
            offset += 1
            struct_run_gps_unavailable = struct.Struct("<B")
            buff.write(struct_run_gps_unavailable.pack(self.run_gps_unavailable))
            offset += 1
            struct_run_matrix_singularity = struct.Struct("<B")
            buff.write(struct_run_matrix_singularity.pack(self.run_matrix_singularity))
            offset += 1
            struct_run_position_covariance_warning = struct.Struct("<B")
            buff.write(struct_run_position_covariance_warning.pack(self.run_position_covariance_warning))
            offset += 1
            struct_run_velocity_covariance_warning = struct.Struct("<B")
            buff.write(struct_run_velocity_covariance_warning.pack(self.run_velocity_covariance_warning))
            offset += 1
            struct_run_attitude_covariance_warning = struct.Struct("<B")
            buff.write(struct_run_attitude_covariance_warning.pack(self.run_attitude_covariance_warning))
            offset += 1
            struct_run_nan_in_solution_warning = struct.Struct("<B")
            buff.write(struct_run_nan_in_solution_warning.pack(self.run_nan_in_solution_warning))
            offset += 1
            struct_run_gyro_bias_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_gyro_bias_est_high_warning.pack(self.run_gyro_bias_est_high_warning))
            offset += 1
            struct_run_accel_bias_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_accel_bias_est_high_warning.pack(self.run_accel_bias_est_high_warning))
            offset += 1
            struct_run_gyro_scale_factor_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_gyro_scale_factor_est_high_warning.pack(self.run_gyro_scale_factor_est_high_warning))
            offset += 1
            struct_run_accel_scale_factor_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_accel_scale_factor_est_high_warning.pack(self.run_accel_scale_factor_est_high_warning))
            offset += 1
            struct_run_mag_bias_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_mag_bias_est_high_warning.pack(self.run_mag_bias_est_high_warning))
            offset += 1
            struct_run_ant_offset_correction_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_ant_offset_correction_est_high_warning.pack(self.run_ant_offset_correction_est_high_warning))
            offset += 1
            struct_run_mag_hard_iron_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_mag_hard_iron_est_high_warning.pack(self.run_mag_hard_iron_est_high_warning))
            offset += 1
            struct_run_mag_soft_iron_est_high_warning = struct.Struct("<B")
            buff.write(struct_run_mag_soft_iron_est_high_warning.pack(self.run_mag_soft_iron_est_high_warning))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_init_no_attitude = struct.Struct("<B")
            (self.init_no_attitude,) = struct_init_no_attitude.unpack(buff[offset:(offset + 1)])
            self.init_no_attitude = bool(self.init_no_attitude)
            offset += 1
            struct_init_no_position_velocity = struct.Struct("<B")
            (self.init_no_position_velocity,) = struct_init_no_position_velocity.unpack(buff[offset:(offset + 1)])
            self.init_no_position_velocity = bool(self.init_no_position_velocity)
            offset += 1
            struct_run_imu_unavailable = struct.Struct("<B")
            (self.run_imu_unavailable,) = struct_run_imu_unavailable.unpack(buff[offset:(offset + 1)])
            self.run_imu_unavailable = bool(self.run_imu_unavailable)
            offset += 1
            struct_run_gps_unavailable = struct.Struct("<B")
            (self.run_gps_unavailable,) = struct_run_gps_unavailable.unpack(buff[offset:(offset + 1)])
            self.run_gps_unavailable = bool(self.run_gps_unavailable)
            offset += 1
            struct_run_matrix_singularity = struct.Struct("<B")
            (self.run_matrix_singularity,) = struct_run_matrix_singularity.unpack(buff[offset:(offset + 1)])
            self.run_matrix_singularity = bool(self.run_matrix_singularity)
            offset += 1
            struct_run_position_covariance_warning = struct.Struct("<B")
            (self.run_position_covariance_warning,) = struct_run_position_covariance_warning.unpack(buff[offset:(offset + 1)])
            self.run_position_covariance_warning = bool(self.run_position_covariance_warning)
            offset += 1
            struct_run_velocity_covariance_warning = struct.Struct("<B")
            (self.run_velocity_covariance_warning,) = struct_run_velocity_covariance_warning.unpack(buff[offset:(offset + 1)])
            self.run_velocity_covariance_warning = bool(self.run_velocity_covariance_warning)
            offset += 1
            struct_run_attitude_covariance_warning = struct.Struct("<B")
            (self.run_attitude_covariance_warning,) = struct_run_attitude_covariance_warning.unpack(buff[offset:(offset + 1)])
            self.run_attitude_covariance_warning = bool(self.run_attitude_covariance_warning)
            offset += 1
            struct_run_nan_in_solution_warning = struct.Struct("<B")
            (self.run_nan_in_solution_warning,) = struct_run_nan_in_solution_warning.unpack(buff[offset:(offset + 1)])
            self.run_nan_in_solution_warning = bool(self.run_nan_in_solution_warning)
            offset += 1
            struct_run_gyro_bias_est_high_warning = struct.Struct("<B")
            (self.run_gyro_bias_est_high_warning,) = struct_run_gyro_bias_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_gyro_bias_est_high_warning = bool(self.run_gyro_bias_est_high_warning)
            offset += 1
            struct_run_accel_bias_est_high_warning = struct.Struct("<B")
            (self.run_accel_bias_est_high_warning,) = struct_run_accel_bias_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_accel_bias_est_high_warning = bool(self.run_accel_bias_est_high_warning)
            offset += 1
            struct_run_gyro_scale_factor_est_high_warning = struct.Struct("<B")
            (self.run_gyro_scale_factor_est_high_warning,) = struct_run_gyro_scale_factor_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_gyro_scale_factor_est_high_warning = bool(self.run_gyro_scale_factor_est_high_warning)
            offset += 1
            struct_run_accel_scale_factor_est_high_warning = struct.Struct("<B")
            (self.run_accel_scale_factor_est_high_warning,) = struct_run_accel_scale_factor_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_accel_scale_factor_est_high_warning = bool(self.run_accel_scale_factor_est_high_warning)
            offset += 1
            struct_run_mag_bias_est_high_warning = struct.Struct("<B")
            (self.run_mag_bias_est_high_warning,) = struct_run_mag_bias_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_mag_bias_est_high_warning = bool(self.run_mag_bias_est_high_warning)
            offset += 1
            struct_run_ant_offset_correction_est_high_warning = struct.Struct("<B")
            (self.run_ant_offset_correction_est_high_warning,) = struct_run_ant_offset_correction_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_ant_offset_correction_est_high_warning = bool(self.run_ant_offset_correction_est_high_warning)
            offset += 1
            struct_run_mag_hard_iron_est_high_warning = struct.Struct("<B")
            (self.run_mag_hard_iron_est_high_warning,) = struct_run_mag_hard_iron_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_mag_hard_iron_est_high_warning = bool(self.run_mag_hard_iron_est_high_warning)
            offset += 1
            struct_run_mag_soft_iron_est_high_warning = struct.Struct("<B")
            (self.run_mag_soft_iron_est_high_warning,) = struct_run_mag_soft_iron_est_high_warning.unpack(buff[offset:(offset + 1)])
            self.run_mag_soft_iron_est_high_warning = bool(self.run_mag_soft_iron_est_high_warning)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"init_no_attitude":%s' % self.init_no_attitude
        string_echo += ','
        string_echo += '"init_no_position_velocity":%s' % self.init_no_position_velocity
        string_echo += ','
        string_echo += '"run_imu_unavailable":%s' % self.run_imu_unavailable
        string_echo += ','
        string_echo += '"run_gps_unavailable":%s' % self.run_gps_unavailable
        string_echo += ','
        string_echo += '"run_matrix_singularity":%s' % self.run_matrix_singularity
        string_echo += ','
        string_echo += '"run_position_covariance_warning":%s' % self.run_position_covariance_warning
        string_echo += ','
        string_echo += '"run_velocity_covariance_warning":%s' % self.run_velocity_covariance_warning
        string_echo += ','
        string_echo += '"run_attitude_covariance_warning":%s' % self.run_attitude_covariance_warning
        string_echo += ','
        string_echo += '"run_nan_in_solution_warning":%s' % self.run_nan_in_solution_warning
        string_echo += ','
        string_echo += '"run_gyro_bias_est_high_warning":%s' % self.run_gyro_bias_est_high_warning
        string_echo += ','
        string_echo += '"run_accel_bias_est_high_warning":%s' % self.run_accel_bias_est_high_warning
        string_echo += ','
        string_echo += '"run_gyro_scale_factor_est_high_warning":%s' % self.run_gyro_scale_factor_est_high_warning
        string_echo += ','
        string_echo += '"run_accel_scale_factor_est_high_warning":%s' % self.run_accel_scale_factor_est_high_warning
        string_echo += ','
        string_echo += '"run_mag_bias_est_high_warning":%s' % self.run_mag_bias_est_high_warning
        string_echo += ','
        string_echo += '"run_ant_offset_correction_est_high_warning":%s' % self.run_ant_offset_correction_est_high_warning
        string_echo += ','
        string_echo += '"run_mag_hard_iron_est_high_warning":%s' % self.run_mag_hard_iron_est_high_warning
        string_echo += ','
        string_echo += '"run_mag_soft_iron_est_high_warning":%s' % self.run_mag_soft_iron_est_high_warning
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterStatusGx5StatusFlags"

    def getMD5(self):
        return "82e4f81fef282c1265a9db8f5c2b8418"

    def getDef(self):
        return "bool init_no_attitude\nbool init_no_position_velocity\nbool run_imu_unavailable\nbool run_gps_unavailable\nbool run_matrix_singularity\nbool run_position_covariance_warning\nbool run_velocity_covariance_warning\nbool run_attitude_covariance_warning\nbool run_nan_in_solution_warning\nbool run_gyro_bias_est_high_warning\nbool run_accel_bias_est_high_warning\nbool run_gyro_scale_factor_est_high_warning\nbool run_accel_scale_factor_est_high_warning\nbool run_mag_bias_est_high_warning\nbool run_ant_offset_correction_est_high_warning\nbool run_mag_hard_iron_est_high_warning\nbool run_mag_soft_iron_est_high_warning\n"

_struct_I = struct.Struct('<I')

