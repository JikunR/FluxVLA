import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssCorrectionsRtkCorrectionsStatusEpochStatus(mros.Message):
    __slots__ = ['antenna_location_received','antenna_description_received','gps_received','galileo_received','glonass_received','beidou_received','using_gps_msm_messages','using_glonass_msm_messages','dongle_status_read_failed']
    _slot_types = ['bool','bool','bool','bool','bool','bool','bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssCorrectionsRtkCorrectionsStatusEpochStatus, self).__init__(*args, **kwds)
            if self.antenna_location_received is None:
                self.antenna_location_received = False
            if self.antenna_description_received is None:
                self.antenna_description_received = False
            if self.gps_received is None:
                self.gps_received = False
            if self.galileo_received is None:
                self.galileo_received = False
            if self.glonass_received is None:
                self.glonass_received = False
            if self.beidou_received is None:
                self.beidou_received = False
            if self.using_gps_msm_messages is None:
                self.using_gps_msm_messages = False
            if self.using_glonass_msm_messages is None:
                self.using_glonass_msm_messages = False
            if self.dongle_status_read_failed is None:
                self.dongle_status_read_failed = False
        else:
            self.antenna_location_received = False
            self.antenna_description_received = False
            self.gps_received = False
            self.galileo_received = False
            self.glonass_received = False
            self.beidou_received = False
            self.using_gps_msm_messages = False
            self.using_glonass_msm_messages = False
            self.dongle_status_read_failed = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_antenna_location_received = struct.Struct("<B")
            buff.write(struct_antenna_location_received.pack(self.antenna_location_received))
            offset += 1
            struct_antenna_description_received = struct.Struct("<B")
            buff.write(struct_antenna_description_received.pack(self.antenna_description_received))
            offset += 1
            struct_gps_received = struct.Struct("<B")
            buff.write(struct_gps_received.pack(self.gps_received))
            offset += 1
            struct_galileo_received = struct.Struct("<B")
            buff.write(struct_galileo_received.pack(self.galileo_received))
            offset += 1
            struct_glonass_received = struct.Struct("<B")
            buff.write(struct_glonass_received.pack(self.glonass_received))
            offset += 1
            struct_beidou_received = struct.Struct("<B")
            buff.write(struct_beidou_received.pack(self.beidou_received))
            offset += 1
            struct_using_gps_msm_messages = struct.Struct("<B")
            buff.write(struct_using_gps_msm_messages.pack(self.using_gps_msm_messages))
            offset += 1
            struct_using_glonass_msm_messages = struct.Struct("<B")
            buff.write(struct_using_glonass_msm_messages.pack(self.using_glonass_msm_messages))
            offset += 1
            struct_dongle_status_read_failed = struct.Struct("<B")
            buff.write(struct_dongle_status_read_failed.pack(self.dongle_status_read_failed))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_antenna_location_received = struct.Struct("<B")
            (self.antenna_location_received,) = struct_antenna_location_received.unpack(buff[offset:(offset + 1)])
            self.antenna_location_received = bool(self.antenna_location_received)
            offset += 1
            struct_antenna_description_received = struct.Struct("<B")
            (self.antenna_description_received,) = struct_antenna_description_received.unpack(buff[offset:(offset + 1)])
            self.antenna_description_received = bool(self.antenna_description_received)
            offset += 1
            struct_gps_received = struct.Struct("<B")
            (self.gps_received,) = struct_gps_received.unpack(buff[offset:(offset + 1)])
            self.gps_received = bool(self.gps_received)
            offset += 1
            struct_galileo_received = struct.Struct("<B")
            (self.galileo_received,) = struct_galileo_received.unpack(buff[offset:(offset + 1)])
            self.galileo_received = bool(self.galileo_received)
            offset += 1
            struct_glonass_received = struct.Struct("<B")
            (self.glonass_received,) = struct_glonass_received.unpack(buff[offset:(offset + 1)])
            self.glonass_received = bool(self.glonass_received)
            offset += 1
            struct_beidou_received = struct.Struct("<B")
            (self.beidou_received,) = struct_beidou_received.unpack(buff[offset:(offset + 1)])
            self.beidou_received = bool(self.beidou_received)
            offset += 1
            struct_using_gps_msm_messages = struct.Struct("<B")
            (self.using_gps_msm_messages,) = struct_using_gps_msm_messages.unpack(buff[offset:(offset + 1)])
            self.using_gps_msm_messages = bool(self.using_gps_msm_messages)
            offset += 1
            struct_using_glonass_msm_messages = struct.Struct("<B")
            (self.using_glonass_msm_messages,) = struct_using_glonass_msm_messages.unpack(buff[offset:(offset + 1)])
            self.using_glonass_msm_messages = bool(self.using_glonass_msm_messages)
            offset += 1
            struct_dongle_status_read_failed = struct.Struct("<B")
            (self.dongle_status_read_failed,) = struct_dongle_status_read_failed.unpack(buff[offset:(offset + 1)])
            self.dongle_status_read_failed = bool(self.dongle_status_read_failed)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"antenna_location_received":%s' % self.antenna_location_received
        string_echo += ','
        string_echo += '"antenna_description_received":%s' % self.antenna_description_received
        string_echo += ','
        string_echo += '"gps_received":%s' % self.gps_received
        string_echo += ','
        string_echo += '"galileo_received":%s' % self.galileo_received
        string_echo += ','
        string_echo += '"glonass_received":%s' % self.glonass_received
        string_echo += ','
        string_echo += '"beidou_received":%s' % self.beidou_received
        string_echo += ','
        string_echo += '"using_gps_msm_messages":%s' % self.using_gps_msm_messages
        string_echo += ','
        string_echo += '"using_glonass_msm_messages":%s' % self.using_glonass_msm_messages
        string_echo += ','
        string_echo += '"dongle_status_read_failed":%s' % self.dongle_status_read_failed
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusEpochStatus"

    def getMD5(self):
        return "88d715db92e6df1db097b1ff798927c2"

    def getDef(self):
        return "bool antenna_location_received\nbool antenna_description_received\nbool gps_received\nbool galileo_received\nbool glonass_received\nbool beidou_received\nbool using_gps_msm_messages\nbool using_glonass_msm_messages\nbool dongle_status_read_failed\n"

_struct_I = struct.Struct('<I')

