import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssCorrectionsRtkCorrectionsStatusDongleStatus(mros.Message):
    __slots__ = ['modem_state','connection_type','rssi','signal_quality','tower_change_indicator','nmea_timeout_flag','server_timeout_flag','rtcm_timeout_flag','device_out_of_range_flag','corrections_unavailable_flag']
    _slot_types = ['uint8','uint8','int8','uint8','uint8','bool','bool','bool','bool','bool']

    MODEM_STATE_OFF =  0
    MODEM_STATE_NO_NETWORK =  1
    MODEM_STATE_NETWORK_CONNECTED =  2
    MODEM_STATE_CONFIGURING_DATA_CONTEXT =  3
    MODEM_STATE_ACTIVATING_DATA_CONTEXT =  4
    MODEM_STATE_CONFIGURING_SOCKET =  5
    MODEM_STATE_WAITING_ON_SERVER_HANDSHAKE =  6
    MODEM_STATE_CONNECTED_AND_IDLE =  7
    MODEM_STATE_CONNECTED_AND_STREAMING =  8
    CONNECTION_TYPE_NO_CONNECTION =  0
    CONNECTION_TYPE_CONNECTION_2G =  2
    CONNECTION_TYPE_CONNECTION_3G =  3
    CONNECTION_TYPE_CONNECTION_4G =  4
    CONNECTION_TYPE_CONNECTION_5G =  5

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssCorrectionsRtkCorrectionsStatusDongleStatus, self).__init__(*args, **kwds)
            if self.modem_state is None:
                self.modem_state = 0
            if self.connection_type is None:
                self.connection_type = 0
            if self.rssi is None:
                self.rssi = 0
            if self.signal_quality is None:
                self.signal_quality = 0
            if self.tower_change_indicator is None:
                self.tower_change_indicator = 0
            if self.nmea_timeout_flag is None:
                self.nmea_timeout_flag = False
            if self.server_timeout_flag is None:
                self.server_timeout_flag = False
            if self.rtcm_timeout_flag is None:
                self.rtcm_timeout_flag = False
            if self.device_out_of_range_flag is None:
                self.device_out_of_range_flag = False
            if self.corrections_unavailable_flag is None:
                self.corrections_unavailable_flag = False
        else:
            self.modem_state = 0
            self.connection_type = 0
            self.rssi = 0
            self.signal_quality = 0
            self.tower_change_indicator = 0
            self.nmea_timeout_flag = False
            self.server_timeout_flag = False
            self.rtcm_timeout_flag = False
            self.device_out_of_range_flag = False
            self.corrections_unavailable_flag = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_modem_state = struct.Struct("<B")
            buff.write(struct_modem_state.pack(self.modem_state))
            offset += 1
            struct_connection_type = struct.Struct("<B")
            buff.write(struct_connection_type.pack(self.connection_type))
            offset += 1
            struct_rssi = struct.Struct("<b")
            buff.write(struct_rssi.pack(self.rssi))
            offset += 1
            struct_signal_quality = struct.Struct("<B")
            buff.write(struct_signal_quality.pack(self.signal_quality))
            offset += 1
            struct_tower_change_indicator = struct.Struct("<B")
            buff.write(struct_tower_change_indicator.pack(self.tower_change_indicator))
            offset += 1
            struct_nmea_timeout_flag = struct.Struct("<B")
            buff.write(struct_nmea_timeout_flag.pack(self.nmea_timeout_flag))
            offset += 1
            struct_server_timeout_flag = struct.Struct("<B")
            buff.write(struct_server_timeout_flag.pack(self.server_timeout_flag))
            offset += 1
            struct_rtcm_timeout_flag = struct.Struct("<B")
            buff.write(struct_rtcm_timeout_flag.pack(self.rtcm_timeout_flag))
            offset += 1
            struct_device_out_of_range_flag = struct.Struct("<B")
            buff.write(struct_device_out_of_range_flag.pack(self.device_out_of_range_flag))
            offset += 1
            struct_corrections_unavailable_flag = struct.Struct("<B")
            buff.write(struct_corrections_unavailable_flag.pack(self.corrections_unavailable_flag))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_modem_state = struct.Struct("<B")
            (self.modem_state,) = struct_modem_state.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_connection_type = struct.Struct("<B")
            (self.connection_type,) = struct_connection_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_rssi = struct.Struct("<b")
            (self.rssi,) = struct_rssi.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_signal_quality = struct.Struct("<B")
            (self.signal_quality,) = struct_signal_quality.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_tower_change_indicator = struct.Struct("<B")
            (self.tower_change_indicator,) = struct_tower_change_indicator.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_nmea_timeout_flag = struct.Struct("<B")
            (self.nmea_timeout_flag,) = struct_nmea_timeout_flag.unpack(buff[offset:(offset + 1)])
            self.nmea_timeout_flag = bool(self.nmea_timeout_flag)
            offset += 1
            struct_server_timeout_flag = struct.Struct("<B")
            (self.server_timeout_flag,) = struct_server_timeout_flag.unpack(buff[offset:(offset + 1)])
            self.server_timeout_flag = bool(self.server_timeout_flag)
            offset += 1
            struct_rtcm_timeout_flag = struct.Struct("<B")
            (self.rtcm_timeout_flag,) = struct_rtcm_timeout_flag.unpack(buff[offset:(offset + 1)])
            self.rtcm_timeout_flag = bool(self.rtcm_timeout_flag)
            offset += 1
            struct_device_out_of_range_flag = struct.Struct("<B")
            (self.device_out_of_range_flag,) = struct_device_out_of_range_flag.unpack(buff[offset:(offset + 1)])
            self.device_out_of_range_flag = bool(self.device_out_of_range_flag)
            offset += 1
            struct_corrections_unavailable_flag = struct.Struct("<B")
            (self.corrections_unavailable_flag,) = struct_corrections_unavailable_flag.unpack(buff[offset:(offset + 1)])
            self.corrections_unavailable_flag = bool(self.corrections_unavailable_flag)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"modem_state":%s' % self.modem_state
        string_echo += ','
        string_echo += '"connection_type":%s' % self.connection_type
        string_echo += ','
        string_echo += '"rssi":%s' % self.rssi
        string_echo += ','
        string_echo += '"signal_quality":%s' % self.signal_quality
        string_echo += ','
        string_echo += '"tower_change_indicator":%s' % self.tower_change_indicator
        string_echo += ','
        string_echo += '"nmea_timeout_flag":%s' % self.nmea_timeout_flag
        string_echo += ','
        string_echo += '"server_timeout_flag":%s' % self.server_timeout_flag
        string_echo += ','
        string_echo += '"rtcm_timeout_flag":%s' % self.rtcm_timeout_flag
        string_echo += ','
        string_echo += '"device_out_of_range_flag":%s' % self.device_out_of_range_flag
        string_echo += ','
        string_echo += '"corrections_unavailable_flag":%s' % self.corrections_unavailable_flag
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusDongleStatus"

    def getMD5(self):
        return "c6b32ecff25b8d73f86e7e5db3fce5f8"

    def getDef(self):
        return "uint8 modem_state\nuint8 connection_type\nint8 rssi\nuint8 signal_quality\nuint8 tower_change_indicator\nbool nmea_timeout_flag\nbool server_timeout_flag\nbool rtcm_timeout_flag\nbool device_out_of_range_flag\nbool corrections_unavailable_flag\nuint8 MODEM_STATE_OFF = 0\nuint8 MODEM_STATE_NO_NETWORK = 1\nuint8 MODEM_STATE_NETWORK_CONNECTED = 2\nuint8 MODEM_STATE_CONFIGURING_DATA_CONTEXT = 3\nuint8 MODEM_STATE_ACTIVATING_DATA_CONTEXT = 4\nuint8 MODEM_STATE_CONFIGURING_SOCKET = 5\nuint8 MODEM_STATE_WAITING_ON_SERVER_HANDSHAKE = 6\nuint8 MODEM_STATE_CONNECTED_AND_IDLE = 7\nuint8 MODEM_STATE_CONNECTED_AND_STREAMING = 8\nuint8 CONNECTION_TYPE_NO_CONNECTION = 0\nuint8 CONNECTION_TYPE_CONNECTION_2G = 2\nuint8 CONNECTION_TYPE_CONNECTION_3G = 3\nuint8 CONNECTION_TYPE_CONNECTION_4G = 4\nuint8 CONNECTION_TYPE_CONNECTION_5G = 5\n"

_struct_I = struct.Struct('<I')

