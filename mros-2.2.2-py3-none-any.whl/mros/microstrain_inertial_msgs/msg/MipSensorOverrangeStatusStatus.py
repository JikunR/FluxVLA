import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipSensorOverrangeStatusStatus(mros.Message):
    __slots__ = ['accel_x','accel_y','accel_z','gyro_x','gyro_y','gyro_z','mag_x','mag_y','mag_z','press']
    _slot_types = ['bool','bool','bool','bool','bool','bool','bool','bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipSensorOverrangeStatusStatus, self).__init__(*args, **kwds)
            if self.accel_x is None:
                self.accel_x = False
            if self.accel_y is None:
                self.accel_y = False
            if self.accel_z is None:
                self.accel_z = False
            if self.gyro_x is None:
                self.gyro_x = False
            if self.gyro_y is None:
                self.gyro_y = False
            if self.gyro_z is None:
                self.gyro_z = False
            if self.mag_x is None:
                self.mag_x = False
            if self.mag_y is None:
                self.mag_y = False
            if self.mag_z is None:
                self.mag_z = False
            if self.press is None:
                self.press = False
        else:
            self.accel_x = False
            self.accel_y = False
            self.accel_z = False
            self.gyro_x = False
            self.gyro_y = False
            self.gyro_z = False
            self.mag_x = False
            self.mag_y = False
            self.mag_z = False
            self.press = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_accel_x = struct.Struct("<B")
            buff.write(struct_accel_x.pack(self.accel_x))
            offset += 1
            struct_accel_y = struct.Struct("<B")
            buff.write(struct_accel_y.pack(self.accel_y))
            offset += 1
            struct_accel_z = struct.Struct("<B")
            buff.write(struct_accel_z.pack(self.accel_z))
            offset += 1
            struct_gyro_x = struct.Struct("<B")
            buff.write(struct_gyro_x.pack(self.gyro_x))
            offset += 1
            struct_gyro_y = struct.Struct("<B")
            buff.write(struct_gyro_y.pack(self.gyro_y))
            offset += 1
            struct_gyro_z = struct.Struct("<B")
            buff.write(struct_gyro_z.pack(self.gyro_z))
            offset += 1
            struct_mag_x = struct.Struct("<B")
            buff.write(struct_mag_x.pack(self.mag_x))
            offset += 1
            struct_mag_y = struct.Struct("<B")
            buff.write(struct_mag_y.pack(self.mag_y))
            offset += 1
            struct_mag_z = struct.Struct("<B")
            buff.write(struct_mag_z.pack(self.mag_z))
            offset += 1
            struct_press = struct.Struct("<B")
            buff.write(struct_press.pack(self.press))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_accel_x = struct.Struct("<B")
            (self.accel_x,) = struct_accel_x.unpack(buff[offset:(offset + 1)])
            self.accel_x = bool(self.accel_x)
            offset += 1
            struct_accel_y = struct.Struct("<B")
            (self.accel_y,) = struct_accel_y.unpack(buff[offset:(offset + 1)])
            self.accel_y = bool(self.accel_y)
            offset += 1
            struct_accel_z = struct.Struct("<B")
            (self.accel_z,) = struct_accel_z.unpack(buff[offset:(offset + 1)])
            self.accel_z = bool(self.accel_z)
            offset += 1
            struct_gyro_x = struct.Struct("<B")
            (self.gyro_x,) = struct_gyro_x.unpack(buff[offset:(offset + 1)])
            self.gyro_x = bool(self.gyro_x)
            offset += 1
            struct_gyro_y = struct.Struct("<B")
            (self.gyro_y,) = struct_gyro_y.unpack(buff[offset:(offset + 1)])
            self.gyro_y = bool(self.gyro_y)
            offset += 1
            struct_gyro_z = struct.Struct("<B")
            (self.gyro_z,) = struct_gyro_z.unpack(buff[offset:(offset + 1)])
            self.gyro_z = bool(self.gyro_z)
            offset += 1
            struct_mag_x = struct.Struct("<B")
            (self.mag_x,) = struct_mag_x.unpack(buff[offset:(offset + 1)])
            self.mag_x = bool(self.mag_x)
            offset += 1
            struct_mag_y = struct.Struct("<B")
            (self.mag_y,) = struct_mag_y.unpack(buff[offset:(offset + 1)])
            self.mag_y = bool(self.mag_y)
            offset += 1
            struct_mag_z = struct.Struct("<B")
            (self.mag_z,) = struct_mag_z.unpack(buff[offset:(offset + 1)])
            self.mag_z = bool(self.mag_z)
            offset += 1
            struct_press = struct.Struct("<B")
            (self.press,) = struct_press.unpack(buff[offset:(offset + 1)])
            self.press = bool(self.press)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"accel_x":%s' % self.accel_x
        string_echo += ','
        string_echo += '"accel_y":%s' % self.accel_y
        string_echo += ','
        string_echo += '"accel_z":%s' % self.accel_z
        string_echo += ','
        string_echo += '"gyro_x":%s' % self.gyro_x
        string_echo += ','
        string_echo += '"gyro_y":%s' % self.gyro_y
        string_echo += ','
        string_echo += '"gyro_z":%s' % self.gyro_z
        string_echo += ','
        string_echo += '"mag_x":%s' % self.mag_x
        string_echo += ','
        string_echo += '"mag_y":%s' % self.mag_y
        string_echo += ','
        string_echo += '"mag_z":%s' % self.mag_z
        string_echo += ','
        string_echo += '"press":%s' % self.press
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipSensorOverrangeStatusStatus"

    def getMD5(self):
        return "0b343e6367e45b73c841c8255a4cfbba"

    def getDef(self):
        return "bool accel_x\nbool accel_y\nbool accel_z\nbool gyro_x\nbool gyro_y\nbool gyro_z\nbool mag_x\nbool mag_y\nbool mag_z\nbool press\n"

_struct_I = struct.Struct('<I')

