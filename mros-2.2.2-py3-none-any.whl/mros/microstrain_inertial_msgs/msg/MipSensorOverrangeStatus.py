import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipSensorOverrangeStatus(mros.Message):
    __slots__ = ['header','status']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','microstrain_inertial_msgs/MipSensorOverrangeStatusStatus']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipSensorOverrangeStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.status is None:
                self.status = mros.microstrain_inertial_msgs.msg.MipSensorOverrangeStatusStatus()
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.status = mros.microstrain_inertial_msgs.msg.MipSensorOverrangeStatusStatus()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            offset += self.status.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            offset += self.status.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.status.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipSensorOverrangeStatus"

    def getMD5(self):
        return "e4b3393a8089b6d038d3663ca732b3c4"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nmicrostrain_inertial_msgs/MipSensorOverrangeStatusStatus status\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipSensorOverrangeStatusStatus\nbool accel_x\nbool accel_y\nbool accel_z\nbool gyro_x\nbool gyro_y\nbool gyro_z\nbool mag_x\nbool mag_y\nbool mag_z\nbool press\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

