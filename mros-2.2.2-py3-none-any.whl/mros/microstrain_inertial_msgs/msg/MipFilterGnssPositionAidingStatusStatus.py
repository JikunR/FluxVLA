import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterGnssPositionAidingStatusStatus(mros.Message):
    __slots__ = ['tight_coupling','differential','integer_fix','gps_l1','gps_l2','gps_l5','glo_l1','glo_l2','gal_e1','gal_e5','gal_e6','bei_b1','bei_b2','bei_b3','no_fix','config_error']
    _slot_types = ['bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterGnssPositionAidingStatusStatus, self).__init__(*args, **kwds)
            if self.tight_coupling is None:
                self.tight_coupling = False
            if self.differential is None:
                self.differential = False
            if self.integer_fix is None:
                self.integer_fix = False
            if self.gps_l1 is None:
                self.gps_l1 = False
            if self.gps_l2 is None:
                self.gps_l2 = False
            if self.gps_l5 is None:
                self.gps_l5 = False
            if self.glo_l1 is None:
                self.glo_l1 = False
            if self.glo_l2 is None:
                self.glo_l2 = False
            if self.gal_e1 is None:
                self.gal_e1 = False
            if self.gal_e5 is None:
                self.gal_e5 = False
            if self.gal_e6 is None:
                self.gal_e6 = False
            if self.bei_b1 is None:
                self.bei_b1 = False
            if self.bei_b2 is None:
                self.bei_b2 = False
            if self.bei_b3 is None:
                self.bei_b3 = False
            if self.no_fix is None:
                self.no_fix = False
            if self.config_error is None:
                self.config_error = False
        else:
            self.tight_coupling = False
            self.differential = False
            self.integer_fix = False
            self.gps_l1 = False
            self.gps_l2 = False
            self.gps_l5 = False
            self.glo_l1 = False
            self.glo_l2 = False
            self.gal_e1 = False
            self.gal_e5 = False
            self.gal_e6 = False
            self.bei_b1 = False
            self.bei_b2 = False
            self.bei_b3 = False
            self.no_fix = False
            self.config_error = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_tight_coupling = struct.Struct("<B")
            buff.write(struct_tight_coupling.pack(self.tight_coupling))
            offset += 1
            struct_differential = struct.Struct("<B")
            buff.write(struct_differential.pack(self.differential))
            offset += 1
            struct_integer_fix = struct.Struct("<B")
            buff.write(struct_integer_fix.pack(self.integer_fix))
            offset += 1
            struct_gps_l1 = struct.Struct("<B")
            buff.write(struct_gps_l1.pack(self.gps_l1))
            offset += 1
            struct_gps_l2 = struct.Struct("<B")
            buff.write(struct_gps_l2.pack(self.gps_l2))
            offset += 1
            struct_gps_l5 = struct.Struct("<B")
            buff.write(struct_gps_l5.pack(self.gps_l5))
            offset += 1
            struct_glo_l1 = struct.Struct("<B")
            buff.write(struct_glo_l1.pack(self.glo_l1))
            offset += 1
            struct_glo_l2 = struct.Struct("<B")
            buff.write(struct_glo_l2.pack(self.glo_l2))
            offset += 1
            struct_gal_e1 = struct.Struct("<B")
            buff.write(struct_gal_e1.pack(self.gal_e1))
            offset += 1
            struct_gal_e5 = struct.Struct("<B")
            buff.write(struct_gal_e5.pack(self.gal_e5))
            offset += 1
            struct_gal_e6 = struct.Struct("<B")
            buff.write(struct_gal_e6.pack(self.gal_e6))
            offset += 1
            struct_bei_b1 = struct.Struct("<B")
            buff.write(struct_bei_b1.pack(self.bei_b1))
            offset += 1
            struct_bei_b2 = struct.Struct("<B")
            buff.write(struct_bei_b2.pack(self.bei_b2))
            offset += 1
            struct_bei_b3 = struct.Struct("<B")
            buff.write(struct_bei_b3.pack(self.bei_b3))
            offset += 1
            struct_no_fix = struct.Struct("<B")
            buff.write(struct_no_fix.pack(self.no_fix))
            offset += 1
            struct_config_error = struct.Struct("<B")
            buff.write(struct_config_error.pack(self.config_error))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_tight_coupling = struct.Struct("<B")
            (self.tight_coupling,) = struct_tight_coupling.unpack(buff[offset:(offset + 1)])
            self.tight_coupling = bool(self.tight_coupling)
            offset += 1
            struct_differential = struct.Struct("<B")
            (self.differential,) = struct_differential.unpack(buff[offset:(offset + 1)])
            self.differential = bool(self.differential)
            offset += 1
            struct_integer_fix = struct.Struct("<B")
            (self.integer_fix,) = struct_integer_fix.unpack(buff[offset:(offset + 1)])
            self.integer_fix = bool(self.integer_fix)
            offset += 1
            struct_gps_l1 = struct.Struct("<B")
            (self.gps_l1,) = struct_gps_l1.unpack(buff[offset:(offset + 1)])
            self.gps_l1 = bool(self.gps_l1)
            offset += 1
            struct_gps_l2 = struct.Struct("<B")
            (self.gps_l2,) = struct_gps_l2.unpack(buff[offset:(offset + 1)])
            self.gps_l2 = bool(self.gps_l2)
            offset += 1
            struct_gps_l5 = struct.Struct("<B")
            (self.gps_l5,) = struct_gps_l5.unpack(buff[offset:(offset + 1)])
            self.gps_l5 = bool(self.gps_l5)
            offset += 1
            struct_glo_l1 = struct.Struct("<B")
            (self.glo_l1,) = struct_glo_l1.unpack(buff[offset:(offset + 1)])
            self.glo_l1 = bool(self.glo_l1)
            offset += 1
            struct_glo_l2 = struct.Struct("<B")
            (self.glo_l2,) = struct_glo_l2.unpack(buff[offset:(offset + 1)])
            self.glo_l2 = bool(self.glo_l2)
            offset += 1
            struct_gal_e1 = struct.Struct("<B")
            (self.gal_e1,) = struct_gal_e1.unpack(buff[offset:(offset + 1)])
            self.gal_e1 = bool(self.gal_e1)
            offset += 1
            struct_gal_e5 = struct.Struct("<B")
            (self.gal_e5,) = struct_gal_e5.unpack(buff[offset:(offset + 1)])
            self.gal_e5 = bool(self.gal_e5)
            offset += 1
            struct_gal_e6 = struct.Struct("<B")
            (self.gal_e6,) = struct_gal_e6.unpack(buff[offset:(offset + 1)])
            self.gal_e6 = bool(self.gal_e6)
            offset += 1
            struct_bei_b1 = struct.Struct("<B")
            (self.bei_b1,) = struct_bei_b1.unpack(buff[offset:(offset + 1)])
            self.bei_b1 = bool(self.bei_b1)
            offset += 1
            struct_bei_b2 = struct.Struct("<B")
            (self.bei_b2,) = struct_bei_b2.unpack(buff[offset:(offset + 1)])
            self.bei_b2 = bool(self.bei_b2)
            offset += 1
            struct_bei_b3 = struct.Struct("<B")
            (self.bei_b3,) = struct_bei_b3.unpack(buff[offset:(offset + 1)])
            self.bei_b3 = bool(self.bei_b3)
            offset += 1
            struct_no_fix = struct.Struct("<B")
            (self.no_fix,) = struct_no_fix.unpack(buff[offset:(offset + 1)])
            self.no_fix = bool(self.no_fix)
            offset += 1
            struct_config_error = struct.Struct("<B")
            (self.config_error,) = struct_config_error.unpack(buff[offset:(offset + 1)])
            self.config_error = bool(self.config_error)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"tight_coupling":%s' % self.tight_coupling
        string_echo += ','
        string_echo += '"differential":%s' % self.differential
        string_echo += ','
        string_echo += '"integer_fix":%s' % self.integer_fix
        string_echo += ','
        string_echo += '"gps_l1":%s' % self.gps_l1
        string_echo += ','
        string_echo += '"gps_l2":%s' % self.gps_l2
        string_echo += ','
        string_echo += '"gps_l5":%s' % self.gps_l5
        string_echo += ','
        string_echo += '"glo_l1":%s' % self.glo_l1
        string_echo += ','
        string_echo += '"glo_l2":%s' % self.glo_l2
        string_echo += ','
        string_echo += '"gal_e1":%s' % self.gal_e1
        string_echo += ','
        string_echo += '"gal_e5":%s' % self.gal_e5
        string_echo += ','
        string_echo += '"gal_e6":%s' % self.gal_e6
        string_echo += ','
        string_echo += '"bei_b1":%s' % self.bei_b1
        string_echo += ','
        string_echo += '"bei_b2":%s' % self.bei_b2
        string_echo += ','
        string_echo += '"bei_b3":%s' % self.bei_b3
        string_echo += ','
        string_echo += '"no_fix":%s' % self.no_fix
        string_echo += ','
        string_echo += '"config_error":%s' % self.config_error
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterGnssPositionAidingStatusStatus"

    def getMD5(self):
        return "16a70154d04cba5f7c01e663ddb16c49"

    def getDef(self):
        return "bool tight_coupling\nbool differential\nbool integer_fix\nbool gps_l1\nbool gps_l2\nbool gps_l5\nbool glo_l1\nbool glo_l2\nbool gal_e1\nbool gal_e5\nbool gal_e6\nbool bei_b1\nbool bei_b2\nbool bei_b3\nbool no_fix\nbool config_error\n"

_struct_I = struct.Struct('<I')

