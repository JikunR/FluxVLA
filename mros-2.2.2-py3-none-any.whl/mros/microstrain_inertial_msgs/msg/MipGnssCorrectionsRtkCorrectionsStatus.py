import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssCorrectionsRtkCorrectionsStatus(mros.Message):
    __slots__ = ['header','time_of_week','week_number','epoch_status','dongle_status','gps_correction_latency','glonass_correction_latency','galileo_correction_latency','beidou_correction_latency']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','float64','uint16','microstrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusEpochStatus','microstrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusDongleStatus','float32','float32','float32','float32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssCorrectionsRtkCorrectionsStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.time_of_week is None:
                self.time_of_week = 0.
            if self.week_number is None:
                self.week_number = 0
            if self.epoch_status is None:
                self.epoch_status = mros.microstrain_inertial_msgs.msg.MipGnssCorrectionsRtkCorrectionsStatusEpochStatus()
            if self.dongle_status is None:
                self.dongle_status = mros.microstrain_inertial_msgs.msg.MipGnssCorrectionsRtkCorrectionsStatusDongleStatus()
            if self.gps_correction_latency is None:
                self.gps_correction_latency = 0.
            if self.glonass_correction_latency is None:
                self.glonass_correction_latency = 0.
            if self.galileo_correction_latency is None:
                self.galileo_correction_latency = 0.
            if self.beidou_correction_latency is None:
                self.beidou_correction_latency = 0.
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.time_of_week = 0.
            self.week_number = 0
            self.epoch_status = mros.microstrain_inertial_msgs.msg.MipGnssCorrectionsRtkCorrectionsStatusEpochStatus()
            self.dongle_status = mros.microstrain_inertial_msgs.msg.MipGnssCorrectionsRtkCorrectionsStatusDongleStatus()
            self.gps_correction_latency = 0.
            self.glonass_correction_latency = 0.
            self.galileo_correction_latency = 0.
            self.beidou_correction_latency = 0.

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_time_of_week = struct.Struct("<d")
            buff.write(struct_time_of_week.pack(self.time_of_week))
            offset += 8
            struct_week_number = struct.Struct("<H")
            buff.write(struct_week_number.pack(self.week_number))
            offset += 2
            offset += self.epoch_status.serialize(buff)
            offset += self.dongle_status.serialize(buff)
            struct_gps_correction_latency = struct.Struct("<f")
            buff.write(struct_gps_correction_latency.pack(self.gps_correction_latency))
            offset += 4
            struct_glonass_correction_latency = struct.Struct("<f")
            buff.write(struct_glonass_correction_latency.pack(self.glonass_correction_latency))
            offset += 4
            struct_galileo_correction_latency = struct.Struct("<f")
            buff.write(struct_galileo_correction_latency.pack(self.galileo_correction_latency))
            offset += 4
            struct_beidou_correction_latency = struct.Struct("<f")
            buff.write(struct_beidou_correction_latency.pack(self.beidou_correction_latency))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_time_of_week = struct.Struct("<d")
            (self.time_of_week,) = struct_time_of_week.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_week_number = struct.Struct("<H")
            (self.week_number,) = struct_week_number.unpack(buff[offset:(offset + 2)])
            offset += 2
            offset += self.epoch_status.deserialize(buff[offset:])
            offset += self.dongle_status.deserialize(buff[offset:])
            struct_gps_correction_latency = struct.Struct("<f")
            (self.gps_correction_latency,) = struct_gps_correction_latency.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_glonass_correction_latency = struct.Struct("<f")
            (self.glonass_correction_latency,) = struct_glonass_correction_latency.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_galileo_correction_latency = struct.Struct("<f")
            (self.galileo_correction_latency,) = struct_galileo_correction_latency.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_beidou_correction_latency = struct.Struct("<f")
            (self.beidou_correction_latency,) = struct_beidou_correction_latency.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 2
        length += self.epoch_status.serializedLength()
        length += self.dongle_status.serializedLength()
        length += 4
        length += 4
        length += 4
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"time_of_week":%s' % self.time_of_week
        string_echo += ','
        string_echo += '"week_number":%s' % self.week_number
        string_echo += ','
        string_echo += '"epoch_status":'
        string_echo += self.epoch_status.echo()
        string_echo += ','
        string_echo += '"dongle_status":'
        string_echo += self.dongle_status.echo()
        string_echo += ','
        string_echo += '"gps_correction_latency":%s' % self.gps_correction_latency
        string_echo += ','
        string_echo += '"glonass_correction_latency":%s' % self.glonass_correction_latency
        string_echo += ','
        string_echo += '"galileo_correction_latency":%s' % self.galileo_correction_latency
        string_echo += ','
        string_echo += '"beidou_correction_latency":%s' % self.beidou_correction_latency
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatus"

    def getMD5(self):
        return "8009259871395ab958d79d7762565e9d"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nfloat64 time_of_week\nuint16 week_number\nmicrostrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusEpochStatus epoch_status\nmicrostrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusDongleStatus dongle_status\nfloat32 gps_correction_latency\nfloat32 glonass_correction_latency\nfloat32 galileo_correction_latency\nfloat32 beidou_correction_latency\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusEpochStatus\nbool antenna_location_received\nbool antenna_description_received\nbool gps_received\nbool galileo_received\nbool glonass_received\nbool beidou_received\nbool using_gps_msm_messages\nbool using_glonass_msm_messages\nbool dongle_status_read_failed\n================================================================================\nMSG: microstrain_inertial_msgs/MipGnssCorrectionsRtkCorrectionsStatusDongleStatus\nuint8 modem_state\nuint8 connection_type\nint8 rssi\nuint8 signal_quality\nuint8 tower_change_indicator\nbool nmea_timeout_flag\nbool server_timeout_flag\nbool rtcm_timeout_flag\nbool device_out_of_range_flag\nbool corrections_unavailable_flag\nuint8 MODEM_STATE_OFF = 0\nuint8 MODEM_STATE_NO_NETWORK = 1\nuint8 MODEM_STATE_NETWORK_CONNECTED = 2\nuint8 MODEM_STATE_CONFIGURING_DATA_CONTEXT = 3\nuint8 MODEM_STATE_ACTIVATING_DATA_CONTEXT = 4\nuint8 MODEM_STATE_CONFIGURING_SOCKET = 5\nuint8 MODEM_STATE_WAITING_ON_SERVER_HANDSHAKE = 6\nuint8 MODEM_STATE_CONNECTED_AND_IDLE = 7\nuint8 MODEM_STATE_CONNECTED_AND_STREAMING = 8\nuint8 CONNECTION_TYPE_NO_CONNECTION = 0\nuint8 CONNECTION_TYPE_CONNECTION_2G = 2\nuint8 CONNECTION_TYPE_CONNECTION_3G = 3\nuint8 CONNECTION_TYPE_CONNECTION_4G = 4\nuint8 CONNECTION_TYPE_CONNECTION_5G = 5\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

