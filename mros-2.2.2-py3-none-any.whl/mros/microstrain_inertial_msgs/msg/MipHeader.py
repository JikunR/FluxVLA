import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg
import mros.std_msgs.msg

class MipHeader(mros.Message):
    __slots__ = ['header','event_source','reference_timestamp','gps_timestamp']
    _slot_types = ['std_msgs/Header','uint8','uint64','microstrain_inertial_msgs/MipGpsTimestamp']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipHeader, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.event_source is None:
                self.event_source = 0
            if self.reference_timestamp is None:
                self.reference_timestamp = 0
            if self.gps_timestamp is None:
                self.gps_timestamp = mros.microstrain_inertial_msgs.msg.MipGpsTimestamp()
        else:
            self.header = mros.std_msgs.msg.Header()
            self.event_source = 0
            self.reference_timestamp = 0
            self.gps_timestamp = mros.microstrain_inertial_msgs.msg.MipGpsTimestamp()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            struct_event_source = struct.Struct("<B")
            buff.write(struct_event_source.pack(self.event_source))
            offset += 1
            struct_reference_timestamp = struct.Struct("<Q")
            buff.write(struct_reference_timestamp.pack(self.reference_timestamp))
            offset += 8
            offset += self.gps_timestamp.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            struct_event_source = struct.Struct("<B")
            (self.event_source,) = struct_event_source.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_reference_timestamp = struct.Struct("<Q")
            (self.reference_timestamp,) = struct_reference_timestamp.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.gps_timestamp.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 8
        length += self.gps_timestamp.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"event_source":%s' % self.event_source
        string_echo += ','
        string_echo += '"reference_timestamp":%s' % self.reference_timestamp
        string_echo += ','
        string_echo += '"gps_timestamp":'
        string_echo += self.gps_timestamp.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipHeader"

    def getMD5(self):
        return "b221e7405d7e5db5e0aa579c4fb849e7"

    def getDef(self):
        return "std_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

