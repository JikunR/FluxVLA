import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssSbasInfoSbasStatus(mros.Message):
    __slots__ = ['range_available','corrections_available','integrity_available','test_mode']
    _slot_types = ['bool','bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssSbasInfoSbasStatus, self).__init__(*args, **kwds)
            if self.range_available is None:
                self.range_available = False
            if self.corrections_available is None:
                self.corrections_available = False
            if self.integrity_available is None:
                self.integrity_available = False
            if self.test_mode is None:
                self.test_mode = False
        else:
            self.range_available = False
            self.corrections_available = False
            self.integrity_available = False
            self.test_mode = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_range_available = struct.Struct("<B")
            buff.write(struct_range_available.pack(self.range_available))
            offset += 1
            struct_corrections_available = struct.Struct("<B")
            buff.write(struct_corrections_available.pack(self.corrections_available))
            offset += 1
            struct_integrity_available = struct.Struct("<B")
            buff.write(struct_integrity_available.pack(self.integrity_available))
            offset += 1
            struct_test_mode = struct.Struct("<B")
            buff.write(struct_test_mode.pack(self.test_mode))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_range_available = struct.Struct("<B")
            (self.range_available,) = struct_range_available.unpack(buff[offset:(offset + 1)])
            self.range_available = bool(self.range_available)
            offset += 1
            struct_corrections_available = struct.Struct("<B")
            (self.corrections_available,) = struct_corrections_available.unpack(buff[offset:(offset + 1)])
            self.corrections_available = bool(self.corrections_available)
            offset += 1
            struct_integrity_available = struct.Struct("<B")
            (self.integrity_available,) = struct_integrity_available.unpack(buff[offset:(offset + 1)])
            self.integrity_available = bool(self.integrity_available)
            offset += 1
            struct_test_mode = struct.Struct("<B")
            (self.test_mode,) = struct_test_mode.unpack(buff[offset:(offset + 1)])
            self.test_mode = bool(self.test_mode)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"range_available":%s' % self.range_available
        string_echo += ','
        string_echo += '"corrections_available":%s' % self.corrections_available
        string_echo += ','
        string_echo += '"integrity_available":%s' % self.integrity_available
        string_echo += ','
        string_echo += '"test_mode":%s' % self.test_mode
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssSbasInfoSbasStatus"

    def getMD5(self):
        return "d44b1dcf4b6c5470a42c909b93caefc4"

    def getDef(self):
        return "bool range_available\nbool corrections_available\nbool integrity_available\nbool test_mode\n"

_struct_I = struct.Struct('<I')

