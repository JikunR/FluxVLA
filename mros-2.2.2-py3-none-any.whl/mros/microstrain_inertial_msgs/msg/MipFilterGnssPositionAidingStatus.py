import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterGnssPositionAidingStatus(mros.Message):
    __slots__ = ['header','receiver_id','time_of_week','status']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','uint8','float64','microstrain_inertial_msgs/MipFilterGnssPositionAidingStatusStatus']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterGnssPositionAidingStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.receiver_id is None:
                self.receiver_id = 0
            if self.time_of_week is None:
                self.time_of_week = 0.
            if self.status is None:
                self.status = mros.microstrain_inertial_msgs.msg.MipFilterGnssPositionAidingStatusStatus()
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.receiver_id = 0
            self.time_of_week = 0.
            self.status = mros.microstrain_inertial_msgs.msg.MipFilterGnssPositionAidingStatusStatus()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_receiver_id = struct.Struct("<B")
            buff.write(struct_receiver_id.pack(self.receiver_id))
            offset += 1
            struct_time_of_week = struct.Struct("<d")
            buff.write(struct_time_of_week.pack(self.time_of_week))
            offset += 8
            offset += self.status.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_receiver_id = struct.Struct("<B")
            (self.receiver_id,) = struct_receiver_id.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_time_of_week = struct.Struct("<d")
            (self.time_of_week,) = struct_time_of_week.unpack(buff[offset:(offset + 8)])
            offset += 8
            offset += self.status.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 8
        length += self.status.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"receiver_id":%s' % self.receiver_id
        string_echo += ','
        string_echo += '"time_of_week":%s' % self.time_of_week
        string_echo += ','
        string_echo += '"status":'
        string_echo += self.status.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterGnssPositionAidingStatus"

    def getMD5(self):
        return "5966560e0a0af6740c0673a99a393e66"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nuint8 receiver_id\nfloat64 time_of_week\nmicrostrain_inertial_msgs/MipFilterGnssPositionAidingStatusStatus status\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipFilterGnssPositionAidingStatusStatus\nbool tight_coupling\nbool differential\nbool integer_fix\nbool gps_l1\nbool gps_l2\nbool gps_l5\nbool glo_l1\nbool glo_l2\nbool gal_e1\nbool gal_e5\nbool gal_e6\nbool bei_b1\nbool bei_b2\nbool bei_b3\nbool no_fix\nbool config_error\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

