import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterStatusGq7StatusFlags(mros.Message):
    __slots__ = ['filter_condition','roll_pitch_warning','heading_warning','position_warning','velocity_warning','imu_bias_warning','gnss_clk_warning','antenna_lever_arm_warning','mounting_transform_warning','time_sync_warning','solution_error']
    _slot_types = ['uint8','bool','bool','bool','bool','bool','bool','bool','bool','bool','bool']

    FILTER_CONDITION_STABLE =  1
    FILTER_CONDITION_CONVERGING =  2
    FILTER_CONDITION_UNSTABLE =  3

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterStatusGq7StatusFlags, self).__init__(*args, **kwds)
            if self.filter_condition is None:
                self.filter_condition = 0
            if self.roll_pitch_warning is None:
                self.roll_pitch_warning = False
            if self.heading_warning is None:
                self.heading_warning = False
            if self.position_warning is None:
                self.position_warning = False
            if self.velocity_warning is None:
                self.velocity_warning = False
            if self.imu_bias_warning is None:
                self.imu_bias_warning = False
            if self.gnss_clk_warning is None:
                self.gnss_clk_warning = False
            if self.antenna_lever_arm_warning is None:
                self.antenna_lever_arm_warning = False
            if self.mounting_transform_warning is None:
                self.mounting_transform_warning = False
            if self.time_sync_warning is None:
                self.time_sync_warning = False
            if self.solution_error is None:
                self.solution_error = False
        else:
            self.filter_condition = 0
            self.roll_pitch_warning = False
            self.heading_warning = False
            self.position_warning = False
            self.velocity_warning = False
            self.imu_bias_warning = False
            self.gnss_clk_warning = False
            self.antenna_lever_arm_warning = False
            self.mounting_transform_warning = False
            self.time_sync_warning = False
            self.solution_error = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_filter_condition = struct.Struct("<B")
            buff.write(struct_filter_condition.pack(self.filter_condition))
            offset += 1
            struct_roll_pitch_warning = struct.Struct("<B")
            buff.write(struct_roll_pitch_warning.pack(self.roll_pitch_warning))
            offset += 1
            struct_heading_warning = struct.Struct("<B")
            buff.write(struct_heading_warning.pack(self.heading_warning))
            offset += 1
            struct_position_warning = struct.Struct("<B")
            buff.write(struct_position_warning.pack(self.position_warning))
            offset += 1
            struct_velocity_warning = struct.Struct("<B")
            buff.write(struct_velocity_warning.pack(self.velocity_warning))
            offset += 1
            struct_imu_bias_warning = struct.Struct("<B")
            buff.write(struct_imu_bias_warning.pack(self.imu_bias_warning))
            offset += 1
            struct_gnss_clk_warning = struct.Struct("<B")
            buff.write(struct_gnss_clk_warning.pack(self.gnss_clk_warning))
            offset += 1
            struct_antenna_lever_arm_warning = struct.Struct("<B")
            buff.write(struct_antenna_lever_arm_warning.pack(self.antenna_lever_arm_warning))
            offset += 1
            struct_mounting_transform_warning = struct.Struct("<B")
            buff.write(struct_mounting_transform_warning.pack(self.mounting_transform_warning))
            offset += 1
            struct_time_sync_warning = struct.Struct("<B")
            buff.write(struct_time_sync_warning.pack(self.time_sync_warning))
            offset += 1
            struct_solution_error = struct.Struct("<B")
            buff.write(struct_solution_error.pack(self.solution_error))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_filter_condition = struct.Struct("<B")
            (self.filter_condition,) = struct_filter_condition.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_roll_pitch_warning = struct.Struct("<B")
            (self.roll_pitch_warning,) = struct_roll_pitch_warning.unpack(buff[offset:(offset + 1)])
            self.roll_pitch_warning = bool(self.roll_pitch_warning)
            offset += 1
            struct_heading_warning = struct.Struct("<B")
            (self.heading_warning,) = struct_heading_warning.unpack(buff[offset:(offset + 1)])
            self.heading_warning = bool(self.heading_warning)
            offset += 1
            struct_position_warning = struct.Struct("<B")
            (self.position_warning,) = struct_position_warning.unpack(buff[offset:(offset + 1)])
            self.position_warning = bool(self.position_warning)
            offset += 1
            struct_velocity_warning = struct.Struct("<B")
            (self.velocity_warning,) = struct_velocity_warning.unpack(buff[offset:(offset + 1)])
            self.velocity_warning = bool(self.velocity_warning)
            offset += 1
            struct_imu_bias_warning = struct.Struct("<B")
            (self.imu_bias_warning,) = struct_imu_bias_warning.unpack(buff[offset:(offset + 1)])
            self.imu_bias_warning = bool(self.imu_bias_warning)
            offset += 1
            struct_gnss_clk_warning = struct.Struct("<B")
            (self.gnss_clk_warning,) = struct_gnss_clk_warning.unpack(buff[offset:(offset + 1)])
            self.gnss_clk_warning = bool(self.gnss_clk_warning)
            offset += 1
            struct_antenna_lever_arm_warning = struct.Struct("<B")
            (self.antenna_lever_arm_warning,) = struct_antenna_lever_arm_warning.unpack(buff[offset:(offset + 1)])
            self.antenna_lever_arm_warning = bool(self.antenna_lever_arm_warning)
            offset += 1
            struct_mounting_transform_warning = struct.Struct("<B")
            (self.mounting_transform_warning,) = struct_mounting_transform_warning.unpack(buff[offset:(offset + 1)])
            self.mounting_transform_warning = bool(self.mounting_transform_warning)
            offset += 1
            struct_time_sync_warning = struct.Struct("<B")
            (self.time_sync_warning,) = struct_time_sync_warning.unpack(buff[offset:(offset + 1)])
            self.time_sync_warning = bool(self.time_sync_warning)
            offset += 1
            struct_solution_error = struct.Struct("<B")
            (self.solution_error,) = struct_solution_error.unpack(buff[offset:(offset + 1)])
            self.solution_error = bool(self.solution_error)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"filter_condition":%s' % self.filter_condition
        string_echo += ','
        string_echo += '"roll_pitch_warning":%s' % self.roll_pitch_warning
        string_echo += ','
        string_echo += '"heading_warning":%s' % self.heading_warning
        string_echo += ','
        string_echo += '"position_warning":%s' % self.position_warning
        string_echo += ','
        string_echo += '"velocity_warning":%s' % self.velocity_warning
        string_echo += ','
        string_echo += '"imu_bias_warning":%s' % self.imu_bias_warning
        string_echo += ','
        string_echo += '"gnss_clk_warning":%s' % self.gnss_clk_warning
        string_echo += ','
        string_echo += '"antenna_lever_arm_warning":%s' % self.antenna_lever_arm_warning
        string_echo += ','
        string_echo += '"mounting_transform_warning":%s' % self.mounting_transform_warning
        string_echo += ','
        string_echo += '"time_sync_warning":%s' % self.time_sync_warning
        string_echo += ','
        string_echo += '"solution_error":%s' % self.solution_error
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterStatusGq7StatusFlags"

    def getMD5(self):
        return "1db9853b9f08ade89304b0b0fc0f9df7"

    def getDef(self):
        return "uint8 filter_condition\nbool roll_pitch_warning\nbool heading_warning\nbool position_warning\nbool velocity_warning\nbool imu_bias_warning\nbool gnss_clk_warning\nbool antenna_lever_arm_warning\nbool mounting_transform_warning\nbool time_sync_warning\nbool solution_error\nuint8 FILTER_CONDITION_STABLE     = 1\nuint8 FILTER_CONDITION_CONVERGING = 2\nuint8 FILTER_CONDITION_UNSTABLE   = 3\n"

_struct_I = struct.Struct('<I')

