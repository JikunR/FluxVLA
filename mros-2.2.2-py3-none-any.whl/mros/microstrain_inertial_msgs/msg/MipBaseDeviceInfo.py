import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipBaseDeviceInfo(mros.Message):
    __slots__ = ['firmware_version','model_name','model_number','serial_number','lot_number','device_options']
    _slot_types = ['string','string','string','string','string','string']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipBaseDeviceInfo, self).__init__(*args, **kwds)
            if self.firmware_version is None:
                self.firmware_version = ''
            if self.model_name is None:
                self.model_name = ''
            if self.model_number is None:
                self.model_number = ''
            if self.serial_number is None:
                self.serial_number = ''
            if self.lot_number is None:
                self.lot_number = ''
            if self.device_options is None:
                self.device_options = ''
        else:
            self.firmware_version = ''
            self.model_name = ''
            self.model_number = ''
            self.serial_number = ''
            self.lot_number = ''
            self.device_options = ''

    def serialize(self, buff):
        offset = 0
        try:
            _x = self.firmware_version
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.model_name
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.model_number
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.serial_number
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.lot_number
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.device_options
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (length_firmware_version,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.firmware_version = buff[offset:(offset + length_firmware_version)].decode('utf-8')
            else:
                self.firmware_version = buff[offset:(offset + length_firmware_version)]
            offset += length_firmware_version
            (length_model_name,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.model_name = buff[offset:(offset + length_model_name)].decode('utf-8')
            else:
                self.model_name = buff[offset:(offset + length_model_name)]
            offset += length_model_name
            (length_model_number,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.model_number = buff[offset:(offset + length_model_number)].decode('utf-8')
            else:
                self.model_number = buff[offset:(offset + length_model_number)]
            offset += length_model_number
            (length_serial_number,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.serial_number = buff[offset:(offset + length_serial_number)].decode('utf-8')
            else:
                self.serial_number = buff[offset:(offset + length_serial_number)]
            offset += length_serial_number
            (length_lot_number,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.lot_number = buff[offset:(offset + length_lot_number)].decode('utf-8')
            else:
                self.lot_number = buff[offset:(offset + length_lot_number)]
            offset += length_lot_number
            (length_device_options,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.device_options = buff[offset:(offset + length_device_options)].decode('utf-8')
            else:
                self.device_options = buff[offset:(offset + length_device_options)]
            offset += length_device_options
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        firmware_version_x = self.firmware_version
        firmware_version_length = len(firmware_version_x)
        if python3 or type(firmware_version_x) == unicode:
            firmware_version_x = firmware_version_x.encode('utf-8')
            firmware_version_length = len(firmware_version_x)
        length += 4
        length += firmware_version_length
        model_name_x = self.model_name
        model_name_length = len(model_name_x)
        if python3 or type(model_name_x) == unicode:
            model_name_x = model_name_x.encode('utf-8')
            model_name_length = len(model_name_x)
        length += 4
        length += model_name_length
        model_number_x = self.model_number
        model_number_length = len(model_number_x)
        if python3 or type(model_number_x) == unicode:
            model_number_x = model_number_x.encode('utf-8')
            model_number_length = len(model_number_x)
        length += 4
        length += model_number_length
        serial_number_x = self.serial_number
        serial_number_length = len(serial_number_x)
        if python3 or type(serial_number_x) == unicode:
            serial_number_x = serial_number_x.encode('utf-8')
            serial_number_length = len(serial_number_x)
        length += 4
        length += serial_number_length
        lot_number_x = self.lot_number
        lot_number_length = len(lot_number_x)
        if python3 or type(lot_number_x) == unicode:
            lot_number_x = lot_number_x.encode('utf-8')
            lot_number_length = len(lot_number_x)
        length += 4
        length += lot_number_length
        device_options_x = self.device_options
        device_options_length = len(device_options_x)
        if python3 or type(device_options_x) == unicode:
            device_options_x = device_options_x.encode('utf-8')
            device_options_length = len(device_options_x)
        length += 4
        length += device_options_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"firmware_version":"%s"' % self.firmware_version
        string_echo += ','
        string_echo += '"model_name":"%s"' % self.model_name
        string_echo += ','
        string_echo += '"model_number":"%s"' % self.model_number
        string_echo += ','
        string_echo += '"serial_number":"%s"' % self.serial_number
        string_echo += ','
        string_echo += '"lot_number":"%s"' % self.lot_number
        string_echo += ','
        string_echo += '"device_options":"%s"' % self.device_options
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipBaseDeviceInfo"

    def getMD5(self):
        return "df41d79ab6c7222345becf9da712892f"

    def getDef(self):
        return "string firmware_version\nstring model_name\nstring model_number\nstring serial_number\nstring lot_number\nstring device_options\n"

_struct_I = struct.Struct('<I')

