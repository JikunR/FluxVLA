import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGpsTimestamp(mros.Message):
    __slots__ = ['tow','week_number']
    _slot_types = ['float64','uint16']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGpsTimestamp, self).__init__(*args, **kwds)
            if self.tow is None:
                self.tow = 0.
            if self.week_number is None:
                self.week_number = 0
        else:
            self.tow = 0.
            self.week_number = 0

    def serialize(self, buff):
        offset = 0
        try:
            struct_tow = struct.Struct("<d")
            buff.write(struct_tow.pack(self.tow))
            offset += 8
            struct_week_number = struct.Struct("<H")
            buff.write(struct_week_number.pack(self.week_number))
            offset += 2
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_tow = struct.Struct("<d")
            (self.tow,) = struct_tow.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_week_number = struct.Struct("<H")
            (self.week_number,) = struct_week_number.unpack(buff[offset:(offset + 2)])
            offset += 2
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 8
        length += 2
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"tow":%s' % self.tow
        string_echo += ','
        string_echo += '"week_number":%s' % self.week_number
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGpsTimestamp"

    def getMD5(self):
        return "88fe807e9d8e1c4b6a051b4ca1d32b50"

    def getDef(self):
        return "float64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

