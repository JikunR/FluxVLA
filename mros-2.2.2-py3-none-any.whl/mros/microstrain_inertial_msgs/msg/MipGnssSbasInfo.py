import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssSbasInfo(mros.Message):
    __slots__ = ['header','time_of_week','week_number','sbas_system','sbas_id','count','sbas_status']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','float64','uint16','uint8','uint8','uint8','microstrain_inertial_msgs/MipGnssSbasInfoSbasStatus']

    SBAS_SYSTEM_UNKNOWN =  0
    SBAS_SYSTEM_WAAS =  1
    SBAS_SYSTEM_EGNOS =  2
    SBAS_SYSTEM_MSAS =  3
    SBAS_SYSTEM_GAGAN =  4

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssSbasInfo, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.time_of_week is None:
                self.time_of_week = 0.
            if self.week_number is None:
                self.week_number = 0
            if self.sbas_system is None:
                self.sbas_system = 0
            if self.sbas_id is None:
                self.sbas_id = 0
            if self.count is None:
                self.count = 0
            if self.sbas_status is None:
                self.sbas_status = mros.microstrain_inertial_msgs.msg.MipGnssSbasInfoSbasStatus()
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.time_of_week = 0.
            self.week_number = 0
            self.sbas_system = 0
            self.sbas_id = 0
            self.count = 0
            self.sbas_status = mros.microstrain_inertial_msgs.msg.MipGnssSbasInfoSbasStatus()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_time_of_week = struct.Struct("<d")
            buff.write(struct_time_of_week.pack(self.time_of_week))
            offset += 8
            struct_week_number = struct.Struct("<H")
            buff.write(struct_week_number.pack(self.week_number))
            offset += 2
            struct_sbas_system = struct.Struct("<B")
            buff.write(struct_sbas_system.pack(self.sbas_system))
            offset += 1
            struct_sbas_id = struct.Struct("<B")
            buff.write(struct_sbas_id.pack(self.sbas_id))
            offset += 1
            struct_count = struct.Struct("<B")
            buff.write(struct_count.pack(self.count))
            offset += 1
            offset += self.sbas_status.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_time_of_week = struct.Struct("<d")
            (self.time_of_week,) = struct_time_of_week.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_week_number = struct.Struct("<H")
            (self.week_number,) = struct_week_number.unpack(buff[offset:(offset + 2)])
            offset += 2
            struct_sbas_system = struct.Struct("<B")
            (self.sbas_system,) = struct_sbas_system.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_sbas_id = struct.Struct("<B")
            (self.sbas_id,) = struct_sbas_id.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_count = struct.Struct("<B")
            (self.count,) = struct_count.unpack(buff[offset:(offset + 1)])
            offset += 1
            offset += self.sbas_status.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 2
        length += 1
        length += 1
        length += 1
        length += self.sbas_status.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"time_of_week":%s' % self.time_of_week
        string_echo += ','
        string_echo += '"week_number":%s' % self.week_number
        string_echo += ','
        string_echo += '"sbas_system":%s' % self.sbas_system
        string_echo += ','
        string_echo += '"sbas_id":%s' % self.sbas_id
        string_echo += ','
        string_echo += '"count":%s' % self.count
        string_echo += ','
        string_echo += '"sbas_status":'
        string_echo += self.sbas_status.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssSbasInfo"

    def getMD5(self):
        return "bb73e76bee0a0c74e92b2fc167954b56"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nfloat64 time_of_week\nuint16 week_number\nuint8 sbas_system\nuint8 sbas_id\nuint8 count\nmicrostrain_inertial_msgs/MipGnssSbasInfoSbasStatus sbas_status\nuint8 SBAS_SYSTEM_UNKNOWN = 0\nuint8 SBAS_SYSTEM_WAAS    = 1\nuint8 SBAS_SYSTEM_EGNOS   = 2\nuint8 SBAS_SYSTEM_MSAS    = 3\nuint8 SBAS_SYSTEM_GAGAN   = 4\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipGnssSbasInfoSbasStatus\nbool range_available\nbool corrections_available\nbool integrity_available\nbool test_mode\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

