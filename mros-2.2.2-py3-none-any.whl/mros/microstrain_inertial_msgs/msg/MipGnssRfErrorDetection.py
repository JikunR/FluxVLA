import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssRfErrorDetection(mros.Message):
    __slots__ = ['header','rf_band','jamming_state','spoofing_state']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','uint8','uint8','uint8']

    RF_BAND_UNKNOWN =  0
    RF_BAND_L1 =  1
    RF_BAND_L2 =  2
    RF_BAND_L5 =  5
    JAMMING_STATE_UNKNOWN =  0
    JAMMING_STATE_NONE =  1
    JAMMING_STATE_PARTIAL =  2
    JAMMING_STATE_SIGNIFICANT =  3
    SPOOFING_STATE_UNKNOWN =  0
    SPOOFING_STATE_NONE =  1
    SPOOFING_STATE_PARTIAL =  2
    SPOOFING_STATE_SIGNIFICANT =  3

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssRfErrorDetection, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.rf_band is None:
                self.rf_band = 0
            if self.jamming_state is None:
                self.jamming_state = 0
            if self.spoofing_state is None:
                self.spoofing_state = 0
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.rf_band = 0
            self.jamming_state = 0
            self.spoofing_state = 0

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_rf_band = struct.Struct("<B")
            buff.write(struct_rf_band.pack(self.rf_band))
            offset += 1
            struct_jamming_state = struct.Struct("<B")
            buff.write(struct_jamming_state.pack(self.jamming_state))
            offset += 1
            struct_spoofing_state = struct.Struct("<B")
            buff.write(struct_spoofing_state.pack(self.spoofing_state))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_rf_band = struct.Struct("<B")
            (self.rf_band,) = struct_rf_band.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_jamming_state = struct.Struct("<B")
            (self.jamming_state,) = struct_jamming_state.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_spoofing_state = struct.Struct("<B")
            (self.spoofing_state,) = struct_spoofing_state.unpack(buff[offset:(offset + 1)])
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"rf_band":%s' % self.rf_band
        string_echo += ','
        string_echo += '"jamming_state":%s' % self.jamming_state
        string_echo += ','
        string_echo += '"spoofing_state":%s' % self.spoofing_state
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssRfErrorDetection"

    def getMD5(self):
        return "66603763c626fad4fae6b3c693611670"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nuint8 rf_band\nuint8 jamming_state\nuint8 spoofing_state\nuint8 RF_BAND_UNKNOWN = 0\nuint8 RF_BAND_L1      = 1\nuint8 RF_BAND_L2      = 2\nuint8 RF_BAND_L5      = 5\nuint8 JAMMING_STATE_UNKNOWN     = 0\nuint8 JAMMING_STATE_NONE        = 1\nuint8 JAMMING_STATE_PARTIAL     = 2\nuint8 JAMMING_STATE_SIGNIFICANT = 3\nuint8 SPOOFING_STATE_UNKNOWN     = 0\nuint8 SPOOFING_STATE_NONE        = 1\nuint8 SPOOFING_STATE_PARTIAL     = 2\nuint8 SPOOFING_STATE_SIGNIFICANT = 3\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

