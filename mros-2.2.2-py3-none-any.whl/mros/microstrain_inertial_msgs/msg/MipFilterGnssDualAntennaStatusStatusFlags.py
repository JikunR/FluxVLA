import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterGnssDualAntennaStatusStatusFlags(mros.Message):
    __slots__ = ['rcv_1_data_valid','rcv_2_data_valid','antenna_offsets_valid']
    _slot_types = ['bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterGnssDualAntennaStatusStatusFlags, self).__init__(*args, **kwds)
            if self.rcv_1_data_valid is None:
                self.rcv_1_data_valid = False
            if self.rcv_2_data_valid is None:
                self.rcv_2_data_valid = False
            if self.antenna_offsets_valid is None:
                self.antenna_offsets_valid = False
        else:
            self.rcv_1_data_valid = False
            self.rcv_2_data_valid = False
            self.antenna_offsets_valid = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_rcv_1_data_valid = struct.Struct("<B")
            buff.write(struct_rcv_1_data_valid.pack(self.rcv_1_data_valid))
            offset += 1
            struct_rcv_2_data_valid = struct.Struct("<B")
            buff.write(struct_rcv_2_data_valid.pack(self.rcv_2_data_valid))
            offset += 1
            struct_antenna_offsets_valid = struct.Struct("<B")
            buff.write(struct_antenna_offsets_valid.pack(self.antenna_offsets_valid))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_rcv_1_data_valid = struct.Struct("<B")
            (self.rcv_1_data_valid,) = struct_rcv_1_data_valid.unpack(buff[offset:(offset + 1)])
            self.rcv_1_data_valid = bool(self.rcv_1_data_valid)
            offset += 1
            struct_rcv_2_data_valid = struct.Struct("<B")
            (self.rcv_2_data_valid,) = struct_rcv_2_data_valid.unpack(buff[offset:(offset + 1)])
            self.rcv_2_data_valid = bool(self.rcv_2_data_valid)
            offset += 1
            struct_antenna_offsets_valid = struct.Struct("<B")
            (self.antenna_offsets_valid,) = struct_antenna_offsets_valid.unpack(buff[offset:(offset + 1)])
            self.antenna_offsets_valid = bool(self.antenna_offsets_valid)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"rcv_1_data_valid":%s' % self.rcv_1_data_valid
        string_echo += ','
        string_echo += '"rcv_2_data_valid":%s' % self.rcv_2_data_valid
        string_echo += ','
        string_echo += '"antenna_offsets_valid":%s' % self.antenna_offsets_valid
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterGnssDualAntennaStatusStatusFlags"

    def getMD5(self):
        return "606778f7e3bc3fceb7877383568e2671"

    def getDef(self):
        return "bool rcv_1_data_valid\nbool rcv_2_data_valid\nbool antenna_offsets_valid\n"

_struct_I = struct.Struct('<I')

