import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg
import mros.std_msgs.msg

class HumanReadableStatus(mros.Message):
    __slots__ = ['header','device_info','gnss_state','dual_antenna_fix_type','filter_state','status_flags']
    _slot_types = ['std_msgs/Header','microstrain_inertial_msgs/MipBaseDeviceInfo','string','string','string','string[]']

    UNSUPPORTED =  "Unsupported"
    GNSS_STATE_NO_FIX =  "No Fix"
    GNSS_STATE_3D_FIX =  "3D Fix"
    GNSS_STATE_SBAS =  "SBAS"
    GNSS_STATE_RTK_FLOAT =  "RTK Float"
    GNSS_STATE_RTK_FIXED =  "RTK Fixed"
    DUAL_ANTENNA_FIX_TYPE_NONE =  "None"
    DUAL_ANTENNA_FIX_TYPE_FLOAT =  "Dual Antenna Float"
    DUAL_ANTENNA_FIX_TYPE_FIXED =  "Dual Antenna Fixed"
    FILTER_STATE_GX5_STARTUP =  "Startup"
    FILTER_STATE_GX5_INIT =  "Init"
    FILTER_STATE_GX5_RUN_SOLUTION_VALID =  "Solution Valid"
    FILTER_STATE_GX5_RUN_SOLUTION_ERROR =  "Solution Error"
    FILTER_STATE_GQ7_INIT =  "Init"
    FILTER_STATE_GQ7_VERT_GYRO =  "Vertical Gyro"
    FILTER_STATE_GQ7_AHRS =  "AHRS"
    FILTER_STATE_GQ7_FULL_NAV =  "Full Nav"
    STATUS_FLAGS_GX5_INIT_NO_ATTITUDE =  "Init No Attitude"
    STATUS_FLAGS_GX5_INIT_NO_POSITION_VELOCITY =  "Init No Position / Velocity"
    STATUS_FLAGS_GX5_RUN_IMU_UNAVAILABLE =  "IMU Unavailable"
    STATUS_FLAGS_GX5_RUN_GPS_UNAVAILABLE =  "GPS Unavailable"
    STATUS_FLAGS_GX5_RUN_MATRIX_SINGULARITY =  "Matrix Singularity"
    STATUS_FLAGS_GX5_RUN_POSITION_COVARIANCE_WARNING =  "Position Covariance Warning"
    STATUS_FLAGS_GX5_RUN_VELOCITY_COVARIANCE_WARNING =  "Velocity Covariance Warning"
    STATUS_FLAGS_GX5_RUN_ATTITUDE_COVARIANCE_WARNING =  "Attitude Covariance Warning"
    STATUS_FLAGS_GX5_RUN_NAN_IN_SOLUTION_WARNING =  "NaN in Solution"
    STATUS_FLAGS_GX5_RUN_GYRO_BIAS_EST_HIGH_WARNING =  "Gyroscope Bias Estimate High"
    STATUS_FLAGS_GX5_RUN_ACCEL_BIAS_EST_HIGH_WARNING =  "Accelerometer Bias Estimate High"
    STATUS_FLAGS_GX5_RUN_GYRO_SCALE_FACTOR_EST_HIGH_WARNING =  "Gyroscope Scale Factor Estimate High"
    STATUS_FLAGS_GX5_RUN_ACCEL_SCALE_FACTOR_EST_HIGH_WARNING =  "Accelerometer Scal Factor Estimate High"
    STATUS_FLAGS_GX5_RUN_MAG_BIAS_EST_HIGH_WARNING =  "Magnetometer Bias Estimate High"
    STATUS_FLAGS_GX5_RUN_ANT_OFFSET_CORRECTION_EST_HIGH_WARNING =  "Antenna Offset Correction Estimate High"
    STATUS_FLAGS_GX5_RUN_MAG_HARD_IRON_EST_HIGH_WARNING =  "Magnetometer Hard Iron Estimate High"
    STATUS_FLAGS_GX5_RUN_MAG_SOFT_IRON_EST_HIGH_WARNING =  "Magnetometer Soft Iron Estimate High"
    STATUS_FLAGS_GQ7_FILTER_CONDITION_STABLE =  "Stable"
    STATUS_FLAGS_GQ7_FILTER_CONDITION_CONVERGING =  "Converging"
    STATUS_FLAGS_GQ7_FILTER_CONDITION_UNSTABLE =  "Unstable"
    STATUS_FLAGS_GQ7_ROLL_PITCH_WARNING =  "Roll / Pitch Warning"
    STATUS_FLAGS_GQ7_HEADING_WARNING =  "Heading Warning"
    STATUS_FLAGS_GQ7_POSITION_WARNING =  "Position Warning"
    STATUS_FLAGS_GQ7_VELOCITY_WARNING =  "Velocity Warning"
    STATUS_FLAGS_GQ7_IMU_BIAS_WARNING =  "IMU Bias Warning"
    STATUS_FLAGS_GQ7_GNSS_CLK_WARNING =  "GNSS Clock Warning"
    STATUS_FLAGS_GQ7_ANTENNA_LEVER_ARM_WARNING =  "Antenna Lever Arm Warning"
    STATUS_FLAGS_GQ7_MOUNTING_TRANSFORM_WARNING =  "Mounting Transform Warning"
    STATUS_FLAGS_GQ7_TIME_SYNC_WARNING =  "Time Sync Warning"
    STATUS_FLAGS_GQ7_SOLUTION_ERROR =  "Solution Error"

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HumanReadableStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.device_info is None:
                self.device_info = mros.microstrain_inertial_msgs.msg.MipBaseDeviceInfo()
            if self.gnss_state is None:
                self.gnss_state = ''
            if self.dual_antenna_fix_type is None:
                self.dual_antenna_fix_type = ''
            if self.filter_state is None:
                self.filter_state = ''
            if self.status_flags is None:
                self.status_flags = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.device_info = mros.microstrain_inertial_msgs.msg.MipBaseDeviceInfo()
            self.gnss_state = ''
            self.dual_antenna_fix_type = ''
            self.filter_state = ''
            self.status_flags = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            offset += self.device_info.serialize(buff)
            _x = self.gnss_state
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.dual_antenna_fix_type
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            _x = self.filter_state
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            status_flags_length = len(self.status_flags)
            buff.write(struct.pack('<I', status_flags_length))
            offset += 4
            for i in range(0, status_flags_length):
                _x = self.status_flags[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            offset += self.device_info.deserialize(buff[offset:])
            (length_gnss_state,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.gnss_state = buff[offset:(offset + length_gnss_state)].decode('utf-8')
            else:
                self.gnss_state = buff[offset:(offset + length_gnss_state)]
            offset += length_gnss_state
            (length_dual_antenna_fix_type,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.dual_antenna_fix_type = buff[offset:(offset + length_dual_antenna_fix_type)].decode('utf-8')
            else:
                self.dual_antenna_fix_type = buff[offset:(offset + length_dual_antenna_fix_type)]
            offset += length_dual_antenna_fix_type
            (length_filter_state,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.filter_state = buff[offset:(offset + length_filter_state)].decode('utf-8')
            else:
                self.filter_state = buff[offset:(offset + length_filter_state)]
            offset += length_filter_state
            (status_flags_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.status_flags) != status_flags_length:
                self.status_flags = ['' for _ in range(status_flags_length)]
            for i in range(0, status_flags_length):
                (length_status_flagsi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.status_flags[i] = buff[offset:(offset + length_status_flagsi)].decode('utf-8')
                else:
                    self.status_flags[i] = buff[offset:(offset + length_status_flagsi)]
                offset += length_status_flagsi
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += self.device_info.serializedLength()
        gnss_state_x = self.gnss_state
        gnss_state_length = len(gnss_state_x)
        if python3 or type(gnss_state_x) == unicode:
            gnss_state_x = gnss_state_x.encode('utf-8')
            gnss_state_length = len(gnss_state_x)
        length += 4
        length += gnss_state_length
        dual_antenna_fix_type_x = self.dual_antenna_fix_type
        dual_antenna_fix_type_length = len(dual_antenna_fix_type_x)
        if python3 or type(dual_antenna_fix_type_x) == unicode:
            dual_antenna_fix_type_x = dual_antenna_fix_type_x.encode('utf-8')
            dual_antenna_fix_type_length = len(dual_antenna_fix_type_x)
        length += 4
        length += dual_antenna_fix_type_length
        filter_state_x = self.filter_state
        filter_state_length = len(filter_state_x)
        if python3 or type(filter_state_x) == unicode:
            filter_state_x = filter_state_x.encode('utf-8')
            filter_state_length = len(filter_state_x)
        length += 4
        length += filter_state_length
        length += 4
        for i in range(0, status_flags_length):
            status_flagsi_x = self.status_flags[i]
            status_flagsi_length = len(status_flagsi_x)
            if python3 or type(status_flagsi_x) == unicode:
                status_flagsi_x = status_flagsi_x.encode('utf-8')
                status_flagsi_length = len(status_flagsi_x)
            length += 4
            length += status_flagsi_length
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"device_info":'
        string_echo += self.device_info.echo()
        string_echo += ','
        string_echo += '"gnss_state":"%s"' % self.gnss_state
        string_echo += ','
        string_echo += '"dual_antenna_fix_type":"%s"' % self.dual_antenna_fix_type
        string_echo += ','
        string_echo += '"filter_state":"%s"' % self.filter_state
        string_echo += ','
        string_echo += '"status_flags":['
        status_flags_length = len(self.status_flags)
        for i in range(0, status_flags_length):
            if i == (status_flags_length - 1): 
                string_echo += '"status_flags[i]":"%s"' % self.status_flags[i]
                string_echo += ''
            else:
                string_echo += '"status_flags[i]":"%s"' % self.status_flags[i]
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/HumanReadableStatus"

    def getMD5(self):
        return "6271a8309b0c8fdb9ab31e419c91434b"

    def getDef(self):
        return "std_msgs/Header header\nmicrostrain_inertial_msgs/MipBaseDeviceInfo device_info\nstring gnss_state\nstring dual_antenna_fix_type\nstring filter_state\nstring[] status_flags\nstring UNSUPPORTED = \"Unsupported\"\nstring GNSS_STATE_NO_FIX    = \"No Fix\"\nstring GNSS_STATE_3D_FIX    = \"3D Fix\"\nstring GNSS_STATE_SBAS      = \"SBAS\"\nstring GNSS_STATE_RTK_FLOAT = \"RTK Float\"\nstring GNSS_STATE_RTK_FIXED = \"RTK Fixed\"\nstring DUAL_ANTENNA_FIX_TYPE_NONE  = \"None\"\nstring DUAL_ANTENNA_FIX_TYPE_FLOAT = \"Dual Antenna Float\"\nstring DUAL_ANTENNA_FIX_TYPE_FIXED = \"Dual Antenna Fixed\"\nstring FILTER_STATE_GX5_STARTUP            = \"Startup\"\nstring FILTER_STATE_GX5_INIT               = \"Init\"\nstring FILTER_STATE_GX5_RUN_SOLUTION_VALID = \"Solution Valid\"\nstring FILTER_STATE_GX5_RUN_SOLUTION_ERROR = \"Solution Error\"\nstring FILTER_STATE_GQ7_INIT      = \"Init\"\nstring FILTER_STATE_GQ7_VERT_GYRO = \"Vertical Gyro\"\nstring FILTER_STATE_GQ7_AHRS      = \"AHRS\"\nstring FILTER_STATE_GQ7_FULL_NAV  = \"Full Nav\"\nstring STATUS_FLAGS_GX5_INIT_NO_ATTITUDE                           = \"Init No Attitude\"\nstring STATUS_FLAGS_GX5_INIT_NO_POSITION_VELOCITY                  = \"Init No Position / Velocity\"\nstring STATUS_FLAGS_GX5_RUN_IMU_UNAVAILABLE                        = \"IMU Unavailable\"\nstring STATUS_FLAGS_GX5_RUN_GPS_UNAVAILABLE                        = \"GPS Unavailable\"\nstring STATUS_FLAGS_GX5_RUN_MATRIX_SINGULARITY                     = \"Matrix Singularity\"\nstring STATUS_FLAGS_GX5_RUN_POSITION_COVARIANCE_WARNING            = \"Position Covariance Warning\"\nstring STATUS_FLAGS_GX5_RUN_VELOCITY_COVARIANCE_WARNING            = \"Velocity Covariance Warning\"\nstring STATUS_FLAGS_GX5_RUN_ATTITUDE_COVARIANCE_WARNING            = \"Attitude Covariance Warning\"\nstring STATUS_FLAGS_GX5_RUN_NAN_IN_SOLUTION_WARNING                = \"NaN in Solution\"\nstring STATUS_FLAGS_GX5_RUN_GYRO_BIAS_EST_HIGH_WARNING             = \"Gyroscope Bias Estimate High\"\nstring STATUS_FLAGS_GX5_RUN_ACCEL_BIAS_EST_HIGH_WARNING            = \"Accelerometer Bias Estimate High\"\nstring STATUS_FLAGS_GX5_RUN_GYRO_SCALE_FACTOR_EST_HIGH_WARNING     = \"Gyroscope Scale Factor Estimate High\"\nstring STATUS_FLAGS_GX5_RUN_ACCEL_SCALE_FACTOR_EST_HIGH_WARNING    = \"Accelerometer Scal Factor Estimate High\"\nstring STATUS_FLAGS_GX5_RUN_MAG_BIAS_EST_HIGH_WARNING              = \"Magnetometer Bias Estimate High\"\nstring STATUS_FLAGS_GX5_RUN_ANT_OFFSET_CORRECTION_EST_HIGH_WARNING = \"Antenna Offset Correction Estimate High\"\nstring STATUS_FLAGS_GX5_RUN_MAG_HARD_IRON_EST_HIGH_WARNING         = \"Magnetometer Hard Iron Estimate High\"\nstring STATUS_FLAGS_GX5_RUN_MAG_SOFT_IRON_EST_HIGH_WARNING         = \"Magnetometer Soft Iron Estimate High\"\nstring STATUS_FLAGS_GQ7_FILTER_CONDITION_STABLE     = \"Stable\"\nstring STATUS_FLAGS_GQ7_FILTER_CONDITION_CONVERGING = \"Converging\"\nstring STATUS_FLAGS_GQ7_FILTER_CONDITION_UNSTABLE   = \"Unstable\"\nstring STATUS_FLAGS_GQ7_ROLL_PITCH_WARNING          = \"Roll / Pitch Warning\"\nstring STATUS_FLAGS_GQ7_HEADING_WARNING             = \"Heading Warning\"\nstring STATUS_FLAGS_GQ7_POSITION_WARNING            = \"Position Warning\"\nstring STATUS_FLAGS_GQ7_VELOCITY_WARNING            = \"Velocity Warning\"\nstring STATUS_FLAGS_GQ7_IMU_BIAS_WARNING            = \"IMU Bias Warning\"\nstring STATUS_FLAGS_GQ7_GNSS_CLK_WARNING            = \"GNSS Clock Warning\"\nstring STATUS_FLAGS_GQ7_ANTENNA_LEVER_ARM_WARNING   = \"Antenna Lever Arm Warning\"\nstring STATUS_FLAGS_GQ7_MOUNTING_TRANSFORM_WARNING  = \"Mounting Transform Warning\"\nstring STATUS_FLAGS_GQ7_TIME_SYNC_WARNING           = \"Time Sync Warning\"\nstring STATUS_FLAGS_GQ7_SOLUTION_ERROR              = \"Solution Error\"\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipBaseDeviceInfo\nstring firmware_version\nstring model_name\nstring model_number\nstring serial_number\nstring lot_number\nstring device_options\n"

_struct_I = struct.Struct('<I')

