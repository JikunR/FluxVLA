import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterAidingMeasurementSummary(mros.Message):
    __slots__ = ['header','time_of_week','source','type','indicator']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','float64','uint8','uint8','microstrain_inertial_msgs/MipFilterAidingMeasurementSummaryIndicator']

    TYPE_GNSS =  1
    TYPE_DUAL_ANTENNA =  2
    TYPE_HEADING =  3
    TYPE_PRESSURE =  4
    TYPE_MAGNETOMETER =  5
    TYPE_SPEED =  6

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterAidingMeasurementSummary, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.time_of_week is None:
                self.time_of_week = 0.
            if self.source is None:
                self.source = 0
            if self.type is None:
                self.type = 0
            if self.indicator is None:
                self.indicator = mros.microstrain_inertial_msgs.msg.MipFilterAidingMeasurementSummaryIndicator()
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.time_of_week = 0.
            self.source = 0
            self.type = 0
            self.indicator = mros.microstrain_inertial_msgs.msg.MipFilterAidingMeasurementSummaryIndicator()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_time_of_week = struct.Struct("<d")
            buff.write(struct_time_of_week.pack(self.time_of_week))
            offset += 8
            struct_source = struct.Struct("<B")
            buff.write(struct_source.pack(self.source))
            offset += 1
            struct_type = struct.Struct("<B")
            buff.write(struct_type.pack(self.type))
            offset += 1
            offset += self.indicator.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_time_of_week = struct.Struct("<d")
            (self.time_of_week,) = struct_time_of_week.unpack(buff[offset:(offset + 8)])
            offset += 8
            struct_source = struct.Struct("<B")
            (self.source,) = struct_source.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_type = struct.Struct("<B")
            (self.type,) = struct_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            offset += self.indicator.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 8
        length += 1
        length += 1
        length += self.indicator.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"time_of_week":%s' % self.time_of_week
        string_echo += ','
        string_echo += '"source":%s' % self.source
        string_echo += ','
        string_echo += '"type":%s' % self.type
        string_echo += ','
        string_echo += '"indicator":'
        string_echo += self.indicator.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterAidingMeasurementSummary"

    def getMD5(self):
        return "d7edada71914b75e6bca6085af52e59d"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nfloat64 time_of_week\nuint8 source\nuint8 type\nmicrostrain_inertial_msgs/MipFilterAidingMeasurementSummaryIndicator indicator\nuint8 TYPE_GNSS         = 1\nuint8 TYPE_DUAL_ANTENNA = 2\nuint8 TYPE_HEADING      = 3\nuint8 TYPE_PRESSURE     = 4\nuint8 TYPE_MAGNETOMETER = 5\nuint8 TYPE_SPEED        = 6\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipFilterAidingMeasurementSummaryIndicator\nbool enabled\nbool used\nbool residual_high_warning\nbool sample_time_warning\nbool configuration_error\nbool max_num_meas_exceeded\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

