import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterAidingMeasurementSummaryIndicator(mros.Message):
    __slots__ = ['enabled','used','residual_high_warning','sample_time_warning','configuration_error','max_num_meas_exceeded']
    _slot_types = ['bool','bool','bool','bool','bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterAidingMeasurementSummaryIndicator, self).__init__(*args, **kwds)
            if self.enabled is None:
                self.enabled = False
            if self.used is None:
                self.used = False
            if self.residual_high_warning is None:
                self.residual_high_warning = False
            if self.sample_time_warning is None:
                self.sample_time_warning = False
            if self.configuration_error is None:
                self.configuration_error = False
            if self.max_num_meas_exceeded is None:
                self.max_num_meas_exceeded = False
        else:
            self.enabled = False
            self.used = False
            self.residual_high_warning = False
            self.sample_time_warning = False
            self.configuration_error = False
            self.max_num_meas_exceeded = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_enabled = struct.Struct("<B")
            buff.write(struct_enabled.pack(self.enabled))
            offset += 1
            struct_used = struct.Struct("<B")
            buff.write(struct_used.pack(self.used))
            offset += 1
            struct_residual_high_warning = struct.Struct("<B")
            buff.write(struct_residual_high_warning.pack(self.residual_high_warning))
            offset += 1
            struct_sample_time_warning = struct.Struct("<B")
            buff.write(struct_sample_time_warning.pack(self.sample_time_warning))
            offset += 1
            struct_configuration_error = struct.Struct("<B")
            buff.write(struct_configuration_error.pack(self.configuration_error))
            offset += 1
            struct_max_num_meas_exceeded = struct.Struct("<B")
            buff.write(struct_max_num_meas_exceeded.pack(self.max_num_meas_exceeded))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_enabled = struct.Struct("<B")
            (self.enabled,) = struct_enabled.unpack(buff[offset:(offset + 1)])
            self.enabled = bool(self.enabled)
            offset += 1
            struct_used = struct.Struct("<B")
            (self.used,) = struct_used.unpack(buff[offset:(offset + 1)])
            self.used = bool(self.used)
            offset += 1
            struct_residual_high_warning = struct.Struct("<B")
            (self.residual_high_warning,) = struct_residual_high_warning.unpack(buff[offset:(offset + 1)])
            self.residual_high_warning = bool(self.residual_high_warning)
            offset += 1
            struct_sample_time_warning = struct.Struct("<B")
            (self.sample_time_warning,) = struct_sample_time_warning.unpack(buff[offset:(offset + 1)])
            self.sample_time_warning = bool(self.sample_time_warning)
            offset += 1
            struct_configuration_error = struct.Struct("<B")
            (self.configuration_error,) = struct_configuration_error.unpack(buff[offset:(offset + 1)])
            self.configuration_error = bool(self.configuration_error)
            offset += 1
            struct_max_num_meas_exceeded = struct.Struct("<B")
            (self.max_num_meas_exceeded,) = struct_max_num_meas_exceeded.unpack(buff[offset:(offset + 1)])
            self.max_num_meas_exceeded = bool(self.max_num_meas_exceeded)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"enabled":%s' % self.enabled
        string_echo += ','
        string_echo += '"used":%s' % self.used
        string_echo += ','
        string_echo += '"residual_high_warning":%s' % self.residual_high_warning
        string_echo += ','
        string_echo += '"sample_time_warning":%s' % self.sample_time_warning
        string_echo += ','
        string_echo += '"configuration_error":%s' % self.configuration_error
        string_echo += ','
        string_echo += '"max_num_meas_exceeded":%s' % self.max_num_meas_exceeded
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterAidingMeasurementSummaryIndicator"

    def getMD5(self):
        return "4e3131125b51ac75dceed1517c488713"

    def getDef(self):
        return "bool enabled\nbool used\nbool residual_high_warning\nbool sample_time_warning\nbool configuration_error\nbool max_num_meas_exceeded\n"

_struct_I = struct.Struct('<I')

