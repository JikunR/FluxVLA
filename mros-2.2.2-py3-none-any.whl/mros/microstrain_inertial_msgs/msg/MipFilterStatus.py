import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterStatus(mros.Message):
    __slots__ = ['header','filter_state','dynamics_mode','gx5_status_flags','gq7_status_flags']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','uint16','uint16','microstrain_inertial_msgs/MipFilterStatusGx5StatusFlags','microstrain_inertial_msgs/MipFilterStatusGq7StatusFlags']

    FILTER_STATE_GX5_STARTUP =  0
    FILTER_STATE_GX5_INIT =  1
    FILTER_STATE_GX5_RUN_SOLUTION_VALID =  2
    FILTER_STATE_GX5_RUN_SOLUTION_ERROR =  3
    FILTER_STATE_GQ7_INIT =  1
    FILTER_STATE_GQ7_VERT_GYRO =  2
    FILTER_STATE_GQ7_AHRS =  3
    FILTER_STATE_GQ7_FULL_NAV =  4
    DYNAMICS_MODE_GX5_PORTABLE =  1
    DYNAMICS_MODE_GX5_AUTOMOTIVE =  2
    DYNAMICS_MODE_GX5_AIRBORNE =  3
    DYNAMICS_MODE_GQ7_DEFAULT =  1

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.filter_state is None:
                self.filter_state = 0
            if self.dynamics_mode is None:
                self.dynamics_mode = 0
            if self.gx5_status_flags is None:
                self.gx5_status_flags = mros.microstrain_inertial_msgs.msg.MipFilterStatusGx5StatusFlags()
            if self.gq7_status_flags is None:
                self.gq7_status_flags = mros.microstrain_inertial_msgs.msg.MipFilterStatusGq7StatusFlags()
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.filter_state = 0
            self.dynamics_mode = 0
            self.gx5_status_flags = mros.microstrain_inertial_msgs.msg.MipFilterStatusGx5StatusFlags()
            self.gq7_status_flags = mros.microstrain_inertial_msgs.msg.MipFilterStatusGq7StatusFlags()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_filter_state = struct.Struct("<H")
            buff.write(struct_filter_state.pack(self.filter_state))
            offset += 2
            struct_dynamics_mode = struct.Struct("<H")
            buff.write(struct_dynamics_mode.pack(self.dynamics_mode))
            offset += 2
            offset += self.gx5_status_flags.serialize(buff)
            offset += self.gq7_status_flags.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_filter_state = struct.Struct("<H")
            (self.filter_state,) = struct_filter_state.unpack(buff[offset:(offset + 2)])
            offset += 2
            struct_dynamics_mode = struct.Struct("<H")
            (self.dynamics_mode,) = struct_dynamics_mode.unpack(buff[offset:(offset + 2)])
            offset += 2
            offset += self.gx5_status_flags.deserialize(buff[offset:])
            offset += self.gq7_status_flags.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 2
        length += 2
        length += self.gx5_status_flags.serializedLength()
        length += self.gq7_status_flags.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"filter_state":%s' % self.filter_state
        string_echo += ','
        string_echo += '"dynamics_mode":%s' % self.dynamics_mode
        string_echo += ','
        string_echo += '"gx5_status_flags":'
        string_echo += self.gx5_status_flags.echo()
        string_echo += ','
        string_echo += '"gq7_status_flags":'
        string_echo += self.gq7_status_flags.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterStatus"

    def getMD5(self):
        return "e9679d8a6e2a873f1e5d6301921d4292"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nuint16 filter_state\nuint16 dynamics_mode\nmicrostrain_inertial_msgs/MipFilterStatusGx5StatusFlags gx5_status_flags\nmicrostrain_inertial_msgs/MipFilterStatusGq7StatusFlags gq7_status_flags\nuint16 FILTER_STATE_GX5_STARTUP            = 0\nuint16 FILTER_STATE_GX5_INIT               = 1\nuint16 FILTER_STATE_GX5_RUN_SOLUTION_VALID = 2\nuint16 FILTER_STATE_GX5_RUN_SOLUTION_ERROR = 3\nuint16 FILTER_STATE_GQ7_INIT      = 1\nuint16 FILTER_STATE_GQ7_VERT_GYRO = 2\nuint16 FILTER_STATE_GQ7_AHRS      = 3\nuint16 FILTER_STATE_GQ7_FULL_NAV  = 4\nuint16 DYNAMICS_MODE_GX5_PORTABLE   = 1\nuint16 DYNAMICS_MODE_GX5_AUTOMOTIVE = 2\nuint16 DYNAMICS_MODE_GX5_AIRBORNE   = 3\nuint16 DYNAMICS_MODE_GQ7_DEFAULT = 1\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipFilterStatusGx5StatusFlags\nbool init_no_attitude\nbool init_no_position_velocity\nbool run_imu_unavailable\nbool run_gps_unavailable\nbool run_matrix_singularity\nbool run_position_covariance_warning\nbool run_velocity_covariance_warning\nbool run_attitude_covariance_warning\nbool run_nan_in_solution_warning\nbool run_gyro_bias_est_high_warning\nbool run_accel_bias_est_high_warning\nbool run_gyro_scale_factor_est_high_warning\nbool run_accel_scale_factor_est_high_warning\nbool run_mag_bias_est_high_warning\nbool run_ant_offset_correction_est_high_warning\nbool run_mag_hard_iron_est_high_warning\nbool run_mag_soft_iron_est_high_warning\n================================================================================\nMSG: microstrain_inertial_msgs/MipFilterStatusGq7StatusFlags\nuint8 filter_condition\nbool roll_pitch_warning\nbool heading_warning\nbool position_warning\nbool velocity_warning\nbool imu_bias_warning\nbool gnss_clk_warning\nbool antenna_lever_arm_warning\nbool mounting_transform_warning\nbool time_sync_warning\nbool solution_error\nuint8 FILTER_CONDITION_STABLE     = 1\nuint8 FILTER_CONDITION_CONVERGING = 2\nuint8 FILTER_CONDITION_UNSTABLE   = 3\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

