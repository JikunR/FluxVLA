import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterMultiAntennaOffsetCorrection(mros.Message):
    __slots__ = ['header','receiver_id','offset']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','uint8','float32[3]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterMultiAntennaOffsetCorrection, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.receiver_id is None:
                self.receiver_id = 0
            if self.offset is None:
                self.offset = [0. for x in range(0, 3)]
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.receiver_id = 0
            self.offset = [0. for x in range(0, 3)]

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_receiver_id = struct.Struct("<B")
            buff.write(struct_receiver_id.pack(self.receiver_id))
            offset += 1
            buff.write(struct.pack(f'<{3}f', *self.offset))
            offset += 3 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_receiver_id = struct.Struct("<B")
            (self.receiver_id,) = struct_receiver_id.unpack(buff[offset:(offset + 1)])
            offset += 1
            self.offset = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 3 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"receiver_id":%s' % self.receiver_id
        string_echo += ','
        string_echo += '"offset":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.offset[i]
            else:
                string_echo += '%s,' % self.offset[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterMultiAntennaOffsetCorrection"

    def getMD5(self):
        return "f72088cfbea599278c8965775259b14e"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nuint8 receiver_id\nfloat32[3] offset\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

