import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipFilterGnssDualAntennaStatus(mros.Message):
    __slots__ = ['header','time_of_week','heading','heading_unc','fix_type','status_flags','valid_flags']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','float32','float32','float32','uint8','microstrain_inertial_msgs/MipFilterGnssDualAntennaStatusStatusFlags','uint16']

    FIX_TYPE_FIX_NONE =  0
    FIX_TYPE_FIX_DA_FLOAT =  1
    FIX_TYPE_FIX_DA_FIXED =  2

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipFilterGnssDualAntennaStatus, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.time_of_week is None:
                self.time_of_week = 0.
            if self.heading is None:
                self.heading = 0.
            if self.heading_unc is None:
                self.heading_unc = 0.
            if self.fix_type is None:
                self.fix_type = 0
            if self.status_flags is None:
                self.status_flags = mros.microstrain_inertial_msgs.msg.MipFilterGnssDualAntennaStatusStatusFlags()
            if self.valid_flags is None:
                self.valid_flags = 0
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.time_of_week = 0.
            self.heading = 0.
            self.heading_unc = 0.
            self.fix_type = 0
            self.status_flags = mros.microstrain_inertial_msgs.msg.MipFilterGnssDualAntennaStatusStatusFlags()
            self.valid_flags = 0

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_time_of_week = struct.Struct("<f")
            buff.write(struct_time_of_week.pack(self.time_of_week))
            offset += 4
            struct_heading = struct.Struct("<f")
            buff.write(struct_heading.pack(self.heading))
            offset += 4
            struct_heading_unc = struct.Struct("<f")
            buff.write(struct_heading_unc.pack(self.heading_unc))
            offset += 4
            struct_fix_type = struct.Struct("<B")
            buff.write(struct_fix_type.pack(self.fix_type))
            offset += 1
            offset += self.status_flags.serialize(buff)
            struct_valid_flags = struct.Struct("<H")
            buff.write(struct_valid_flags.pack(self.valid_flags))
            offset += 2
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_time_of_week = struct.Struct("<f")
            (self.time_of_week,) = struct_time_of_week.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_heading = struct.Struct("<f")
            (self.heading,) = struct_heading.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_heading_unc = struct.Struct("<f")
            (self.heading_unc,) = struct_heading_unc.unpack(buff[offset:(offset + 4)])
            offset += 4
            struct_fix_type = struct.Struct("<B")
            (self.fix_type,) = struct_fix_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            offset += self.status_flags.deserialize(buff[offset:])
            struct_valid_flags = struct.Struct("<H")
            (self.valid_flags,) = struct_valid_flags.unpack(buff[offset:(offset + 2)])
            offset += 2
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        length += 4
        length += 4
        length += 1
        length += self.status_flags.serializedLength()
        length += 2
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"time_of_week":%s' % self.time_of_week
        string_echo += ','
        string_echo += '"heading":%s' % self.heading
        string_echo += ','
        string_echo += '"heading_unc":%s' % self.heading_unc
        string_echo += ','
        string_echo += '"fix_type":%s' % self.fix_type
        string_echo += ','
        string_echo += '"status_flags":'
        string_echo += self.status_flags.echo()
        string_echo += ','
        string_echo += '"valid_flags":%s' % self.valid_flags
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipFilterGnssDualAntennaStatus"

    def getMD5(self):
        return "ad9908a6aa0377a5e2b9ff2dd2b27ba5"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nfloat32 time_of_week\nfloat32 heading\nfloat32 heading_unc\nuint8 fix_type\nmicrostrain_inertial_msgs/MipFilterGnssDualAntennaStatusStatusFlags status_flags\nuint16 valid_flags\nuint8 FIX_TYPE_FIX_NONE     = 0\nuint8 FIX_TYPE_FIX_DA_FLOAT = 1\nuint8 FIX_TYPE_FIX_DA_FIXED = 2\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipFilterGnssDualAntennaStatusStatusFlags\nbool rcv_1_data_valid\nbool rcv_2_data_valid\nbool antenna_offsets_valid\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

