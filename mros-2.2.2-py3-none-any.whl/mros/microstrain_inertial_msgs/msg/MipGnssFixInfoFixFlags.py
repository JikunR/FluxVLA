import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssFixInfoFixFlags(mros.Message):
    __slots__ = ['sbas_used','dgnss_used']
    _slot_types = ['bool','bool']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssFixInfoFixFlags, self).__init__(*args, **kwds)
            if self.sbas_used is None:
                self.sbas_used = False
            if self.dgnss_used is None:
                self.dgnss_used = False
        else:
            self.sbas_used = False
            self.dgnss_used = False

    def serialize(self, buff):
        offset = 0
        try:
            struct_sbas_used = struct.Struct("<B")
            buff.write(struct_sbas_used.pack(self.sbas_used))
            offset += 1
            struct_dgnss_used = struct.Struct("<B")
            buff.write(struct_dgnss_used.pack(self.dgnss_used))
            offset += 1
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            struct_sbas_used = struct.Struct("<B")
            (self.sbas_used,) = struct_sbas_used.unpack(buff[offset:(offset + 1)])
            self.sbas_used = bool(self.sbas_used)
            offset += 1
            struct_dgnss_used = struct.Struct("<B")
            (self.dgnss_used,) = struct_dgnss_used.unpack(buff[offset:(offset + 1)])
            self.dgnss_used = bool(self.dgnss_used)
            offset += 1
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 1
        length += 1
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"sbas_used":%s' % self.sbas_used
        string_echo += ','
        string_echo += '"dgnss_used":%s' % self.dgnss_used
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssFixInfoFixFlags"

    def getMD5(self):
        return "200751727401aacbfb01ffdee0995730"

    def getDef(self):
        return "bool sbas_used\nbool dgnss_used\n"

_struct_I = struct.Struct('<I')

