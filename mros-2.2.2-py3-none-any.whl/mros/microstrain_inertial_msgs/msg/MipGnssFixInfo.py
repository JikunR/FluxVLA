import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipGnssFixInfo(mros.Message):
    __slots__ = ['header','fix_type','num_sv','fix_flags']
    _slot_types = ['microstrain_inertial_msgs/MipHeader','uint8','uint8','microstrain_inertial_msgs/MipGnssFixInfoFixFlags']

    FIX_TYPE_FIX_3D =  0
    FIX_TYPE_FIX_2D =  1
    FIX_TYPE_FIX_TIME_ONLY =  2
    FIX_TYPE_FIX_NONE =  3
    FIX_TYPE_FIX_INVALID =  4
    FIX_TYPE_FIX_RTK_FLOAT =  5
    FIX_TYPE_FIX_RTK_FIXED =  6

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipGnssFixInfo, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            if self.fix_type is None:
                self.fix_type = 0
            if self.num_sv is None:
                self.num_sv = 0
            if self.fix_flags is None:
                self.fix_flags = mros.microstrain_inertial_msgs.msg.MipGnssFixInfoFixFlags()
        else:
            self.header = mros.microstrain_inertial_msgs.msg.MipHeader()
            self.fix_type = 0
            self.num_sv = 0
            self.fix_flags = mros.microstrain_inertial_msgs.msg.MipGnssFixInfoFixFlags()

    def serialize(self, buff):
        offset = 0
        try:
            offset += self.header.serialize(buff)
            struct_fix_type = struct.Struct("<B")
            buff.write(struct_fix_type.pack(self.fix_type))
            offset += 1
            struct_num_sv = struct.Struct("<B")
            buff.write(struct_num_sv.pack(self.num_sv))
            offset += 1
            offset += self.fix_flags.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            offset += self.header.deserialize(buff[offset:])
            struct_fix_type = struct.Struct("<B")
            (self.fix_type,) = struct_fix_type.unpack(buff[offset:(offset + 1)])
            offset += 1
            struct_num_sv = struct.Struct("<B")
            (self.num_sv,) = struct_num_sv.unpack(buff[offset:(offset + 1)])
            offset += 1
            offset += self.fix_flags.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 1
        length += 1
        length += self.fix_flags.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"fix_type":%s' % self.fix_type
        string_echo += ','
        string_echo += '"num_sv":%s' % self.num_sv
        string_echo += ','
        string_echo += '"fix_flags":'
        string_echo += self.fix_flags.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipGnssFixInfo"

    def getMD5(self):
        return "44a681c5b6f5c8dfb7e7ae9261598b4b"

    def getDef(self):
        return "microstrain_inertial_msgs/MipHeader header\nuint8 fix_type\nuint8 num_sv\nmicrostrain_inertial_msgs/MipGnssFixInfoFixFlags fix_flags\nuint8 FIX_TYPE_FIX_3D        = 0\nuint8 FIX_TYPE_FIX_2D        = 1\nuint8 FIX_TYPE_FIX_TIME_ONLY = 2\nuint8 FIX_TYPE_FIX_NONE      = 3\nuint8 FIX_TYPE_FIX_INVALID   = 4\nuint8 FIX_TYPE_FIX_RTK_FLOAT = 5\nuint8 FIX_TYPE_FIX_RTK_FIXED = 6\n================================================================================\nMSG: microstrain_inertial_msgs/MipHeader\nstd_msgs/Header header\nuint8 event_source\nuint64 reference_timestamp\nmicrostrain_inertial_msgs/MipGpsTimestamp gps_timestamp\n================================================================================\nMSG: microstrain_inertial_msgs/MipGnssFixInfoFixFlags\nbool sbas_used\nbool dgnss_used\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: microstrain_inertial_msgs/MipGpsTimestamp\nfloat64 tow\nuint16 week_number\n"

_struct_I = struct.Struct('<I')

