import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class Mip3dmCaptureGyroBiasRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Mip3dmCaptureGyroBiasRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/Mip3dmCaptureGyroBias"

    def getMD5(self):
        return "c3544fdea5e4e5d21daeac4669eef238"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class Mip3dmCaptureGyroBiasResponse(mros.Message):
    __slots__ = ['__id__','bias']
    _slot_types = ['uint32','float32[3]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Mip3dmCaptureGyroBiasResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.bias is None:
                self.bias = [0. for x in range(0, 3)]
        else:
            self.__id__ = 0
            self.bias = [0. for x in range(0, 3)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            buff.write(struct.pack(f'<{3}f', *self.bias))
            offset += 3 * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            self.bias = np.frombuffer(buff[offset:offset + 3 * 4], dtype=np.float32)
            offset += 3 * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += 3 * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"bias":['
        for i in range(0, 3):
            if i == (3 - 1): 
                string_echo += '%s' % self.bias[i]
            else:
                string_echo += '%s,' % self.bias[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/Mip3dmCaptureGyroBias"

    def getMD5(self):
        return "c3544fdea5e4e5d21daeac4669eef238"
    def getDef(self):
        return "float32[3] bias\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class Mip3dmCaptureGyroBias(object):
    Request = Mip3dmCaptureGyroBiasRequest
    Response = Mip3dmCaptureGyroBiasResponse

    __slots__ = ['request','response']
    _slot_types = ['Mip3dmCaptureGyroBiasRequest','Mip3dmCaptureGyroBiasResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(Mip3dmCaptureGyroBias, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

