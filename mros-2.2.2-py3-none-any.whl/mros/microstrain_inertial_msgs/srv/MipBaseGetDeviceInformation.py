import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.microstrain_inertial_msgs.msg

class MipBaseGetDeviceInformationRequest(mros.Message):
    __slots__ = ['__id__']
    _slot_types = ['uint32']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipBaseGetDeviceInformationRequest, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
        else:
            self.__id__ = 0

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipBaseGetDeviceInformation"

    def getMD5(self):
        return "2c655b109370cba7cdc7620bb1869aa5"
    def getDef(self):
        return ""

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class MipBaseGetDeviceInformationResponse(mros.Message):
    __slots__ = ['__id__','device_info']
    _slot_types = ['uint32','microstrain_inertial_msgs/MipBaseDeviceInfo']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipBaseGetDeviceInformationResponse, self).__init__(*args, **kwds)
            if self.__id__ is None:
                self.__id__ = 0
            if self.device_info is None:
                self.device_info = mros.microstrain_inertial_msgs.msg.MipBaseDeviceInfo()
        else:
            self.__id__ = 0
            self.device_info = mros.microstrain_inertial_msgs.msg.MipBaseDeviceInfo()

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(_struct_I.pack(self.__id__))
            offset += 4
            offset += self.device_info.serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            (self.__id__,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            offset += self.device_info.deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += 4
        length += self.device_info.serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"__id__":%s' % self.__id__
        string_echo += ','
        string_echo += '"device_info":'
        string_echo += self.device_info.echo()
        string_echo += ''
        string_echo += '}'
        return string_echo

    def getType(self):
        return "microstrain_inertial_msgs/MipBaseGetDeviceInformation"

    def getMD5(self):
        return "2c655b109370cba7cdc7620bb1869aa5"
    def getDef(self):
        return "microstrain_inertial_msgs/MipBaseDeviceInfo device_info\n================================================================================\nMSG: microstrain_inertial_msgs/MipBaseDeviceInfo\nstring firmware_version\nstring model_name\nstring model_number\nstring serial_number\nstring lot_number\nstring device_options\n"

    def getID(self):
        return self.__id__

    def setID(self, id):
        self.__id__ = id

class MipBaseGetDeviceInformation(object):
    Request = MipBaseGetDeviceInformationRequest
    Response = MipBaseGetDeviceInformationResponse

    __slots__ = ['request','response']
    _slot_types = ['MipBaseGetDeviceInformationRequest','MipBaseGetDeviceInformationResponse']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(MipBaseGetDeviceInformation, self).__init__(*args, **kwds)
            if self.request is None:
                self.request = None
            if self.response is None:
                self.response = None
        else:
            self.request = None
            self.response = None

_struct_I = struct.Struct('<I')

