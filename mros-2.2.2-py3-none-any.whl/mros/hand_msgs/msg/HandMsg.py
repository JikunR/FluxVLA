import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.hand_msgs.msg
import mros.std_msgs.msg

class HandMsg(mros.Message):
    __slots__ = ['header','names','pos','vel','current','time']
    _slot_types = ['std_msgs/Header','string[]','float32[]','float32[]','float32[]','float32[]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HandMsg, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.names is None:
                self.names = []
            if self.pos is None:
                self.pos = []
            if self.vel is None:
                self.vel = []
            if self.current is None:
                self.current = []
            if self.time is None:
                self.time = []
        else:
            self.header = mros.std_msgs.msg.Header()
            self.names = []
            self.pos = []
            self.vel = []
            self.current = []
            self.time = []

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            names_length = len(self.names)
            buff.write(struct.pack('<I', names_length))
            offset += 4
            for i in range(0, names_length):
                _x = self.names[i]
                length = len(_x)
                if python3 or type(_x) == unicode:
                    _x = _x.encode('utf-8')
                    length = len(_x)
                if python3:
                    buff.write(struct.pack('<I%sB'%length, length, *_x))
                else:
                    buff.write(struct.pack('<I%ss'%length, length, _x))
                offset += 4
                offset += length
            pos_length = len(self.pos)
            buff.write(struct.pack('<I', pos_length))
            buff.write(struct.pack(f'<{pos_length}f', *self.pos))
            offset += 4 + pos_length * 4
            vel_length = len(self.vel)
            buff.write(struct.pack('<I', vel_length))
            buff.write(struct.pack(f'<{vel_length}f', *self.vel))
            offset += 4 + vel_length * 4
            current_length = len(self.current)
            buff.write(struct.pack('<I', current_length))
            buff.write(struct.pack(f'<{current_length}f', *self.current))
            offset += 4 + current_length * 4
            time_length = len(self.time)
            buff.write(struct.pack('<I', time_length))
            buff.write(struct.pack(f'<{time_length}f', *self.time))
            offset += 4 + time_length * 4
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (names_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            if len(self.names) != names_length:
                self.names = ['' for _ in range(names_length)]
            for i in range(0, names_length):
                (length_namesi,) = _struct_I.unpack(buff[offset:(offset + 4)])
                offset += 4
                if python3:
                    self.names[i] = buff[offset:(offset + length_namesi)].decode('utf-8')
                else:
                    self.names[i] = buff[offset:(offset + length_namesi)]
                offset += length_namesi
            (pos_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.pos = np.frombuffer(buff[offset:offset + pos_length * 4], dtype=np.float32)
            offset += pos_length * 4
            (vel_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.vel = np.frombuffer(buff[offset:offset + vel_length * 4], dtype=np.float32)
            offset += vel_length * 4
            (current_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.current = np.frombuffer(buff[offset:offset + current_length * 4], dtype=np.float32)
            offset += current_length * 4
            (time_length,) = struct.unpack_from('<I', buff, offset)
            offset += 4
            self.time = np.frombuffer(buff[offset:offset + time_length * 4], dtype=np.float32)
            offset += time_length * 4
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        length += 4
        for i in range(0, names_length):
            namesi_x = self.names[i]
            namesi_length = len(namesi_x)
            if python3 or type(namesi_x) == unicode:
                namesi_x = namesi_x.encode('utf-8')
                namesi_length = len(namesi_x)
            length += 4
            length += namesi_length
        length += 4
        length += len(self.pos) * 4
        length += 4
        length += len(self.vel) * 4
        length += 4
        length += len(self.current) * 4
        length += 4
        length += len(self.time) * 4
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"names":['
        names_length = len(self.names)
        for i in range(0, names_length):
            if i == (names_length - 1): 
                string_echo += '"names[i]":"%s"' % self.names[i]
                string_echo += ''
            else:
                string_echo += '"names[i]":"%s"' % self.names[i]
                string_echo += ','
        string_echo += '],'
        string_echo += '"pos":['
        pos_length = len(self.pos)
        for i in range(0, pos_length):
            if i == (pos_length - 1): 
                string_echo += '%s' % self.pos[i]
            else:
                string_echo += '%s,' % self.pos[i]
        string_echo += '],'
        string_echo += '"vel":['
        vel_length = len(self.vel)
        for i in range(0, vel_length):
            if i == (vel_length - 1): 
                string_echo += '%s' % self.vel[i]
            else:
                string_echo += '%s,' % self.vel[i]
        string_echo += '],'
        string_echo += '"current":['
        current_length = len(self.current)
        for i in range(0, current_length):
            if i == (current_length - 1): 
                string_echo += '%s' % self.current[i]
            else:
                string_echo += '%s,' % self.current[i]
        string_echo += '],'
        string_echo += '"time":['
        time_length = len(self.time)
        for i in range(0, time_length):
            if i == (time_length - 1): 
                string_echo += '%s' % self.time[i]
            else:
                string_echo += '%s,' % self.time[i]
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "hand_msgs/HandMsg"

    def getMD5(self):
        return "5bf399d0b94663b56e927d0e9c254c1c"

    def getDef(self):
        return "std_msgs/Header header\nstring[] names\nfloat32[] pos\nfloat32[] vel\nfloat32[] current\nfloat32[] time\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n"

_struct_I = struct.Struct('<I')

