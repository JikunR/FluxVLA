import sys
python3 = True if sys.hexversion > 0x03000000 else False
import struct
import numpy as np
import mros
import mros.hand_msgs.msg
import mros.std_msgs.msg

class HandState(mros.Message):
    __slots__ = ['header','hand_type','ctrl_mode','hand_state']
    _slot_types = ['std_msgs/Header','string','uint8[2]','mros.hand_msgs.msg.HandMsg[2]']

    def __init__(self, *args, **kwds):
        if args or kwds:
            super(HandState, self).__init__(*args, **kwds)
            if self.header is None:
                self.header = mros.std_msgs.msg.Header()
            if self.hand_type is None:
                self.hand_type = ''
            if self.ctrl_mode is None:
                self.ctrl_mode = chr(0)*2
            if self.hand_state is None:
                self.hand_state = [mros.hand_msgs.msg.HandMsg() for x in range(0, 2)]
        else:
            self.header = mros.std_msgs.msg.Header()
            self.hand_type = ''
            self.ctrl_mode = chr(0)*2
            self.hand_state = [mros.hand_msgs.msg.HandMsg() for x in range(0, 2)]

    def serialize(self, buff):
        offset = 0
        try:
            buff.write(struct.pack('<III', self.header.seq, self.header.stamp.sec, self.header.stamp.nsec))
            offset += 4 * 3
            _x = self.header.frame_id
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4 + length
            _x = self.hand_type
            length = len(_x)
            if python3 or type(_x) == unicode:
                _x = _x.encode('utf-8')
                length = len(_x)
            if python3:
                buff.write(struct.pack('<I%sB'%length, length, *_x))
            else:
                buff.write(struct.pack('<I%ss'%length, length, _x))
            offset += 4
            offset += length
            buff.write(struct.pack(f'<{2}B', *self.ctrl_mode))
            offset += 2
            for i in range(0, 2):
                offset += self.hand_state[i].serialize(buff)
        except Exception as e:
            print('Unable to serialize message: %s' % str(e))
        return offset

    def deserialize(self, buff):
        offset = 0
        try:
            self.header.seq, self.header.stamp.sec, self.header.stamp.nsec, length_frame_id = struct.unpack_from('<IIII', buff, offset)
            offset += 4 * 4
            if python3:
                self.header.frame_id = buff[offset:(offset + length_frame_id)].decode('utf-8')
            else:
                self.header.frame_id = buff[offset:(offset + length_frame_id)]
            offset += length_frame_id
            (length_hand_type,) = _struct_I.unpack(buff[offset:(offset + 4)])
            offset += 4
            if python3:
                self.hand_type = buff[offset:(offset + length_hand_type)].decode('utf-8')
            else:
                self.hand_type = buff[offset:(offset + length_hand_type)]
            offset += length_hand_type
            self.ctrl_mode = np.frombuffer(buff[offset:offset + 2], dtype=np.uint8)
            offset += 2
            for i in range(0, 2):
                offset += self.hand_state[i].deserialize(buff[offset:])
        except Exception as e:
            print('Unable to deserialize message: %s' % str(e))
        return offset

    def serializedLength(self):
        length = 0
        length += self.header.serializedLength()
        hand_type_x = self.hand_type
        hand_type_length = len(hand_type_x)
        if python3 or type(hand_type_x) == unicode:
            hand_type_x = hand_type_x.encode('utf-8')
            hand_type_length = len(hand_type_x)
        length += 4
        length += hand_type_length
        length += 2
        for i in range(0, 2):
            length += self.hand_state[i].serializedLength()
        return length

    def echo(self):
        string_echo = '{'
        string_echo += '"header":'
        string_echo += self.header.echo()
        string_echo += ','
        string_echo += '"hand_type":"%s"' % self.hand_type
        string_echo += ','
        string_echo += '"ctrl_mode":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '%s' % self.ctrl_mode[i]
            else:
                string_echo += '%s,' % self.ctrl_mode[i]
        string_echo += '],'
        string_echo += '"hand_state":['
        for i in range(0, 2):
            if i == (2 - 1): 
                string_echo += '{hand_state%s":' % i
                string_echo += self.hand_state[i].echo()
                string_echo += ''
            else:
                string_echo += '{hand_state%s":' % i
                string_echo += self.hand_state[i].echo()
                string_echo += ','
        string_echo += ']'
        string_echo += '}'
        return string_echo

    def getType(self):
        return "hand_msgs/HandState"

    def getMD5(self):
        return "0e859982707a5c9b2e1da5a16bffb891"

    def getDef(self):
        return "std_msgs/Header header\nstring hand_type\nuint8[2] ctrl_mode\nhand_msgs/HandMsg[2] hand_state\n================================================================================\nMSG: std_msgs/Header\nuint32 seq\ntime stamp\nstring frame_id\n================================================================================\nMSG: hand_msgs/HandMsg\nstd_msgs/Header header\nstring[] names\nfloat32[] pos\nfloat32[] vel\nfloat32[] current\nfloat32[] time\n"

_struct_I = struct.Struct('<I')

